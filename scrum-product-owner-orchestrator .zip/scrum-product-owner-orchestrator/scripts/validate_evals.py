#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate trigger, output, pressure, and tool evals.")
    parser.add_argument("skill_dir", type=Path)
    args = parser.parse_args()
    eval_dir = args.skill_dir / "evals"
    errors: list[str] = []
    try:
        triggers = load_json(eval_dir / "trigger_queries.json")
        if len(triggers.get("should_trigger", [])) < 8:
            errors.append("need at least 8 should_trigger queries")
        if len(triggers.get("should_not_trigger", [])) < 8:
            errors.append("need at least 8 should_not_trigger queries")
        outputs = load_json(eval_dir / "output_evals.json")
        if not isinstance(outputs.get("evals"), list) or len(outputs["evals"]) < 8:
            errors.append("need at least 8 output evals")
        for item in outputs.get("evals", []):
            if not all(key in item for key in ("id", "prompt", "assertions")):
                errors.append(f"output eval missing fields: {item}")
        pressures = load_json(eval_dir / "pressure_evals.json")
        if not isinstance(pressures.get("evals"), list) or len(pressures["evals"]) < 5:
            errors.append("need at least 5 pressure evals")
        tree = ET.parse(eval_dir / "tool_evals.xml")
        root = tree.getroot()
        if root.tag != "evaluation" or len(root.findall("qa_pair")) < 5:
            errors.append("tool_evals.xml needs evaluation root and at least 5 qa_pair nodes")
    except Exception as exc:
        errors.append(str(exc))
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print("evals: valid")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
