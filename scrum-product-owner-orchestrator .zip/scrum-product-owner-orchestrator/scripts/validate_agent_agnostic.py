#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate agent-agnostic compatibility notes and report.")
    parser.add_argument("skill_dir", type=Path)
    args = parser.parse_args()
    ref = args.skill_dir / "references" / "agent-agnostic-compatibility.md"
    report_path = args.skill_dir / "reports" / "agent-compatibility-report.json"
    errors: list[str] = []
    if not ref.is_file():
        errors.append("compatibility reference missing")
    try:
        report = json.loads(report_path.read_text(encoding="utf-8"))
        if report.get("semantic_portability") != "supported":
            errors.append("semantic_portability must be supported")
        if not report.get("runtime_differences"):
            errors.append("runtime differences must be documented")
    except Exception as exc:
        errors.append(str(exc))
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print("agent compatibility: valid")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
