#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

REQUIRED_FUNCTIONS = {
    "project_discovery",
    "sprint_planning",
    "value_centered_selection",
    "jira_ticket_authoring",
    "jira_ticket_updates",
    "github_daily_change_review",
    "github_jira_reconciliation",
    "project_overview",
}


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate preservation of requested core functionality.")
    parser.add_argument("skill_dir", type=Path)
    args = parser.parse_args()
    try:
        data = json.loads((args.skill_dir / "reports" / "core-functionality-preservation.json").read_text(encoding="utf-8"))
        preserved = set(data.get("preserved_core_functions", []))
        missing = REQUIRED_FUNCTIONS - preserved
        if missing:
            raise ValueError(f"missing core functions: {sorted(missing)}")
        if data.get("unintended_breaking_changes"):
            raise ValueError("unintended breaking changes present")
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    print("core functionality: preserved")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
