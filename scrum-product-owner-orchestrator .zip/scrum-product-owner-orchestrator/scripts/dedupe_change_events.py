#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def event_key(event: dict) -> tuple:
    return (
        event.get("repository"),
        event.get("commit_sha"),
        event.get("pull_request"),
        event.get("path"),
        event.get("event_type"),
    )


def dedupe(events: list[dict]) -> list[dict]:
    result: list[dict] = []
    seen: set[tuple] = set()
    for event in events:
        key = event_key(event)
        if key in seen:
            continue
        seen.add(key)
        result.append(event)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Deduplicate GitHub change events.")
    parser.add_argument("path", nargs="?", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        sample = [{"repository": "a/b", "commit_sha": "1", "path": "x"}] * 2
        if len(dedupe(sample)) != 1:
            print("self-test failed", file=sys.stderr)
            return 1
        print("dedupe_change_events: self-test passed")
        return 0
    raw = args.path.read_text(encoding="utf-8") if args.path else sys.stdin.read()
    data = json.loads(raw)
    if not isinstance(data, list) or not all(isinstance(x, dict) for x in data):
        print("ERROR: input must be a JSON array of objects", file=sys.stderr)
        return 1
    print(json.dumps(dedupe(data), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
