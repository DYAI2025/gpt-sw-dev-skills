#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

DEFAULT_PATTERN = r"\b[A-Z][A-Z0-9_]+-\d+\b"


def extract(texts: list[str], patterns: list[str]) -> list[str]:
    found: set[str] = set()
    for pattern in patterns:
        compiled = re.compile(pattern, re.IGNORECASE)
        for text in texts:
            for match in compiled.findall(text or ""):
                value = match[0] if isinstance(match, tuple) else match
                found.add(str(value).upper())
    return sorted(found)


def main() -> int:
    parser = argparse.ArgumentParser(description="Extract unique Jira keys from text or JSON input.")
    parser.add_argument("text", nargs="*", help="Text fragments. If omitted, stdin is read.")
    parser.add_argument("--pattern", action="append", default=[], help="Regex pattern; repeatable.")
    parser.add_argument("--json-file", type=Path, help="Read strings recursively from a JSON file.")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()

    if args.self_test:
        result = extract(["EX-12 branch", "fix ex-12 and API_2-9"], [DEFAULT_PATTERN])
        expected = ["API_2-9", "EX-12"]
        if result != expected:
            print(f"self-test failed: {result}", file=sys.stderr)
            return 1
        print("extract_jira_keys: self-test passed")
        return 0

    texts = list(args.text)
    if args.json_file:
        data = json.loads(args.json_file.read_text(encoding="utf-8"))
        def walk(value):
            if isinstance(value, str):
                texts.append(value)
            elif isinstance(value, list):
                for item in value:
                    walk(item)
            elif isinstance(value, dict):
                for item in value.values():
                    walk(item)
        walk(data)
    if not texts and not sys.stdin.isatty():
        texts.append(sys.stdin.read())
    print(json.dumps(extract(texts, args.pattern or [DEFAULT_PATTERN]), ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
