#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate source map presence and structure.")
    parser.add_argument("skill_dir", type=Path)
    args = parser.parse_args()
    path = args.skill_dir / "references" / "source-map.md"
    if not path.is_file():
        print("ERROR: references/source-map.md missing", file=sys.stderr)
        return 1
    text = path.read_text(encoding="utf-8")
    required = ["# Source Map", "Confidence", "Laufzeit-MISSING"]
    missing = [item for item in required if item not in text]
    if missing:
        print(f"ERROR: source map missing sections: {missing}", file=sys.stderr)
        return 1
    rows = [line for line in text.splitlines() if re.match(r"\| S\d{3} \|", line)]
    if len(rows) < 5:
        print("ERROR: source map needs at least five classified sources", file=sys.stderr)
        return 1
    if "https://" not in text:
        print("ERROR: source map has no primary-source URLs", file=sys.stderr)
        return 1
    print("source map: valid")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
