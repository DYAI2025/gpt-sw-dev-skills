#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

DIMENSIONS = (
    "product_goal_contribution",
    "user_value",
    "learning_risk_reduction",
    "time_criticality",
    "dependency_multiplier",
    "operational_quality_value",
    "evidence_strength",
)


def score_item(item: dict, weights: dict[str, float]) -> dict:
    scores = item.get("scores", {})
    for dimension in DIMENSIONS:
        value = scores.get(dimension)
        if not isinstance(value, (int, float)) or not 0 <= value <= 5:
            raise ValueError(f"{item.get('issueKey', '?')}: invalid score for {dimension}")
    readiness_factor = float(item.get("readinessFactor", 1.0))
    confidence_factor = float(item.get("confidenceFactor", 1.0))
    if not 0 <= readiness_factor <= 1 or not 0 <= confidence_factor <= 1:
        raise ValueError("readinessFactor and confidenceFactor must be between 0 and 1")
    raw = sum(float(scores[d]) * float(weights[d]) for d in DIMENSIONS)
    adjusted = raw * readiness_factor * confidence_factor
    result = dict(item)
    result["rawValue"] = round(raw, 4)
    result["adjustedValue"] = round(adjusted, 4)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Score sprint candidate items; does not replace Developers capacity confirmation.")
    parser.add_argument("input", nargs="?", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        weights = {d: 1 / len(DIMENSIONS) for d in DIMENSIONS}
        item = {"issueKey": "EX-1", "scores": {d: 5 for d in DIMENSIONS}, "readinessFactor": 1, "confidenceFactor": 1}
        result = score_item(item, weights)
        if abs(result["adjustedValue"] - 5.0) > 1e-6:
            print("self-test failed", file=sys.stderr)
            return 1
        print("score_sprint_candidates: self-test passed")
        return 0
    raw = args.input.read_text(encoding="utf-8") if args.input else sys.stdin.read()
    data = json.loads(raw)
    weights = data.get("weights")
    items = data.get("items")
    if not isinstance(weights, dict) or not isinstance(items, list):
        print("ERROR: input requires weights object and items array", file=sys.stderr)
        return 1
    if set(DIMENSIONS) - set(weights):
        print("ERROR: missing weights", file=sys.stderr)
        return 1
    total = sum(float(weights[d]) for d in DIMENSIONS)
    if abs(total - 1.0) > 1e-9:
        print(f"ERROR: weights must sum to 1.0, got {total}", file=sys.stderr)
        return 1
    try:
        scored = [score_item(item, weights) for item in items]
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    scored.sort(key=lambda x: (-x["adjustedValue"], x.get("issueKey", "")))
    print(json.dumps({"warning": "ranking is advisory; optimize coherent sets and confirm capacity with Developers", "items": scored}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
