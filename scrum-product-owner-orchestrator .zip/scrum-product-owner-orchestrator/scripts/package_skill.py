#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
import zipfile
from pathlib import Path

EXCLUDE_PARTS = {"__pycache__", ".git", ".DS_Store"}


def should_include(path: Path) -> bool:
    if any(part in EXCLUDE_PARTS for part in path.parts):
        return False
    if path.suffix in {".pyc", ".pyo"}:
        return False
    if path.name == "skill.zip":
        return False
    return path.is_file()


def main() -> int:
    parser = argparse.ArgumentParser(description="Package one validated skill directory as skill.zip.")
    parser.add_argument("skill_dir", type=Path)
    parser.add_argument("dist_dir", nargs="?", type=Path, default=Path("./dist"))
    args = parser.parse_args()
    skill_dir = args.skill_dir.resolve()
    if not (skill_dir / "SKILL.md").is_file():
        print("ERROR: SKILL.md missing", file=sys.stderr)
        return 1
    args.dist_dir.mkdir(parents=True, exist_ok=True)
    output = args.dist_dir / "skill.zip"
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(skill_dir.rglob("*")):
            if should_include(path):
                arcname = Path(skill_dir.name) / path.relative_to(skill_dir)
                info = zipfile.ZipInfo(str(arcname).replace("\\", "/"), date_time=(2026, 7, 23, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o644 << 16
                zf.writestr(info, path.read_bytes())
    print(output.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
