#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate ChatGPT skill package readiness controlled by this package.")
    parser.add_argument("skill_dir", type=Path)
    args = parser.parse_args()
    required = [args.skill_dir / "SKILL.md", args.skill_dir / "agents" / "openai.yaml"]
    missing = [str(path.relative_to(args.skill_dir)) for path in required if not path.is_file()]
    try:
        report = json.loads((args.skill_dir / "reports" / "installability-report.json").read_text(encoding="utf-8"))
        if report.get("artifact_name") != "skill.zip":
            missing.append("installability artifact_name must be skill.zip")
        if report.get("frontend_install_suggestion_status") not in {"prepared", "blocked", "not_controlled_by_skill"}:
            missing.append("invalid frontend_install_suggestion_status")
        if report.get("frontend_install_suggestion_status") == "guaranteed":
            missing.append("frontend installation may not be guaranteed")
        if report.get("blocking_issues"):
            missing.append("installability report has blocking issues")
    except Exception as exc:
        missing.append(str(exc))
    if missing:
        for item in missing:
            print(f"ERROR: {item}", file=sys.stderr)
        return 1
    print("installability: prepared")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
