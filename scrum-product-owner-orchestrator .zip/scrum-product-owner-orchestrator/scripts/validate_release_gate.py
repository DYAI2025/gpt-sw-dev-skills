#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate enterprise release gate report.")
    parser.add_argument("skill_dir", type=Path)
    args = parser.parse_args()
    path = args.skill_dir / "reports" / "release-gate-report.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        gate = data["release_gate"]
        anti = data["anti_confabulation_gate"]
        syc = data["anti_sycophancy"]
        bias = data["bias_gate"]
        conditions = [
            gate.get("status") == "PASS",
            gate.get("allowed_to_package") is True,
            data["craftsmanship_gate"].get("status") == "PASS",
            anti.get("status") == "PASS",
            not anti.get("blocked_claims"),
            syc.get("score", 99) < syc.get("threshold", 0),
            bias.get("status") == "PASS",
        ]
        if not all(conditions):
            raise ValueError("release gate is not PASS")
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    print("release gate: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
