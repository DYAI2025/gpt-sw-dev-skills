#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import py_compile
import re
import subprocess
import sys
import zipfile
from pathlib import Path

NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
REQUIRED = [
    "SKILL.md",
    "agents/openai.yaml",
    "references/source-policy.md",
    "references/source-map.md",
    "references/security-and-tools.md",
    "references/eval-design.md",
    "evals/trigger_queries.json",
    "evals/output_evals.json",
    "reports/release-gate-report.json",
    "reports/installability-report.json",
    "reports/core-functionality-preservation.json",
]


def parse_frontmatter(text: str) -> dict[str, str]:
    if not text.startswith("---\n"):
        raise ValueError("SKILL.md must start with YAML frontmatter")
    end = text.find("\n---\n", 4)
    if end < 0:
        raise ValueError("frontmatter closing delimiter missing")
    result: dict[str, str] = {}
    for line in text[4:end].splitlines():
        if not line.strip():
            continue
        if ":" not in line:
            raise ValueError(f"invalid frontmatter line: {line}")
        key, value = line.split(":", 1)
        result[key.strip()] = value.strip().strip('"').strip("'")
    return result


def run(script: Path, *args: str) -> None:
    subprocess.run([sys.executable, str(script), *args], check=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate the Scrum Product Owner skill package.")
    parser.add_argument("skill_dir", type=Path)
    args = parser.parse_args()
    root = args.skill_dir.resolve()
    errors: list[str] = []
    for rel in REQUIRED:
        if not (root / rel).is_file():
            errors.append(f"missing {rel}")
    try:
        meta = parse_frontmatter((root / "SKILL.md").read_text(encoding="utf-8"))
        if set(meta) != {"name", "description"}:
            errors.append("frontmatter must contain only name and description")
        name = meta.get("name", "")
        if not NAME_RE.fullmatch(name):
            errors.append("invalid skill name")
        if name != root.name:
            errors.append("skill name must match directory name")
        description = meta.get("description", "")
        if not description or "<" in description or ">" in description:
            errors.append("description missing or contains angle brackets")
        if len(description) > 1024:
            errors.append("description exceeds 1024 characters")
    except Exception as exc:
        errors.append(str(exc))
    for path in root.rglob("*.json"):
        try:
            json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            errors.append(f"invalid JSON {path.relative_to(root)}: {exc}")
    for path in root.rglob("*.py"):
        try:
            py_compile.compile(str(path), doraise=True)
        except Exception as exc:
            errors.append(f"invalid Python {path.relative_to(root)}: {exc}")
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    scripts = root / "scripts"
    try:
        run(scripts / "validate_project_context.py", str(root / "assets" / "project-context.example.json"))
        run(scripts / "extract_jira_keys.py", "--self-test")
        run(scripts / "dedupe_change_events.py", "--self-test")
        run(scripts / "score_sprint_candidates.py", "--self-test")
        for script in (
            "validate_source_map.py",
            "validate_evals.py",
            "validate_release_gate.py",
            "validate_installability.py",
            "validate_agent_agnostic.py",
            "validate_core_parity.py",
        ):
            run(scripts / script, str(root))
    except subprocess.CalledProcessError as exc:
        print(f"ERROR: validator failed with code {exc.returncode}", file=sys.stderr)
        return 1
    print("quick validation: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
