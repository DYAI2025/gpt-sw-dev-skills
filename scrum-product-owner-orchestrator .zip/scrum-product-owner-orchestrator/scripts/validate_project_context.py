#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from zoneinfo import ZoneInfo

REQUIRED_WEIGHTS = {
    "product_goal_contribution",
    "user_value",
    "learning_risk_reduction",
    "time_criticality",
    "dependency_multiplier",
    "operational_quality_value",
    "evidence_strength",
}


def fail(message: str) -> None:
    raise ValueError(message)


def validate(data: dict) -> list[str]:
    errors: list[str] = []
    try:
        if not isinstance(data.get("version"), int) or data["version"] < 1:
            fail("version must be an integer >= 1")
        project = data["project"]
        for key in ("id", "name", "timezone", "product_goal"):
            if not isinstance(project.get(key), str) or not project[key].strip():
                fail(f"project.{key} must be a non-empty string")
        ZoneInfo(project["timezone"])

        jira = data["jira"]
        for key in ("cloud_id", "project_key"):
            if not isinstance(jira.get(key), str) or not jira[key].strip():
                fail(f"jira.{key} must be a non-empty string")
        if not re.fullmatch(r"[A-Z][A-Z0-9_]+", jira["project_key"]):
            fail("jira.project_key must be uppercase Jira-key syntax")
        if not isinstance(jira.get("issue_types"), dict) or not jira["issue_types"]:
            fail("jira.issue_types must be a non-empty object")
        if not isinstance(jira.get("jql", {}).get("candidate_backlog"), str):
            fail("jira.jql.candidate_backlog is required")
        if not isinstance(jira.get("write_policy"), dict):
            fail("jira.write_policy must be an object")

        github = data["github"]
        repos = github.get("repositories")
        if not isinstance(repos, list) or not repos:
            fail("github.repositories must be a non-empty array")
        for repo in repos:
            if not isinstance(repo, str) or repo.count("/") != 1:
                fail(f"invalid GitHub repository: {repo!r}")
        if not isinstance(github.get("default_branch"), str) or not github["default_branch"]:
            fail("github.default_branch is required")
        patterns = github.get("jira_key_patterns")
        if not isinstance(patterns, list) or not patterns:
            fail("github.jira_key_patterns must be a non-empty array")
        for pattern in patterns:
            re.compile(pattern)
        if not isinstance(github.get("audit_scope"), dict):
            fail("github.audit_scope must be an object")
        if not isinstance(github.get("write_policy"), dict):
            fail("github.write_policy must be an object")

        scrum = data["scrum"]
        days = scrum.get("sprint_length_days")
        if not isinstance(days, int) or not 1 <= days <= 31:
            fail("scrum.sprint_length_days must be between 1 and 31")
        dod = scrum.get("definition_of_done")
        if not isinstance(dod, list) or not dod or not all(isinstance(x, str) and x.strip() for x in dod):
            fail("scrum.definition_of_done must be a non-empty string array")
        if not isinstance(scrum.get("capacity_source"), str) or not scrum["capacity_source"]:
            fail("scrum.capacity_source is required")
        for key in ("require_developer_sizing", "require_sprint_goal"):
            if not isinstance(scrum.get(key), bool):
                fail(f"scrum.{key} must be boolean")

        weights = data["value_model"]["weights"]
        missing = REQUIRED_WEIGHTS - set(weights)
        if missing:
            fail(f"missing value weights: {sorted(missing)}")
        total = sum(float(weights[k]) for k in REQUIRED_WEIGHTS)
        if abs(total - 1.0) > 1e-9:
            fail(f"value weights must sum to 1.0, got {total}")
        if any(float(weights[k]) < 0 for k in REQUIRED_WEIGHTS):
            fail("value weights must be non-negative")
    except (KeyError, TypeError, ValueError, re.error) as exc:
        errors.append(str(exc))
    except Exception as exc:
        errors.append(f"unexpected validation error: {exc}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate Scrum Product Owner project context JSON.")
    parser.add_argument("path", type=Path)
    args = parser.parse_args()
    try:
        data = json.loads(args.path.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"ERROR: cannot read JSON: {exc}", file=sys.stderr)
        return 1
    errors = validate(data)
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print("project context: valid")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
