# Sprintplanungs-Workflow

## Phase 1: Ziel und Evidenz

- Product Goal und aktuelle Outcome-Signale lesen.
- Ergebnis des letzten Sprints, offene Incidents, Supportsignale und Nutzerforschung berücksichtigen.
- Veraltete oder rein politische Priorität nicht ungeprüft übernehmen.

## Phase 2: Kandidatenqualität

Für jedes Jira-Item prüfen:

- erwartetes Ergebnis;
- Akzeptanzkriterien;
- Abhängigkeiten und Blocker;
- Größe/Estimate und Unsicherheit;
- Definition-of-Done-Erreichbarkeit;
- GitHub-Evidenz zu bereits vorhandener oder fehlender Implementierung;
- Doppelte oder überholte Tickets.

## Phase 3: Setbildung

1. Gruppiere Items nach Nutzenhypothese, Nutzerreise oder technischem Enabler.
2. Bilde mehrere kleine Kandidatensets.
3. Bewerte Wert, Kohärenz, Risiko, Abhängigkeiten und Fragmentierung.
4. Verwerfe Sets ohne klaren Increment-Pfad.
5. Erzeuge bis zu drei Sprint-Goal-Optionen.
6. Empfehle ein Set, nenne aber ausgeschlossene Alternativen und Trade-offs.

## Phase 4: Developers-Gate

Fordere Bestätigung für:

- verfügbare Kapazität;
- Größen/Estimates;
- technische Umsetzbarkeit;
- notwendige Reihenfolge;
- Support-/Betriebsreserve;
- Fähigkeit, die Definition of Done zu erfüllen.

Ohne Bestätigung bleibt `approvalStatus = proposal` und `capacityGate.status = pending_developer_confirmation`.

## Phase 5: Jira-Anwendung

Nach Freigabe und im `APPLY`-Modus:

- fehlende Felder oder Akzeptanzkriterien ergänzen;
- Sprintzuordnung nur mit vorhandener Capability durchführen;
- Status nicht pauschal auf In Progress setzen; ausgewählt bedeutet nicht begonnen;
- Sprint Goal, Entscheidung und Ausnahmen dokumentieren;
- Zielzustand erneut lesen.

## Outputschema

Verwende `schemas/sprint-candidate.schema.json` für maschinenlesbare Ergebnisse. Der menschenlesbare Report muss dieselben Entscheidungen erklären.
