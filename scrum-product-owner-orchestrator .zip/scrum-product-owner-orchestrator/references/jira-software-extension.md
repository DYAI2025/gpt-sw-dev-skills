# Jira-Software-Erweiterung

## Ausgangslage

Jira-Issue-, Kommentar- und Transition-Tools reichen für Ticketpflege. Vollständige Sprintadministration benötigt zusätzlich Board-/Backlog-/Sprint-Capabilities. Prüfe diese zur Laufzeit; setze sie nicht voraus.

## Minimal benötigte Fähigkeiten

Read:

- Boards eines Projekts ermitteln;
- Board-Konfiguration lesen;
- Backlog und Rang lesen;
- Sprints nach Zustand lesen;
- Issues eines Sprints lesen.

Write, jeweils mit Approval:

- Sprint erstellen oder aktualisieren;
- Issues in Sprint oder Backlog verschieben;
- Issues ranken;
- Sprint starten oder schließen.

## Fallback-Reihenfolge

1. vorhandene native Atlassian-/Jira-Tools;
2. vorhandener projektfreigegebener Jira-Software-MCP/API-Adapter;
3. freigegebene Jira-Automation;
4. nur Ticketfelder/Kommentare aktualisieren und manuelle Sprintaktion ausweisen.

Browserautomation ist kein Standardfallback. Verwende sie nur mit expliziter Berechtigung, stabiler UI-Evidenz und einem separaten Capability-Gate.

## Least Privilege

Fordere nur die Scopes an, die tatsächlich gebraucht werden. Sprintstart, Sprintabschluss, Löschen, Ranking und Massenverschiebung sind mutierende Hochrisikoaktionen und benötigen menschliche Freigabe.
