# Evaluationsdesign

## Trigger-Evals

`evals/trigger_queries.json` enthält positive und negative Trigger. Der Skill soll bei konkreter Sprintplanung, Jira-/GitHub-Abgleich und Product-Owner-Backlogarbeit triggern, nicht bei allgemeinen Scrum- oder Codefragen.

## Output-Evals

`evals/output_evals.json` prüft:

- Korrektur der Annahme, der Product Owner lege allein den Sprint Backlog fest;
- Sprint Goal mit Nutzenhypothese und Erfolgsevidenz;
- kohärentes Set statt reiner Einzelrangliste;
- Ausschluss untestbarer/blockierter Items;
- Developers-/Kapazitätsgate;
- Jira-Key-Disziplin;
- Done-Gate und read-after-write.

## Pressure-Evals

`evals/pressure_evals.json` testet Zeitdruck, Autoritätsdruck, Sunk Cost, fehlende Transition-IDs, grüne CI bei unerfüllter Akzeptanz und den Wunsch, alle Commits als Done zu markieren.

## Tool-Evals

`evals/tool_evals.xml` ist für ein festes, isoliertes Fixture-Projekt vorgesehen. Read-only-Evals sind unabhängig, idempotent und erwarten einen einzelnen stabilen Wert. Mutationsevals dürfen nur gegen ein Testprojekt laufen und müssen Approval, Verifikation und Fehlerstopp prüfen.

## Release-Kriterium

Ein Enterprise-Release ist nur zulässig, wenn:

- alle Trigger-Evals syntaktisch valide sind;
- mindestens acht positive und acht negative Trigger vorhanden sind;
- mindestens acht Output-Evals vorhanden sind;
- Pressure-Evals die Kern-Stop-Gates abdecken;
- der Release-Gate-Report PASS meldet.
