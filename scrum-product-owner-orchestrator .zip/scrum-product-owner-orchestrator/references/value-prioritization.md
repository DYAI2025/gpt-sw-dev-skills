# Wertpriorisierung

## Status des Modells

Scrum schreibt keine numerische Priorisierungsformel vor. Dieses Modell ist eine konfigurierbare Designentscheidung. Es darf nicht als „die Scrum-Methode“ bezeichnet werden.

## Item-Dimensionen

Bewerte von 0 bis 5 und begründe jede Zahl:

| Dimension | Leitfrage |
|---|---|
| Product-Goal-Beitrag | Wie direkt bringt das Item das aktuelle Product Goal voran? |
| Nutzerwert | Welches beobachtbare Nutzerproblem oder Ergebnis verbessert es? |
| Lern-/Risikowert | Welche zentrale Unsicherheit oder welches Risiko reduziert es? |
| Zeitkritikalität | Welcher messbare Nachteil entsteht durch Verzögerung? |
| Abhängigkeitsmultiplikator | Welche weitere wertvolle Arbeit wird entsperrt? |
| Betriebs-/Qualitätswert | Welche Nutzerwirkung entsteht durch Zuverlässigkeit, Sicherheit oder Wartbarkeit? |
| Evidenzstärke | Wie gut ist der angenommene Nutzen belegt? |
| Readiness | Ist das Item verständlich, testbar, klein genug und unblocked? |

## Defaultgewichtung

```text
item_value =
  0.25 * product_goal_contribution +
  0.25 * user_value +
  0.15 * learning_risk_reduction +
  0.10 * time_criticality +
  0.10 * dependency_multiplier +
  0.10 * operational_quality_value +
  0.05 * evidence_strength

adjusted_value = item_value * readiness_factor * confidence_factor
```

Verwende Projektgewichte, wenn vorhanden. Halte die Summe bei 1.0. Readiness und Confidence dürfen Wert nicht künstlich erhöhen, sondern nur begrenzen.

## Sprint-Set-Kohärenz

Optimiere das Set zusätzlich nach:

- einem gemeinsamen Sprint Goal;
- Lieferbarkeit eines nutzbaren Increments;
- geringer Fragmentierung und wenig Kontextwechsel;
- sinnvoller Abhängigkeitsreihenfolge;
- ausgewogenem Lern-, Liefer- und Betriebsrisiko;
- Kapazitäts- und WIP-Grenzen;
- ausreichender Reserve für Unsicherheit und Support.

## Harte Ausschlüsse

Nicht automatisch auswählen, wenn:

- kein Nutzer-/Stakeholderergebnis formuliert ist;
- keine testbare Erwartung existiert;
- ein harter Blocker offen ist;
- Größe oder Abhängigkeiten unbekannt sind;
- das Item nur durch versunkenen Aufwand attraktiv wirkt;
- der Wert nur aus Technikfaszination oder Statusdruck abgeleitet wird.

## Bias-Prüfung

Prüfe HiPPO-/Autoritätsbias, Recency Bias, Sunk Cost, Roadmap-Confirmation-Bias, Technikfaszination, leicht messbare Aktivität statt Outcome und unzulässigen Story-Point-Vergleich zwischen Teams.
