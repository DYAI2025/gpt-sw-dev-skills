# Scrum-Grenzen

## Rollenverteilung

Der Product Owner maximiert den Produktwert und ist für wirksames Product-Backlog-Management accountable. Der Skill darf Backlog Items ordnen, Wertannahmen prüfen, Sprint-Goal-Optionen formulieren und Trade-offs sichtbar machen.

Die Developers entscheiden im Sprint Planning, welche Arbeit unter Berücksichtigung von Kapazität, Größe und technischer Umsetzbarkeit in den Sprint aufgenommen werden kann. Sie erstellen den Umsetzungsplan. Der Skill liefert deshalb einen Sprintkandidaten, keinen einseitigen Sprintvertrag.

Das Scrum Team finalisiert das Sprint Goal gemeinsam. Der Skill kann den Dialog vorbereiten, aber kein Teamgespräch fingieren.

## Product-Backlog-Item-Gate

Ein Item ist nur ein belastbarer Sprintkandidat, wenn:

- ein beobachtbares Nutzer- oder Stakeholderergebnis benannt ist;
- der Product-Goal-Beitrag nachvollziehbar ist oder die Abweichung begründet wird;
- Akzeptanzkriterien oder eine äquivalente testbare Erwartung existieren;
- bekannte Abhängigkeiten und Blocker sichtbar sind;
- es plausibel innerhalb eines Sprints Done werden kann;
- die projektlokale Definition of Done erreichbar ist;
- Developers Größe und Umsetzbarkeit bestätigen können.

Eine Definition of Ready ist keine Scrum-Vorgabe. Behandle sie, falls vorhanden, als lokale Projektpolicy.

## Artefaktgrenzen

- Product Backlog: geordnete, emergente Arbeit zur Verbesserung des Produkts.
- Sprint Backlog: Sprint Goal, ausgewählte Product-Backlog-Items und Umsetzungsplan der Developers.
- Increment: nutzbarer Schritt zum Product Goal, der die Definition of Done erfüllt.

## Anti-Pattern

Verwechsle weder Anzahl erledigter Tickets noch Story Points noch Commitmenge mit Produktwert. Aktivität ist Evidenz für Arbeit, nicht automatisch für Outcome oder Done.
