# GitHub–Jira-Reconciliation

## Bedeutung von „überprüfen“

Der Befehl `überprüfen` startet einen Tagesabgleich für den aktuellen Projekttag. Ein Projekttag wird in der Projektzeitzone definiert und anschließend in ein absolutes UTC-Fenster umgerechnet.

## Scope

Der Projektkontext legt fest:

- Default Branch einbeziehen;
- offene und heute aktualisierte Pull Requests einbeziehen;
- zusätzliche Branches;
- Forks;
- Repository-Unterbereiche;
- Bot- und generierte Änderungen.

Ohne Scope darf der Skill nicht behaupten, „alle Dateien“ vollständig geprüft zu haben.

## Ablauf

1. Tagesfenster und Repository-Scope bestimmen.
2. Commits im Zeitfenster laden.
3. offene oder heute aktualisierte PRs laden.
4. pro Commit/PR geänderte Dateien, Diff, Autor, CI, Reviews, Threads und Merge-Status erfassen.
5. Jira-Keys aus Branchname, Commit Message, PR-Titel, PR-Body und Mappingdatei extrahieren.
6. Ereignisse deduplizieren.
7. Jira-Issues lesen.
8. Evidenz klassifizieren.
9. Status- und Kommentarvorschläge erzeugen.
10. im `APPLY`-Modus erlaubte Mutationen ausführen.
11. read-after-write durchführen.
12. Konsistenzreport nach `schemas/reconciliation-report.schema.json` erzeugen.

## Eindeutige Zuordnung

Bevorzugte Konvention:

```text
Branch:   EX-123-short-description
Commit:   EX-123 implement validation
PR title: EX-123 Add validation workflow
```

Kein eindeutiger Key führt zu `unmapped_changes`. Mehrere Keys führen zu einer Ambiguität oder zu einer belegbaren Aufteilung, niemals zu einer geratenen Einzelzuordnung.

## Evidenzklassen

- `activity_only`: Dateiveränderung oder Commit ohne Qualitätsnachweis.
- `development_started`: eindeutiger Jira-Key plus nichttriviale Entwicklungsaktivität.
- `review_candidate`: PR offen, relevante Checks/Reviews vorhanden, Merge ausstehend.
- `done_candidate`: Merge, erforderliche Checks, Reviews, Akzeptanz und DoD sind belegt.
- `contradictory`: Signale widersprechen sich.
- `insufficient`: Daten fehlen.

## Jira-Kommentar

```markdown
Automatischer GitHub–Jira-Abgleich

- Zeitfenster: 2026-07-23, Europe/Berlin
- UTC: 2026-07-22T22:00:00Z bis 2026-07-23T22:00:00Z
- Repository: owner/repo
- Evidenz: PR #123, Commit abc1234
- Dateien: 7
- CI: passed
- Reviews: approved; 0 blocking unresolved threads
- Vorschlag: In Progress -> Review
- Confidence: 0.91
- Begründung: PR offen, Checks grün, Merge ausstehend.
```

## Fehlermodi

- Jira-Issue nicht sichtbar: keine Neuanlage ohne Auftrag.
- Transition nicht verfügbar: keine Statusmutation; Blocker melden.
- Bot-/Dependency-Commit: nicht automatisch als Produktfortschritt werten.
- Revert-only: keine Fortschrittshochstufung.
- Read-after-write nicht möglich: Mutation als `unverified` melden.
