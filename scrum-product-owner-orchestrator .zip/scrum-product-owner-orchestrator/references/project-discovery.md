# Projekt-Discovery

## Project Snapshot

Erzeuge vor Planung oder Reconciliation einen Snapshot:

```text
project_id
snapshot_time
project_timezone
jira_target
jira_capabilities
jira_status_mapping
jira_transition_capabilities
github_repositories
github_default_branches
github_capabilities
product_goal
definition_of_done
capacity_source
approval_policy
missing
conflicts
confidence
```

## Jira-Discovery

- Liste sichtbare Projekte und bestätige den Projekt-Key.
- Ermittle Issue-Typen und relevante Felder.
- Suche offene Backlog-Items per projektspezifischer JQL.
- Lies Status, Priorität, Sprint, Akzeptanzkriterien, Blocker, Links und Assignee.
- Hole vor Statusänderungen die aktuell verfügbaren Transitions.
- Prüfe separat, ob Board-/Backlog-/Sprintoperationen exponiert sind.

## GitHub-Discovery

- Ermittle Repository-Metadaten und Default Branch.
- Lies README, Architektur-/ADR-Dateien, CONTRIBUTING und Definition-of-Done-relevante Dokumente.
- Ermittle Branch Protection, erforderliche Checks und Review-Konventionen, soweit Tools dies erlauben.
- Ermittle Jira-Key-Konventionen aus Branches, Commits, PRs und Projektdokumentation.

## Umfangsregel

Ein Vollaudit des gesamten Repositories ist nicht vor jedem Sprint nötig. Führe einen tiefen Architektur- oder Codebase-Audit nur aus, wenn:

- der Projektkontext unbekannt ist;
- große Architekturänderungen geplant werden;
- das Backlog den tatsächlichen Implementierungsstand wahrscheinlich nicht abbildet;
- wiederholt falsche Ticketstatus gefunden werden;
- Sicherheits- oder Integritätsrisiken vorliegen.
