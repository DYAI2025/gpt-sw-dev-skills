# Source Map

Stand: 2026-07-23

| ID | Quelle | Typ | Zweck | Confidence | Grenzen |
|---|---|---|---|---:|---|
| S001 | Scrum Guide, offizielle aktuelle Fassung November 2020, https://scrumguides.org/scrum-guide.html | primary | Rollen, Artefakte, Sprint Planning, Product Goal, Sprint Goal, Definition of Done | 5 | Keine Jira-/GitHub-Regeln und keine Priorisierungsformel |
| S002 | Scrum.org Evidence-Based Management, https://www.scrum.org/resources/evidence-based-management | primary | Outcome- und Wertperspektiven | 4 | Keine automatische Ticketreihenfolge |
| S003 | Jira Cloud Platform REST API v3, https://developer.atlassian.com/cloud/jira/platform/rest/v3/intro/ | primary | Issues, Felder, Kommentare, Links, Transitions | 5 | Jira-Software-Agile-API separat |
| S004 | Jira Software Cloud REST API, https://developer.atlassian.com/cloud/jira/software/rest/ | primary | Boards, Backlog, Sprints und Ranking | 5 | Benötigt Berechtigungen und tatsächlich exponierte Tools/API |
| S005 | GitHub REST API: Commits, https://docs.github.com/en/rest/commits | primary | Commits, Vergleiche und Status | 5 | Pagination, Branch- und Zeitfenster beachten |
| S006 | GitHub Pull Request Dokumentation, https://docs.github.com/en/pull-requests/get-started/about-pull-requests | primary | Diffs, Reviews, Checks und Merge-Evidenz | 5 | Projektregeln entscheiden, was erforderlich ist |
| S007 | OpenAI Help: Skills in ChatGPT, https://help.openai.com/en/articles/20001066 | primary | Upload, Installation und Workspace-Grenzen | 5 | Verfügbarkeit und Adminrechte variieren |
| S008 | Nutzerpaket `scrum-gpt-research-foundation.zip` | user_provided | Scrum-Grenzen, Capability-Matrix, Wertmodell, Reconciliation und Schemas | 5 | Stand 2026-07-23; Projektwerte fehlen absichtlich |
| S009 | Direkt beobachtete GitHub- und Atlassian-Connector-Schemata in der Bauumgebung | primary | Capability-Kandidaten und Tool-Lücken | 5 | Nicht auf jeden ChatGPT-Workspace übertragbar |
| S010 | Enterprise Skill Creator | user_provided | Research-, Release-, Installability- und Portabilitäts-Gates | 5 | Baut keine externen Berechtigungen |

## Designableitungen

| ID | Ableitung | Confidence | Behandlung |
|---|---|---:|---|
| D001 | Zweistufiges Wertmodell aus Itemwert und Sprint-Set-Kohärenz | 3 | Als konfigurierbare Architekturentscheidung markieren |
| D002 | PROPOSE/APPLY-Trennung | 4 | Sicherheits- und Governance-Regel |
| D003 | Human Gate für Done, Sprintstart/-abschluss und Merge | 4 | konservativer Default, projektspezifisch anpassbar |
| D004 | Jira bleibt Backlog-Source-of-Truth; GitHub bleibt Code-Source-of-Truth | 4 | Architekturregel zur Vermeidung konkurrierender Wahrheiten |

## Laufzeit-MISSING

Diese Werte gehören nicht in den generischen Skill und müssen je Projekt entdeckt werden:

- Jira-Cloud/Site, Projekt-Key, Board-ID und Sprint-Feld;
- konkrete Statusnamen und Transition-IDs;
- GitHub-Repositories, Default Branch und Merge-Policy;
- Product Goal, Nutzergruppen und Wertindikatoren;
- Definition of Done und lokale Readiness-Regeln;
- Sprintlänge, Teamkapazität und Abwesenheiten;
- Freigabepolicy für Done, Sprintoperationen und GitHub-Schreibzugriffe.
