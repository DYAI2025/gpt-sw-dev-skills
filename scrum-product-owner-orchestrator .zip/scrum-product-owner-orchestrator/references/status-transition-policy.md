# Status-Transition-Policy

## Grundsatz

Mappe semantische Zustände auf projektspezifische Jira-Status und Transition-IDs. Verwende niemals universelle Statusnamen als harte Annahme.

## In Progress

Vorschlag oder Transition ist zulässig, wenn:

- ein eindeutiger Jira-Key vorliegt;
- nichttriviale Entwicklungsaktivität belegt ist;
- das Issue nicht bereits in einem späteren Zustand ist;
- kein Revert-only- oder Bot-only-Fall vorliegt;
- Projektpolicy den Übergang erlaubt.

## Review / QA

Vorschlag ist geeignet, wenn:

- ein PR offen oder aktualisiert ist;
- relevante CI läuft oder grün ist;
- Review-/Testnachweise vorliegen;
- Merge noch nicht abgeschlossen ist;
- Zielstatus im Workflow verfügbar ist.

## Done

`Done` ist nur zulässig, wenn die Projektpolicy dies erlaubt und alle verpflichtenden Gates erfüllt sind:

- PR in maßgeblichen Branch gemerged oder äquivalente Lieferintegration belegt;
- erforderliche CI-/Qualitätschecks grün;
- keine blockierenden offenen Reviews/Threads;
- Akzeptanzkriterien erfüllt;
- Definition of Done erfüllt;
- keine offenen Blocker;
- erforderliche menschliche Freigabe vorhanden.

Folgende Signale reichen nie allein:

- Commit vorhanden;
- Datei geändert;
- PR geöffnet;
- PR gemerged;
- Entwickler sagt „fertig“ ohne Akzeptanz-/DoD-Nachweis.

## Blocked

Setze oder kommentiere `Blocked` nur, wenn der Blocker konkret ist, eine verantwortliche Klärung benannt werden kann und die Projektpolicy den Status unterstützt. Nutze keinen Blocked-Status als Sammelbecken für Unsicherheit.

## Mutation

1. Issue vor Mutation lesen.
2. verfügbare Transitions lesen.
3. passende Transition-ID auswählen.
4. Mutation ausführen.
5. Issue erneut lesen.
6. Vorher/Nachher und Toolresultat protokollieren.
