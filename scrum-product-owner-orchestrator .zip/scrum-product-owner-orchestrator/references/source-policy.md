# Quellenpolicy

## Quellenklassen

- `primary`: offizielle Spezifikation, API-Dokumentation oder direkt beobachtete Tool-Schnittstelle.
- `secondary`: kuratierte Fachquelle zur Einordnung.
- `user_provided`: Projektwissen, Notizen, Research-Paket oder interner Skill.
- `derived`: Modellableitung oder Zusammenfassung.
- `uncertain`: Herkunft oder Gültigkeit unklar.

## Confidence

| Score | Regel |
|---:|---|
| 5 | direkte aktuelle Primärquelle oder direkt beobachtete Capability; harte Regel zulässig |
| 4 | starke Quelle oder mehrere übereinstimmende Quellen; harte Regel zulässig |
| 3 | plausible Ableitung; als Annahme/Designentscheidung markieren |
| 2 | schwach oder kontextabhängig; nicht als harte Regel verwenden |
| 1 | unbelegt; blockieren oder SOURCE_NEEDED |

## Projektquellen

Nutzerdokumente und Projektdateien sind nicht automatisch wahr. Prüfe Aktualität, Gültigkeitsbereich und Widersprüche. Projektspezifische Policies dürfen globale Scrum-Fakten ergänzen, aber nicht stillschweigend als Scrum-Regel ausgegeben werden.

## Laufzeitclaims

Tool-, App-, API-, Plan- und Workspace-Fähigkeiten können sich ändern. Führe eine Capability Probe durch. Behandle die in der Source Map dokumentierten Fähigkeiten als Referenz, nicht als Garantie für jeden Workspace.
