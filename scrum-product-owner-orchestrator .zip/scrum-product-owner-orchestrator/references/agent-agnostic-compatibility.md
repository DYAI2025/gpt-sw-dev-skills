# Agentenagnostische Kompatibilität

## Semantisch portabel

Die folgenden Teile sind agentenagnostisch:

- Scrum-Rollen- und Artefaktgrenzen;
- PROPOSE/APPLY-Modell;
- Projektkontextvertrag;
- Wert- und Kohärenzmodell;
- GitHub–Jira-Reconciliation;
- Status-, Approval- und Read-after-write-Gates;
- JSON-Schemas und deterministische Hilfsskripte.

## Laufzeitabhängig

Nicht portabel ohne Anpassung sind:

- konkrete GitHub- und Atlassian-Toolnamen;
- Authentifizierung, Scopes und Workspace-Berechtigungen;
- ChatGPT-Projekt-/Skill-Discovery;
- Jira-Board-/Sprint-Capabilities;
- Dateisystem, Shell und Python-Verfügbarkeit;
- UI-Installationsablauf.

## Handoff an andere Agenten

Ein anderer Agent muss:

1. seine GitHub-/Jira-Capabilities inventarisieren;
2. Projektkontext in das bereitgestellte Schema normalisieren;
3. Toolnamen im Workflow ersetzen, ohne Sicherheitsgates zu entfernen;
4. Mutationen nur nach gleicher Approval- und Verifikationslogik ausführen;
5. fehlende Capabilities offen melden.

Kompatibilität bedeutet semantische Portabilität, nicht identische Tool- oder UI-Laufzeit.
