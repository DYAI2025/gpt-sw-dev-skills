# Projektkontext-Vertrag

## Discovery-Reihenfolge

1. Projektinstruktionen und projektspezifische Skills.
2. Projekt-Knowledge-Dateien und Repository-Dokumentation.
3. `.scrum-po/project-context.json` oder semantisch gleichwertige Datei.
4. Jira-/GitHub-Metadaten, die mit Lesetools ermittelt werden können.
5. Explizite Nutzerangaben.

Normalisiere die Ergebnisse nach `schemas/project-context.schema.json`. Der Skill darf unterschiedliche Quellformate lesen; intern muss er trotzdem dieselben Felder unterscheiden.

## Pflichtfelder für eine belastbare Sprintplanung

- Projekt-ID, Name und Zeitzone.
- Jira-Site/Cloud-ID und Projekt-Key.
- GitHub-Repositories und Default Branch.
- Product Goal und Nutzergruppen.
- Sprintlänge und Kapazitätsquelle.
- Definition-of-Done-Referenz oder explizite Kriterien.
- Jira-Key-Muster.
- Freigaberegeln für Ticketanlage, Statuswechsel, Done, Sprintoperationen und GitHub-Schreibzugriffe.

## Bedingte Felder

- Board-ID und Sprint-Field-ID bei Jira-Sprintmutationen.
- Story-Points-/Estimate-Feld bei lokaler Nutzung.
- Statusmapping und Transition-IDs, soweit bekannt.
- zusätzliche Branches, Fork-Regeln, Monorepo-Bereiche und Mappingdateien.

## Fehlende Daten

Verwende diese Marker:

- `MISSING`: Information fehlt, Arbeit kann eventuell mit Einschränkung fortgesetzt werden.
- `BLOCKING_MISSING`: sichere oder korrekte Mutation ist ohne die Information nicht möglich.
- `CAPABILITY_MISSING`: der Kontext ist bekannt, aber kein geeignetes Tool ist verfügbar.
- `SOURCE_NEEDED`: eine externe Behauptung benötigt eine belastbare Quelle.

## Kontextpriorität

Widersprechen sich Quellen, gilt nicht automatisch die jüngste oder autoritär klingende Quelle. Vergleiche Gültigkeitsbereich, Datum, Projektbezug und explizite Freigabe. Melde den Konflikt.
