# Product Canvas: MISSING

Status: draft  
Feature Slug: MISSING

| Section | ID | Value | Source Type | Source |
|---|---|---|---|---|
| Problem | CAN-001 | MISSING | BLOCKER | SOURCE_NEEDED |
| Users / Customers | CAN-002 | MISSING | BLOCKER | SOURCE_NEEDED |
| Value Promise | CAN-003 | MISSING | BLOCKER | SOURCE_NEEDED |
| Current Alternatives | CAN-004 | MISSING | MISSING | SOURCE_NEEDED |
| Key Capabilities | CAN-005 | MISSING | MISSING | SOURCE_NEEDED |
| Non-Goals | CAN-006 | MISSING | MISSING | SOURCE_NEEDED |
| Constraints | CAN-007 | MISSING | MISSING | SOURCE_NEEDED |
| Risks | CAN-008 | Product-critical fields are missing. | BLOCKER | SOURCE_NEEDED |
| Success Signal | CAN-009 | MISSING | BLOCKER | SOURCE_NEEDED |
| Evidence | CAN-010 | MISSING | MISSING | SOURCE_NEEDED |
| Allowed Scope | CAN-011 | MISSING | BLOCKER | SOURCE_NEEDED |
| Unresolved Questions | CAN-012 | MISSING | BLOCKER | SOURCE_NEEDED |

## User Confirmation

The assistant must not confirm this canvas.
