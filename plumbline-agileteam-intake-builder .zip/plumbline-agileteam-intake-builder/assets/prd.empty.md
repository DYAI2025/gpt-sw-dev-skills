# PRD: MISSING

Status: draft  
Feature Slug: MISSING  
Owner: MISSING  
User Confirmation Required: yes

## Problem Statement

| Field | Value | Source Type | Source |
|---|---|---|---|
| Problem Statement | MISSING | BLOCKER | SOURCE_NEEDED |

## Target Users

| ID | User | Source Type | Source |
|---|---|---|---|
| USER-001 | MISSING | BLOCKER | SOURCE_NEEDED |

## Requirements

| Requirement ID | Requirement | Priority | Source Type | Source |
|---|---|---|---|---|
| REQ-001 | MISSING | MISSING | MISSING | SOURCE_NEEDED |

## Acceptance Criteria

| AC ID | Requirement ID | Given | When | Then | Source Type |
|---|---|---|---|---|---|
| AC-001 | REQ-001 | MISSING | MISSING | MISSING | MISSING |

## Evidence Needed

| Evidence ID | Requirement ID | Evidence Needed | Source Type |
|---|---|---|---|
| EV-001 | REQ-001 | MISSING | MISSING |

## Links

- Vision: `docs/vision/MISSING.vision.md`
- Canvas: `docs/canvas/MISSING.canvas.md`
- Traceability: `docs/traceability.md`

## User Confirmation Required

The assistant must not confirm this PRD.
