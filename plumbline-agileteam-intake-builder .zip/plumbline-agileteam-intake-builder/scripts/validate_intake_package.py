#!/usr/bin/env python3
"""Validate a Plumbline AgileTeam intake package JSON.

Usage:
  python scripts/validate_intake_package.py intake-package.json
  python scripts/validate_intake_package.py intake-package.json --json
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

ALLOWED_READINESS = {
    "TEMPLATE_ONLY", "DRAFT_FROM_RAW_INPUT", "INTERVIEW_IN_PROGRESS",
    "READY_FOR_USER_CONFIRMATION", "READY_FOR_AGILETEAM_PLANNING",
    "BLOCKED_MISSING_VALUE", "BLOCKED_TRACEABILITY", "BLOCKED_CONTRADICTION",
}
ALLOWED_SOURCE_TYPES = {"EXPLICIT", "ASSUMPTION", "MISSING", "BLOCKER", "CONTRADICTION"}
REQ_RE = re.compile(r"^REQ-[0-9]{3}$")
AC_RE = re.compile(r"^AC-[0-9]{3}$")
TRC_RE = re.compile(r"^TRC-[0-9]{3}$")
SLUG_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")

class Result:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []
    @property
    def ok(self) -> bool:
        return not self.errors
    def error(self, msg: str) -> None:
        self.errors.append(msg)
    def warn(self, msg: str) -> None:
        self.warnings.append(msg)
    def as_dict(self) -> dict[str, Any]:
        return {"ok": self.ok, "errors": self.errors, "warnings": self.warnings}

def walk(obj: Any):
    yield obj
    if isinstance(obj, dict):
        for value in obj.values():
            yield from walk(value)
    elif isinstance(obj, list):
        for value in obj:
            yield from walk(value)

def source_type(value: Any) -> str | None:
    return value.get("source_type") if isinstance(value, dict) else None

def value_text(value: Any) -> str:
    if isinstance(value, dict):
        return str(value.get("value", ""))
    return str(value or "")

def missing_like(value: Any) -> bool:
    st = source_type(value)
    txt = value_text(value).strip().upper()
    return st in {"MISSING", "BLOCKER", "CONTRADICTION"} or txt in {"", "MISSING", "SOURCE_NEEDED"}

def first(value: Any) -> Any:
    if isinstance(value, list):
        return value[0] if value else {"value":"MISSING", "source_type":"MISSING"}
    return value

def validate(pkg: Any) -> Result:
    r = Result()
    if not isinstance(pkg, dict):
        r.error("Root value must be an object.")
        return r

    slug = pkg.get("feature_slug")
    if not isinstance(slug, str) or not SLUG_RE.match(slug):
        r.error("feature_slug must be hyphen-case ASCII.")
    if pkg.get("readiness_level") not in ALLOWED_READINESS:
        r.error("Invalid readiness_level.")

    artifacts = pkg.get("artifacts")
    if not isinstance(artifacts, dict):
        r.error("artifacts must be an object.")
        return r
    for key in ("prd", "vision", "canvas", "traceability"):
        if key not in artifacts:
            r.error(f"artifacts.{key} is required.")

    for item in walk(pkg):
        if isinstance(item, dict) and "source_type" in item and item["source_type"] not in ALLOWED_SOURCE_TYPES:
            r.error(f"Invalid source_type: {item['source_type']!r}")

    prd = artifacts.get("prd", {}) if isinstance(artifacts, dict) else {}
    trace = artifacts.get("traceability", {}) if isinstance(artifacts, dict) else {}
    req_ids: set[str] = set()
    ac_ids: set[str] = set()
    trace_req_ids: set[str] = set()

    if isinstance(prd, dict):
        for req in prd.get("requirements", []) or []:
            rid = req.get("id") if isinstance(req, dict) else None
            if not isinstance(rid, str) or not REQ_RE.match(rid):
                r.error(f"Invalid requirement id: {rid!r}")
            elif rid in req_ids:
                r.error(f"Duplicate requirement id: {rid}")
            else:
                req_ids.add(rid)
        for ac in prd.get("acceptance_criteria", []) or []:
            aid = ac.get("id") if isinstance(ac, dict) else None
            rid = ac.get("requirement_id") if isinstance(ac, dict) else None
            if not isinstance(aid, str) or not AC_RE.match(aid):
                r.error(f"Invalid acceptance criterion id: {aid!r}")
            else:
                ac_ids.add(aid)
            if rid not in req_ids:
                r.error(f"Acceptance criterion {aid!r} references unknown requirement {rid!r}")

    if isinstance(trace, dict):
        for row in trace.get("rows", []) or []:
            if not isinstance(row, dict):
                r.error("Traceability row must be an object.")
                continue
            tid = row.get("trace_id")
            rid = row.get("requirement_id")
            if not isinstance(tid, str) or not TRC_RE.match(tid):
                r.error(f"Invalid trace_id: {tid!r}")
            if isinstance(rid, str):
                trace_req_ids.add(rid)

    for rid in sorted(req_ids - trace_req_ids):
        r.error(f"{rid} exists in PRD but is missing from traceability.")
    for rid in sorted(trace_req_ids - req_ids):
        r.error(f"Traceability references unknown requirement {rid}.")

    canvas = artifacts.get("canvas", {})
    if isinstance(canvas, dict):
        for label, value in [
            ("canvas.problem", canvas.get("problem")),
            ("canvas.users_customers", first(canvas.get("users_customers"))),
            ("canvas.value_promise", canvas.get("value_promise")),
            ("canvas.success_signal", canvas.get("success_signal")),
            ("canvas.allowed_scope", first(canvas.get("allowed_scope"))),
        ]:
            if missing_like(value):
                r.error(f"Product-critical field missing/blocking: {label}")

    vision = artifacts.get("vision", {})
    if isinstance(vision, dict):
        for label, value in [
            ("vision.product_vision_statement", vision.get("product_vision_statement")),
            ("vision.target_group", vision.get("target_group")),
            ("vision.product_value", vision.get("product_value")),
            ("vision.success_signals", first(vision.get("success_signals"))),
        ]:
            if missing_like(value):
                r.error(f"Vision-critical field missing/blocking: {label}")

    confirmation = pkg.get("user_confirmation", {})
    confirmed = isinstance(confirmation, dict) and confirmation.get("confirmed_by_user") is True
    if pkg.get("readiness_level") == "READY_FOR_AGILETEAM_PLANNING" and not confirmed:
        r.error("READY_FOR_AGILETEAM_PLANNING requires explicit user confirmation.")

    ledger = pkg.get("missing_blocker_ledger", [])
    if isinstance(ledger, list):
        has_blocker = any(isinstance(x, dict) and (x.get("source_type") in {"BLOCKER", "CONTRADICTION"} or x.get("severity") == "blocker") for x in ledger)
        if has_blocker and pkg.get("readiness_level") in {"READY_FOR_USER_CONFIRMATION", "READY_FOR_AGILETEAM_PLANNING"}:
            r.error("Readiness is inconsistent with blocker ledger.")
    else:
        r.error("missing_blocker_ledger must be an array.")
    return r

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    try:
        pkg = json.loads(Path(args.path).read_text(encoding="utf-8"))
    except Exception as exc:
        raise SystemExit(f"Cannot read JSON: {exc}")
    result = validate(pkg)
    if args.json:
        print(json.dumps(result.as_dict(), indent=2, ensure_ascii=False))
    else:
        print("VALID" if result.ok else "INVALID")
        if result.errors:
            print("\nErrors:")
            for msg in result.errors:
                print(f"- {msg}")
        if result.warnings:
            print("\nWarnings:")
            for msg in result.warnings:
                print(f"- {msg}")
    return 0 if result.ok else 1

if __name__ == "__main__":
    raise SystemExit(main())
