---
name: plumbline-agileteam-intake-builder
description: Creates Plumbline AgileTeam intake artifacts from raw ideas, chats, notes, PRD fragments, or interviews; use when generating empty templates, guided intake interviews, Product Vision, Product Canvas, PRD, traceability matrices, JSON validation packages, missing/blocker audits, user-confirmation gates, and repo-ready docs for AgileTeam planning.
---

# Plumbline AgileTeam Intake Builder

## When to use

Use this skill when the user needs Plumbline-compatible AgileTeam intake artifacts for:

- `docs/prd/<feature>.prd.md`
- `docs/vision/<feature>.vision.md`
- `docs/canvas/<feature>.canvas.md`
- `docs/traceability.md`

Typical triggers include: `/agileteam ready`, Plumbline intake, PRD generation, Product Vision, Product Canvas, traceability matrix, missing-field audit, guided product interview, raw chat extraction, repo-ready planning package, or user-confirmation gate.

Do not use for generic product copy, implementation coding, or repository mutation without a connector and explicit write confirmation.

## Operating modes

Select exactly one primary mode.

### TEMPLATE_ONLY

Generate empty fillable templates for PRD, Product Vision, Product Canvas, and Traceability. Use `assets/prd.empty.md`, `assets/vision.empty.md`, `assets/canvas.empty.md`, and `assets/traceability.empty.md` as the canonical starting shapes.

### INTERVIEW_MODE

Run a structured intake interview. Ask at most five questions per round. Prioritize product-critical gaps: target users, problem statement, value proposition, success signal, feature scope, non-goals, risks, requirements, acceptance criteria, and evidence needs.

### DRAFT_FROM_RAW_INPUT

Extract artifacts from raw material such as long chats, notes, transcripts, PRD fragments, or mixed context. Preserve uncertainty. Every substantive field must be marked as `EXPLICIT`, `ASSUMPTION`, `MISSING`, `BLOCKER`, or `CONTRADICTION`.

### PLUMBLINE_READY_PACKAGE

Return a repo-ready file pack with paths, full Markdown contents, optional JSON, a Missing/Blocker ledger, a Readiness-Level, and a User Confirmation block. Without a connector, do not write files.

## Required readiness level

Always output exactly one of these statuses:

- `TEMPLATE_ONLY`
- `DRAFT_FROM_RAW_INPUT`
- `INTERVIEW_IN_PROGRESS`
- `READY_FOR_USER_CONFIRMATION`
- `READY_FOR_AGILETEAM_PLANNING`
- `BLOCKED_MISSING_VALUE`
- `BLOCKED_TRACEABILITY`
- `BLOCKED_CONTRADICTION`

Rules:

- Use `BLOCKED_MISSING_VALUE` when target user, problem, value proposition, success signal, or feature scope is missing.
- Use `BLOCKED_TRACEABILITY` when any `REQ-*` cannot be linked to Vision, Canvas, Acceptance Criteria, and Evidence.
- Use `BLOCKED_CONTRADICTION` when supplied material contains unresolved product-direction conflicts.
- Use `READY_FOR_USER_CONFIRMATION` when artifacts are complete enough for review but the user has not confirmed them.
- Use `READY_FOR_AGILETEAM_PLANNING` only after explicit user confirmation in the current context.

## Core rules

1. Never invent missing product truth.
2. Never simulate user confirmation.
3. Never merge Vision, Canvas, PRD, and Traceability into one artifact.
4. Every requirement must have a stable `REQ-###` ID.
5. Every requirement must appear in `docs/traceability.md`.
6. Acceptance Criteria should use `Given / When / Then` with observable results.
7. Markdown is the primary output; JSON is optional for validation and agent handoff.
8. Use the user's language for prose. Keep paths, IDs, and status markers unchanged.
9. Without a filesystem, GitHub, or repository connector, output only repo-ready text and validation instructions.

## Reference loading

Load reference files only when relevant:

- `references/plumbline-path-contract.md` for paths and slug rules.
- `references/artifact-contract-prd.md` for PRD requirements.
- `references/artifact-contract-vision.md` for Product Vision requirements.
- `references/artifact-contract-canvas.md` for Product Canvas requirements.
- `references/artifact-contract-traceability.md` for traceability rules.
- `references/interview-playbook.md` for interview loops.
- `references/missing-blocker-policy.md` for uncertainty markers and blockers.
- `references/repository-integration-contract.md` for write boundaries.
- `references/evaluation-plan.md` for quality gates.

## Workflow

1. Classify input type: raw idea, chat, transcript, PRD fragment, interview answer, existing artifact, or mixed.
2. Normalize `feature_slug` to `^[a-z0-9]+(?:-[a-z0-9]+)*$`; if impossible, mark `BLOCKER`.
3. Build a source map with `SRC-###` IDs.
4. Extract or generate Vision, Canvas, PRD, and Traceability separately.
5. Assign stable IDs: `VIS-###`, `CAN-###`, `REQ-###`, `AC-###`, `TRC-###`, `EV-###`, `RISK-###`, `OQ-###`.
6. Mark every field as `EXPLICIT`, `ASSUMPTION`, `MISSING`, `BLOCKER`, or `CONTRADICTION`.
7. Validate traceability coverage for every `REQ-*`.
8. Produce a Missing/Blocker ledger and readiness status.
9. Present a User Confirmation block without filling it on behalf of the user.
10. If JSON is generated, validate against `schemas/intake-package.schema.json` and with `scripts/validate_intake_package.py` when executable access exists.

## Output format

For repo-ready output, use:

```text
Readiness-Level: <one allowed status>
Mode: <one operating mode>

1. Readiness Card
2. Source Map
3. File Pack
   - docs/prd/<feature>.prd.md
   - docs/vision/<feature>.vision.md
   - docs/canvas/<feature>.canvas.md
   - docs/traceability.md
4. Missing / Assumption / Blocker Ledger
5. Traceability Summary
6. User Confirmation Block
7. Validation Report
```

For interview mode, use:

```text
Readiness-Level: INTERVIEW_IN_PROGRESS or BLOCKED_MISSING_VALUE

Known Fields
| Field | Current Value | Source Type | Source |

Critical Gaps
| Gap | Severity | Why it matters |

Questions
1. ...
2. ...
3. ...
4. ...
5. ...
```

## Confirmation phrase

English:

```text
I confirm that the Product Canvas and Product Vision reflect my intent and may be used as the basis for AgileTeam planning.
```

German:

```text
Ich bestätige, dass Product Canvas und Product Vision meine Absicht korrekt wiedergeben und als Grundlage für AgileTeam Planning verwendet werden dürfen.
```

The assistant must not fill these phrases for the user.

## Examples

### Empty templates

User: `Generate empty Plumbline intake templates for billing-retry.`

Expected: `TEMPLATE_ONLY`, four file paths, empty Markdown templates, no confirmation.

### Guided interview

User: `Interview me until this idea is AgileTeam-ready: invoice dashboard.`

Expected: ask at most five product-critical questions, then update known fields and blockers.

### Raw extraction

User: `Here is a long chat. Extract PRD, Vision, Canvas, and Traceability.`

Expected: source-indexed extraction, ID assignment, Missing/Blocker ledger, readiness no higher than `READY_FOR_USER_CONFIRMATION` unless confirmation is explicit.
