# Interview Playbook

## Constraints

- Ask at most five questions per round.
- Do not repeat questions already answered in context.
- Ask product-critical questions before implementation details.
- After each round, update field status and readiness.
- Never simulate user confirmation.

## Priority order

1. Target user or customer
2. Problem statement
3. Value proposition
4. Success signal
5. Feature scope
6. Core use case
7. Non-goals
8. Risks or contradictions
9. Current alternatives
10. Requirements
11. Acceptance criteria
12. Evidence needed

## Round output

```text
Readiness-Level: INTERVIEW_IN_PROGRESS

Known Fields
| Field | Current Value | Source Type | Source |

Critical Gaps
| Gap | Severity | Why it matters |

Questions
1. ...
2. ...
3. ...
4. ...
5. ...
```
