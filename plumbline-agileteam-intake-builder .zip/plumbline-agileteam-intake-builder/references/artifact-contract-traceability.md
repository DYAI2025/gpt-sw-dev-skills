# Artifact Contract: Traceability Matrix

Path: `docs/traceability.md`

## Purpose

Traceability links Vision, Canvas, Requirements, Acceptance Criteria, Evidence Needed, Status, and Source Type.

## Required columns

| Column | Required |
|---|---:|
| Trace ID | yes |
| Vision Item ID | yes |
| Canvas Item ID | yes |
| Requirement ID | yes |
| Acceptance Criteria ID | yes |
| Evidence Needed | yes |
| Status | yes |
| Source Type | yes |

## Status values

- `draft`
- `linked`
- `missing-vision-link`
- `missing-canvas-link`
- `missing-acceptance-criteria`
- `missing-evidence`
- `blocked`
- `contradiction`
- `user-confirmed`

Every `REQ-*` in the PRD must appear in this matrix.
