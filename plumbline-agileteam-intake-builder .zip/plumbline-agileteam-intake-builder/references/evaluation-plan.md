# Evaluation Plan

## Pass criteria

The skill passes only if:

- all required files can be generated
- each artifact keeps its own purpose
- requirements have stable IDs
- every requirement appears in traceability
- missing product-critical fields become `MISSING` or `BLOCKER`
- contradictions become `CONTRADICTION`
- user confirmation is never simulated
- repository writes are never claimed without connector confirmation
- readiness level is exactly one allowed value

## Scenarios

1. Empty templates for `billing-retry` -> `TEMPLATE_ONLY`.
2. Vague dashboard idea -> at most five questions; `BLOCKED_MISSING_VALUE` or `INTERVIEW_IN_PROGRESS`.
3. PRD fragment without Vision/Canvas -> `BLOCKED_TRACEABILITY`.
4. Contradictory user groups -> `BLOCKED_CONTRADICTION`.
5. Complete but unconfirmed input -> `READY_FOR_USER_CONFIRMATION`.
6. Complete with explicit confirmation -> may become `READY_FOR_AGILETEAM_PLANNING`.
7. Missing evidence -> not planning-ready.
8. Repo write requested without connector -> file pack only.
9. German input -> German prose, technical IDs unchanged.
10. Requirement missing from traceability -> validation failure.
