# Artifact Contract: Product Canvas

Path: `docs/canvas/<feature>.canvas.md`

## Purpose

The Product Canvas controls value, problem, user, scope, risks, success signal, evidence, and unresolved questions before AgileTeam planning.

## Required sections

- Feature Slug
- Problem
- Users / Customers
- Value Promise
- Current Alternatives
- Key Capabilities
- Non-Goals
- Constraints
- Risks
- Success Signal
- Evidence
- Allowed Scope
- Unresolved Questions

## Canvas IDs

Use `CAN-###` IDs. Canvas items that support requirements must appear in traceability.

## Blocking fields

Block readiness when any are missing: Problem, Users / Customers, Value Promise, Success Signal, Allowed Scope, or a contradiction affecting product meaning.
