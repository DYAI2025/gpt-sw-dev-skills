# Artifact Contract: PRD

Path: `docs/prd/<feature>.prd.md`

## Purpose

The PRD is the implementation-facing requirements artifact. It translates Vision and Canvas into testable requirements, acceptance criteria, constraints, risks, and evidence needs.

## Required sections

- Title
- Status
- Feature Slug
- Owner
- Source Summary
- Problem Statement
- Target Users
- Goals
- Non-Goals
- Assumptions
- Open Questions
- Requirements with `REQ-###` IDs
- Acceptance Criteria with `AC-###` IDs
- Non-Functional Requirements
- Risks
- Evidence Needed
- Links to Vision, Canvas, and Traceability
- User Confirmation Required

## Status values

- `draft`
- `blocked`
- `ready-for-user-confirmation`
- `user-confirmed`

Never set `user-confirmed` without explicit user confirmation.

## Acceptance Criteria

Preferred format:

```text
Given <context>
When <action>
Then <observable result>
```

The `Then` line must be observable.
