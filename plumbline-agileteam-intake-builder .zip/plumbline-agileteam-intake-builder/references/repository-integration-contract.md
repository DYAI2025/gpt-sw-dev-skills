# Repository Integration Contract

## Default: no connector

Without authenticated filesystem, GitHub, or repository connector, output only repo-ready content.

Allowed:

- paths
- full file contents
- JSON package
- validation report
- local commands

Forbidden:

- claim files were written
- claim repository creation
- claim branch creation
- claim commit or pull request creation
- imply validation ran when it did not

## Connector mode

Before any write, require explicit confirmation of:

- repository owner
- repository name
- target branch
- file paths
- operation: create, update, or append
- conflict behavior: overwrite, fail, or ask
- user approval

Prefer pull requests over direct writes to protected branches.
