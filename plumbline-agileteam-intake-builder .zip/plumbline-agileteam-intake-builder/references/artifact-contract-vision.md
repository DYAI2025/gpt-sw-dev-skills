# Artifact Contract: Product Vision

Path: `docs/vision/<feature>.vision.md`

## Purpose

The Product Vision captures user-owned product intent: target group, user need, value, goals, success signals, and boundaries.

## Required sections

- Product Vision Statement
- Target Group
- User Needs
- Product Value
- Business or Project Goals
- Success Signals
- Boundaries
- Assumptions
- Missing Items
- Confirmation Status

## Vision IDs

Use `VIS-###` IDs. Each Vision item that supports a requirement must appear in traceability.

## Confirmation status

- `not-requested`
- `pending-user-confirmation`
- `user-confirmed`
- `blocked`

Do not set `user-confirmed` unless the user explicitly confirms.
