# Plumbline Path Contract

## Repository

Target repository: `plumbline`  
Domain: `AgileTeam Agent Harness`

## Canonical output paths

| Artifact | Path |
|---|---|
| PRD | `docs/prd/<feature>.prd.md` |
| Product Vision | `docs/vision/<feature>.vision.md` |
| Product Canvas | `docs/canvas/<feature>.canvas.md` |
| Traceability Matrix | `docs/traceability.md` |

## Feature slug

`<feature>` must match `^[a-z0-9]+(?:-[a-z0-9]+)*$`.

Examples:

- `billing-retry`
- `admin-dashboard-v2`
- `invoice-export`

If a stable slug cannot be derived, set `feature_slug: MISSING` and mark it as `BLOCKER`.

## No-write default

Without a connector, output path plus complete content only. Do not claim repository writes, branch creation, commits, or pull requests.
