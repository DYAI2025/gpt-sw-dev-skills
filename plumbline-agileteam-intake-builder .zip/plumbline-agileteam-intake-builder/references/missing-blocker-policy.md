# Missing and Blocker Policy

Use exactly these markers:

| Marker | Meaning |
|---|---|
| `EXPLICIT` | Directly stated in supplied material |
| `ASSUMPTION` | Plausibly inferred but not confirmed |
| `MISSING` | Needed but absent |
| `BLOCKER` | Missing/unsafe condition prevents reliable readiness |
| `CONTRADICTION` | Sources or statements conflict |

## Product-critical blockers

- Target user missing
- Problem missing
- Value proposition missing
- Success signal missing
- Feature scope unclear
- Requirements cannot be traced to Vision and Canvas
- User confirmation is required but absent for planning claim

## Rule

Prefer visible `MISSING` over invented certainty.
