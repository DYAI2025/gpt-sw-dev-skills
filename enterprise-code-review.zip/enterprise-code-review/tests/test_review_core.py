from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

from atomic_sort import atomic_sort_report, finding_fingerprint
from import_sarif import sarif_to_packet
from merge_review_packets import merge_packets
from pipeline_ledger import append_event, artifact_digest, rebuild_state
from report_to_sarif import to_sarif
from snapshot_repo import build_manifest, DEFAULT_IGNORE
from validate_review_report import errors_for_report


class ReviewCoreTests(unittest.TestCase):
    def load_fixture(self, name: str):
        return json.loads((ROOT / "evals" / "fixtures" / name).read_text(encoding="utf-8"))

    def test_valid_report(self):
        self.assertEqual([], errors_for_report(self.load_fixture("valid_report.json")))

    def test_model_only_critical_blocked(self):
        errors = errors_for_report(self.load_fixture("invalid_model_only_critical.json"))
        self.assertTrue(any("cannot be MODEL_ONLY" in item for item in errors))

    def test_ready_with_blocker_blocked(self):
        errors = errors_for_report(self.load_fixture("invalid_ready_with_blocker.json"))
        self.assertTrue(any("unresolved Blocker/Critical" in item for item in errors))

    def test_pasted_ready_blocked(self):
        errors = errors_for_report(self.load_fixture("invalid_pasted_ready.json"))
        self.assertTrue(any("pasted-code" in item for item in errors))

    def test_atomic_sort_idempotent_and_preserves_severity(self):
        value = self.load_fixture("atomic_sort_input.json")
        before = {item["finding_id"]: (item["severity"], item["confidence"]) for item in value["findings"]}
        once = atomic_sort_report(value)
        twice = atomic_sort_report(once)
        self.assertEqual(json.dumps(once, sort_keys=True), json.dumps(twice, sort_keys=True))
        self.assertEqual(1, once["atomic_sort"]["duplicate_count"])
        for item in once["findings"]:
            self.assertEqual(before[item["finding_id"]][0], item["severity"])
            self.assertEqual(before[item["finding_id"]][1], item["confidence"])

    def test_fingerprint_stable(self):
        finding = self.load_fixture("valid_report.json")["findings"][0]
        self.assertEqual(finding_fingerprint(finding), finding_fingerprint(json.loads(json.dumps(finding))))

    def test_sarif_export(self):
        sarif = to_sarif(self.load_fixture("valid_report.json"))
        self.assertEqual("2.1.0", sarif["version"])
        self.assertEqual(1, len(sarif["runs"][0]["results"]))

    def test_sarif_import_never_promotes_critical(self):
        sarif = {
            "version": "2.1.0",
            "runs": [{
                "tool": {"driver": {"name": "fixture", "version": "1", "rules": []}},
                "results": [{"ruleId": "R1", "level": "error", "message": {"text": "candidate"}, "locations": [{"physicalLocation": {"artifactLocation": {"uri": "x.py"}, "region": {"startLine": 1}}}]}]
            }]
        }
        packet = sarif_to_packet(sarif, "git:" + "a" * 64, "tool")
        self.assertEqual("Important", packet["findings"][0]["severity"])
        self.assertEqual("SUPPORTED", packet["findings"][0]["status"])

    def test_merge_requires_same_snapshot(self):
        packet_a = {"reviewer_id": "a", "snapshot_id": "s1", "findings": [], "evidence": []}
        packet_b = {"reviewer_id": "b", "snapshot_id": "s2", "findings": [], "evidence": []}
        with self.assertRaises(ValueError):
            merge_packets([packet_a, packet_b])

    def test_snapshot_does_not_read_ignored_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "src").mkdir()
            (root / "src" / "a.py").write_text("print('x')\n", encoding="utf-8")
            (root / "node_modules").mkdir()
            (root / "node_modules" / "secret.js").write_text("secret\n", encoding="utf-8")
            manifest = build_manifest(root, "LOCAL", 1024 * 1024, DEFAULT_IGNORE)
            paths = {item["path"] for item in manifest["files"]}
            self.assertIn("src/a.py", paths)
            self.assertNotIn("node_modules/secret.js", paths)

    def test_quick_validate_accepts_dot_path(self):
        result = subprocess.run(
            [sys.executable, str(SCRIPTS / "quick_validate.py"), "."],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)

    def test_placeholder_validator_does_not_flag_its_own_patterns(self):
        result = subprocess.run(
            [sys.executable, str(SCRIPTS / "validate_no_placeholders.py"), str(ROOT)],
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)

    def test_pipeline_ledger_detects_stale_digest(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "skill"
            root.mkdir()
            (root / "SKILL.md").write_text("x\n", encoding="utf-8")
            events = root / "reports" / "events.jsonl"
            run_id = "test"
            for event_type in ["INTAKE_COMPLETED", "RESEARCH_COMPLETED", "CAPABILITY_DECISION_COMPLETED", "ARCHITECTURE_GATE_PASSED"]:
                append_event(events, event_type, run_id=run_id)
            digest = artifact_digest(root)
            append_event(events, "DRAFT_FROZEN", run_id=run_id, artifact_digest=digest)
            for event_type in ["RELEASE_GATE_PASSED", "EVALUATOR_PASSED", "VALIDATION_PASSED", "PACKAGE_AUTHORIZED"]:
                append_event(events, event_type, run_id=run_id, artifact_digest=digest)
            self.assertTrue(rebuild_state(events, current_artifact_digest=digest)["package_authorized"])
            (root / "SKILL.md").write_text("changed\n", encoding="utf-8")
            state = rebuild_state(events, current_artifact_digest=artifact_digest(root))
            self.assertFalse(state["package_authorized"])
            self.assertIn("STALE_ARTIFACT_DIGEST", state["errors"])


if __name__ == "__main__":
    unittest.main()
