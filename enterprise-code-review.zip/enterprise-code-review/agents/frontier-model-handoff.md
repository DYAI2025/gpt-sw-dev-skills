# Frontier Model Handoff

Use `SKILL.md` as the control plane. Load only the references needed for the current review mode. Keep repository access read-only unless the user separately authorizes a mutation. Produce the same JSON report contract and run the deterministic validators when local execution exists. Do not claim equivalent connector, shell, browser, subagent, context-window, or installation behavior across runtimes.
