#!/usr/bin/env python3
"""Create a content-addressed, read-only repository or file snapshot manifest."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DEFAULT_IGNORE = {
    ".git", ".hg", ".svn", ".venv", "venv", "node_modules", "vendor",
    "dist", "build", "target", "coverage", ".pytest_cache", ".mypy_cache",
    ".ruff_cache", "__pycache__", ".next", ".nuxt", ".gradle", ".idea",
}
MAX_FILE_BYTES = 20 * 1024 * 1024


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run_git(root: Path, args: list[str]) -> str | None:
    try:
        proc = subprocess.run(
            ["git", "-C", str(root), *args],
            text=True,
            capture_output=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    return proc.stdout.strip() if proc.returncode == 0 else None


def language_hint(path: Path) -> str:
    mapping = {
        ".py": "Python", ".js": "JavaScript", ".jsx": "JavaScript",
        ".ts": "TypeScript", ".tsx": "TypeScript", ".java": "Java",
        ".kt": "Kotlin", ".kts": "Kotlin", ".go": "Go", ".rs": "Rust",
        ".c": "C", ".h": "C/C++", ".cc": "C++", ".cpp": "C++",
        ".cs": "C#", ".rb": "Ruby", ".php": "PHP", ".swift": "Swift",
        ".sol": "Solidity", ".move": "Move", ".vy": "Vyper",
        ".sql": "SQL", ".sh": "Shell", ".yaml": "YAML", ".yml": "YAML",
        ".json": "JSON", ".toml": "TOML", ".md": "Markdown",
    }
    return mapping.get(path.suffix.lower(), "Other")


def iter_files(root: Path, ignored: set[str]) -> tuple[list[Path], list[str]]:
    files: list[Path] = []
    skipped: list[str] = []
    if root.is_file():
        if root.is_symlink():
            skipped.append(f"symlink:{root.name}")
        else:
            files.append(root)
        return files, skipped
    for current, dirs, names in os.walk(root, followlinks=False):
        current_path = Path(current)
        kept_dirs: list[str] = []
        for name in sorted(dirs):
            candidate = current_path / name
            if name in ignored:
                skipped.append(f"ignored_dir:{candidate.relative_to(root).as_posix()}")
            elif candidate.is_symlink():
                skipped.append(f"symlink_dir:{candidate.relative_to(root).as_posix()}")
            else:
                kept_dirs.append(name)
        dirs[:] = kept_dirs
        for name in sorted(names):
            path = current_path / name
            rel = path.relative_to(root).as_posix()
            if path.is_symlink():
                skipped.append(f"symlink_file:{rel}")
                continue
            if path.is_file():
                files.append(path)
    return files, skipped


def build_manifest(root: Path, mode: str, max_file_bytes: int, ignored: set[str]) -> dict[str, Any]:
    root = root.resolve()
    if not root.exists():
        raise ValueError(f"path not found: {root}")
    files, skipped = iter_files(root, ignored)
    records: list[dict[str, Any]] = []
    language_counts: dict[str, int] = {}
    total_bytes = 0
    oversized: list[str] = []
    unreadable: list[str] = []
    base = root.parent if root.is_file() else root
    for path in sorted(files, key=lambda p: p.relative_to(base).as_posix()):
        rel = path.relative_to(base).as_posix()
        try:
            size = path.stat().st_size
        except OSError as exc:
            unreadable.append(f"{rel}:{type(exc).__name__}")
            continue
        total_bytes += size
        lang = language_hint(path)
        language_counts[lang] = language_counts.get(lang, 0) + 1
        if size > max_file_bytes:
            oversized.append(rel)
            records.append({"path": rel, "size": size, "sha256": None, "language": lang, "status": "OVERSIZED_SKIPPED"})
            continue
        try:
            digest = file_hash(path)
        except OSError as exc:
            unreadable.append(f"{rel}:{type(exc).__name__}")
            records.append({"path": rel, "size": size, "sha256": None, "language": lang, "status": "UNREADABLE"})
            continue
        records.append({"path": rel, "size": size, "sha256": digest, "language": lang, "status": "HASHED"})

    tree_hasher = hashlib.sha256()
    for rec in records:
        tree_hasher.update(rec["path"].encode("utf-8"))
        tree_hasher.update(b"\0")
        tree_hasher.update(str(rec["size"]).encode("ascii"))
        tree_hasher.update(b"\0")
        tree_hasher.update((rec["sha256"] or rec["status"]).encode("ascii"))
        tree_hasher.update(b"\0")
    tree_digest = tree_hasher.hexdigest()

    git_root = root if root.is_dir() else root.parent
    git_head = run_git(git_root, ["rev-parse", "HEAD"])
    git_branch = run_git(git_root, ["rev-parse", "--abbrev-ref", "HEAD"])
    git_status = run_git(git_root, ["status", "--porcelain=v1"])
    kind = "PASTED" if mode == "PASTED" else ("GIT" if git_head else ("TREE" if root.is_dir() else "FILE"))
    snapshot_id = f"{kind.lower()}:{tree_digest}"
    limitations: list[str] = []
    if skipped:
        limitations.append(f"{len(skipped)} paths skipped by ignore/symlink policy")
    if oversized:
        limitations.append(f"{len(oversized)} oversized files not content-hashed")
    if unreadable:
        limitations.append(f"{len(unreadable)} unreadable files")
    if mode == "PASTED":
        limitations.extend([
            "caller, dependency, build, runtime, CI, deployment, and consumer context not proven",
            "READY_FOR_MERGE is prohibited for pasted-code mode",
        ])

    return {
        "schema_version": "1.0.0",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "root": str(root),
        "mode": mode,
        "kind": kind,
        "snapshot_id": snapshot_id,
        "tree_digest": tree_digest,
        "git": {
            "head": git_head,
            "branch": git_branch,
            "dirty": bool(git_status) if git_status is not None else None,
            "status_entry_count": len(git_status.splitlines()) if git_status else 0,
        },
        "summary": {
            "visible_file_count": len(records),
            "hashed_file_count": sum(1 for r in records if r["status"] == "HASHED"),
            "total_bytes": total_bytes,
            "language_counts": dict(sorted(language_counts.items())),
        },
        "ignore_policy": sorted(ignored),
        "max_file_bytes": max_file_bytes,
        "skipped": skipped,
        "oversized": oversized,
        "unreadable": unreadable,
        "files": records,
        "limitations": limitations,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path")
    parser.add_argument("output")
    parser.add_argument("--mode", choices=["LOCAL", "PASTED"], default="LOCAL")
    parser.add_argument("--max-file-bytes", type=int, default=MAX_FILE_BYTES)
    parser.add_argument("--ignore", action="append", default=[])
    args = parser.parse_args()
    try:
        manifest = build_manifest(Path(args.path), args.mode, args.max_file_bytes, DEFAULT_IGNORE | set(args.ignore))
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    print(f"PASS: snapshot {manifest['snapshot_id']} ({manifest['summary']['visible_file_count']} files)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
