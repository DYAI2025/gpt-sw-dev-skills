#!/usr/bin/env python3
"""Validate source-map/source-policy enterprise source controls."""
from __future__ import annotations

import re
import sys
from pathlib import Path

REQUIRED_TERMS = [
    "type:", "purpose:", "reliability:", "limitations:", "confidence_default:",
    "user_provided", "primary", "derived", "uncertain", "SOURCE_NEEDED", "MISSING",
]


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_source_map.py <skill-dir>")
    root = Path(argv[1])
    source_map = root / "references" / "source-map.md"
    source_policy = root / "references" / "source-policy.md"
    if not source_map.exists() or not source_policy.exists():
        return fail("source map or source policy missing")
    text = source_map.read_text(encoding="utf-8") + "\n" + source_policy.read_text(encoding="utf-8")
    missing = [term for term in REQUIRED_TERMS if term not in text]
    if missing:
        return fail("missing source terms: " + ", ".join(missing))
    source_ids = re.findall(r"^## (S\d+)\b", source_map.read_text(encoding="utf-8"), flags=re.MULTILINE)
    if len(source_ids) < 10 or len(source_ids) != len(set(source_ids)):
        return fail("source map needs at least 10 unique source IDs")
    if "Canon Resolver" not in text or "Technology Radar" not in text or "web3-docs" not in text or "Weft" not in text or "Atom of Thoughts" not in text:
        return fail("required uploaded repository sources missing")
    print(f"PASS: source map ({len(source_ids)} sources)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
