#!/usr/bin/env python3
"""Validate portable workflow claims and runtime limitations."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_agent_agnostic.py <skill-dir>")
    root = Path(argv[1])
    ref = root / "references" / "agent-agnostic-compatibility.md"
    report_path = root / "reports" / "agent-compatibility-report.json"
    if not ref.exists() or not report_path.exists():
        return fail("agent compatibility artifacts missing")
    try:
        report = json.loads(report_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(str(exc))
    if report.get("agent_agnostic_ready") is not True:
        return fail("agent_agnostic_ready must be true")
    if not report.get("portable_components") or not report.get("runtime_specific_components"):
        return fail("portable/runtime-specific components missing")
    if not report.get("not_guaranteed"):
        return fail("runtime limitations missing")
    text = ref.read_text(encoding="utf-8").lower()
    for term in ("does not imply", "runtime-specific", "capability"):
        if term not in text:
            return fail(f"compatibility reference missing term: {term}")
    print("PASS: agent-agnostic compatibility")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
