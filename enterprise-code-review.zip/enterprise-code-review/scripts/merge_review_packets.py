#!/usr/bin/env python3
"""Merge independent reviewer packets while preserving evidence origins and disagreements."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from atomic_sort import atomic_sort_report, finding_fingerprint


def merge_packets(packets: list[dict[str, Any]]) -> dict[str, Any]:
    if not packets:
        raise ValueError("at least one packet required")
    snapshot_ids = {packet.get("snapshot_id") for packet in packets}
    if len(snapshot_ids) != 1 or None in snapshot_ids:
        raise ValueError("all packets must use the same snapshot_id")
    findings: list[dict[str, Any]] = []
    evidence: list[dict[str, Any]] = []
    evidence_ids: set[str] = set()
    reviewers: list[str] = []
    for packet in packets:
        reviewer = str(packet.get("reviewer_id") or "unknown-reviewer")
        reviewers.append(reviewer)
        for item in packet.get("evidence", []):
            eid = item.get("evidence_id")
            if not eid or eid in evidence_ids:
                raise ValueError(f"duplicate or missing evidence_id: {eid}")
            evidence_ids.add(eid)
            evidence.append(item)
        for finding in packet.get("findings", []):
            copied = json.loads(json.dumps(finding))
            copied.setdefault("reviewer_ids", [])
            copied["reviewer_ids"] = sorted(set(copied["reviewer_ids"] + [reviewer]))
            copied.setdefault("fingerprint", finding_fingerprint(copied))
            findings.append(copied)
    scaffold = {"findings": findings}
    sorted_scaffold = atomic_sort_report(scaffold)
    conflicts = sorted_scaffold.get("atomic_sort", {}).get("conflicts", [])
    by_id = {f.get("finding_id"): f for f in sorted_scaffold["findings"]}
    corroboration: list[dict[str, Any]] = []
    for finding in sorted_scaffold["findings"]:
        if finding.get("status") == "DUPLICATE":
            canonical = by_id.get(finding.get("duplicate_of"))
            if canonical:
                reviewer_set = set(canonical.get("reviewer_ids", [])) | set(finding.get("reviewer_ids", []))
                canonical["reviewer_ids"] = sorted(reviewer_set)
                if len(reviewer_set) > 1:
                    corroboration.append({
                        "canonical_id": canonical.get("finding_id"),
                        "other_id": finding.get("finding_id"),
                        "label": "INDEPENDENTLY_CORROBORATED",
                        "reviewer_ids": sorted(reviewer_set),
                        "note": "Corroboration does not upgrade verification status."
                    })
    return {
        "schema_version": "1.0.0",
        "snapshot_id": next(iter(snapshot_ids)),
        "reviewer_ids": sorted(set(reviewers)),
        "findings": sorted_scaffold["findings"],
        "evidence": evidence,
        "corroboration": corroboration,
        "disagreements": conflicts,
        "merge_invariant": "No reviewer consensus automatically upgrades severity or status."
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output")
    parser.add_argument("packets", nargs="+")
    args = parser.parse_args()
    try:
        packets = [json.loads(Path(path).read_text(encoding="utf-8")) for path in args.packets]
        result = merge_packets(packets)
        Path(args.output).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    print(f"PASS: merged {len(packets)} packets, {len(result['findings'])} findings")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
