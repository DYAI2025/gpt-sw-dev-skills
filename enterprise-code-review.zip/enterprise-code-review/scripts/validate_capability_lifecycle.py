#!/usr/bin/env python3
"""Validate capability records and lifecycle transitions."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

STATES = {"DISCOVERED", "PRIMARY_SOURCE_PENDING", "SOURCE_INSPECTED", "EXPERIMENTAL", "RUNTIME_VERIFIED", "ADOPTED", "REJECTED", "STALE"}
ALLOWED = {
    None: {"DISCOVERED"},
    "DISCOVERED": {"PRIMARY_SOURCE_PENDING", "SOURCE_INSPECTED", "REJECTED"},
    "PRIMARY_SOURCE_PENDING": {"SOURCE_INSPECTED", "REJECTED"},
    "SOURCE_INSPECTED": {"EXPERIMENTAL", "REJECTED", "STALE"},
    "EXPERIMENTAL": {"RUNTIME_VERIFIED", "REJECTED", "STALE"},
    "RUNTIME_VERIFIED": {"ADOPTED", "REJECTED", "STALE"},
    "ADOPTED": {"STALE", "REJECTED"},
    "REJECTED": {"DISCOVERED"},
    "STALE": {"DISCOVERED", "SOURCE_INSPECTED", "REJECTED"},
}
REQUIRED_RECORD = {"capability_id", "name", "category", "purpose", "status", "source_ids", "authorization", "data_boundary", "runtime_verification", "limitations", "decision"}


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    values: list[dict[str, Any]] = []
    for line_no, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not raw.strip():
            continue
        value = json.loads(raw)
        if not isinstance(value, dict):
            raise ValueError(f"line {line_no} must be object")
        values.append(value)
    return values


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_capability_lifecycle.py <skill-dir>")
    root = Path(argv[1])
    record_path = root / "reports" / "capability-records.json"
    event_path = root / "reports" / "capability-lifecycle-events.jsonl"
    if not record_path.exists() or not event_path.exists():
        return fail("capability record/event reports missing")
    try:
        records = json.loads(record_path.read_text(encoding="utf-8"))
        events = load_jsonl(event_path)
    except Exception as exc:
        return fail(str(exc))
    if not isinstance(records, list) or not records:
        return fail("capability-records.json must be a non-empty array")
    by_id: dict[str, dict[str, Any]] = {}
    for record in records:
        missing = REQUIRED_RECORD - set(record)
        if missing:
            return fail("capability record missing: " + ", ".join(sorted(missing)))
        cid = record["capability_id"]
        if cid in by_id:
            return fail(f"duplicate capability_id: {cid}")
        if record["status"] not in STATES:
            return fail(f"invalid capability status: {cid}")
        by_id[cid] = record
    current: dict[str, str | None] = {}
    for index, event in enumerate(events, start=1):
        cid = event.get("capability_id")
        target = event.get("to_status")
        source = event.get("from_status")
        if cid not in by_id:
            return fail(f"event {index} references unknown capability {cid}")
        if target not in STATES:
            return fail(f"event {index} invalid to_status")
        expected_source = current.get(cid)
        if source != expected_source:
            return fail(f"event {index} from_status mismatch for {cid}: expected {expected_source}, got {source}")
        if target not in ALLOWED.get(source, set()):
            return fail(f"event {index} illegal transition {source}->{target} for {cid}")
        if target in {"RUNTIME_VERIFIED", "ADOPTED"} and not event.get("evidence_ids"):
            return fail(f"event {index} {target} requires evidence_ids")
        current[cid] = target
    for cid, record in by_id.items():
        if current.get(cid) != record["status"]:
            return fail(f"final lifecycle status mismatch for {cid}: events={current.get(cid)} record={record['status']}")
        if record["status"] == "ADOPTED" and record.get("runtime_verification") in {"none", "unverified", None, ""}:
            return fail(f"ADOPTED capability lacks runtime verification: {cid}")
    print(f"PASS: capability lifecycle ({len(records)} capabilities, {len(events)} events)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
