#!/usr/bin/env python3
"""Validate release-gate and reliability preconditions."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_release_gate.py <skill-dir>")
    path = Path(argv[1]) / "reports" / "release-gate-report.json"
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(str(exc))
    release = report.get("release_gate", {})
    craft = report.get("craftsmanship_gate", {})
    confab = report.get("anti_confabulation_gate", {})
    syco = report.get("anti_sycophancy", {})
    bias = report.get("bias_gate", {})
    reliability = report.get("reliability_gate", {})
    if release.get("status") != "PASS" or release.get("allowed_to_package") is not True:
        return fail("release gate not PASS/allowed")
    if craft.get("status") != "PASS":
        return fail("craftsmanship gate not PASS")
    if confab.get("status") != "PASS" or confab.get("blocked_claims"):
        return fail("anti-confabulation gate blocked")
    if not isinstance(syco.get("score"), int) or syco.get("score") >= syco.get("threshold", 3):
        return fail("anti-sycophancy threshold exceeded")
    if syco.get("status") != "PASS":
        return fail("anti-sycophancy status not PASS")
    if bias.get("status") != "PASS":
        return fail("bias gate not PASS")
    required = {
        "source_registry_status": "PASS",
        "capability_lifecycle_status": "PASS",
        "review_evals_status": "PASS",
        "core_regression_status": "PASS",
        "pipeline_trace_status": "PASS",
        "enterprise_evaluator_status": "PASS",
        "installability_status": "PASS",
    }
    for key, expected in required.items():
        if reliability.get(key) != expected:
            return fail(f"reliability_gate.{key} must be {expected}")
    if report.get("final_decision") != "proceed_to_packaging":
        return fail("final_decision must be proceed_to_packaging")
    print("PASS: release gate")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
