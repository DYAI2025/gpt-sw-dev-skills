#!/usr/bin/env python3
"""Validate the Enterprise Code Review build trace and frozen artifact digest."""
from __future__ import annotations

import json
import sys
from pathlib import Path

from pipeline_ledger import artifact_digest, rebuild_state


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_pipeline_ledger.py <skill-dir>")
    root = Path(argv[1])
    events = root / "reports" / "build-events.jsonl"
    state_path = root / "reports" / "pipeline-state.json"
    if not events.exists() or not state_path.exists():
        return fail("build event/state report missing")
    try:
        current_digest = artifact_digest(root)
        state = rebuild_state(events, current_artifact_digest=current_digest)
        stored = json.loads(state_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(str(exc))
    if state != stored:
        return fail("stored pipeline state does not match deterministic replay")
    if not state.get("package_authorized"):
        return fail("pipeline is not package-authorized: " + "; ".join(state.get("errors", []) + state.get("missing_stages", [])))
    print(f"PASS: pipeline ledger ({state['event_count']} events, digest {state['draft_digest'][:12]})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
