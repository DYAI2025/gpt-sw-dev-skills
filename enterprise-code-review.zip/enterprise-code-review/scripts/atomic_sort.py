#!/usr/bin/env python3
"""Deterministically fingerprint, deduplicate, and order review findings without upgrading claims."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

SEVERITY_RANK = {"Blocker": 0, "Critical": 1, "Important": 2, "Minor": 3}
STATUS_RANK = {
    "VERIFIED": 0,
    "SUPPORTED": 1,
    "CANDIDATE": 2,
    "INCONCLUSIVE": 3,
    "PRE_EXISTING": 4,
    "ACCEPTED_RISK": 5,
    "REFUTED": 6,
    "DUPLICATE": 7,
}


def normalize_text(value: str) -> str:
    lowered = value.strip().lower()
    lowered = re.sub(r"\s+", " ", lowered)
    lowered = re.sub(r"[^a-z0-9_./:@ -]", "", lowered)
    return lowered


def finding_fingerprint(finding: dict[str, Any]) -> str:
    location = finding.get("location") or {}
    key = "|".join([
        normalize_text(str(finding.get("category", ""))),
        normalize_text(str(location.get("path", ""))),
        str(location.get("start_line") or ""),
        normalize_text(str(location.get("symbol") or "")),
        normalize_text(str(finding.get("claim") or finding.get("title") or "")),
    ])
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:24]


def sort_key(finding: dict[str, Any]) -> tuple[Any, ...]:
    location = finding.get("location") or {}
    return (
        SEVERITY_RANK.get(finding.get("severity"), 99),
        STATUS_RANK.get(finding.get("status"), 99),
        -int(finding.get("impact_priority", 0) or 0),
        str(location.get("path", "")),
        int(location.get("start_line") or 0),
        str(finding.get("finding_id", "")),
    )


def atomic_sort_report(report: dict[str, Any]) -> dict[str, Any]:
    out = copy.deepcopy(report)
    findings = out.get("findings", [])
    if not isinstance(findings, list):
        raise ValueError("findings must be an array")
    original_guard = {
        str(f.get("finding_id")): (f.get("severity"), f.get("status"), f.get("confidence"))
        for f in findings if isinstance(f, dict)
    }
    by_fingerprint: dict[str, list[dict[str, Any]]] = {}
    for finding in findings:
        if not isinstance(finding, dict):
            raise ValueError("every finding must be an object")
        fingerprint = finding.get("fingerprint") or finding_fingerprint(finding)
        finding["fingerprint"] = fingerprint
        finding.setdefault("corroborating_finding_ids", [])
        finding.setdefault("duplicate_of", None)
        by_fingerprint.setdefault(fingerprint, []).append(finding)

    conflicts: list[dict[str, Any]] = []
    normalized: list[dict[str, Any]] = []
    for fingerprint in sorted(by_fingerprint):
        group = sorted(by_fingerprint[fingerprint], key=sort_key)
        canonical = group[0]
        duplicate_ids: list[str] = []
        for duplicate in group[1:]:
            duplicate_id = str(duplicate.get("finding_id"))
            duplicate_ids.append(duplicate_id)
            duplicate["duplicate_of"] = canonical.get("finding_id")
            if duplicate.get("status") != "DUPLICATE":
                duplicate["pre_duplicate_status"] = duplicate.get("status")
            duplicate["status"] = "DUPLICATE"
            normalized.append(duplicate)
            canonical_prior_status = canonical.get("pre_duplicate_status", original_guard.get(str(canonical.get("finding_id")), (None, None, None))[1])
            duplicate_prior_status = duplicate.get("pre_duplicate_status", original_guard.get(duplicate_id, (None, None, None))[1])
            if duplicate.get("severity") != canonical.get("severity") or duplicate_prior_status != canonical_prior_status:
                conflicts.append({
                    "fingerprint": fingerprint,
                    "canonical_id": canonical.get("finding_id"),
                    "other_id": duplicate_id,
                    "severity_pair": [canonical.get("severity"), duplicate.get("severity")],
                    "status_pair_before_sort": [canonical_prior_status, duplicate_prior_status],
                    "resolution": "explicit_adjudication_required",
                })
        canonical["corroborating_finding_ids"] = sorted(set(canonical.get("corroborating_finding_ids", []) + duplicate_ids))
        normalized.append(canonical)

    normalized.sort(key=sort_key)
    for finding in normalized:
        fid = str(finding.get("finding_id"))
        before = original_guard.get(fid)
        if before is None:
            continue
        before_severity, before_status, before_confidence = before
        if finding.get("severity") != before_severity:
            raise AssertionError(f"Atomic Sort changed severity for {fid}")
        if finding.get("confidence") != before_confidence:
            raise AssertionError(f"Atomic Sort changed confidence for {fid}")
        if finding.get("status") != before_status and finding.get("status") != "DUPLICATE":
            raise AssertionError(f"Atomic Sort changed status for {fid}")
    out["findings"] = normalized
    out["atomic_sort"] = {
        "version": "1.0.0",
        "finding_count": len(normalized),
        "fingerprint_count": len(by_fingerprint),
        "duplicate_count": sum(1 for f in normalized if f.get("status") == "DUPLICATE"),
        "conflicts": conflicts,
        "invariants": [
            "severity_not_upgraded",
            "confidence_not_changed",
            "non_duplicate_status_not_changed",
            "stable_order",
        ],
    }
    return out


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    try:
        report = json.loads(Path(args.input).read_text(encoding="utf-8"))
        sorted_report = atomic_sort_report(report)
        Path(args.output).write_text(json.dumps(sorted_report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    print(f"PASS: Atomic Sort ({len(sorted_report.get('findings', []))} findings)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
