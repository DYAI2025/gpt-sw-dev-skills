#!/usr/bin/env python3
"""Render a validated code_review_report.json as deterministic Markdown."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

SEVERITIES = ("Blocker", "Critical", "Important", "Minor")


def esc(value: Any) -> str:
    return str(value).replace("|", "\\|").replace("\n", " ").strip()


def bullet_lines(values: list[Any], empty: str = "None recorded.") -> list[str]:
    if not values:
        return [f"- {empty}"]
    return [f"- {str(item).strip()}" for item in values]


def render(report: dict[str, Any]) -> str:
    snapshot = report["snapshot"]
    findings = report.get("findings", [])
    counts = {severity: sum(1 for f in findings if f.get("severity") == severity and f.get("status") not in {"REFUTED", "DUPLICATE"}) for severity in SEVERITIES}
    lines: list[str] = []
    lines.extend([
        "# Enterprise Code Review Report",
        "",
        "## 1. Review identity and exact scope",
        "",
        f"- Report ID: `{esc(report['report_id'])}`",
        f"- Mode / type: `{esc(report['review_mode'])}` / `{esc(report['review_type'])}`",
        f"- Target: `{esc(report.get('target', {}).get('identifier', 'unknown'))}`",
        f"- Snapshot: `{esc(snapshot.get('snapshot_id'))}`",
        f"- Digest: `{esc(snapshot.get('digest'))}`",
        f"- Base / head: `{esc(snapshot.get('base_ref'))}` / `{esc(snapshot.get('head_ref'))}`",
        f"- Coverage claim: {esc(report.get('scope', {}).get('coverage_claim', ''))}",
        "",
        "## 2. Verdict",
        "",
        f"**{esc(report['verdict'])}**",
        "",
        "## 3. Executive summary",
        "",
        str(report.get("executive_summary", "")).strip(),
        "",
        "## 4. Snapshot and capability manifest",
        "",
    ])
    for cap in report.get("capability_manifest", []):
        lines.append(f"- `{esc(cap.get('capability_id', cap.get('name', 'capability')))}`: {esc(cap.get('status', 'UNKNOWN'))} - {esc(cap.get('limitation', cap.get('limitations', '')))}")
    lines.extend(["", "### Snapshot limitations", ""])
    lines.extend(bullet_lines(snapshot.get("limitations", [])))
    lines.extend(["", "## 5. Coverage and impact inventory", ""])
    lines.append(f"- Files reviewed / visible: `{report.get('coverage', {}).get('reviewed_files', 0)}` / `{report.get('coverage', {}).get('total_visible_files', 0)}`")
    lines.append("")
    lines.append("| ID | Category | Status | Reason |")
    lines.append("|---|---|---|---|")
    for item in report.get("coverage", {}).get("impact_categories", []):
        lines.append(f"| {esc(item.get('id'))} | {esc(item.get('name'))} | {esc(item.get('status'))} | {esc(item.get('reason'))} |")
    lines.extend(["", "### Coverage limitations", ""])
    lines.extend(bullet_lines(report.get("coverage", {}).get("limitations", [])))
    lines.extend(["", "## 6. Findings summary", ""])
    lines.append("| Severity | Open count |")
    lines.append("|---|---:|")
    for severity in SEVERITIES:
        lines.append(f"| {severity} | {counts[severity]} |")
    lines.extend(["", "| ID | Severity | Status | Location | Title |", "|---|---|---|---|---|"])
    for finding in findings:
        loc = finding.get("location", {})
        loc_text = f"{loc.get('path')}:{loc.get('start_line') or '-'}"
        lines.append(f"| {esc(finding.get('finding_id'))} | {esc(finding.get('severity'))} | {esc(finding.get('status'))} | {esc(loc_text)} | {esc(finding.get('title'))} |")

    lines.extend(["", "## 7. Detailed findings", ""])
    if not findings:
        lines.append("No final findings were recorded. This does not imply absence of defects outside the reviewed scope.")
    for finding in findings:
        loc = finding.get("location", {})
        real = finding.get("real_world_impact", {})
        tech = finding.get("technical_impact", {})
        fix = finding.get("fix_strategy", {})
        lines.extend([
            f"### {esc(finding.get('finding_id'))} - {esc(finding.get('title'))}",
            "",
            f"- Severity / status / confidence: `{esc(finding.get('severity'))}` / `{esc(finding.get('status'))}` / `{esc(finding.get('confidence'))}/5`",
            f"- Category: `{esc(finding.get('category'))}`",
            f"- Location: `{esc(loc.get('path'))}:{esc(loc.get('start_line'))}-{esc(loc.get('end_line'))}` symbol `{esc(loc.get('symbol'))}`",
            f"- Claim: {esc(finding.get('claim'))}",
            f"- Failure scenario: {esc(finding.get('failure_scenario', ''))}",
            f"- Evidence: {', '.join(f'`{esc(x)}`' for x in finding.get('evidence_ids', []))}",
            f"- Counterevidence: {', '.join(f'`{esc(x)}`' for x in finding.get('counterevidence_ids', [])) or 'none recorded'}",
            "",
            "**Real-world impact**",
            "",
            f"- Affected actors: {', '.join(esc(x) for x in real.get('affected_actors', [])) or 'unknown'}",
            f"- Scenario: {esc(real.get('scenario'))}",
            f"- Consequence: {esc(real.get('consequence'))}",
            f"- Value effect: {esc(real.get('value_effect'))}",
            f"- Likelihood / reversibility / exploitability: `{esc(real.get('likelihood'))}` / `{esc(real.get('reversibility'))}` / `{esc(real.get('exploitability', 'NOT_APPLICABLE'))}`",
            "",
            "**Technical impact**",
            "",
            f"- Direct: {', '.join(esc(x) for x in tech.get('direct_components', [])) or 'none identified'}",
            f"- Propagated: {', '.join(esc(x) for x in tech.get('propagated_components', [])) or 'none identified'}",
            f"- Contracts: {', '.join(esc(x) for x in tech.get('contracts', [])) or 'none identified'}",
            f"- Data: {', '.join(esc(x) for x in tech.get('data', [])) or 'none identified'}",
            f"- Operations: {', '.join(esc(x) for x in tech.get('operations', [])) or 'none identified'}",
            f"- Blast radius: `{esc(tech.get('blast_radius'))}`",
            "",
            "**Fix strategy**",
            "",
            f"- Preferred: {esc(fix.get('preferred'))}",
            f"- Alternatives: {', '.join(esc(x) for x in fix.get('alternatives', [])) or 'none'}",
            f"- Tests: {', '.join(esc(x) for x in fix.get('tests', [])) or 'none'}",
            f"- Rollback: {esc(fix.get('rollback'))}",
            f"- Required revalidation: {', '.join(esc(x) for x in finding.get('required_revalidation', []))}",
            f"- Limitations: {', '.join(esc(x) for x in finding.get('limitations', [])) or 'none recorded'}",
            "",
        ])

    lines.extend(["## 8. Counterevidence and reviewer disagreements", ""])
    disagreements = report.get("reviewer_disagreements", [])
    if disagreements:
        for item in disagreements:
            lines.append(f"- `{esc(item.get('finding_id', item.get('id', 'disagreement')))}`: {esc(item.get('summary', item))}")
    else:
        lines.append("- None recorded. Absence of disagreement does not prove independent agreement.")

    lines.extend(["", "## 9. Test and tool evidence", ""])
    for run in report.get("tool_runs", []):
        lines.append(f"- `{esc(run.get('capability_id', run.get('tool', 'tool')))}`: `{esc(run.get('status'))}`; snapshot `{esc(run.get('snapshot_id'))}`; {esc(run.get('limitations', ''))}")
    lines.extend(["", "## 10. Real-world impact synthesis", ""])
    lines.extend(bullet_lines(report.get("residual_risks", []), "No residual risks recorded within scope; unknown external risks remain possible."))
    lines.extend(["", "## 11. Fix strategy and revalidation plan", ""])
    for item in report.get("fix_plan", []):
        lines.append(f"- `{esc(item.get('finding_id', 'plan'))}`: {esc(item.get('strategy', item))}")
    if not report.get("fix_plan"):
        lines.append("- No consolidated fix plan recorded.")

    lines.extend(["", "## 12. Residual uncertainty and boundaries", "", "### Assumptions", ""])
    lines.extend(bullet_lines(report.get("assumptions", [])))
    lines.extend(["", "### MISSING", ""])
    lines.extend(bullet_lines(report.get("missing", [])))
    lines.extend(["", "### SOURCE_NEEDED", ""])
    lines.extend(bullet_lines(report.get("source_needed", [])))
    lines.extend(["", "## 13. Machine-readable artifacts", ""])
    policy = report.get("artifact_policy", {})
    for key in ("markdown", "json", "sarif", "evidence_jsonl", "atoms_json"):
        lines.append(f"- {key}: `{esc(policy.get(key))}`")
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    try:
        report = json.loads(Path(args.input).read_text(encoding="utf-8"))
        markdown = render(report)
        Path(args.output).write_text(markdown, encoding="utf-8")
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    print(f"PASS: rendered {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
