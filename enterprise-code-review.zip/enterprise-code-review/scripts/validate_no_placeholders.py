#!/usr/bin/env python3
"""Reject unresolved generation placeholders in production files."""
from __future__ import annotations

import re
import sys
from pathlib import Path

PATTERNS = [
    re.compile(r"\{\{[A-Z_][A-Z0-9_]*\}\}"),
    re.compile(r"\{[A-Z_][A-Z0-9_]*\}"),
    re.compile(r"\b(?:TODO|TBD|FIXME|INSERT_HERE|PLACEHOLDER)\b"),
]
IGNORE = {"assets", "evals", "reports", "tests"}


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_no_placeholders.py <skill-dir>")
    root = Path(argv[1])
    hits: list[str] = []
    self_path = Path(__file__).resolve()
    for path in root.rglob("*"):
        if not path.is_file() or path.resolve() == self_path or set(path.relative_to(root).parts) & IGNORE:
            continue
        if path.suffix.lower() not in {".md", ".py", ".yaml", ".yml", ".json", ".dot"} and path.name != "SKILL.md":
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for pattern in PATTERNS:
            for match in pattern.finditer(text):
                hits.append(f"{path.relative_to(root)}:{match.group(0)}")
    if hits:
        return fail("unresolved placeholders: " + ", ".join(hits[:20]))
    print("PASS: no unresolved production placeholders")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
