#!/usr/bin/env python3
"""Re-run review evals and compare them with the stored result report."""
from __future__ import annotations

import json
import sys
from pathlib import Path

from run_review_evals import run_case


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_review_evals.py <skill-dir>")
    root = Path(argv[1])
    try:
        cases = json.loads((root / "evals" / "review_cases.json").read_text(encoding="utf-8"))
        results = [run_case(root, case) for case in cases]
        observed = {
            "evaluation_type": "deterministic_review_contract",
            "runtime_model_behavior_tested": False,
            "passed": all(item["status"] == "PASS" for item in results),
            "case_count": len(results),
            "results": results,
            "limitations": [
                "Validates deterministic report contracts and utilities, not stochastic reviewer recall or precision.",
                "No external repository, connector, compiler, scanner, or second model is exercised by this suite."
            ]
        }
        stored = json.loads((root / "reports" / "review-eval-results.json").read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(str(exc))
    if observed != stored:
        return fail("stored review eval results differ from deterministic rerun")
    if not observed["passed"]:
        return fail("review evals failed")
    print(f"PASS: review evals ({len(results)} cases)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
