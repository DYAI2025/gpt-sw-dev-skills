#!/usr/bin/env python3
"""Validate the semantic hard gates of an Enterprise Code Review JSON report."""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

SEVERITIES = {"Blocker", "Critical", "Important", "Minor"}
STATUSES = {"CANDIDATE", "SUPPORTED", "VERIFIED", "REFUTED", "INCONCLUSIVE", "PRE_EXISTING", "DUPLICATE", "ACCEPTED_RISK"}
VERDICTS = {"BLOCKED", "CHANGES_REQUIRED", "ACCEPTED_WITH_RISK", "READY_FOR_MERGE", "INCONCLUSIVE"}
MODES = {"GITHUB", "LOCAL", "PASTED"}
NON_MODEL_EVIDENCE = {
    "SOURCE_INSPECTED", "CONTRACT_OR_SPEC", "STATIC_TOOL", "COMPILER_OR_BUILD",
    "UNIT_TEST", "INTEGRATION_TEST", "CONTRACT_TEST", "MUTATION_TEST",
    "FUZZ_COUNTEREXAMPLE", "REAL_BOUNDARY_SMOKE", "PRODUCTION_OBSERVED", "HUMAN_CONFIRMED",
}
REQUIRED_TOP = {
    "schema_version", "report_id", "generated_at", "review_mode", "review_type", "target",
    "snapshot", "scope", "verdict", "executive_summary", "capability_manifest", "coverage",
    "findings", "evidence", "reviewer_disagreements", "tool_runs", "fix_plan", "residual_risks",
    "assumptions", "missing", "source_needed", "artifact_policy",
}
REQUIRED_FINDING = {
    "finding_id", "category", "severity", "status", "title", "claim", "snapshot_id", "location",
    "evidence_ids", "counterevidence_ids", "independence_groups", "real_world_impact",
    "technical_impact", "confidence", "limitations", "fix_strategy", "required_revalidation", "origin",
}


def errors_for_report(report: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    missing_top = REQUIRED_TOP - set(report)
    if missing_top:
        errors.append("missing top fields: " + ", ".join(sorted(missing_top)))
        return errors
    if report.get("schema_version") != "1.0.0":
        errors.append("schema_version must be 1.0.0")
    if report.get("review_mode") not in MODES:
        errors.append("invalid review_mode")
    if report.get("verdict") not in VERDICTS:
        errors.append("invalid verdict")
    snapshot = report.get("snapshot")
    if not isinstance(snapshot, dict):
        errors.append("snapshot must be object")
        snapshot = {}
    for key in ("snapshot_id", "kind", "digest", "stale", "limitations"):
        if key not in snapshot:
            errors.append(f"snapshot.{key} missing")
    digest = str(snapshot.get("digest", ""))
    if len(digest) < 16 or not re.fullmatch(r"[a-zA-Z0-9:_-]+", digest):
        errors.append("snapshot.digest must be a stable digest-like identifier")
    if report.get("verdict") == "READY_FOR_MERGE" and snapshot.get("stale") is True:
        errors.append("READY_FOR_MERGE prohibited for stale snapshot")
    if report.get("review_mode") == "PASTED" and report.get("verdict") == "READY_FOR_MERGE":
        errors.append("READY_FOR_MERGE prohibited for pasted-code mode")
    if report.get("review_mode") == "PASTED":
        combined_limits = " ".join(str(x).lower() for x in (snapshot.get("limitations") or []) + (report.get("coverage", {}).get("limitations") or []))
        required_words = ("runtime", "caller", "merge")
        for word in required_words:
            if word not in combined_limits:
                errors.append(f"pasted-code limitations must mention {word}")

    evidence = report.get("evidence")
    if not isinstance(evidence, list):
        errors.append("evidence must be array")
        evidence = []
    evidence_by_id: dict[str, dict[str, Any]] = {}
    for index, item in enumerate(evidence):
        if not isinstance(item, dict):
            errors.append(f"evidence[{index}] must be object")
            continue
        eid = item.get("evidence_id")
        if not isinstance(eid, str) or not eid:
            errors.append(f"evidence[{index}].evidence_id missing")
            continue
        if eid in evidence_by_id:
            errors.append(f"duplicate evidence_id: {eid}")
        evidence_by_id[eid] = item
        for key in ("source_type", "source_role", "location", "snapshot_id", "method", "observed_fact", "evidence_class", "verification_status", "confidence", "limitations", "independence_group"):
            if key not in item:
                errors.append(f"evidence {eid} missing {key}")
        if item.get("snapshot_id") != snapshot.get("snapshot_id"):
            errors.append(f"evidence {eid} snapshot mismatch")
        if item.get("confidence") not in {1, 2, 3, 4, 5}:
            errors.append(f"evidence {eid} confidence must be 1-5")

    findings = report.get("findings")
    if not isinstance(findings, list):
        errors.append("findings must be array")
        findings = []
    finding_ids: set[str] = set()
    unresolved_blocker_critical = False
    for index, finding in enumerate(findings):
        if not isinstance(finding, dict):
            errors.append(f"finding[{index}] must be object")
            continue
        fid = str(finding.get("finding_id", ""))
        missing = REQUIRED_FINDING - set(finding)
        if missing:
            errors.append(f"finding {fid or index} missing: {', '.join(sorted(missing))}")
            continue
        if not fid:
            errors.append(f"finding[{index}] finding_id empty")
        elif fid in finding_ids:
            errors.append(f"duplicate finding_id: {fid}")
        finding_ids.add(fid)
        if finding.get("severity") not in SEVERITIES:
            errors.append(f"finding {fid} invalid severity")
        if finding.get("status") not in STATUSES:
            errors.append(f"finding {fid} invalid status")
        if finding.get("snapshot_id") != snapshot.get("snapshot_id"):
            errors.append(f"finding {fid} snapshot mismatch")
        if finding.get("confidence") not in {1, 2, 3, 4, 5}:
            errors.append(f"finding {fid} confidence must be 1-5")
        location = finding.get("location")
        if not isinstance(location, dict) or not str(location.get("path", "")):
            errors.append(f"finding {fid} location.path missing")
        evidence_ids = finding.get("evidence_ids")
        if not isinstance(evidence_ids, list) or not evidence_ids:
            errors.append(f"finding {fid} requires evidence_ids")
            evidence_ids = []
        missing_evidence = [eid for eid in evidence_ids if eid not in evidence_by_id]
        if missing_evidence:
            errors.append(f"finding {fid} references missing evidence: {', '.join(missing_evidence)}")
        classes = {evidence_by_id[eid].get("evidence_class") for eid in evidence_ids if eid in evidence_by_id}
        if finding.get("severity") in {"Blocker", "Critical"} and not (classes & NON_MODEL_EVIDENCE):
            errors.append(f"finding {fid} {finding.get('severity')} cannot be MODEL_ONLY")
        if finding.get("status") == "VERIFIED" and not (classes & NON_MODEL_EVIDENCE):
            errors.append(f"finding {fid} VERIFIED requires non-model evidence")
        if finding.get("status") == "ACCEPTED_RISK" and "HUMAN_CONFIRMED" not in classes:
            errors.append(f"finding {fid} ACCEPTED_RISK requires HUMAN_CONFIRMED evidence")
        real = finding.get("real_world_impact")
        for key in ("affected_actors", "scenario", "consequence", "likelihood", "reversibility", "value_effect"):
            if not isinstance(real, dict) or key not in real:
                errors.append(f"finding {fid} real_world_impact.{key} missing")
        tech = finding.get("technical_impact")
        for key in ("direct_components", "propagated_components", "contracts", "data", "operations", "blast_radius"):
            if not isinstance(tech, dict) or key not in tech:
                errors.append(f"finding {fid} technical_impact.{key} missing")
        fix = finding.get("fix_strategy")
        for key in ("preferred", "alternatives", "tests", "rollback"):
            if not isinstance(fix, dict) or key not in fix:
                errors.append(f"finding {fid} fix_strategy.{key} missing")
        if not finding.get("required_revalidation"):
            errors.append(f"finding {fid} required_revalidation empty")
        if finding.get("severity") in {"Blocker", "Critical"} and finding.get("status") not in {"REFUTED", "DUPLICATE", "ACCEPTED_RISK"}:
            unresolved_blocker_critical = True

    if report.get("verdict") == "READY_FOR_MERGE" and unresolved_blocker_critical:
        errors.append("READY_FOR_MERGE prohibited with unresolved Blocker/Critical findings")
    if report.get("verdict") == "ACCEPTED_WITH_RISK":
        if not any(f.get("status") == "ACCEPTED_RISK" for f in findings if isinstance(f, dict)):
            errors.append("ACCEPTED_WITH_RISK requires at least one ACCEPTED_RISK finding")
    if report.get("review_mode") in {"GITHUB", "LOCAL"}:
        categories = report.get("coverage", {}).get("impact_categories")
        if not isinstance(categories, list) or len(categories) != 24:
            errors.append("repository modes require exactly 24 impact category records")
        else:
            for idx, category in enumerate(categories):
                if not isinstance(category, dict) or not all(key in category for key in ("id", "name", "status", "reason", "evidence_ids")):
                    errors.append(f"impact category {idx} missing required fields")
        if report.get("verdict") == "READY_FOR_MERGE":
            blocking_statuses = {"PARTIAL", "CAPABILITY_MISSING", "NO_EVIDENCE", "BOUNDARY_EXIT"}
            unresolved = [c.get("id") for c in categories if c.get("status") in blocking_statuses and c.get("required_for_verdict", False)] if isinstance(categories, list) else []
            if unresolved:
                errors.append("READY_FOR_MERGE has unresolved required impact categories: " + ", ".join(str(x) for x in unresolved))
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("report")
    args = parser.parse_args()
    try:
        value = json.loads(Path(args.report).read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("report root must be object")
        errors = errors_for_report(value)
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    if errors:
        for error in errors:
            print(f"FAIL: {error}", file=sys.stderr)
        return 1
    print(f"PASS: review report {value.get('report_id')} ({len(value.get('findings', []))} findings)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
