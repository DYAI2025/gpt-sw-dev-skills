#!/usr/bin/env python3
"""Deterministic hash-chained build pipeline ledger for Enterprise Code Review."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCHEMA_VERSION = 1
GENESIS = "GENESIS"
FORBIDDEN_DATA_KEYS = {
    "prompt", "prompts", "document", "documents", "body", "content",
    "credential", "credentials", "secret", "secrets", "token", "tokens",
    "tool_arguments", "arguments", "model_response", "response",
    "private_key", "api_key", "password",
}
PRE_DRAFT_REQUIRED = (
    "INTAKE_COMPLETED",
    "RESEARCH_COMPLETED",
    "CAPABILITY_DECISION",
    "ARCHITECTURE_GATE_PASSED",
)
POST_DRAFT_REQUIRED = (
    "RELEASE_GATE_PASSED",
    "EVALUATOR_PASSED",
    "VALIDATION_PASSED",
    "PACKAGE_AUTHORIZED",
)
CAPABILITY_EVENTS = {"CAPABILITY_DECISION_COMPLETED", "CAPABILITY_DECISION_SKIPPED"}
BLOCKING_SUFFIXES = ("_BLOCKED", "_FAILED", "_REVISE")
EXCLUDED_TOP_LEVEL = {"reports", "dist", ".git", "__pycache__"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo"}


def _canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _event_hash(event: dict[str, Any]) -> str:
    payload = {k: v for k, v in event.items() if k != "event_hash"}
    return _sha256_text(_canonical_json(payload))


def _contains_forbidden_key(value: Any) -> str | None:
    if isinstance(value, dict):
        for key, child in value.items():
            if str(key).lower() in FORBIDDEN_DATA_KEYS:
                return str(key)
            nested = _contains_forbidden_key(child)
            if nested:
                return nested
    elif isinstance(value, list):
        for child in value:
            nested = _contains_forbidden_key(child)
            if nested:
                return nested
    return None


def read_events(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    events: list[dict[str, Any]] = []
    for line_no, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not raw.strip():
            continue
        try:
            event = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid JSON at line {line_no}: {exc}") from exc
        if not isinstance(event, dict):
            raise ValueError(f"event at line {line_no} must be an object")
        events.append(event)
    return events


def verify_chain(events: list[dict[str, Any]]) -> None:
    prev_hash = GENESIS
    for index, event in enumerate(events, start=1):
        required = {"schema_version", "seq", "ts", "run_id", "event_type", "artifact_digest", "evidence_ids", "data", "prev_hash", "event_hash"}
        missing = required - set(event)
        if missing:
            raise ValueError(f"event {index} missing fields: {', '.join(sorted(missing))}")
        if event["schema_version"] != SCHEMA_VERSION:
            raise ValueError(f"event {index} unsupported schema_version")
        if event["seq"] != index:
            raise ValueError(f"event sequence gap at {index}: got {event['seq']}")
        if event["prev_hash"] != prev_hash:
            raise ValueError(f"event {index} prev_hash mismatch")
        forbidden = _contains_forbidden_key(event.get("data", {}))
        if forbidden:
            raise ValueError(f"event {index} contains forbidden data key: {forbidden}")
        calculated = _event_hash(event)
        if event["event_hash"] != calculated:
            raise ValueError(f"event {index} hash mismatch")
        prev_hash = event["event_hash"]


def _atomic_write_lines(path: Path, lines: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text("".join(lines), encoding="utf-8")
    os.replace(tmp, path)


def append_event(
    path: Path,
    event_type: str,
    *,
    run_id: str,
    data: dict[str, Any] | None = None,
    artifact_digest: str | None = None,
    evidence_ids: list[str] | None = None,
    ts: str | None = None,
) -> dict[str, Any]:
    data = data or {}
    forbidden = _contains_forbidden_key(data)
    if forbidden:
        raise ValueError(f"forbidden data key: {forbidden}")
    events = read_events(path)
    verify_chain(events)
    prev_hash = events[-1]["event_hash"] if events else GENESIS
    event: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "seq": len(events) + 1,
        "ts": ts or datetime.now(timezone.utc).isoformat(),
        "run_id": run_id,
        "event_type": event_type,
        "artifact_digest": artifact_digest,
        "evidence_ids": list(evidence_ids or []),
        "data": data,
        "prev_hash": prev_hash,
    }
    event["event_hash"] = _event_hash(event)
    events.append(event)
    _atomic_write_lines(path, [_canonical_json(item) + "\n" for item in events])
    return event


def artifact_digest(root: Path) -> str:
    """Hash build-controlled files; exclude reports/log outputs to avoid self-reference."""
    if not root.is_dir():
        raise ValueError(f"artifact root is not a directory: {root}")
    digest = hashlib.sha256()
    files: list[Path] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if rel.parts and rel.parts[0] in EXCLUDED_TOP_LEVEL:
            continue
        if any(part == "__pycache__" for part in rel.parts):
            continue
        if path.suffix in EXCLUDED_SUFFIXES:
            continue
        files.append(path)
    for path in sorted(files, key=lambda p: p.relative_to(root).as_posix()):
        rel = path.relative_to(root).as_posix()
        digest.update(rel.encode("utf-8"))
        digest.update(b"\0")
        digest.update(hashlib.sha256(path.read_bytes()).digest())
        digest.update(b"\0")
    return digest.hexdigest()


def rebuild_state(path: Path, *, run_id: str | None = None, current_artifact_digest: str | None = None) -> dict[str, Any]:
    events = read_events(path)
    verify_chain(events)
    if not events:
        return {
            "schema_version": 1,
            "run_id": run_id,
            "event_count": 0,
            "last_event_hash": None,
            "draft_digest": None,
            "completed_stages": [],
            "missing_stages": list(PRE_DRAFT_REQUIRED) + ["DRAFT_FROZEN"] + list(POST_DRAFT_REQUIRED),
            "errors": ["NO_EVENTS"],
            "package_authorized": False,
        }
    selected_run = run_id or events[-1]["run_id"]
    run_events = [e for e in events if e["run_id"] == selected_run]
    if not run_events:
        raise ValueError(f"run_id not found: {selected_run}")

    completed: list[str] = []
    errors: list[str] = []
    seen_types = {e["event_type"] for e in run_events}
    for required in PRE_DRAFT_REQUIRED:
        if required == "CAPABILITY_DECISION":
            if seen_types & CAPABILITY_EVENTS:
                completed.append("CAPABILITY_DECISION")
            else:
                errors.append("MISSING_CAPABILITY_DECISION")
        elif required in seen_types:
            completed.append(required)
        else:
            errors.append(f"MISSING_{required}")

    frozen_events = [e for e in run_events if e["event_type"] == "DRAFT_FROZEN"]
    if not frozen_events:
        errors.append("MISSING_DRAFT_FROZEN")
        draft_digest = None
        frozen_seq = None
    else:
        frozen = frozen_events[-1]
        draft_digest = frozen.get("artifact_digest")
        frozen_seq = frozen["seq"]
        completed.append("DRAFT_FROZEN")
        if not isinstance(draft_digest, str) or len(draft_digest) != 64:
            errors.append("INVALID_DRAFT_DIGEST")

    if current_artifact_digest is not None and draft_digest is not None and current_artifact_digest != draft_digest:
        errors.append("STALE_ARTIFACT_DIGEST")

    next_required = 0
    if frozen_seq is not None and draft_digest:
        for event in run_events:
            if event["seq"] <= frozen_seq:
                continue
            et = event["event_type"]
            if et.endswith(BLOCKING_SUFFIXES):
                errors.append(f"BLOCKING_EVENT:{et}")
                continue
            if et not in POST_DRAFT_REQUIRED:
                continue
            if event.get("artifact_digest") != draft_digest:
                errors.append(f"STALE_GATE_DIGEST:{et}")
                continue
            expected = POST_DRAFT_REQUIRED[next_required] if next_required < len(POST_DRAFT_REQUIRED) else None
            if et != expected:
                errors.append(f"INVALID_GATE_ORDER:{et}:expected:{expected}")
                continue
            completed.append(et)
            next_required += 1

    missing_post = [stage for stage in POST_DRAFT_REQUIRED if stage not in completed]
    package_authorized = not errors and not missing_post and "PACKAGE_AUTHORIZED" in completed
    return {
        "schema_version": 1,
        "run_id": selected_run,
        "event_count": len(run_events),
        "last_event_hash": events[-1]["event_hash"],
        "draft_digest": draft_digest,
        "completed_stages": completed,
        "missing_stages": missing_post,
        "errors": errors,
        "package_authorized": package_authorized,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_digest = sub.add_parser("digest")
    p_digest.add_argument("artifact_root")

    p_append = sub.add_parser("append")
    p_append.add_argument("events")
    p_append.add_argument("event_type")
    p_append.add_argument("--run-id", required=True)
    p_append.add_argument("--artifact-root")
    p_append.add_argument("--data-json", default="{}")

    p_rebuild = sub.add_parser("rebuild")
    p_rebuild.add_argument("events")
    p_rebuild.add_argument("--run-id")
    p_rebuild.add_argument("--artifact-root")
    p_rebuild.add_argument("--write")

    args = parser.parse_args()
    if args.cmd == "digest":
        print(artifact_digest(Path(args.artifact_root)))
        return 0
    if args.cmd == "append":
        digest = artifact_digest(Path(args.artifact_root)) if args.artifact_root else None
        data = json.loads(args.data_json)
        event = append_event(Path(args.events), args.event_type, run_id=args.run_id, data=data, artifact_digest=digest)
        print(_canonical_json(event))
        return 0
    if args.cmd == "rebuild":
        current = artifact_digest(Path(args.artifact_root)) if args.artifact_root else None
        state = rebuild_state(Path(args.events), run_id=args.run_id, current_artifact_digest=current)
        text = json.dumps(state, indent=2, ensure_ascii=False) + "\n"
        if args.write:
            Path(args.write).write_text(text, encoding="utf-8")
        print(text, end="")
        return 0 if state["package_authorized"] or "PACKAGE_AUTHORIZED" in state["missing_stages"] else 1
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
