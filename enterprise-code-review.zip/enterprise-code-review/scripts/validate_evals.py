#!/usr/bin/env python3
"""Validate trigger, output, and review eval definitions."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_evals.py <skill-dir>")
    root = Path(argv[1])
    try:
        triggers = load(root / "evals" / "trigger_queries.json")
        outputs = load(root / "evals" / "output_evals.json")
        cases = load(root / "evals" / "review_cases.json")
    except Exception as exc:
        return fail(str(exc))
    if not isinstance(triggers, list) or len(triggers) < 8:
        return fail("trigger_queries.json requires at least 8 cases")
    if not any(x.get("should_trigger") is True for x in triggers if isinstance(x, dict)) or not any(x.get("should_trigger") is False for x in triggers if isinstance(x, dict)):
        return fail("trigger cases require true and false cases")
    for item in triggers:
        if not all(key in item for key in ("query", "should_trigger", "reason")):
            return fail("invalid trigger item")
    if not isinstance(outputs, list) or len(outputs) < 6:
        return fail("output_evals.json requires at least 6 cases")
    for item in outputs:
        if not all(key in item for key in ("id", "prompt", "expected_properties", "failure_modes")):
            return fail("invalid output eval item")
    if not isinstance(cases, list) or len(cases) < 6:
        return fail("review_cases.json requires at least 6 deterministic cases")
    if not any(item.get("expected_valid") is False for item in cases):
        return fail("review cases require negative cases")
    required_kinds = {"valid_report", "model_only_critical", "ready_with_blocker", "pasted_ready", "atomic_sort", "sarif_roundtrip"}
    kinds = {item.get("kind") for item in cases}
    if not required_kinds.issubset(kinds):
        return fail("review cases missing required kinds")
    print(f"PASS: eval definitions ({len(triggers)} triggers, {len(outputs)} outputs, {len(cases)} review cases)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
