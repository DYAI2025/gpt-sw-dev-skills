#!/usr/bin/env python3
"""Run deterministic positive and negative Enterprise Code Review evals."""
from __future__ import annotations

import argparse
import json
import tempfile
from pathlib import Path
from typing import Any

from atomic_sort import atomic_sort_report
from report_to_sarif import to_sarif
from validate_review_report import errors_for_report


def run_case(root: Path, case: dict[str, Any]) -> dict[str, Any]:
    fixture = root / case["fixture"]
    report = json.loads(fixture.read_text(encoding="utf-8"))
    kind = case["kind"]
    expected_valid = bool(case["expected_valid"])
    details: dict[str, Any] = {}
    if kind == "atomic_sort":
        first = atomic_sort_report(report)
        second = atomic_sort_report(first)
        first_semantic = json.dumps(first, sort_keys=True)
        second_semantic = json.dumps(second, sort_keys=True)
        valid = first_semantic == second_semantic
        details = {
            "idempotent": valid,
            "duplicate_count": first.get("atomic_sort", {}).get("duplicate_count"),
            "conflict_count": len(first.get("atomic_sort", {}).get("conflicts", [])),
        }
        valid = valid and details["duplicate_count"] == 1 and details["conflict_count"] >= 1
    elif kind == "sarif_roundtrip":
        report_errors = errors_for_report(report)
        sarif = to_sarif(report)
        runs = sarif.get("runs", [])
        results = runs[0].get("results", []) if runs else []
        valid = not report_errors and sarif.get("version") == "2.1.0" and len(results) == 1
        details = {"report_errors": report_errors, "sarif_results": len(results)}
    else:
        report_errors = errors_for_report(report)
        valid = not report_errors
        details = {"errors": report_errors}
    passed = valid == expected_valid
    return {
        "id": case["id"],
        "kind": kind,
        "expected_valid": expected_valid,
        "observed_valid": valid,
        "status": "PASS" if passed else "FAIL",
        "details": details,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_dir")
    parser.add_argument("--write")
    args = parser.parse_args()
    root = Path(args.skill_dir)
    cases = json.loads((root / "evals" / "review_cases.json").read_text(encoding="utf-8"))
    results = [run_case(root, case) for case in cases]
    output = {
        "evaluation_type": "deterministic_review_contract",
        "runtime_model_behavior_tested": False,
        "passed": all(item["status"] == "PASS" for item in results),
        "case_count": len(results),
        "results": results,
        "limitations": [
            "Validates deterministic report contracts and utilities, not stochastic reviewer recall or precision.",
            "No external repository, connector, compiler, scanner, or second model is exercised by this suite."
        ]
    }
    text = json.dumps(output, indent=2, sort_keys=True) + "\n"
    if args.write:
        Path(args.write).write_text(text, encoding="utf-8")
    print(text, end="")
    return 0 if output["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
