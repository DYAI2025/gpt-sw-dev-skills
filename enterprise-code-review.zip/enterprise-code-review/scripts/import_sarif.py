#!/usr/bin/env python3
"""Convert SARIF results into bounded review finding candidates without severity inflation."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any


def safe_text(value: Any) -> str:
    if isinstance(value, dict):
        return str(value.get("text") or value.get("markdown") or "")
    return str(value or "")


def sarif_to_packet(sarif: dict[str, Any], snapshot_id: str, reviewer_id: str) -> dict[str, Any]:
    findings: list[dict[str, Any]] = []
    evidence: list[dict[str, Any]] = []
    counter = 0
    for run_index, run in enumerate(sarif.get("runs", [])):
        driver = run.get("tool", {}).get("driver", {})
        tool_name = driver.get("name", "SARIF tool")
        tool_version = driver.get("version") or driver.get("semanticVersion")
        rules = {rule.get("id"): rule for rule in driver.get("rules", []) if isinstance(rule, dict)}
        for result in run.get("results", []):
            counter += 1
            rule_id = str(result.get("ruleId") or f"rule-{counter}")
            message = safe_text(result.get("message")) or rule_id
            location = (result.get("locations") or [{}])[0].get("physicalLocation", {})
            artifact = location.get("artifactLocation", {})
            region = location.get("region", {})
            path = str(artifact.get("uri") or "unknown")
            start_line = region.get("startLine")
            end_line = region.get("endLine") or start_line
            level = str(result.get("level") or "warning")
            severity = "Minor" if level in {"note", "none"} else "Important"
            fingerprint_basis = f"{tool_name}|{rule_id}|{path}|{start_line}|{message}"
            fingerprint = hashlib.sha256(fingerprint_basis.encode("utf-8")).hexdigest()[:24]
            eid = f"E-SARIF-{counter:04d}"
            fid = f"SARIF-{counter:04d}"
            evidence.append({
                "evidence_id": eid,
                "source_type": "derived",
                "source_role": "static_analyzer_result",
                "location": path,
                "revision": None,
                "content_hash": None,
                "snapshot_id": snapshot_id,
                "pointer": f"run:{run_index}/result:{counter - 1}",
                "tool_or_method": tool_name,
                "method": "SARIF import",
                "version": tool_version,
                "configuration_hash": None,
                "execution_context": "imported SARIF; execution context must be supplied separately",
                "observed_fact": message,
                "evidence_class": "STATIC_TOOL",
                "verification_status": "SUPPORTED",
                "confidence": 3,
                "limitations": ["Imported tool result; configuration, execution success, and false-positive status require verification"],
                "independence_group": f"sarif:{tool_name}:{run_index}",
                "timestamp": None,
            })
            rule = rules.get(rule_id, {})
            help_text = safe_text(rule.get("help")) or safe_text(rule.get("shortDescription"))
            findings.append({
                "finding_id": fid,
                "fingerprint": fingerprint,
                "category": "static_analysis",
                "severity": severity,
                "status": "SUPPORTED",
                "title": f"{rule_id}: {message[:120]}",
                "claim": message,
                "snapshot_id": snapshot_id,
                "location": {"path": path, "start_line": start_line, "end_line": end_line, "symbol": None},
                "evidence_ids": [eid],
                "counterevidence_ids": [],
                "independence_groups": [f"sarif:{tool_name}:{run_index}"],
                "failure_scenario": "Requires code-context review and, where possible, reproduction.",
                "real_world_impact": {
                    "affected_actors": ["SOURCE_NEEDED"],
                    "scenario": "SOURCE_NEEDED: analyzer result requires contextual validation",
                    "consequence": "SOURCE_NEEDED: tool result alone does not establish consequence",
                    "likelihood": "UNKNOWN",
                    "reversibility": "UNKNOWN",
                    "value_effect": "Unverified until adjudicated",
                    "exploitability": "UNKNOWN"
                },
                "technical_impact": {
                    "direct_components": [path],
                    "propagated_components": [],
                    "contracts": [],
                    "data": [],
                    "operations": [],
                    "blast_radius": "LOCAL"
                },
                "confidence": 3,
                "limitations": ["SARIF severity was conservatively mapped; no Critical/Blocker promotion", help_text] if help_text else ["SARIF severity was conservatively mapped; no Critical/Blocker promotion"],
                "fix_strategy": {
                    "preferred": "Validate the result against source context and the rule guidance before choosing a fix.",
                    "alternatives": [],
                    "tests": ["Add or run a regression check that can fail on the reported condition"],
                    "rollback": "Revert only the bounded remediation if validation shows regression"
                },
                "required_revalidation": ["source review", "tool rerun on exact snapshot"],
                "origin": "TOOL_IMPORTED",
                "duplicate_of": None,
                "corroborating_finding_ids": [],
                "reviewer_ids": [reviewer_id],
                "impact_priority": 2
            })
    return {"reviewer_id": reviewer_id, "snapshot_id": snapshot_id, "findings": findings, "evidence": evidence}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("sarif")
    parser.add_argument("output")
    parser.add_argument("--snapshot-id", required=True)
    parser.add_argument("--reviewer-id", default="sarif-import")
    args = parser.parse_args()
    try:
        sarif = json.loads(Path(args.sarif).read_text(encoding="utf-8"))
        packet = sarif_to_packet(sarif, args.snapshot_id, args.reviewer_id)
        Path(args.output).write_text(json.dumps(packet, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    print(f"PASS: imported {len(packet['findings'])} SARIF results")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
