#!/usr/bin/env python3
"""Validate, verify, and query claim-near evidence records without changing authority."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

REQUIRED = {
    "evidence_id", "source_type", "source_role", "location", "snapshot_id", "method",
    "observed_fact", "evidence_class", "verification_status", "confidence", "limitations",
    "independence_group",
}
SOURCE_TYPES = {"primary", "secondary", "user_provided", "derived", "uncertain"}


def load_records(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for line_no, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not raw.strip():
            continue
        try:
            value = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid JSON line {line_no}: {exc}") from exc
        if not isinstance(value, dict):
            raise ValueError(f"line {line_no} must be object")
        records.append(value)
    return records


def validate(records: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    ids: set[str] = set()
    for index, record in enumerate(records, start=1):
        eid = str(record.get("evidence_id", ""))
        missing = REQUIRED - set(record)
        if missing:
            errors.append(f"record {index} missing: {', '.join(sorted(missing))}")
        if not eid:
            errors.append(f"record {index} evidence_id empty")
        elif eid in ids:
            errors.append(f"duplicate evidence_id: {eid}")
        ids.add(eid)
        if record.get("source_type") not in SOURCE_TYPES:
            errors.append(f"{eid} invalid source_type")
        if record.get("confidence") not in {1, 2, 3, 4, 5}:
            errors.append(f"{eid} confidence must be 1-5")
        if not isinstance(record.get("limitations"), list):
            errors.append(f"{eid} limitations must be array")
        if record.get("verification_status") == "VERIFIED" and record.get("evidence_class") == "MODEL_ONLY":
            errors.append(f"{eid} MODEL_ONLY cannot be VERIFIED")
        if not str(record.get("snapshot_id", "")):
            errors.append(f"{eid} snapshot_id missing")
    return errors


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_local(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for record in records:
        location = Path(str(record.get("location", "")))
        expected = record.get("content_hash")
        if expected and location.is_file():
            actual = sha256_file(location)
            output.append({"evidence_id": record["evidence_id"], "status": "MATCH" if actual == expected else "MISMATCH", "expected": expected, "actual": actual})
        elif expected:
            output.append({"evidence_id": record["evidence_id"], "status": "LOCATION_UNAVAILABLE", "expected": expected, "actual": None})
        else:
            output.append({"evidence_id": record["evidence_id"], "status": "NO_HASH", "expected": None, "actual": None})
    return output


def tokenize(value: str) -> set[str]:
    return {token for token in re.findall(r"[a-z0-9_./:@-]+", value.lower()) if len(token) > 1}


def query(records: list[dict[str, Any]], text: str, limit: int) -> list[dict[str, Any]]:
    query_tokens = tokenize(text)
    scored: list[tuple[float, dict[str, Any]]] = []
    for record in records:
        haystack = " ".join(str(record.get(key, "")) for key in ("evidence_id", "location", "pointer", "observed_fact", "method", "source_role"))
        tokens = tokenize(haystack)
        overlap = len(query_tokens & tokens)
        score = overlap / max(len(query_tokens), 1)
        if score > 0 or text.lower() in haystack.lower():
            copy_record = json.loads(json.dumps(record))
            copy_record["retrieval_score"] = round(score, 6)
            copy_record["retrieval_note"] = "Navigation score only; source_type and verification_status are unchanged."
            scored.append((score, copy_record))
    scored.sort(key=lambda item: (-item[0], str(item[1].get("evidence_id"))))
    return [record for _, record in scored[:limit]]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="cmd", required=True)
    p_validate = sub.add_parser("validate")
    p_validate.add_argument("registry")
    p_query = sub.add_parser("query")
    p_query.add_argument("registry")
    p_query.add_argument("text")
    p_query.add_argument("--limit", type=int, default=20)
    p_verify = sub.add_parser("verify-local")
    p_verify.add_argument("registry")
    args = parser.parse_args()
    try:
        records = load_records(Path(args.registry))
        errors = validate(records)
        if errors:
            raise ValueError("; ".join(errors))
        if args.cmd == "validate":
            print(f"PASS: evidence registry ({len(records)} records)")
        elif args.cmd == "query":
            print(json.dumps(query(records, args.text, args.limit), indent=2, sort_keys=True))
        elif args.cmd == "verify-local":
            print(json.dumps(verify_local(records), indent=2, sort_keys=True))
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
