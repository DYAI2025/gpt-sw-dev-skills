#!/usr/bin/env python3
"""Perform a deterministic structural validation of SARIF 2.1.0 output."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_sarif.py <sarif.json>")
    try:
        value = json.loads(Path(argv[1]).read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(str(exc))
    if value.get("version") != "2.1.0":
        return fail("SARIF version must be 2.1.0")
    runs = value.get("runs")
    if not isinstance(runs, list) or not runs:
        return fail("runs must be a non-empty array")
    for run in runs:
        driver = run.get("tool", {}).get("driver", {})
        if not driver.get("name"):
            return fail("tool.driver.name missing")
        for result in run.get("results", []):
            if not result.get("ruleId") or not result.get("message", {}).get("text"):
                return fail("result requires ruleId and message.text")
            if result.get("level") not in {"error", "warning", "note", "none"}:
                return fail("invalid result level")
    print(f"PASS: SARIF ({sum(len(r.get('results', [])) for r in runs)} results)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
