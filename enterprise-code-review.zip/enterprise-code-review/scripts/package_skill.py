#!/usr/bin/env python3
"""Run all hard gates, then package exactly skill.zip with one Skill root."""
from __future__ import annotations

import argparse
import subprocess
import sys
import zipfile
from pathlib import Path

VALIDATORS = [
    "quick_validate.py",
    "validate_source_map.py",
    "validate_evals.py",
    "validate_no_placeholders.py",
    "validate_evidence_registry.py",
    "validate_capability_lifecycle.py",
    "validate_review_evals.py",
    "validate_core_parity.py",
    "validate_installability.py",
    "validate_agent_agnostic.py",
    "validate_release_gate.py",
    "validate_pipeline_ledger.py",
]
EXCLUDE_PARTS = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", "dist", ".git"}
EXCLUDE_SUFFIXES = {".pyc", ".pyo"}


def run(command: list[str], cwd: Path) -> None:
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True)
    if result.stdout:
        print(result.stdout.rstrip())
    if result.returncode != 0:
        if result.stderr:
            print(result.stderr.rstrip(), file=sys.stderr)
        raise SystemExit(result.returncode)


def package(root: Path, out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    zip_path = out_dir / "skill.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(root.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(root)
            if set(rel.parts) & EXCLUDE_PARTS or path.suffix in EXCLUDE_SUFFIXES:
                continue
            archive.write(path, Path(root.name) / rel)
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
        if not names or any(not name.startswith(root.name + "/") for name in names):
            raise SystemExit("FAIL: package must contain exactly one root Skill directory")
        for required in (f"{root.name}/SKILL.md", f"{root.name}/agents/openai.yaml"):
            if required not in names:
                raise SystemExit(f"FAIL: package missing {required}")
        if any("__pycache__" in name or name.endswith((".pyc", ".pyo")) for name in names):
            raise SystemExit("FAIL: package contains cache/bytecode")
    return zip_path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_dir")
    parser.add_argument("out_dir", nargs="?", default="./dist")
    args = parser.parse_args()
    root = Path(args.skill_dir).resolve()
    scripts = root / "scripts"
    for name in VALIDATORS:
        run([sys.executable, str(scripts / name), str(root)], root)
    run([sys.executable, str(scripts / "validate_enterprise_skill_evaluation.py"), str(root / "reports" / "enterprise-skill-evaluation.xml")], root)
    run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py"], root)
    zip_path = package(root, Path(args.out_dir).resolve())
    print(f"PACKAGED: {zip_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
