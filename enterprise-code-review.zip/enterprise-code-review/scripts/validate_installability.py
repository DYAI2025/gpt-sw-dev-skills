#!/usr/bin/env python3
"""Validate installability report and minimum Skill package shape."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_installability.py <skill-dir>")
    root = Path(argv[1])
    try:
        report = json.loads((root / "reports" / "installability-report.json").read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(str(exc))
    if report.get("artifact_name") != "skill.zip":
        return fail("artifact_name must be skill.zip")
    if report.get("chatgpt_install_ready") is not True:
        return fail("chatgpt_install_ready must be true")
    if report.get("frontend_install_suggestion_status") != "prepared":
        return fail("frontend_install_suggestion_status must be prepared")
    if report.get("blocking_issues"):
        return fail("blocking_issues must be empty")
    if not report.get("not_controlled_by_skill"):
        return fail("frontend limitations missing")
    if not (root / "SKILL.md").exists() or not (root / "agents" / "openai.yaml").exists():
        return fail("minimum Skill files missing")
    print("PASS: installability")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
