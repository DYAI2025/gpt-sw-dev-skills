#!/usr/bin/env python3
"""Export non-refuted code review findings as SARIF 2.1.0-compatible JSON."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


def sarif_level(severity: str) -> str:
    if severity in {"Blocker", "Critical", "Important"}:
        return "error" if severity in {"Blocker", "Critical"} else "warning"
    return "note"


def to_sarif(report: dict[str, Any]) -> dict[str, Any]:
    rules: dict[str, dict[str, Any]] = {}
    results: list[dict[str, Any]] = []
    for finding in report.get("findings", []):
        if finding.get("status") in {"REFUTED", "DUPLICATE"}:
            continue
        rule_id = str(finding.get("category") or "enterprise-code-review")
        rules.setdefault(rule_id, {
            "id": rule_id,
            "name": rule_id.replace("_", "-"),
            "shortDescription": {"text": f"Enterprise code review category: {rule_id}"},
            "help": {"text": "See the Markdown/JSON report for evidence, impact, and fix strategy."}
        })
        location = finding.get("location", {})
        region: dict[str, Any] = {}
        if isinstance(location.get("start_line"), int):
            region["startLine"] = location["start_line"]
        if isinstance(location.get("end_line"), int):
            region["endLine"] = location["end_line"]
        result = {
            "ruleId": rule_id,
            "level": sarif_level(str(finding.get("severity"))),
            "message": {"text": f"[{finding.get('severity')}/{finding.get('status')}] {finding.get('title')}: {finding.get('claim')}"},
            "locations": [{
                "physicalLocation": {
                    "artifactLocation": {"uri": str(location.get("path") or "unknown")},
                    "region": region
                }
            }],
            "partialFingerprints": {"enterpriseCodeReviewFingerprint": str(finding.get("fingerprint") or finding.get("finding_id"))},
            "properties": {
                "findingId": finding.get("finding_id"),
                "severity": finding.get("severity"),
                "status": finding.get("status"),
                "snapshotId": finding.get("snapshot_id"),
                "confidence": finding.get("confidence"),
                "evidenceIds": finding.get("evidence_ids", []),
                "realWorldConsequence": finding.get("real_world_impact", {}).get("consequence"),
                "preferredFix": finding.get("fix_strategy", {}).get("preferred")
            }
        }
        results.append(result)
    return {
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": [{
            "tool": {"driver": {"name": "Enterprise Code Review", "version": "1.0.0", "rules": list(rules.values())}},
            "automationDetails": {"id": str(report.get("report_id"))},
            "results": results,
            "properties": {"snapshotId": report.get("snapshot", {}).get("snapshot_id")}
        }]
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("report")
    parser.add_argument("output")
    args = parser.parse_args()
    try:
        report = json.loads(Path(args.report).read_text(encoding="utf-8"))
        sarif = to_sarif(report)
        Path(args.output).write_text(json.dumps(sarif, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    print(f"PASS: SARIF {len(sarif['runs'][0]['results'])} results")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
