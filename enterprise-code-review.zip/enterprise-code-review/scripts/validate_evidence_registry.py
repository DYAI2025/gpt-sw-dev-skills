#!/usr/bin/env python3
"""Validate the packaged canonical evidence registry."""
from __future__ import annotations

import sys
from pathlib import Path

from evidence_registry import load_records, validate


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_evidence_registry.py <skill-dir>")
    path = Path(argv[1]) / "reports" / "canonical-evidence-records.jsonl"
    if not path.exists():
        return fail("reports/canonical-evidence-records.jsonl missing")
    try:
        records = load_records(path)
        errors = validate(records)
    except Exception as exc:
        return fail(str(exc))
    if errors:
        return fail("; ".join(errors))
    if not records:
        return fail("evidence registry must not be empty")
    print(f"PASS: evidence registry ({len(records)} records)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
