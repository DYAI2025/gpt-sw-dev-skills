#!/usr/bin/env python3
"""Validate that the new Skill's declared core capabilities are present."""
from __future__ import annotations

import json
import sys
from pathlib import Path

CORE = {
    "github_mode", "local_mode", "pasted_mode", "snapshot_binding", "primary_review",
    "blind_independent_review", "deterministic_validation", "countertesting",
    "impact_24_categories", "severity_four_levels", "real_world_impact", "fix_strategy",
    "atomic_sort", "markdown_json_sarif", "exact_head_gate", "source_discipline",
    "security_boundary", "evals", "release_gate", "packaging",
}


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_core_parity.py <skill-dir>")
    root = Path(argv[1])
    try:
        report = json.loads((root / "reports" / "core-functionality-preservation.json").read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(str(exc))
    present = set(report.get("core_capabilities_present", []))
    missing = CORE - present
    if missing:
        return fail("missing core capabilities: " + ", ".join(sorted(missing)))
    if report.get("new_skill") is not True or report.get("status") != "PASS":
        return fail("new-skill core report must be PASS")
    skill_text = (root / "SKILL.md").read_text(encoding="utf-8")
    required_terms = ["GitHub mode", "Local mode", "Pasted-code mode", "Atomic Sort", "Blocker", "Critical", "Important", "Minor", "READY_FOR_MERGE"]
    for term in required_terms:
        if term not in skill_text:
            return fail(f"SKILL.md missing core term: {term}")
    print(f"PASS: core functionality ({len(CORE)} capabilities)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
