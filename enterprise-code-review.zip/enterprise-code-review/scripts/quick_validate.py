#!/usr/bin/env python3
"""Validate Enterprise Code Review Skill structure and control-plane constraints."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
REQUIRED = [
    "SKILL.md", "agents/openai.yaml", "agents/frontier-model-handoff.md",
    "references/input-modes.md", "references/review-methodology.md",
    "references/severity-evidence-and-verdicts.md", "references/impact-taxonomy.md",
    "references/independent-review-protocol.md", "references/atomic-review-graph.md",
    "references/tool-capability-matrix.md", "references/source-policy.md",
    "references/source-map.md", "references/security-and-tools.md",
    "references/eval-design.md", "references/release-gate-policy.md",
    "references/enterprise-skill-output-evaluator.md",
    "schemas/review-job.schema.json", "schemas/review-report.schema.json",
    "schemas/review-finding.schema.json", "schemas/evidence-record.schema.json",
    "schemas/review-atom.schema.json", "schemas/capability-record.schema.json",
    "schemas/pipeline-event.schema.json",
    "scripts/snapshot_repo.py", "scripts/atomic_sort.py", "scripts/merge_review_packets.py",
    "scripts/import_sarif.py", "scripts/report_to_sarif.py", "scripts/validate_sarif.py",
    "scripts/validate_review_report.py", "scripts/render_review_report.py",
    "scripts/evidence_registry.py", "scripts/pipeline_ledger.py",
    "scripts/run_review_evals.py", "scripts/package_skill.py",
    "evals/trigger_queries.json", "evals/output_evals.json", "evals/review_cases.json",
    "reports/release-gate-report.json", "reports/enterprise-skill-evaluation.xml",
    "reports/installability-report.json", "reports/agent-compatibility-report.json",
    "reports/core-functionality-preservation.json", "reports/canonical-evidence-records.jsonl",
    "reports/capability-records.json", "reports/capability-lifecycle-events.jsonl",
    "reports/review-eval-results.json", "reports/build-events.jsonl", "reports/pipeline-state.json",
]


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def frontmatter(text: str) -> dict[str, str]:
    if not text.startswith("---\n"):
        raise ValueError("SKILL.md must start with YAML frontmatter")
    end = text.find("\n---\n", 4)
    if end < 0:
        raise ValueError("frontmatter closing marker missing")
    data: dict[str, str] = {}
    for line in text[4:end].splitlines():
        if not line.strip():
            continue
        if ":" not in line:
            raise ValueError(f"invalid frontmatter line: {line}")
        key, value = line.split(":", 1)
        data[key.strip()] = value.strip().strip('"').strip("'")
    return data


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: quick_validate.py <skill-dir>")
    root = Path(argv[1]).resolve()
    if not root.is_dir():
        return fail(f"not a directory: {root}")
    for rel in REQUIRED:
        if not (root / rel).exists():
            return fail(f"missing required path: {rel}")
    try:
        text = (root / "SKILL.md").read_text(encoding="utf-8")
        fm = frontmatter(text)
    except Exception as exc:
        return fail(str(exc))
    name = fm.get("name", "")
    description = fm.get("description", "")
    if not NAME_RE.fullmatch(name):
        return fail("invalid frontmatter name")
    if root.name != name:
        return fail(f"directory name {root.name!r} does not match name {name!r}")
    if not description or len(description) > 1024 or "<" in description or ">" in description:
        return fail("invalid frontmatter description")
    if set(fm) != {"name", "description"}:
        return fail("frontmatter must contain only name and description")
    body_lines = text.split("\n---\n", 1)[1].splitlines()
    if len(body_lines) > 500:
        return fail(f"SKILL.md body exceeds 500 lines: {len(body_lines)}")
    empties = [str(p.relative_to(root)) for p in root.rglob("*") if p.is_file() and p.stat().st_size == 0]
    if empties:
        return fail("empty files: " + ", ".join(empties))
    for path in root.rglob("*.json"):
        try:
            json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            return fail(f"invalid JSON {path.relative_to(root)}: {exc}")
    print(f"PASS: {root} ({len(body_lines)} SKILL.md body lines)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
