# Enterprise Code Review Report Template

Use `scripts/render_review_report.py` to generate the canonical Markdown from the JSON report. The required order is:

1. Review identity and exact scope
2. Verdict
3. Executive summary
4. Snapshot and capability manifest
5. Coverage and 24-category impact inventory
6. Findings summary by severity
7. Detailed findings
8. Counterevidence and reviewer disagreements
9. Test and tool evidence
10. Real-world impact synthesis
11. Fix strategy and revalidation plan
12. Residual uncertainty and boundaries
13. Machine-readable artifacts
