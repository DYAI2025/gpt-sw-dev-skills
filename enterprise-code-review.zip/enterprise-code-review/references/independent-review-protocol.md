# Independent Review Protocol

## Goal

Reduce anchoring and shared-context failure without pretending model agreement is proof.

## Protocol

1. Freeze one canonical review packet: snapshot, requirements, scope, exclusions, tool boundary, and output schema.
2. Reviewer A and Reviewer B receive the same packet.
3. Reviewer B must not receive Reviewer A findings during its initial pass.
4. Use a separate model, provider, subagent context, or fresh session when available.
5. Each reviewer emits stable IDs, locations, evidence pointers, counterevidence, and limitations.
6. The adjudicator sees both packets only after they are frozen.
7. Deterministic evidence and source contracts outrank reviewer consensus.
8. Preserve disagreements and benign alternative explanations.

## Capability degradation

If the runtime cannot create an independent context, set:

`independent_review_status: INDEPENDENT_REVIEW_CAPABILITY_MISSING`

Do not ask the same context to role-play independence and label it independent.

## Agreement labels

- `INDEPENDENTLY_CORROBORATED`
- `SINGLE_REVIEWER_ONLY`
- `REVIEWER_DISAGREEMENT`
- `SHARED_EVIDENCE_ORIGIN`
- `NOT_TESTED`

These labels do not change finding status by themselves.
