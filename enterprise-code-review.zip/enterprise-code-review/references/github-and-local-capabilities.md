# GitHub and Local Runtime Capabilities

## GitHub

The Skill is connector-agnostic. In a ChatGPT runtime with the GitHub app/connector, use the available read operations to obtain repository, pull request, patch, file, commit, workflow, review, and thread evidence. In an MCP runtime, prefer a read-only server configuration and minimum toolsets. Never infer write permission from read access.

Required GitHub review packet:

- repository identifier;
- PR/commit/branch identity;
- base and head SHA or equivalent immutable refs;
- complete changed-file list and per-file patch coverage;
- relevant full-file and dependent-file content;
- CI/check state tied to the same head;
- unresolved review threads and known required approvals;
- access limitations and omitted paths.

A search index may miss or delay content. Repository search is navigation, not proof of absence.

## Local runtime

Safe default operations:

- list files and metadata;
- calculate hashes and git identifiers;
- read source and configuration;
- run already available compilers, tests, linters, and scanners in an isolated workspace;
- produce reports under a dedicated output directory.

Approval required before:

- dependency installation;
- network access;
- executing untrusted repository binaries or lifecycle hooks;
- starting services or containers;
- migrations, write tests against shared systems, browser actions with side effects;
- commits, pushes, PR comments, merge, or deployment.

## Archive handling

Reject path traversal and symlink escapes. Extract into a new sandbox directory. Hash the archive and extracted tree. Record duplicate roots, nested archives, unreadable files, generated/vendor directories, and skipped oversized files.
