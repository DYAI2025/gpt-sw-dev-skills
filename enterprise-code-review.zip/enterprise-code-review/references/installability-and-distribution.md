# Installability and Distribution

The package controls its directory structure, `SKILL.md`, `agents/openai.yaml`, supporting resources, deterministic scripts, validators, and the output name `skill.zip`. It does not control client UI, workspace policy, plan availability, connector authorization, or whether an install button is displayed.

A package is `chatgpt_install_ready` only after validators pass and ZIP inspection confirms exactly one root folder named `enterprise-code-review` containing `SKILL.md` and `agents/openai.yaml`.
