# Atomic Review Graph and Atomic Sort

## Source boundary

The uploaded Atom of Thoughts repository supports a typed dependency-graph pattern. This Skill adopts only the public typed-node and dependency idea. It does not use hidden chain-of-thought, model self-confidence as evidence, or automatic conclusion termination.

No independently verified external `atomic-sort` or `AtomSort` package was established for this build. `Atomic Sort` in this Skill is a project-defined deterministic postprocessor implemented in `scripts/atomic_sort.py`.

## Review atom types

- `OBSERVATION`: directly observed code, diff, test, tool, or source fact.
- `HYPOTHESIS`: falsifiable defect or benign explanation.
- `VERIFICATION`: check, result, counterexample, or limitation.
- `IMPACT`: supported propagation and practical consequence.
- `FIX_STRATEGY`: bounded remediation option and revalidation.
- `DECISION`: adjudicated status, severity, or verdict.

Each atom has `atom_id`, `atom_type`, `statement`, `dependencies`, `evidence_ids`, `snapshot_id`, `status`, and `limitations`.

## Invalid transitions

- `HYPOTHESIS -> DECISION` without a verification or explicit `INCONCLUSIVE` reason.
- `MODEL_ONLY -> VERIFIED`.
- retrieval score -> source authority.
- reviewer agreement -> verification.
- finding count -> severity.

## Atomic Sort invariants

Atomic Sort:

1. normalizes identifiers and ordering fields;
2. computes a stable fingerprint from category, location, and normalized claim;
3. links duplicates without discarding their evidence origins;
4. orders by severity, unresolved status, impact priority, location, and ID;
5. emits conflict records when duplicate findings disagree materially;
6. never raises severity, status, confidence, exploitability, or source authority;
7. is idempotent: sorting an already sorted report yields the same semantic output.
