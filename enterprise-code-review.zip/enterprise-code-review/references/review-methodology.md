# Review Methodology

## Review dimensions

1. Product intent and acceptance criteria.
2. Correctness and edge cases.
3. Security, privacy, authorization, trust boundaries, and secrets.
4. Reliability, error handling, idempotency, retries, rollback, and recovery.
5. Concurrency, transactions, ordering, and state consistency.
6. Performance, resource use, scalability, and denial-of-service surfaces.
7. Architecture, layering, dependencies, and unnecessary complexity.
8. API, event, schema, serialization, and backward compatibility.
9. Data migrations, retention, integrity, and lineage.
10. Tests: validity, negative paths, mutation sensitivity, and false-green risk.
11. Observability, audit logs, metrics, tracing, and operator diagnosis.
12. Dependencies, supply chain, licenses, generated code, and provenance.
13. Build, configuration, deployment, infrastructure, and feature flags.
14. Documentation, runbooks, support, accessibility, and localization.
15. Domain modules: Web3/smart contracts and AI/LLM systems when present.

## Review sequence

- Understand the intended user and system behavior before rating implementation.
- Inspect each assigned human-written line and enough surrounding context to understand it.
- Reconstruct relevant call, data, contract, state, and deployment paths.
- Generate alternative defect hypotheses, including the strongest benign explanation.
- Seek counterevidence before promoting a finding.
- Prefer reproducible counterexamples over persuasive prose.
- Distinguish introduced defects from pre-existing debt.
- Keep a conservative test superset when complete dependency proof is unavailable.

## Tests are review targets

A passing test suite is evidence only for the paths and assertions it actually exercises. Check whether tests can fail when behavior is broken. Use mutation tests or deliberate counterexamples where risk justifies them. Do not equate coverage percentage with behavioral adequacy.

## Independent review

Reviewer B receives the same canonical snapshot, requirements, and tool boundary, but not Reviewer A conclusions. After both packets exist, the adjudicator may compare them. Reviewer agreement raises corroboration, not verification status.

## Reviewer behavior

Comments should be specific, professional, impact-linked, and actionable. Avoid personal language, vague demands, and unbounded rewrites. Praise is optional; evidence quality is mandatory.
