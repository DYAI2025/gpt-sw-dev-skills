# Domain Playbooks

Load only applicable sections.

## Web3 and smart contracts

Review authorization, ownership, upgradeability, reentrancy, external calls, state/accounting invariants, oracle assumptions, signature/domain separation, replay, rounding, MEV/front-running exposure, gas/resource bounds, chain/reorg behavior, event completeness, pause/recovery, key custody, and deployment/migration controls. Do not imply audit certification or mainnet safety from static review alone.

## AI and LLM systems

Review prompt/data trust boundaries, prompt injection, tool authorization, retrieval provenance, source laundering, output schema enforcement, model/provider changes, nondeterminism, eval leakage, data retention, privacy, training/evaluation separation, fallback behavior, cost/rate limits, content safety, human approval, and observability. LLM-as-judge results are evidence, not ground truth.

## APIs and distributed systems

Review compatibility, idempotency, retries, timeouts, pagination, rate limits, ordering, eventual consistency, partial failure, circuit breaking, auth scopes, error contracts, telemetry, and consumer tests.

## Data and migrations

Review forward/backward compatibility, locking, transaction scope, backfill, data loss, null/default semantics, rollback, dual-read/write, retention, privacy, and operational observability.

## Frontend and mobile

Review state transitions, error/loading/empty states, accessibility, localization, network/offline behavior, security storage, performance, analytics/privacy, browser/device compatibility, and user-visible regression paths.
