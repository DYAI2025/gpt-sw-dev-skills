# Pipeline Ledger

The build ledger is adapted from the event-store/replay/guard pattern observed in the supplied Weft snapshot and reimplemented with the Python standard library.

It proves only process integrity:

- required build stages were recorded in order;
- events form a SHA-256 hash chain;
- downstream gates apply to the same frozen artifact digest;
- package authorization is not stale.

It does not prove source truth, code-review precision, security, or model quality.

Required stages:

1. `INTAKE_COMPLETED`
2. `RESEARCH_COMPLETED`
3. `CAPABILITY_DECISION_COMPLETED` or `CAPABILITY_DECISION_SKIPPED`
4. `ARCHITECTURE_GATE_PASSED`
5. `DRAFT_FROZEN`
6. `RELEASE_GATE_PASSED`
7. `EVALUATOR_PASSED`
8. `VALIDATION_PASSED`
9. `PACKAGE_AUTHORIZED`

The digest excludes `reports/`, `dist/`, caches, and bytecode to avoid self-reference. Event data must contain only IDs, statuses, counts, and redacted pointers; prompts, documents, responses, credentials, secrets, tokens, and tool-argument bodies are prohibited.
