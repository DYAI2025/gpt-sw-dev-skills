# Enterprise Skill Output Evaluator

Evaluate this package on:

1. `spec_compliance`: valid Skill shape, frontmatter, progressive disclosure, trigger precision.
2. `research_quality`: source map, classification, confidence, MISSING/SOURCE_NEEDED, no source laundering.
3. `enterprise_readiness`: security boundary, least privilege, no secrets/destructive defaults, tool permission gates.
4. `architecture_quality`: coherent three-mode workflow, schemas/scripts/evals, deterministic reporting and packaging.
5. `release_gate_integrity`: craftsmanship, anti-confabulation, anti-sycophancy, bias, validators, trace, and packaging.

Output XML with root `enterprise_skill_evaluation`, integer scores 1-5, blocking issues, required revisions, decision, and evidence-based reason. Do not fabricate validator output.
