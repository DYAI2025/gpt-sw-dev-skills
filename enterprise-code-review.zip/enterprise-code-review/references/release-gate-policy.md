# Release Gate Policy

## Craftsmanship

Require coherent scope, progressive disclosure, explicit failure chain, smallest robust implementation, deterministic utilities, and no hidden dependency on a specific external reviewer service.

## Anti-confabulation

Block unverified hard claims about tool capability, complete coverage, security guarantees, runtime behavior, versions, prices, licenses, or cross-model equivalence. External capabilities remain optional until verified in the target run.

## Anti-sycophancy

Score 0-5. Score 3 or higher blocks packaging. User-requested methods are adopted only when evidence and fit justify them. `Atomic Sort` lineage remains uncertain; Canon/Radar code is not copied under unclear licensing.

## Bias

Check confirmation, automation, severity inflation, tool, authority, novelty, vendor, survivorship, and reviewer-consensus bias.

## Reliability

Require:

- package validators and unit tests pass;
- review eval suite passes;
- source/evidence records validate;
- capability lifecycle contains no direct unsupported adoption;
- hash-chained build ledger replays and binds all gates to one artifact digest;
- enterprise evaluator decision is `PASS`;
- package is exactly `skill.zip` with one root Skill directory.

A passing package gate proves structural/reproducible readiness of this Skill package. It does not prove perfect defect recall, absence of false positives, or effectiveness on every repository.
