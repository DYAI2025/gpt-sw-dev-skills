# Tool and Capability Matrix

## Selection rule

Use the smallest sufficient ladder:

1. native repository and host capability;
2. repository-native compiler, test, lint, and build tools;
3. deterministic local script;
4. small pinned dependency;
5. external analyzer or MCP;
6. paid/external service only with explicit permission and data-boundary review.

A capability is active only after access, authorization, version, configuration, execution context, output shape, limitations, and a successful run are recorded.

## Core modes

| Capability | Purpose | Default | Truth boundary |
|---|---|---|---|
| Chat/file context | pasted-code review | available when supplied | only visible material |
| Local read-only filesystem | local repo/archive review | runtime-dependent | snapshot and readable files only |
| GitHub connector | repository/PR/commit/context/CI reads | optional, read-only | authorized repositories and exposed actions |
| Separate reviewer context | blind counter-review | optional | corroboration only |
| Deterministic report scripts | normalization, validation, rendering | bundled | structure/process, not code correctness |

## Optional analyzers

| Capability family | Examples | Best use | Mandatory gate |
|---|---|---|---|
| Compiler/type checker | repository-native | syntax, type, build contracts | record command/version/exit |
| Static/dataflow/taint | CodeQL, Semgrep | source-to-sink, patterns, security | tool result is evidence, not verdict |
| Quality/metrics | SonarQube | issues, metrics, quality gates | verify project/config/snapshot |
| SCA/IaC/container | Snyk or equivalent | dependencies, IaC, containers, SBOM | authorization and data-egress review |
| Secret scan | repository/native scanner | credential candidates | redact values; never echo secrets |
| Mutation | Stryker, PIT, mutmut or equivalent | test sensitivity | bounded target; no production mutation |
| Property testing | language-native framework | invariants and generated cases | property must trace to spec |
| Fuzzing | language-native, libFuzzer, OSS-Fuzz patterns | parser/protocol/input boundaries | isolated, bounded resources |
| Contract testing | Pact or repository-native | API/event consumer compatibility | real consumer/provider version binding |
| Browser/API smoke | Playwright CLI/MCP or repository-native | user-visible/runtime boundary | test environment and consent |

## GitHub capability contract

Prefer read-only operations for repository metadata, PR metadata, changed filenames, patches/diffs, full files, commits, workflow runs/checks, reviews, and review threads. Discover the current connector/MCP schema rather than assuming every runtime exposes identical function names.

Before `READY_FOR_MERGE`, verify the exact current head and its relevant checks. A cached patch or old PR summary is stale evidence after a new commit.

## Capability records

For every non-trivial tool run capture:

- capability ID and source;
- version and configuration hash;
- authorization and data classification;
- snapshot/head binding;
- command or tool operation name without secret arguments;
- exit/result status;
- output artifact pointer;
- limitations and missing coverage.
