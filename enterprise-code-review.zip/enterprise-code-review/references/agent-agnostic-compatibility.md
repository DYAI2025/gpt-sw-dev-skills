# Agent-Agnostic Compatibility

## Portable core

- source/snapshot binding;
- evidence and finding schemas;
- atomic review graph;
- blind independent review protocol;
- 24-category impact scan;
- severity/status/verdict rules;
- deterministic scripts, evals, and report artifacts.

## Runtime-specific

- ChatGPT GitHub connector and file mounts;
- OpenAI metadata in `agents/openai.yaml`;
- Claude Code, Codex, Cursor, Windsurf, or other tool names;
- shell, browser, subagent, MCP, and context-window availability.

Use capability discovery and explicit degradation. Semantic portability does not imply identical behavior, tool access, or model quality.
