# 24-Category Impact Taxonomy

For repository reviews, emit one record per category with status `ANALYZED`, `PARTIAL`, `NOT_APPLICABLE`, `CAPABILITY_MISSING`, `NO_EVIDENCE`, or `BOUNDARY_EXIT`. `NOT_APPLICABLE` requires a reason.

1. `repository_workspace_structure`
2. `package_module_import_relations`
3. `symbols_references_calls_dataflow`
4. `types_interfaces_inheritance_traits`
5. `dependency_injection_reflection_dynamic_resolution`
6. `build_targets_generators_compilers`
7. `tests_fixtures_test_selection`
8. `public_apis_protocols_serialization`
9. `data_models_schemas_migrations_storage`
10. `events_queues_jobs_schedulers`
11. `authentication_authorization_security_privacy`
12. `configuration_feature_flags_secrets`
13. `dependencies_supply_chain_licenses`
14. `infrastructure_deployment_runtime_environments`
15. `observability_logging_metrics_alerts`
16. `performance_scaling_resource_consumption`
17. `concurrency_transactions_state_consistency`
18. `documentation_runbooks_support_operations`
19. `ui_accessibility_localization_design_systems`
20. `external_consumers_integrations_partners`
21. `history_ownership_cochange_maintenance`
22. `rollback_compatibility_reversibility`
23. `legal_compliance_organizational_controls`
24. `product_user_journey_business_process`

## Critical-path preservation

Never remove or down-rank a path solely because a numeric score decays when it crosses public contracts, events, data, auth, security, production, rollback, compliance, irreversible behavior, or unknown external consumers.

## Real-world impact fields

- affected actor or stakeholder;
- triggering scenario;
- user-visible or operational consequence;
- business/cost/compliance consequence when supported;
- technical blast radius;
- likelihood and preconditions;
- detectability and time to recovery;
- reversibility and rollback path;
- consequence if the reviewer is wrong.
