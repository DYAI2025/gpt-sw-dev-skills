# Evaluation Design

## Layers

1. Trigger tests: positive and near-miss prompts.
2. Structural output tests: required fields, severity/status enums, snapshot binding, impact and fix strategy.
3. Negative safety tests: model-only Critical/Blocker, stale snapshot, pasted-code merge verdict, unresolved Blocker with ready verdict.
4. Deterministic core tests: snapshot, merge, Atomic Sort idempotence/deduplication, report validation, SARIF import/render.
5. Capability degradation tests: no GitHub, no second reviewer, no scanner, no runtime.
6. Differential behavior tests: compare review with and without this Skill on seeded defects; do not claim general model improvement from local structural tests.

## Required eval properties

- findings are evidence-linked and impact-specific;
- tool failures become limitations, not fabricated passes;
- independent review is not simulated;
- code snippets cannot receive `READY_FOR_MERGE`;
- Blocker/Critical cannot be model-only;
- new head invalidates old verdict;
- Atomic Sort never upgrades a finding;
- report renders to Markdown and, when findings exist, SARIF.

## Acceptance

Packaging requires all deterministic validators and `scripts/run_review_evals.py` to pass. Stochastic cross-model precision/recall remains `UNVERIFIED_IMPACT` until benchmarked on representative repositories with seeded and historical defects.
