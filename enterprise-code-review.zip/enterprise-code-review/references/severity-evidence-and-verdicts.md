# Severity, Evidence, Status, and Verdict Contract

## Finding statuses

- `CANDIDATE`: plausible model/tool signal; not yet sufficient for a final defect claim.
- `SUPPORTED`: code/source/tool evidence supports the claim, but direct reproduction may be absent.
- `VERIFIED`: non-model evidence reproduces or deterministically demonstrates the claim within the stated boundary.
- `REFUTED`: counterevidence defeats the claim.
- `INCONCLUSIVE`: evidence is conflicting or insufficient.
- `PRE_EXISTING`: valid issue not introduced by the reviewed change.
- `DUPLICATE`: same underlying issue as another finding.
- `ACCEPTED_RISK`: authorized owner accepted the documented residual risk; an agent may not invent this authorization.

## Evidence classes

Weakest to strongest is context-dependent; no class is universally decisive.

- `MODEL_ONLY`
- `SOURCE_INSPECTED`
- `CONTRACT_OR_SPEC`
- `STATIC_TOOL`
- `COMPILER_OR_BUILD`
- `UNIT_TEST`
- `INTEGRATION_TEST`
- `CONTRACT_TEST`
- `MUTATION_TEST`
- `FUZZ_COUNTEREXAMPLE`
- `REAL_BOUNDARY_SMOKE`
- `PRODUCTION_OBSERVED`
- `HUMAN_CONFIRMED`

Record independence groups. Two summaries derived from one scan are one evidence group.

## Severity

### Blocker

The reviewed change or snapshot cannot safely proceed. Typical conditions include reproducible loss/corruption of critical data, broken essential build/runtime path, authentication/authorization bypass, arbitrary code execution, irreversible unsafe migration, required acceptance criterion demonstrably impossible, or inability to establish a required safety boundary. Requires non-model evidence and a concrete release-blocking consequence.

### Critical

A high-impact defect with a credible path to severe security, privacy, correctness, availability, financial, compliance, or operational harm. Requires non-model evidence, affected boundary, and plausible scenario. Tool severity labels alone do not automatically establish `Critical`.

### Important

A material defect, regression, test weakness, contract incompatibility, reliability risk, architectural debt, performance issue, or operational gap with meaningful user or engineering consequence. It should normally be fixed before release unless explicitly accepted.

### Minor

A bounded issue with low immediate impact: maintainability, clarity, documentation, narrow edge case, or non-blocking improvement. Personal style preference without an applicable rule or impact is not a finding.

## Severity guardrails

- Model confidence never sets severity.
- Popularity, consensus, or count of similar comments never sets severity.
- `Blocker` and `Critical` require at least one evidence class other than `MODEL_ONLY`.
- Severity reflects consequence and credible reach, not difficulty of the fix.
- Uncertain likelihood reduces status/confidence or creates `INCONCLUSIVE`; it does not justify dramatic labels.
- Pre-existing issues remain findings but are separated from change-introduced blockers unless the change worsens or exposes them.

## Verdicts

- `BLOCKED`: a hard review boundary or unresolved Blocker prevents progression.
- `CHANGES_REQUIRED`: supported unresolved defects require repair.
- `ACCEPTED_WITH_RISK`: no unresolved Blocker; residual risk has explicit authorized acceptance.
- `READY_FOR_MERGE`: exact head verified; required tests/checks pass; no unresolved Blocker/Critical; review threads and required categories resolved.
- `INCONCLUSIVE`: evidence or access is insufficient for the requested decision.

Pasted-code mode can return findings but never `READY_FOR_MERGE`.
