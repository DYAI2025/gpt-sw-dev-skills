# Source Map

This map records the sources used to design the Skill. User-provided snapshots support observed architecture patterns; they are not automatic proof of current upstream or production behavior.

## S001 - Current user requirement
- type: `user_provided`
- purpose: Defines a complete enterprise code review Skill, three input modes, severity labels, impact, fix strategy, and validator-backed report.
- reliability: Authoritative for requested product behavior.
- limitations: Does not prove external tool/runtime capability.
- use_in_skill: Scope, output contract, severity names, supported inputs.
- confidence_default: 5.

## S002 - Enterprise Skill Creator
- type: `primary`
- purpose: Governing build pipeline, source discipline, release hook, evaluator, deterministic validation, installability, and packaging.
- reliability: Installed project Skill inspected in this runtime.
- limitations: Internal build contract, not proof of third-party platform behavior.
- use_in_skill: Package architecture and gates.
- confidence_default: 5.

## S003 - Canon Resolver snapshot
- type: `user_provided`
- location: `/mnt/data/canon-resolver(2).zip`
- snapshot_sha256: `2f4c625e200cd43f3fda4e045d1c6c82c3c96c349f0d53fdcc5bd1cf5b74943f`
- purpose: Authority/provenance/freshness separation, fail-closed evidence resolution, retrieval-not-truth rule.
- reliability: Source inspected; 11 local tests passed in this build session.
- limitations: Snapshot contains no license file; MCP runtime not validated; implementation code not redistributed.
- use_in_skill: Reimplemented source/evidence architecture pattern only.
- confidence_default: 5 for observed snapshot behavior; 3 for generalized transfer.

## S004 - DYAI LLM Technology Radar snapshot
- type: `user_provided`
- location: `/mnt/data/dyai-llm-technology-radar(2).zip`
- snapshot_sha256: `a1f97049df949e7cffa0d506717bfb2afc70d46dc963d20e82a939272696fe31`
- purpose: Discovery-is-not-adoption, lifecycle, non-compensatory gates, anti-tool-hopping.
- reliability: Source inspected; 14 records validated and index rendered locally.
- limitations: Candidate records remain discovery evidence; no license file in snapshot; implementation code not redistributed.
- use_in_skill: Capability negotiation and lifecycle policy pattern.
- confidence_default: 5 for observed governance pattern; 2 for candidate technology claims.

## S005 - web3-docs snapshot
- type: `user_provided`
- location: `/mnt/data/web3-docs-main (1).zip`
- snapshot_sha256: `eb1628097adcd1c032e27ca322c908c78b72385cea89e0db74cd50638509895a`
- purpose: Controlled sources to deterministic parsing/normalization to local query surface.
- reliability: Source inspected; 62 dependency-free parser/database/enrichment/polish tests passed locally.
- limitations: Full suite could not collect because optional `mcp` and `pytest_bdd` packages were unavailable; Web3 domain content and runtime are not embedded.
- use_in_skill: Reimplemented normalization/index/query architecture pattern only.
- confidence_default: 5 for exercised parser/database pattern; 2 for unavailable MCP runtime.

## S006 - Weft snapshot
- type: `user_provided`
- location: `/mnt/data/weft-main (1).zip`
- snapshot_sha256: `399964c124d3e88efe440b52192dcd92fbdeffad8ee8b0c20e3e9bc9826315dc`
- purpose: Event-sourced state, deterministic replay, guards, bounded loops, resume semantics.
- reliability: Source inspected; 121 targeted core tests passed locally.
- limitations: Full suite timed out in this session; Claude-specific hooks are not portable to ChatGPT.
- use_in_skill: Host-neutral build/review ledger and gate pattern.
- confidence_default: 5 for exercised core; 2 for cross-runtime hooks.

## S007 - Atom of Thoughts snapshot
- type: `user_provided`
- location: `/mnt/data/mcp-atom-of-thoughts-main.zip`
- snapshot_sha256: `60d55b8d4971d88655a7a7815205b926bfe9b5e82f3f09e81f8f7115a8de63b7`
- purpose: Typed nodes, dependencies, session isolation, graph export.
- reliability: Source and MIT license inspected; TypeScript source shape inspected.
- limitations: Dependency-backed test run was not established in this build; model confidence and auto-termination are explicitly not adopted as evidence logic.
- use_in_skill: Public atomic review graph pattern only.
- confidence_default: 5 for observed type/dependency design; 3 for generalized transfer.

## S008 - Prior repository-to-skill impact analysis
- type: `derived`
- purpose: Consolidates prior local test evidence, fit analysis, license/runtime boundaries, and reuse recommendations for Canon, Radar, Weft, web3-docs, and cctime.
- reliability: Based on inspected snapshots and recorded local runs.
- limitations: Derived report; does not replace source snapshots or current upstream verification.
- use_in_skill: Cross-check and scope discipline.
- confidence_default: 4.

## S009 - Deep Repository Impact Analysis Skill
- type: `primary`
- purpose: 24-category dependency-first scan, critical path preservation, evidence/claim separation, capability degradation.
- reliability: Installed Skill control plane inspected.
- limitations: Method contract; repository precision depends on available evidence/tools.
- use_in_skill: Impact taxonomy and conservative coverage model.
- confidence_default: 5.

## S010 - Evidence-First Coding Agent Delivery Skill
- type: `primary`
- purpose: Exact-head verification, agent output as claims, independent review, merge and post-merge gates.
- reliability: Installed Skill control plane inspected.
- limitations: Delivery orchestration method, not direct code evidence.
- use_in_skill: Exact-snapshot and merge-readiness rules.
- confidence_default: 5.

## S011 - Model Response Audit Comparator Skill
- type: `primary`
- purpose: Independent response comparison, evidence ledger, failure gates, bias/calibration, adjudication.
- reliability: Installed Skill control plane inspected.
- limitations: Adapted from model-response comparison to reviewer-packet adjudication.
- use_in_skill: Counter-review and adjudication pattern.
- confidence_default: 4.

## S012 - OpenAI Skills in ChatGPT documentation
- type: `primary`
- location: `https://help.openai.com/en/articles/20001066`
- verified_date: `2026-08-17`
- purpose: Current official description of reusable Skills, code/resources, installation, and skill-creator behavior.
- reliability: Official OpenAI documentation.
- limitations: Feature availability varies by workspace/client; package cannot guarantee UI behavior.
- use_in_skill: Installability and runtime boundary.
- confidence_default: 5.

## S013 - OpenAI GitHub connection documentation
- type: `primary`
- location: `https://help.openai.com/en/articles/11145903-connecting-github-t-chatgpt-deep-research`
- verified_date: `2026-08-17`
- purpose: Current official read/analyze/search boundary for connected GitHub repositories.
- reliability: Official OpenAI documentation.
- limitations: Availability and repository visibility vary by plan, client, authorization, and indexing.
- use_in_skill: GitHub mode boundary.
- confidence_default: 5.

## S014 - GitHub connector schema in this runtime
- type: `primary`
- purpose: Confirms available read operations for PR metadata/diff/patch/files/reviews/workflows in the current session.
- reliability: Live connector schema inspected.
- limitations: No user repository was accessed; schemas may differ in another runtime.
- use_in_skill: Capability contract, not fixed function names.
- confidence_default: 5 for this runtime schema; 2 for portability.

## S015 - Google Engineering Practices code review guidance
- type: `primary`
- location: `https://google.github.io/eng-practices/review/reviewer/looking-for.html`
- verified_date: `2026-08-17`
- purpose: Design, functionality, tests, complexity, documentation, every-line and system-context review guidance.
- reliability: Original published engineering guidance.
- limitations: Organization-specific practices require adaptation.
- use_in_skill: General review dimensions and test scrutiny.
- confidence_default: 4.

## S016 - OWASP Secure Code Review Cheat Sheet
- type: `primary`
- location: `https://cheatsheetseries.owasp.org/cheatsheets/Secure_Code_Review_Cheat_Sheet.html`
- verified_date: `2026-08-17`
- purpose: Baseline/diff security review, dataflow, trust boundaries, business logic, manual plus automated analysis.
- reliability: Official OWASP guidance.
- limitations: Guidance, not certification or proof of vulnerability absence.
- use_in_skill: Security review methodology.
- confidence_default: 5.

## S017 - NIST SSDF 1.1 and AI community profile
- type: `primary`
- location: `https://csrc.nist.gov/pubs/sp/800/218/final`
- verified_date: `2026-08-17`
- purpose: Secure development and vulnerability-risk practices; AI-specific extension where applicable.
- reliability: Official NIST publications.
- limitations: High-level framework; this Skill does not claim formal compliance.
- use_in_skill: Secure development and AI/LLM review context.
- confidence_default: 5.

## S018 - OASIS SARIF 2.1.0
- type: `primary`
- location: `https://www.oasis-open.org/standard/sarifv2-1-os/`
- verified_date: `2026-08-17`
- purpose: Machine-readable static-analysis result interchange format.
- reliability: OASIS standard.
- limitations: This Skill emits format-compatible SARIF; no certification claim.
- use_in_skill: `code_findings.sarif.json` contract.
- confidence_default: 5.

## S019 - Current official analyzer/tool documentation
- type: `primary`
- purpose: Optional capability candidates including GitHub MCP, CodeQL, Playwright, SonarQube, Semgrep, Snyk, mutation testing, and fuzzing.
- reliability: Official project/vendor sources inspected during research.
- limitations: None are mandatory or runtime-verified for every target project; versions and licensing must be rechecked at use time.
- use_in_skill: Optional tool matrix and SOURCE_NEEDED policy.
- confidence_default: 4 for documented scope; 2 for project-specific suitability.

## S020 - Atomic Sort name
- type: `uncertain`
- purpose: User referenced `Atomic Sort` or `AtomSort` as a prior concept.
- reliability: No local installed Skill or independently verified external implementation with that exact name was established in this build.
- limitations: Do not attribute the deterministic sorter to an external project.
- use_in_skill: Project-defined `scripts/atomic_sort.py` only.
- confidence_default: 2 for lineage; 5 for the implementation bundled here after tests.
