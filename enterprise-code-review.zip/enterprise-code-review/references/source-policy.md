# Source Policy

## Classes

- `primary`: source repository, official specification, official documentation, original logs/data, exact diff or runtime result.
- `secondary`: reputable explanation or curated guidance.
- `user_provided`: files, code, notes, policies, and claims supplied by the user.
- `derived`: summaries, model reviews, transformed reports, retrieval indexes, OCR, and inferred graphs.
- `uncertain`: incomplete, unattributed, stale, contradictory, or unverifiable material.

## Required fields

Every material source record contains:

- `type:` source class;
- `purpose:` role in the review;
- `reliability:` why it can support that role;
- `limitations:` known boundary;
- `confidence_default:` 1-5;
- location, revision/digest, pointer, retrieval/verification time, and independence group when available.

## Authority rules

- User-provided code is authoritative for what the supplied snapshot contains, not for correctness or production behavior.
- Exact source, compiler output, test output, and runtime observation may support facts within their boundary.
- README and vendor claims support project-stated behavior, not independent runtime effectiveness.
- Retrieval score never changes authority or verification.
- Two derived outputs from the same origin are not independent corroboration.

## Confidence

- 5: direct current primary evidence within scope.
- 4: strong primary or convergent independent evidence.
- 3: plausible but indirect/incomplete; assumption only.
- 2: weak, conflicting, stale, or context-specific; not a hard claim.
- 1: unsupported or contradicted; block or mark `SOURCE_NEEDED`.

Use `MISSING` when required information is absent. Use `SOURCE_NEEDED` when a claim exists but lacks adequate evidence. Use `BOUNDARY_EXIT` when the required fact lies outside accessible systems.
