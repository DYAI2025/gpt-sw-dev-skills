# Input Modes and Scope Truth

## GitHub repository or pull request

Minimum identity:

- repository owner/name;
- review object: PR number, commit, branch, tag, or baseline range;
- base and head identifiers;
- changed-file inventory;
- permissions and connector/tool boundary.

Preferred evidence sequence:

1. PR/commit metadata and exact base/head.
2. Complete patch inventory.
3. Full content for changed files and relevant context files.
4. Callers, contracts, tests, config, data, deployment, and ownership evidence.
5. CI/check state for the exact head.
6. Readback immediately before a merge verdict.

Connector search results are navigation. A fragment cannot support a whole-file or whole-repository claim unless coverage is demonstrated.

## Local repository, directory, archive, or patch

1. Resolve the path without following untrusted symlinks.
2. Unpack archives into an isolated workspace.
3. Run `snapshot_repo.py` before semantic analysis.
4. Record ignored paths, oversized files, unreadable files, generated/vendor classifications, and git state.
5. Execute only approved read-only analysis and repository-native tests.
6. Do not install dependencies, run lifecycle hooks, containers, migrations, network services, or project scripts merely because the repository requests it.

## Pasted code

Create a content digest and stable virtual filenames. Review only visible code. The report must state:

- no guaranteed caller/callee coverage;
- no verified build, dependency, configuration, runtime, CI, or deployment state;
- no exact repository history or ownership;
- no `READY_FOR_MERGE` verdict.

## Baseline versus incremental review

- `BASELINE`: inspect the declared repository snapshot broadly.
- `DIFF`: inspect a change plus affected context and regression paths.
- `HYBRID`: diff-first with escalation to baseline review for high-risk components.

A diff-only review cannot silently become a baseline assurance claim.
