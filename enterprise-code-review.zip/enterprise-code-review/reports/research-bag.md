# Research Bag

## Decision

`proceed_with_assumptions`

The build adopts source-backed **patterns**, not a bundle of external runtime dependencies. Canon authority/provenance separation, Radar lifecycle gates, web3-docs normalization/index structure, Weft event-state semantics, and Atom-of-Thoughts typed graph structure are reimplemented in a bounded standard-library package.

## Hard rules supported

- Exact snapshot binding and new evidence epoch after a changed head.
- Model output is a claim; strong severity requires non-model evidence.
- Blind second review when true independent context exists; otherwise capability missing.
- 24-category impact coverage for repository modes.
- Retrieval and consensus cannot upgrade evidence authority.
- Pasted snippets cannot receive `READY_FOR_MERGE`.

## MISSING / SOURCE_NEEDED

- `MISSING`: independently verified lineage for the exact name **Atomic Sort / AtomSort**. The package uses a project-defined deterministic method and makes no external attribution.
- `SOURCE_NEEDED`: target-specific analyzer suitability, licensing, configuration, and runtime success.
- `MISSING`: benchmark on real repositories for precision, recall, false-positive rate, latency, and cost.

## Build boundary

No Canon/Radar source code is copied. No Web3 domain corpus, Claude-only hook, model-confidence termination, or mandatory SaaS reviewer is embedded.
