'use client';

import { CSSProperties, ReactNode, useRef } from 'react';
import './spotlight-card.css';

type SpotlightCardProps = {
  children: ReactNode;
  className?: string;
  spotlightColor?: string;
};

export function SpotlightCard({
  children,
  className = '',
  spotlightColor = 'rgba(255,255,255,0.18)',
}: SpotlightCardProps) {
  const ref = useRef<HTMLDivElement | null>(null);

  function onPointerMove(event: React.PointerEvent<HTMLDivElement>) {
    const element = ref.current;
    if (!element) return;
    const rect = element.getBoundingClientRect();
    element.style.setProperty('--spotlight-x', `${event.clientX - rect.left}px`);
    element.style.setProperty('--spotlight-y', `${event.clientY - rect.top}px`);
    element.style.setProperty('--spotlight-color', spotlightColor);
  }

  return (
    <div
      ref={ref}
      className={`ui-spotlight-card ${className}`}
      onPointerMove={onPointerMove}
      style={{ '--spotlight-color': spotlightColor } as CSSProperties}
    >
      {children}
    </div>
  );
}
