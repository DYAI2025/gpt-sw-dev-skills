'use client';

import { ReactNode, useRef } from 'react';
import './magnetic-wrapper.css';

type MagneticWrapperProps = {
  children: ReactNode;
  className?: string;
  strength?: number;
};

export function MagneticWrapper({ children, className = '', strength = 0.18 }: MagneticWrapperProps) {
  const ref = useRef<HTMLDivElement | null>(null);

  function onPointerMove(event: React.PointerEvent<HTMLDivElement>) {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const element = ref.current;
    if (!element) return;
    const rect = element.getBoundingClientRect();
    const dx = event.clientX - (rect.left + rect.width / 2);
    const dy = event.clientY - (rect.top + rect.height / 2);
    element.style.transform = `translate3d(${dx * strength}px, ${dy * strength}px, 0)`;
  }

  function reset() {
    const element = ref.current;
    if (!element) return;
    element.style.transform = 'translate3d(0, 0, 0)';
  }

  return (
    <div
      ref={ref}
      className={`ui-magnetic-wrapper ${className}`}
      onPointerMove={onPointerMove}
      onPointerLeave={reset}
      onBlur={reset}
    >
      {children}
    </div>
  );
}
