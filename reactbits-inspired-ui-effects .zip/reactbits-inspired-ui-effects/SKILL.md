---
name: reactbits-inspired-ui-effects
description: design, select, and integrate premium React frontend UI animation effects inspired by React Bits patterns. Use when requests mention ReactBits, animated UI components, text animations, cursor effects, particle backgrounds, shader backgrounds, magnetic cards, spotlight cards, scroll reveals, GSAP, Motion, three.js, ogl, Tailwind, shadcn, jsrepo, or adding high-quality interactive effects to websites without copying effects blindly.
---

# ReactBits-Inspired UI Effects

## Purpose

Use this skill to select, adapt, and integrate high-quality frontend animation effects into React, Next.js, Vite, or similar web projects. Treat React Bits as a pattern catalogue and installable component source, not as a reason to paste arbitrary effects without design intent, accessibility checks, dependency control, and performance constraints.

## Source basis

React Bits organizes effects into four semantic groups: Text Animations, Animations, Components, and Backgrounds. It offers JavaScript/CSS, JavaScript/Tailwind, TypeScript/CSS, and TypeScript/Tailwind variants, with dependency variation across components such as GSAP, Motion, three.js, and ogl. Use `references/effect-catalog.md` for the curated effect map and `references/integration-playbook.md` for implementation rules.

Do not claim that every effect has been live-tested in the target project unless it was actually installed and run. If the user asks for exact React Bits source code, fetch or install the official component through its documented CLI path and preserve license/attribution requirements from the source project.

## Workflow

### 1. Classify the website objective

Identify the target use case before choosing an effect:

- Hero section or landing-page first impression.
- Headline/text reveal.
- Cursor interaction or microinteraction.
- Card, grid, gallery, navigation, or menu enhancement.
- Full-screen background or shader atmosphere.
- Metric/counter/content reveal.
- Premium portfolio/product showcase.

Reject decorative overload. One dominant effect plus one supporting microinteraction is usually the maximum for a single viewport.

### 2. Choose the effect family

Use this routing table:

| Need | Prefer |
|---|---|
| premium headline entrance | SplitText, BlurText, GradientText, ScrollReveal |
| hero background atmosphere | Aurora, Particles, Silk, Waves, Beams, DotGrid |
| technical / AI / cyber aesthetic | FaultyTerminal, LetterGlitch, DecryptedText, GridMotion, Particles |
| tactile card interaction | SpotlightCard, TiltedCard, GlareHover, Magnet, PixelCard |
| premium navigation | GooeyNav, PillNav, Dock, FlowingMenu, CardNav |
| visual portfolio / product grid | MagicBento, ChromaGrid, Masonry, CircularGallery, ScrollStack |
| cursor delight | BlobCursor, ClickSpark, PixelTrail, SplashCursor, TargetCursor |
| 3D / shader showcase | Cubes, DomeGallery, FluidGlass, LiquidChrome, ModelViewer |

If the user gives an aesthetic adjective, translate it into effect constraints:

- `minimal` -> low particle count, subtle opacity, short duration, no noisy cursor trails.
- `premium` -> slow easing, restrained highlights, depth, not novelty.
- `playful` -> bounce, cursor trails, elastic controls, but keep focusable UI stable.
- `cyber` -> glitch, terminal, grid, particles, but avoid unreadable text.
- `luxury` -> glass, metallic, silk, subtle gradient, low motion amplitude.

### 3. Inspect project constraints

Before giving code or install instructions, determine or infer:

- Framework: React, Next.js App Router, Vite, Astro with React islands, Remix.
- Styling: CSS modules, global CSS, Tailwind, shadcn.
- Language: TypeScript or JavaScript.
- Motion tolerance: reduced-motion policy and target device class.
- Dependency budget: no dependency, GSAP, Motion, three.js, ogl, or shader stack.
- Rendering boundary: server component vs client component. Interactive effects require client components in Next.js.

If uncertain, choose TypeScript + CSS for durability and explicitly mark the assumption.

### 4. Integration method

Choose one of three methods:

1. **Official install path** for an exact React Bits component:
   - shadcn style: `npx shadcn@latest add https://reactbits.dev/r/<Component>-<LANG>-<STYLE>`
   - jsrepo style: `npx jsrepo add https://reactbits.dev/<variant>/<Category>/<Component>`
2. **Adapted implementation** when the user wants the effect idea but not the exact component.
3. **Custom built effect** when project constraints or brand direction require original code.

Never paste a heavy shader or full third-party source block when an official installer or reference path is more appropriate.

### 5. Quality gates

Every proposed effect must pass these gates:

- **Purpose gate:** identify what the animation helps the user notice or understand.
- **Performance gate:** avoid large WebGL/shader effects on content-heavy pages unless scoped to hero/background and paused offscreen.
- **Accessibility gate:** respect `prefers-reduced-motion`; keep text readable; avoid essential information only appearing through animation.
- **Interaction gate:** hover/cursor effects must not block clicks, focus, keyboard navigation, or mobile use.
- **Composition gate:** do not stack multiple high-energy effects in the same viewport.
- **Cleanup gate:** event listeners, animation frames, observers, GSAP triggers, WebGL contexts, and timeouts must be disposed on unmount.
- **Responsiveness gate:** test small screens, coarse pointers, and reduced GPU power.

### 6. Implementation response structure

When the user asks to add or design an effect, answer with:

1. **Effect choice** — selected effect and why.
2. **Fit assessment** — brand/UX fit, dependency impact, risk.
3. **Install or code path** — official install command or original implementation snippet.
4. **Integration steps** — exact files, imports, and placement.
5. **Tuning knobs** — duration, easing, colors, intensity, count, threshold.
6. **Quality checks** — performance, reduced motion, cleanup, mobile.
7. **Fallback** — CSS-only or static alternative if JS/WebGL is unsuitable.

For larger work, use `scripts/select_effect.py` to create a first-pass recommendation and then refine manually.

## References

- `references/effect-catalog.md` — curated React Bits effect taxonomy and CLI patterns.
- `references/integration-playbook.md` — practical rules for React/Next/Tailwind integration.
- `references/prompt-recipes.md` — paste-ready prompts for requesting high-quality implementation.
- `assets/spotlight-card.tsx` — small original spotlight-card starter.
- `assets/magnetic-wrapper.tsx` — small original magnetic-wrapper starter.
- `assets/reduced-motion.css` — baseline reduced-motion policy.

## Examples

### Example 1 — Hero section

Request: `Build a premium SaaS hero with subtle motion, no gimmicks.`

Expected response: choose Aurora or Silk as a restrained background, SplitText or BlurText for the headline, one CTA hover microinteraction, reduced-motion fallback, and no cursor trail.

### Example 2 — Portfolio grid

Request: `Make my project cards feel more expensive.`

Expected response: choose SpotlightCard or TiltedCard, keep card text readable, use low-intensity glare, provide TypeScript component integration and mobile fallback.

### Example 3 — AI dashboard

Request: `Add an AI/data feeling to the landing page.`

Expected response: choose Particles, DotGrid, GridMotion, or DecryptedText depending on density and readability. Prefer subtle background motion plus metric CountUp, not glitch everywhere.
