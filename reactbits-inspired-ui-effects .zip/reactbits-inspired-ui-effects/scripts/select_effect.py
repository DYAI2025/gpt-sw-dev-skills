#!/usr/bin/env python3
"""Recommend ReactBits-inspired UI effects from intent constraints.

Examples:
  python scripts/select_effect.py --goal hero --mood premium --motion-budget low
  python scripts/select_effect.py --goal cards --mood luxury --framework next
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass


@dataclass(frozen=True)
class Recommendation:
    primary: str
    support: str
    avoid: str
    rationale: str
    dependency: str


RULES: dict[tuple[str, str], Recommendation] = {
    ("hero", "premium"): Recommendation("Aurora or Silk", "SplitText or BlurText", "cursor trails", "premium hero sections need atmosphere plus readable headline motion", "CSS/Motion or shader depending on chosen component"),
    ("hero", "cyber"): Recommendation("DotGrid or Particles", "DecryptedText sparingly", "multiple glitch layers", "cyber mood benefits from grid/particle systems but text must remain readable", "ogl or CSS depending on component"),
    ("hero", "luxury"): Recommendation("Silk or Iridescence", "ShinyText", "noisy particles", "luxury motion should be slow, smooth, and low contrast", "shader/CSS depending on component"),
    ("cards", "premium"): Recommendation("SpotlightCard", "GlareHover", "tilt plus glare plus decay together", "cards need controlled pointer feedback without readability loss", "CSS only or light JS"),
    ("cards", "luxury"): Recommendation("GlassSurface or SpotlightCard", "GlareHover", "pixel/retro effects", "luxury cards benefit from light and material cues", "CSS or WebGL if glass distortion is required"),
    ("navigation", "premium"): Recommendation("PillNav or FlowingMenu", "Magnet on CTA only", "cursor takeover", "navigation must remain predictable and accessible", "CSS/Motion"),
    ("portfolio", "playful"): Recommendation("MagicBento or ChromaGrid", "TiltedCard", "global glitch background", "portfolio pages can carry richer visual interaction if content remains scannable", "Motion/CSS"),
}

FALLBACKS: dict[str, Recommendation] = {
    "hero": Recommendation("Aurora", "BlurText", "high-energy cursor trails", "safe default for a modern hero", "CSS/Motion"),
    "cards": Recommendation("SpotlightCard", "Magnet", "heavy shader on each card", "safe tactile card improvement", "CSS only or light JS"),
    "navigation": Recommendation("PillNav", "subtle active highlight", "complex 3D nav", "navigation should stay stable", "CSS/Motion"),
    "background": Recommendation("Waves or Particles", "Noise at very low opacity", "dense WebGL behind text", "background should support content hierarchy", "CSS/ogl"),
    "text": Recommendation("SplitText", "GradientText", "long typewriter delays", "headline motion works best when short and purposeful", "GSAP or Motion"),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--goal", choices=["hero", "cards", "navigation", "background", "text", "portfolio"], required=True)
    parser.add_argument("--mood", default="premium", choices=["minimal", "premium", "cyber", "luxury", "playful"])
    parser.add_argument("--framework", default="react", choices=["react", "next", "vite", "astro"])
    parser.add_argument("--motion-budget", default="medium", choices=["low", "medium", "high"])
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    rec = RULES.get((args.goal, args.mood), FALLBACKS.get(args.goal, FALLBACKS["hero"]))
    warnings: list[str] = []
    if args.motion_budget == "low":
        warnings.append("Prefer CSS-only or low-density Motion implementation; disable shader/cursor-heavy variants.")
    if args.framework == "next":
        warnings.append("Use a client component boundary for pointer, scroll, canvas, and browser API effects.")
    if args.goal in {"background", "hero"} and args.motion_budget == "high":
        warnings.append("Still provide reduced-motion and mobile fallback; high motion is not a license for visual noise.")

    print(json.dumps({
        "primary_effect": rec.primary,
        "supporting_effect": rec.support,
        "avoid": rec.avoid,
        "rationale": rec.rationale,
        "dependency_note": rec.dependency,
        "warnings": warnings,
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
