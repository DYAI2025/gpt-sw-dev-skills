# ReactBits effect catalog

## Evidence and scope

React Bits is described as an open-source collection of UI elements across Components, Animations, Backgrounds, and Text Animations. It provides four implementation variants: JavaScript + CSS, JavaScript + Tailwind, TypeScript + CSS, and TypeScript + Tailwind. Its documented CLI patterns include shadcn and jsrepo forms.

Use this file as a selection catalogue, not as a guarantee that every component suits every project.

## Installation command patterns

### shadcn

```bash
npx shadcn@latest add https://reactbits.dev/r/<Component>-<LANG>-<STYLE>
```

- `<LANG>`: `JS` or `TS`
- `<STYLE>`: `CSS` or `TW`
- Example:

```bash
npx shadcn@latest add https://reactbits.dev/r/SplitText-TS-CSS
```

### jsrepo

```bash
npx jsrepo add https://reactbits.dev/<variant>/<Category>/<Component>
```

- `<variant>`: `default`, `tailwind`, `ts/default`, or `ts/tailwind`
- `<Category>`: `TextAnimations`, `Animations`, `Components`, `Backgrounds`
- Example:

```bash
npx jsrepo add https://reactbits.dev/ts/default/TextAnimations/SplitText
```

## Text animations

| Effect | Use when | Risk | Default tuning |
|---|---|---|---|
| ASCIIText | retro / terminal hero | can look novelty | low opacity, slow speed |
| BlurText | soft premium reveal | overuse causes sluggish feel | 400-700ms, once |
| CircularText | badge / emblem / visual accent | low readability | short labels only |
| CountUp | metrics / proof points | fake precision | real numbers only |
| CurvedLoop | decorative loop typography | can distract | background or divider |
| DecryptedText | AI/cyber reveal | cliché risk | one phrase only |
| FallingText | playful intro | childish if overused | small scope |
| FuzzyText | distorted tech text | readability | hover only |
| GlitchText | cyber tension | eye strain | brief bursts |
| GradientText | premium headline | color clash | slow gradient sweep |
| RotatingText | positioning variants | layout shift | fixed width container |
| ScrambledText | cursor-driven reveal | pointer-only | fallback static text |
| ScrollFloat | editorial scroll | motion sickness | tiny amplitude |
| ScrollReveal | long-form content reveal | excessive scroll hooks | threshold-based once |
| ScrollVelocity | kinetic marquee | attention drain | brand strips only |
| ShinyText | CTA/text highlight | cheap if too bright | subtle sheen |
| Shuffle | playful reveal | can delay reading | short labels |
| SplitText | high-end staggered heading | dependency/cleanup | words for headlines, chars for short text |
| TextCursor | cursor trail text | can obstruct UI | decorative zones only |
| TextPressure | interactive typographic hero | accessibility | no essential text only |
| TextType | typewriter | slow content access | short phrases |
| TrueFocus | guided word focus | cognitive load | onboarding/hero only |
| VariableProximity | responsive typography | pointer dependency | use for demos |

## Animations and microinteractions

| Effect | Use when | Notes |
|---|---|---|
| AnimatedContent | generic mount/scroll reveal | good default wrapper |
| BlobCursor | playful cursor | avoid on form-heavy pages |
| ClickSpark | click feedback | low-risk if subtle |
| Crosshair | technical/canvas feel | risky for normal sites |
| Cubes | 3D accent | hero/showcase only |
| ElectricBorder | energetic CTA/card | tune down intensity |
| FadeContent | simple reveal | safest motion primitive |
| GhostCursor | cursor trail | avoid productivity UIs |
| GlareHover | premium card hover | good for cards/images |
| GradualBlur | cinematic reveal | verify readability |
| ImageTrail | visual portfolio | pointer-only, mobile fallback |
| LaserFlow | sci-fi surface | high novelty |
| LogoLoop | partner/brand marquee | pause on hover |
| Magnet | tactile buttons/cards | must not move too far |
| MagnetLines | interactive visual field | hero accent |
| MetaBalls | liquid blobs | background/accent only |
| MetallicPaint | SVG premium look | asset-specific |
| Noise | film grain | subtle opacity only |
| PixelTrail | retro pointer trail | decorative zones |
| PixelTransition | reveal on hover | image/card transition |
| Ribbons | fluid cursor trail | high GPU risk |
| ShapeBlur | morphing hover | accent only |
| SplashCursor | liquid click/cursor | playful sites only |
| StarBorder | CTA sparkle | avoid overuse |
| StickerPeel | tactile sticker | product/portfolio detail |
| TargetCursor | focus/lock cursor | game/interactive demos |

## Components

| Effect | Use when | Notes |
|---|---|---|
| AnimatedList | staggered feature lists | safe and useful |
| BounceCards | playful card intro | avoid corporate tone |
| BubbleMenu | floating action menu | mobile consideration |
| CardNav | richer navigation | content-heavy nav |
| CardSwap | product cards | layout control needed |
| Carousel | galleries/testimonials | accessibility critical |
| ChromaGrid | portfolio grid | good premium reveal |
| CircularGallery | image showcase | hero/portfolio |
| Counter | metrics | pair with real data |
| DecayCard | experimental hover card | not for primary content |
| Dock | app-like nav | only if metaphor fits |
| DomeGallery | immersive portfolio | high complexity |
| ElasticSlider | playful controls | use sparingly |
| FlowingMenu | premium nav | strong fit for creative sites |
| FluidGlass | glassmorphism | GPU/performance check |
| FlyingPosters | 3D scrolling showcase | hero/portfolio |
| Folder | nested reveal | skeuomorphic pattern |
| GlassIcons | icon styling | visual consistency needed |
| GlassSurface | Apple-style panel | strong brand constraint |
| GooeyNav | playful premium nav | avoid if conservative brand |
| InfiniteMenu | continuous menu strip | ensure control/pause |
| InfiniteScroll | content feed | accessibility/pagination |
| Lanyard | 3D badge | personal/portfolio |
| MagicBento | interactive bento grid | good landing pattern |
| Masonry | visual grids | image-heavy content |
| ModelViewer | 3D product | asset pipeline needed |
| PillNav | minimal nav | safe, modern |
| PixelCard | retro reveal card | niche aesthetic |
| ProfileCard | personal card | portfolio/team pages |
| ScrollStack | stacked cards on scroll | strong storytelling |
| SpotlightCard | premium cards | low dependency option |
| Stack | swipe/stack | mobile/story cards |
| StaggeredMenu | animated menu | good for mobile nav |
| Stepper | onboarding/flows | useful UI pattern |
| TiltedCard | 3D hover card | good for hero/product cards |

## Backgrounds

| Effect | Use when | Notes |
|---|---|---|
| Aurora | premium gradient hero | strong default |
| Balatro | game/shader aesthetic | niche |
| Ballpit | playful physics | heavy / novelty |
| Beams | tech/saaS hero | tune density |
| ColorBends | vivid modern hero | brand color matching |
| DarkVeil | subtle dark atmosphere | safe dark mode |
| Dither | retro shader | niche |
| DotGrid | tech background | good for AI/data |
| FaultyTerminal | CRT/cyber | readability risk |
| Galaxy | space/deep tech | thematic constraint |
| GradientBlinds | bold gradient hero | visual dominance |
| GridDistortion | interactive grid | hero only |
| GridMotion | perspective grid | tech/AI |
| Hyperspeed | speed/futurism | very intense |
| Iridescence | luxury gradient | premium, subtle |
| LetterGlitch | matrix/cyber | avoid behind text |
| Lightning | high energy | rare use |
| LightRays | cinematic hero | good visual depth |
| LiquidChrome | metallic shader | luxury/3D product |
| LiquidEther | liquid color field | strong atmosphere |
| Orb | focal background object | hero center/accent |
| Particles | configurable particles | reliable tech default |
| PixelBlast | energetic pixel burst | game/creative only |
| Plasma | organic color | high visual energy |
| Prism | geometric light | premium hero |
| PrismaticBurst | light-ray accent | focal hero |
| RippleGrid | animated grid | technical background |
| Silk | soft luxury background | good premium default |
| Squares | geometric motion | minimal tech |
| Threads | fabric-line background | subtle motion texture |
| Waves | calm layered motion | safer than particles |

## Effect-selection shortcuts

- SaaS homepage: Aurora + SplitText + SpotlightCard.
- AI product: DotGrid or Particles + DecryptedText sparingly + CountUp.
- Luxury/premium brand: Silk or Iridescence + ShinyText + GlareHover.
- Developer/tool site: GridMotion or Particles + SplitText + Magnet buttons.
- Portfolio: ChromaGrid or MagicBento + TiltedCard + ImageTrail only if portfolio is visual.
- Calm coaching/consulting: BlurText + FadeContent + Waves; avoid glitch/cursor chaos.
