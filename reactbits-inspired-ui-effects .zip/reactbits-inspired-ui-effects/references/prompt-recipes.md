# Prompt recipes for premium UI effects

## Hero effect prompt

```text
Design and implement a premium React hero animation for this section:
- Brand mood: [minimal / premium / cyber / luxury / playful]
- Framework: [Next.js / Vite / React]
- Styling: [CSS / Tailwind / CSS Modules]
- Motion budget: [low / medium / high]
- Preferred ReactBits family: [Backgrounds / TextAnimations / Animations]
- Must include reduced-motion fallback.
Return: effect choice, installation/code path, component code, CSS, tuning knobs, and test checklist.
```

## Card interaction prompt

```text
Add a high-quality card interaction to this React component without hurting readability or mobile usability.
Use a ReactBits-inspired pattern such as SpotlightCard, TiltedCard, GlareHover, Magnet, or PixelCard.
Constraints:
- no layout shift
- keyboard focus preserved
- reduced-motion supported
- no heavy dependency unless justified
Return exact file changes and explain the tuning knobs.
```

## Background prompt

```text
Select and implement one premium animated background for a website hero.
Goal: support the brand message, not distract from conversion.
Choose among Aurora, Silk, Waves, Particles, DotGrid, Beams, or Iridescence patterns.
Return a restrained implementation with opacity, particle/density limits, mobile fallback, and accessibility notes.
```

## Audit prompt

```text
Audit this website section for animation quality.
Score from 1-5:
- purpose fit
- visual hierarchy
- performance risk
- accessibility
- brand fit
- composition discipline
Then recommend one ReactBits-inspired effect to add, one to avoid, and exact implementation steps.
```
