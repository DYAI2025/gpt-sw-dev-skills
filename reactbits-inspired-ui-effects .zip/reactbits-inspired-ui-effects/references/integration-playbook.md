# Integration playbook

## Default assumptions

Prefer TypeScript + CSS unless the project already uses Tailwind as its primary styling system. In Next.js App Router, put interactive animation components behind a client boundary with `'use client'`.

## Dependency policy

| Dependency | Use for | Caution |
|---|---|---|
| CSS only | spotlight, hover, fade, simple reveal | safest default |
| Motion | layout transitions, enter/exit, stagger | bundle impact acceptable in many apps |
| GSAP | advanced timelines, SplitText, ScrollTrigger | plugin cleanup and license awareness |
| three.js | 3D models/scenes | high complexity and bundle cost |
| ogl | lightweight WebGL shaders/particles | GPU and cleanup needed |

## React / Next.js rules

1. Interactive effects using pointer, scroll, canvas, WebGL, or browser APIs must be client components.
2. Never access `window`, `document`, canvas, or media queries during server render.
3. Initialize animations inside `useEffect`, `useLayoutEffect`, or a library-specific hook.
4. Dispose every listener, animation frame, observer, timeline, WebGL renderer, and ScrollTrigger on unmount.
5. Avoid layout shift: reserve component height and width before animation starts.
6. Keep content readable before, during, and after animation.

## Reduced motion baseline

Use a reduced-motion hook or CSS. If reduced motion is active:

- Replace staggered and scroll animations with immediate visible state.
- Pause particles and shader motion.
- Disable cursor-follow and hover-warp effects.
- Keep essential content visible.

## Composition rules

- One hero background effect per section.
- One headline effect per hero.
- One card hover effect per card system.
- Do not combine glitch, cursor trail, particle background, and scroll parallax in the same viewport.
- Use static screenshots or low-motion fallbacks for mobile when GPU cost is high.

## Tuning knobs

| Knob | Safe range |
|---|---|
| reveal duration | 0.35s to 0.9s |
| stagger | 0.015s to 0.08s per item |
| hover transform | 2px to 12px movement, 1deg to 8deg tilt |
| particle count | 40 to 250 for hero; less on mobile |
| blur radius | 4px to 16px reveal; avoid persistent blur on text |
| background opacity | 0.08 to 0.35 behind content |
| cursor trail length | 3 to 12 items only in decorative areas |

## Implementation checklist

Before finalizing, verify:

- `prefers-reduced-motion` behavior exists.
- Keyboard navigation still works.
- Hover effects do not hide focus indicators.
- Canvas layers use `pointer-events: none` unless intentionally interactive.
- Offscreen backgrounds pause or reduce work when hidden.
- Lighthouse/performance checks do not show obvious regressions.
- CSS variables are scoped, not leaked globally.

## Official install decision

Use official React Bits CLI installation when the user wants the named component exactly. Use adapted original code when the user asks for a similar aesthetic but project constraints differ.

### shadcn command shape

```bash
npx shadcn@latest add https://reactbits.dev/r/<Component>-TS-CSS
```

### jsrepo command shape

```bash
npx jsrepo add https://reactbits.dev/ts/default/<Category>/<Component>
```
