# Framework Cards

## Card 1 - ISO 25010 Quality Taxonomy

Use for: normalizing quality findings.

Map findings to quality attributes:

- Functional suitability: correctness, completeness, appropriateness.
- Performance efficiency: time behavior, resource use, capacity.
- Compatibility: coexistence and interoperability.
- Interaction capability/usability: learnability, operability, accessibility, error protection.
- Reliability: availability, fault tolerance, recoverability.
- Security: confidentiality, integrity, authenticity, accountability, resilience.
- Maintainability: modularity, reusability, analyzability, modifiability, testability.
- Flexibility/portability: adaptability, installability, replaceability, scalability.
- Safety: prevention of harm to people, property, environment, or critical operations.

Action rule: do not output a global quality score unless each score has evidence and limitation.

## Card 2 - ISO 42010 Architecture Description Views

Use for: architecture report completeness.

Minimum useful views:

- stakeholder/concern table;
- context view;
- container/service view;
- component/module view;
- runtime flow view;
- deployment/infrastructure view;
- data/integration view;
- security/trust-boundary view;
- evolution/risk view.

Action rule: architecture diagrams describe models. Validate against actual dependencies, runtime evidence, or stakeholder confirmation.

## Card 3 - ATAM-style Trade-off Review

Use for: non-trivial architecture decisions.

Actions:

1. Elicit business drivers and quality attributes.
2. Build utility tree with measurable quality scenarios.
3. Prioritize scenarios by business value and architectural difficulty.
4. Identify architecture approaches and tactics.
5. Identify sensitivity points, trade-offs, non-risks, and risks.
6. Cluster risk themes and remediation options.

Failure gate: no trade-off claim without a quality-attribute scenario.

## Card 4 - Lightweight Architecture Health Check

Use for: fast maturity and risk snapshot.

Check:

- scalability, reliability, deployment, interoperability, compliance, observability;
- data integrity, security, testability, maintainability, upgradeability;
- dependency cliques, ownership concentration, missing runbooks, incident/rollback gaps.

Output: red/yellow/green health map plus evidence limitations. State that this is a heuristic snapshot, not a full formal assessment.

## Card 5 - DDD Backend Audit

Use for: backend/domain analysis.

Actions:

- identify ubiquitous language from UI labels, APIs, entities, docs, tests, and code identifiers;
- find bounded contexts and context relationships;
- map aggregates, aggregate roots, invariants, domain services, repositories, events;
- locate domain leakage into controllers, ORM, UI, third-party SDKs, or job scripts;
- check anti-corruption boundaries for external systems.

Finding pattern: `domain concept is scattered across controller, ORM model, and UI state without a cohesive application/domain boundary`.

## Card 6 - Clean Architecture / Ports & Adapters Check

Use for: dependency direction, testability, and framework independence.

Actions:

- identify domain/entities;
- identify use cases/application services;
- identify ports/interfaces;
- identify adapters/controllers/presenters/repositories/gateways;
- identify frameworks/drivers;
- flag inward dependency violations and direct infrastructure coupling.

Evidence: imports, package graph, file paths, tests, dependency-cruiser/ArchUnit/import-linter output.

## Card 7 - API Contract Audit

Use for: HTTP, GraphQL, event, webhook, and RPC integrations.

Actions:

- locate OpenAPI, AsyncAPI, schema, protobuf, Postman, SDK, route, or event files;
- compare docs with implementation routes and observed behavior;
- check auth, versioning, errors, pagination, idempotency, rate limits, retries, timeouts;
- inspect schema drift and backward compatibility;
- validate at least one real endpoint if runtime exists.

Failure gate: no API compatibility claim without contract and implementation evidence.

## Card 8 - Frontend Architecture Audit

Use for: React, Vue, Angular, Next, Nuxt, Svelte, or generic UI systems.

Actions:

- map routes, route guards, layouts, components, and design system usage;
- classify state ownership: component, app store, server cache, URL, form, session;
- inspect data fetching, cache invalidation, optimistic updates, stale/error states;
- inspect loading, error, empty, permission, offline, and responsive states;
- inspect accessibility and keyboard-flow evidence;
- measure performance only with lab or field evidence.

Failure gate: a visible button is not proof that its business flow works.

## Card 9 - Security Verification Layer

Use for: security and privacy review.

Actions:

- apply relevant OWASP ASVS/WSTG/SAMM and NIST SSDF families when sources are available;
- run or mark not-run for SAST, SCA, SBOM, secret scanning, and dynamic checks;
- check authN/authZ, tenant isolation, input validation, output encoding, SSRF, XSS, SQLi, file upload, session/cookies, logging privacy;
- redact secrets and require rotation when a real credential is likely exposed.

Safety boundary: provide defensive findings and remediation, not exploitation instructions.

## Card 10 - Supply Chain and License Audit

Use for: dependency and artifact trust.

Actions:

- identify package managers, lockfiles, direct/transitive dependencies;
- generate or request SBOM where possible;
- check known vulnerabilities, licenses, pinned dependencies, abandoned packages;
- inspect CI trust, signed releases, provenance, branch protection, dependency update process;
- classify maturity with SLSA/OpenSSF-style checks only when evidence exists.

Failure gate: dependency vulnerability is not exploitability proof without context.

## Card 11 - Runtime / Cloud / Container Readiness

Use for: deployment, operations, and production-readiness candidates.

Checks:

- config separation, secrets management, environment parity;
- container files, deployment manifests, health endpoints, readiness/liveness probes;
- logging, metrics, traces, alerts, dashboards, SLOs;
- resource requests/limits, scale strategy, queues/workers, zero-downtime rollout;
- rollback, migrations, backward-compatible API changes.

Failure gate: `it deploys` is not production readiness.

## Card 12 - Git Forensics / Software Archaeology

Use for: historical risk and maintainability signals.

Actions:

- identify churn hotspots;
- combine churn with complexity and criticality;
- identify temporal coupling;
- identify authorship concentration and bus factor;
- inspect bug-fix clusters, reverts, emergency commits, old abandoned modules;
- connect history risk to current architecture boundaries.

Failure gate: do not equate high churn alone with bad code. Interpret as a signal.

## Card 13 - AI-era Application Controls

Use when prompts, RAG, tools, agents, model calls, embeddings, evals, or autonomous actions exist.

Actions:

- treat prompts, schemas, evals, RAG templates, and tool manifests as production logic;
- version prompts and model/tool configs;
- inspect retrieval sources, chunking, filters, citations, PII handling;
- test prompt injection, data leakage, unsafe tool use, and permission boundaries;
- separate model-level safety from application-level access control;
- require least privilege for service accounts, API keys, and agent tools.

Failure gate: no AI safety/reliability claim without eval evidence and permission review.

## Card 14 - Reporting and Remediation Model

Use for: final audit outputs.

Every finding must include ID, title or claim, domain, severity, evidence, evidence class, business impact, remediation, owner type, verification method, and limitation.

Prioritize by:

1. user/business impact;
2. security/privacy blast radius;
3. evidence confidence;
4. implementation cost;
5. reversibility;
6. dependency on other fixes;
7. value of the next learning step.
