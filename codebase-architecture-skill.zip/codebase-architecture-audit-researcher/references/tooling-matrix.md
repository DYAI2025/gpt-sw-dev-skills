# Tooling Matrix

Use tools by capability, not brand. Confirm current installation, license, CLI syntax, and output formats from official docs before precise claims.

| Category | Tools / practices | use_for | minimum_input | output | caveat | evidence_class | source_status |
|---|---|---|---|---|---|---|---|
| Language detection | GitHub Linguist, file tree, manifests | repo inventory and generated/vendor separation | repository or file tree | language/framework map | generated/vendor code can distort results | source-inspected | official_docs_needed |
| SAST | CodeQL, Semgrep, SonarQube, language-native analyzers | vulnerability and risky code-pattern detection | source plus config/rules | findings report | false positives need triage | static-analysis | official_docs_needed |
| Quality | eslint/tsc, ruff/mypy, golangci-lint, clippy, SonarQube | type safety, lint, maintainability, complexity, smells | configured project | pass/fail and metric report | metric is not business impact | static-analysis | official_docs_needed |
| Dependency/SCA | OWASP Dependency-Check, OSV-Scanner, Snyk, npm audit, pip-audit, cargo audit | dependency vulnerabilities | lockfiles/manifests | vulnerability list | exploitability requires context | static-analysis | official_docs_needed |
| SBOM/license | CycloneDX tools, SPDX tools, Syft, Trivy | composition, license, supply chain transparency | manifests or artifacts | SBOM and license metadata | completeness varies by ecosystem | static-analysis | official_docs_needed |
| Secrets | Gitleaks, TruffleHog, GitHub secret scanning | leaked credential candidates | repo and optionally history | secret candidates | redact output and rotate if real | static-analysis | official_docs_needed |
| Architecture lint | ArchUnit, NetArchTest, dependency-cruiser, import-linter, custom AST rules | enforce architectural boundaries | code plus declared rules | boundary pass/fail | bad rules create noise | static-analysis | official_docs_needed |
| Dependency graph | madge, dependency-cruiser, pydeps, go list, jdeps, nx graph | cycles, coupling, graph structure | project graph/build files | graph report | graph needs human interpretation | static-analysis | official_docs_needed |
| API contract | Spectral, Schemathesis, Postman/Newman, Dredd, contract tests | API spec validation and drift checks | API spec plus implementation/runtime | validation/test results | mocked API is not real-boundary proof | integration | official_docs_needed |
| Browser E2E | Playwright, Cypress | critical UI flows and browser behavior | running app and test data | browser flow evidence | mock-only tests are fake-only | browser-live | official_docs_needed |
| Frontend performance | Lighthouse, PageSpeed Insights, web-vitals RUM | LCP/INP/CLS, lab and field performance | deployed/local target | performance metrics | lab data is not field data | browser-live | official_docs_needed |
| API performance | k6, autocannon, wrk, vegeta-like tools | latency, throughput, error rate under load | endpoint and scenario | response/error metrics | needs realistic load model | real-boundary-smoke | official_docs_needed |
| Runtime/observability | logs, traces, metrics, OpenTelemetry, Prometheus/Grafana-like systems | actual behavior, failures, health, SLO signals | running system | runtime evidence | access often unavailable | production-observed | official_docs_needed |
| Git forensics | git log, git blame, Code Maat, CodeScene-like hotspot analysis | churn, temporal coupling, ownership, bus factor | git history | risk map | Goodhart and recency bias risk | source-inspected | official_docs_needed |
| Supply-chain assurance | SLSA, OpenSSF Scorecard, Sigstore/cosign, in-toto | provenance and artifact trust | repo/build pipeline/artifact | assurance report | may need CI/provider access | source-inspected | official_docs_needed |
| AI app checks | prompt tests, RAG evals, jailbreak/prompt-injection suites, tool-permission review | AI behavior and permission risk | prompts, tools, model config, eval data | eval findings | model behavior can drift | integration | official_docs_needed |

## Minimum scan suite by repository type

### Node / TypeScript

- Detect package manager: npm, yarn, pnpm, bun.
- Run install/build/test only when safe and feasible.
- Run `tsc --noEmit` when TypeScript is configured.
- Run eslint/biome when configured.
- Run dependency audit and lockfile review.
- Use dependency-cruiser or equivalent for import boundaries when rules can be defined.

### Python

- Inspect pyproject, requirements, setup files, poetry/uv/pipenv config.
- Run pytest when configured and dependencies are available.
- Run ruff/flake8/pylint as present.
- Run mypy/pyright if configured.
- Run pip-audit/OSV where feasible.
- Use import-linter/pydeps for architecture checks when applicable.

### Java / Kotlin

- Run Maven/Gradle build and tests when feasible.
- Use SpotBugs/Checkstyle/PMD when configured.
- Use ArchUnit for architecture rules.
- Use Dependency-Check or equivalent SCA.
- Use jdeps for dependency relations when useful.

### Go

- Run `go test ./...` when feasible.
- Run `go vet` and staticcheck when available.
- Run govulncheck when available.
- Use `go list` for dependency and package graph signals.

### Frontend deployed app

- Run Playwright/Cypress smoke for critical flows when app can run.
- Run Lighthouse/PageSpeed/Web Vitals where appropriate.
- Run accessibility scan plus manual keyboard path where possible.
- Audit routes, links, buttons, forms, loading/error/empty states.
- Inspect bundle, assets, fonts, images, hydration, cache strategy.

## Tool-gating rule

Do not say a tool was used unless there is command output, report artifact, screenshot, CI output, API response, or equivalent evidence. If a tool is unavailable, write `not-run` and explain the limitation.
