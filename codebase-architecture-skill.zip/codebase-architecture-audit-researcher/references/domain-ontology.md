# Domain Ontology

## Core entities

- **Repository inventory**: language mix, package managers, manifests, build systems, frameworks, generated/vendor/binary/test/demo code, deployment assets.
- **System boundary**: apps, APIs, workers, jobs, queues, databases, external services, auth providers, file stores, model providers, CI/CD, observability systems.
- **Business-critical flow**: user-visible or operational path whose failure creates direct product, revenue, security, compliance, or trust risk.
- **Architecture view**: representation for one concern: context, container, component/module, runtime, deployment, data, security/trust boundary, integration, evolution.
- **API contract**: OpenAPI, AsyncAPI, GraphQL schema, protobuf/gRPC definitions, Postman collections, route definitions, event schemas, or equivalent.
- **Evidence class**: confidence category for a claim, from `unverified` through `production-observed`.
- **Finding**: concrete issue, strength, gap, or risk with evidence, impact, severity, remediation, owner, verification, and limitation.
- **Technical debt**: future cost from code, tests, dependencies, architecture, data, platform, or process decisions.
- **Architecture drift**: divergence between intended architecture, documented architecture, actual dependencies, and runtime behavior.
- **Mock-only behavior**: behavior proven only by fake data, mocks, fixtures, stubs, demo mode, or screenshots; cannot prove real functionality.
- **Agent handoff**: scoped implementation brief for a coding agent with facts, constraints, acceptance criteria, tests, and forbidden assumptions.

## Required separation

Always separate:

1. Facts observed in files, command outputs, docs, screenshots, logs, or runtime checks.
2. Assumptions inferred from naming, structure, conventions, or partial evidence.
3. Missing evidence required to strengthen a claim.
4. Blockers that prevent validation.
5. Risk hypotheses that require follow-up.
6. Verified conclusions supported by sufficient evidence class.

## Audit domains

Use these domains in findings and reports:

- `repo`: structure, manifests, build system, generated/vendor/demo code.
- `backend`: domain logic, service boundaries, controllers, jobs, workers, queues.
- `frontend`: routes, components, state, rendering, UX states, accessibility.
- `api`: HTTP, GraphQL, event, gRPC, webhook, SDK, contract, versioning.
- `data`: schema, migrations, indexes, constraints, transactions, ownership, retention.
- `security`: authN, authZ, input validation, sessions, secrets, threat surface.
- `privacy`: data minimization, PII exposure, logging, retention, consent, jurisdiction.
- `supply-chain`: dependencies, lockfiles, SBOM, licenses, provenance, CI trust.
- `testing`: unit, integration, E2E, contract, mutation, coverage quality, test drift.
- `runtime`: deployment, env config, health checks, live flows, real integrations.
- `performance`: latency, throughput, Core Web Vitals, resource use, load behavior.
- `observability`: logs, metrics, traces, alerts, error reporting, SLOs.
- `history`: churn, ownership, temporal coupling, bus factor, drift, firefighting.
- `ai`: prompts, RAG, tools, models, evals, agent permissions, prompt injection risk.
- `process`: CI/CD, release discipline, review policy, incident/rollback process.
- `documentation`: architecture docs, ADRs, runbooks, API docs, onboarding docs.

## Claim classes

- **Inventory claim**: what exists in the repository.
- **Quality claim**: maintainability, reliability, security, performance, accessibility, compatibility, or flexibility assessment.
- **Runtime claim**: what the system does when running.
- **Security claim**: risk or control related to confidentiality, integrity, availability, authentication, authorization, privacy, or supply chain.
- **Compatibility claim**: API/schema/tool/framework/version behavior across boundaries.
- **Production-readiness claim**: deployment, observability, security, performance, reliability, recovery, and acceptance posture.
- **Remediation claim**: proposed change and expected effect.
