# Evidence Taxonomy

## Evidence classes

| Evidence class | Meaning | Supports | Does not support |
|---|---|---|---|
| `unverified` | Claim has not been checked against evidence. | Candidate questions, missing-evidence lists. | Findings, scores, done claims. |
| `source-inspected` | Files, docs, config, manifests, schemas, or source code were inspected. | Inventory, architecture candidates, static structure. | Runtime behavior or production readiness. |
| `static-analysis` | Tool output from lint, typecheck, SAST, SCA, SBOM, graph, complexity, secret scan. | Candidate defects, quality signals, dependency risk. | Exploitability, user-visible behavior, production readiness. |
| `unit-only` | Unit tests passed for isolated logic. | Isolated behavior under test. | Integration, API behavior, browser behavior, production behavior. |
| `integration` | Multi-component or contract test evidence. | Integration behavior in test boundary. | Production behavior unless production-like boundary is proven. |
| `real-boundary-smoke` | Critical flow checked against real local/staging/external boundary. | Runtime claim for checked flow. | Broad production readiness. |
| `browser-live` | Browser flow executed against running app. | UI behavior for tested flow. | Backend correctness beyond observed flow. |
| `production-observed` | Logs, metrics, traces, incident data, RUM, production checks. | Production behavior within observed window. | Future guarantee without ongoing controls. |
| `user-confirmed` | User or maintainer confirms context, behavior, or acceptance. | Context, intent, acceptance, known constraints. | Technical proof by itself. |
| `fake-only` | Evidence comes only from mocks, stubs, fixtures, screenshots, demo mode. | UI intent or test fixture behavior. | Real API/runtime/integration behavior. |
| `contradicted` | Evidence conflicts with the claim. | Reframing, blocker, false-positive correction. | Original claim. |

## Claim support rules

1. Inventory claims require `source-inspected` or better.
2. Code quality candidate findings require `source-inspected` or `static-analysis`.
3. Security findings require source/tool evidence and safe framing; exploitability needs additional context.
4. API compatibility requires contract plus implementation evidence; real endpoint behavior requires `real-boundary-smoke` or stronger.
5. Frontend behavior requires `browser-live` for live flow claims.
6. Performance claims require measurement; architecture descriptions alone are insufficient.
7. Production readiness requires production-like or production evidence across deployment, runtime, security, observability, performance, reliability, and acceptance criteria.
8. Compliance claims require explicit scope, standard version, evidence coverage, and limitation; partial checks are not compliance.
9. AI behavior claims require eval evidence and permission review; prompt inspection alone is not enough.
10. `contradicted` evidence blocks or reframes the claim.

## Evidence ledger entry

Use JSON Lines. One line per evidence item.

```json
{"id":"EVID-AUD-001","date":"2026-06-17","claim":"critical login flow completed against staging","evidence_class":"real-boundary-smoke","source":"evidence/command-outputs/playwright-login.txt","result":"pass","limitation":"staging test account only, no production traffic","supports_done":false}
```

## Done-claim matrix

| Claim type | Minimum acceptable evidence |
|---|---|
| File exists | `source-inspected` |
| Build succeeds | command output with pass result, typically `static-analysis` or `integration` |
| Unit behavior works | `unit-only` |
| API contract matches | `integration` with contract validation or stronger |
| Real API endpoint works | `real-boundary-smoke` |
| Real browser flow works | `browser-live` |
| Production behavior observed | `production-observed` |
| Production ready | broad production-like or production evidence plus accepted criteria |
| Security compliant | explicit standard version, scope, complete evidence matrix, and qualified assessor context |
