# Audit Method Framework

## Phase 0 - Intake and audit corridor

Use when the system is unknown, incomplete, high-risk, or the user asks for a reliable assessment.

Actions:

1. Define target: repository, ZIP, URL, deployed app, API, backend, frontend, AI app, or mixed system.
2. Define scope: `in_scope`, `out_of_scope`, `unknown`.
3. Identify stakeholders and concerns: product, engineering, security, operations, compliance, end users.
4. Identify critical flows: auth, onboarding, payment, admin, import/export, AI/tool calls, jobs, domain workflows.
5. Define evidence expectations by claim type.
6. Mark unavailable boundaries: no runtime, no credentials, no logs, no production, no CI, no git history.

Outputs:

- `AUDIT_SCOPE.md`
- `SYSTEM_BOUNDARY_MAP.md`
- `MISSING_EVIDENCE.md`

Failure gate: do not score architecture or production readiness before this phase is complete.

## Phase 1 - Repository inventory and entrypoint map

Actions:

1. Detect languages, frameworks, package managers, build systems, lockfiles, and monorepo/polyrepo structure.
2. Separate generated, vendor, binary, fixture, test, demo, and migration code from application logic.
3. Identify entrypoints: frontend root, app shell, routes, server root, controllers, API routers, jobs, workers, CLI, infrastructure.
4. Map build, test, lint, typecheck, dev, and deploy commands from manifests and CI.
5. Identify configuration and environment boundaries.

Outputs:

- `REPO_INVENTORY.md`
- `ENTRYPOINT_MAP.md`

Evidence examples: file tree, manifests, package files, CI YAML, Dockerfile, Makefile, README commands.

## Phase 2 - Automated triage

Actions:

1. Run or mark not-run for lint, typecheck, build, unit tests, integration tests, SAST, SCA, SBOM, secret scan, complexity, duplication, architecture graph.
2. Prefer project-native commands before adding new tooling.
3. Record exact command, cwd, timestamp, result, exit code, artifact path, and limitation.
4. Triage findings into `candidate`, `confirmed`, `false-positive`, `needs-runtime`, `needs-human-domain-input`.
5. Avoid treating tool severity as business severity without context.

Outputs:

- `STATIC_ANALYSIS_SUMMARY.md`
- `DEPENDENCY_AND_SUPPLY_CHAIN_AUDIT.md`
- `SCAN_EVIDENCE.jsonl`

Failure gate: if a tool did not run, output `not-run` rather than implying coverage.

## Phase 3 - Architecture deep dive

Actions:

1. Build context, container, component, dependency, runtime, deployment, data, and trust-boundary views when evidence exists.
2. Check DDD boundaries: ubiquitous language, bounded contexts, aggregates, invariants, anti-corruption layers.
3. Check Clean Architecture / Ports & Adapters: dependency direction, use-case isolation, framework leakage.
4. Identify cycles, service cliques, god modules, low-cohesion/high-coupling clusters, shotgun surgery risk.
5. Check API contracts: route/spec drift, versioning, auth, error model, pagination, idempotency, rate limits, compatibility.
6. Check data model: migrations, constraints, indexes, ownership, transaction boundaries, retention, data leaks.

Outputs:

- `ARCHITECTURE_MAP.md`
- `BACKEND_ASSESSMENT.md`
- `API_INTEGRATION_AUDIT.md`
- `DATA_MODEL_AUDIT.md`

Failure gate: no architecture-quality claim without observed dependencies, file references, or verified stakeholder/document evidence.

## Phase 4 - Frontend, UX, and runtime-facing behavior

Actions:

1. Map routes, layouts, component hierarchy, design tokens, UI primitives, and route guards.
2. Identify state ownership: local, global, server cache, URL state, forms, auth/session, feature flags.
3. Review loading, error, empty, permission, offline, retry, and degraded states.
4. Check accessibility basics: keyboard path, labels, headings, focus, contrast evidence, ARIA misuse candidates.
5. Check rendering model, hydration, bundle split, critical path, image/font strategy.
6. If a deployed/local running app exists, run browser smoke and performance probes.

Outputs:

- `FRONTEND_ASSESSMENT.md`
- `RUNTIME_AND_PERFORMANCE_AUDIT.md`
- `UX_EDGE_CASE_GAPS.md`

Failure gate: static route/button inspection is not browser-live proof.

## Phase 5 - Security, privacy, supply chain, and resilience

Actions:

1. Review authN/authZ, session/cookie controls, RBAC/ABAC, tenant boundaries, admin boundaries.
2. Review secrets handling, environment variables, logs, PII exposure, file uploads, SSRF, XSS, SQL injection, CSRF, deserialization, redirects.
3. Run or mark not-run for SAST, SCA, SBOM, secret scanning, license scanning, and provenance checks.
4. Review retries, timeouts, idempotency, transactions, circuit breakers, rate limits, queue handling.
5. Capture logs, traces, health checks, metrics, and alerts when available.
6. For AI apps, review prompts-as-code, RAG sources, evals, tool permissions, prompt injection, data leakage, and least privilege.

Outputs:

- `SECURITY_AND_PRIVACY_AUDIT.md`
- `DEPENDENCY_AND_SUPPLY_CHAIN_AUDIT.md`
- `AI_APPLICATION_CONTROLS.md`
- `RUNTIME_AND_PERFORMANCE_AUDIT.md`

Failure gate: do not assert compliance from partial security checks.

## Phase 6 - Repository history and evolution risk

Actions:

1. Measure churn, hotspot files, temporal coupling, authorship concentration, abandoned modules, and bug-fix clusters.
2. Identify firefighting commits, repeated reverts, risky rewrites, long-lived branches, stale PR patterns.
3. Inspect release tags, CI signal quality, branch protection evidence, and review discipline when available.
4. Evaluate architecture drift, license drift, dependency drift, and test drift over time.
5. Interpret metrics cautiously; high churn alone is not proof of bad design.

Outputs:

- `REPO_HISTORY_ANALYSIS.md`
- `TECHNICAL_DEBT_REGISTER.md`

Failure gate: no organizational conclusion without context; label history metrics as signals.

## Phase 7 - Decision-ready report and next value slice

Actions:

1. Convert findings into severity, evidence, business impact, remediation, owner type, verification method, and limitation.
2. Separate immediate risk reduction from structural refactoring.
3. Prioritize by risk, confidence, blast radius, user value, reversibility, and implementation cost.
4. Define the next smallest user-value-centered improvement.
5. Create a developer/agent handoff with files, constraints, tests, acceptance criteria, and forbidden assumptions.
6. State honest status and residual uncertainty.

Outputs:

- `AUDIT_REPORT.md`
- `RISK_MATRIX.md`
- `NEXT_VALUE_SLICE.md`
- `AGENT_HANDOFF.md`
- `evidence/evidence-ledger.jsonl`

Failure gate: no naked finding. Every finding needs evidence, impact, remediation, verification, and limitation.
