# Validation Rules

## Global report validation

Before delivering an audit answer or package, check:

1. Every finding has required fields from `schemas/audit-finding.schema.json`.
2. Every evidence entry has required fields from `schemas/evidence-entry.schema.json`.
3. No runtime, integration, auth, performance, deployment, or production-readiness claim is supported only by source inspection, static analysis, or unit tests.
4. No tool result is invented. Missing command output must be marked `not-run`.
5. No CVE, license, version, pricing, or current tool capability is asserted without a source or scan artifact.
6. Secrets are redacted and rotation is recommended when exposure is plausible.
7. Mock-only or demo-only behavior is marked `fake-only`.
8. Contradictory evidence is not hidden; it is marked `contradicted` and the claim is reframed.
9. Scores include rubric, evidence, and limitation.
10. All `SOURCE_NEEDED`, `SOURCE_NEEDED_PRIMARY`, and `official_docs_needed` items remain visible.

## Required finding fields

- `id`
- `domain`
- `severity`
- `claim`
- `evidence`
- `evidence_class`
- `business_impact`
- `remediation`
- `owner_type`
- `verification_method`
- `limitation`

## Allowed domains

`repo`, `backend`, `frontend`, `api`, `data`, `security`, `privacy`, `supply-chain`, `testing`, `runtime`, `performance`, `observability`, `history`, `ai`, `process`, `documentation`.

## Allowed severities

`Extreme`, `High`, `Elevated`, `Moderate`, `Low`, `Info`.

## Allowed evidence classes

`unverified`, `source-inspected`, `static-analysis`, `unit-only`, `integration`, `real-boundary-smoke`, `browser-live`, `production-observed`, `user-confirmed`, `fake-only`, `contradicted`.

## Runtime claim validator

A claim is a runtime claim if it says or implies any of the following:

- works, runs, deploys, authenticates, authorizes, connects, syncs, sends, receives, processes, scales, performs, logs, alerts, recovers, fails over, is production-ready.

Minimum evidence:

- `real-boundary-smoke` for real API/auth/integration/deployment flow.
- `browser-live` for real browser UI flow.
- `production-observed` for production behavior.

If evidence is weaker, rewrite as:

> The code suggests this behavior, but runtime behavior is unverified because `[missing evidence]`.

## Security validator

Security findings must avoid exploit walkthroughs and include safe remediation.

Allowed:

- risk description;
- affected file/path/component;
- defensive impact;
- secure configuration or code-level fix;
- test or verification method;
- secret redaction and rotation guidance.

Not allowed:

- exploitation steps;
- credential misuse;
- stealth, persistence, privilege escalation;
- malware or unauthorized access instructions.

## Source validator

Use `source-policy.md` before making standard/tool claims.

- Official standard/tool behavior: require Level 4 or Level 5 source.
- Case study: Level 2, example only.
- User document: Level 1 until verified.
- Generated synthesis: Level 1 or `derived_method`, not a factual authority.

## Score validator

Scores must include:

- rubric;
- evidence per scored dimension;
- limitation;
- confidence;
- what would change the score.

Avoid exact decimals unless the score is computed from defined measurements.

## Agent-handoff validator

Every agent handoff must include:

- bounded goal;
- files/components likely involved;
- constraints and forbidden assumptions;
- acceptance criteria;
- test plan;
- evidence required for done;
- rollback/safety notes where relevant.
