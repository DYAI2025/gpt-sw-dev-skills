# Source Policy

## Source hierarchy

| Level | Source type | Examples | Allowed use |
|---:|---|---|---|
| 5 | Primary standard or official specification | ISO, IEEE, W3C, NIST, OWASP, OpenAPI, AsyncAPI, GraphQL, gRPC, Git documentation | Define validation criteria and hard rules when the source is current and relevant. |
| 4 | Official tool documentation | Semgrep, SonarQube, CodeQL, Playwright, k6, Trivy, GitHub Linguist, OSV-Scanner | Define tool capability, required inputs, and output interpretation. |
| 3 | Strong industry practice | Microsoft Learn, DORA, SEI/CMU material, established architecture methods | Inform methods and heuristics. Mark as method, not universal law. |
| 2 | Vendor blog, product blog, case study | Product articles, company-specific postmortems, benchmark blogs | Use only as example or weak context. Do not convert into hard rules. |
| 1 | User-provided notes, generated packs, previous chats | Attachments, transcripts, model-generated reference packs | Treat as `user_provided` until independently verified. |

## Confidence scale

| Score | Meaning | Delivery rule |
|---:|---|---|
| 5 | Directly supported by current primary or official source | Can be used as rule with citation or source reference. |
| 4 | Supported by official tool docs or strong practice source | Can be used with caveat and version/source status. |
| 3 | Plausible but indirect, partial, stale, or context-specific | Mark as assumption or heuristic. |
| 2 | Weak, vendor-biased, anecdotal, conflicting, or old | Do not use as hard rule. |
| 1 | Unverified or speculative | Mark `SOURCE_NEEDED` or block claim. |

## Source status values

Use these values in source maps and tool cards:

- `verified_by_source`: directly supported by an inspected source in the current task.
- `official_docs_needed`: official documentation is required before using the claim operationally.
- `source_needed_primary`: a primary standard or specification is required.
- `user_provided`: useful design input from the user or uploaded material, not independently verified.
- `derived_method`: a reasoned method synthesized from multiple sources; not a direct external fact.
- `stale_or_version_sensitive`: likely to change and must be refreshed before precise claims.

## Mandatory source rules

- Do not claim current tool capabilities, pricing, licensing, or versions without current official documentation.
- Do not claim production readiness from static analysis, code reading, generated diagrams, or mocked tests.
- Do not use company case studies as proof that a method is universal.
- Treat user attachments as valuable design input, not automatically factual truth.
- Pin standard versions only when verified in the current task. Otherwise write `version: SOURCE_NEEDED_PRIMARY`.
- Mark ATAM/SEI, ISO, OWASP, NIST, W3C, OpenAPI, AsyncAPI, GraphQL, gRPC, SPDX, CycloneDX, SLSA, and OpenSSF references as `source_needed_primary` unless official source content was inspected.

## Claim sourcing format

For each central rule or finding, record:

```yaml
claim:
source_family:
source_level: 1|2|3|4|5
source_status: verified_by_source|official_docs_needed|source_needed_primary|user_provided|derived_method|stale_or_version_sensitive
confidence: 1|2|3|4|5
limitation:
```
