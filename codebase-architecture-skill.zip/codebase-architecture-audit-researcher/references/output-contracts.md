# Output Contracts

## Full audit package

When the user asks for a full audit, create this folder unless a narrower format is requested:

```text
software-audit-report/
├── AUDIT_SCOPE.md
├── SYSTEM_BOUNDARY_MAP.md
├── MISSING_EVIDENCE.md
├── REPO_INVENTORY.md
├── ENTRYPOINT_MAP.md
├── STATIC_ANALYSIS_SUMMARY.md
├── ARCHITECTURE_MAP.md
├── BACKEND_ASSESSMENT.md
├── FRONTEND_ASSESSMENT.md
├── API_INTEGRATION_AUDIT.md
├── DATA_MODEL_AUDIT.md
├── SECURITY_AND_PRIVACY_AUDIT.md
├── DEPENDENCY_AND_SUPPLY_CHAIN_AUDIT.md
├── RUNTIME_AND_PERFORMANCE_AUDIT.md
├── REPO_HISTORY_ANALYSIS.md
├── TECHNICAL_DEBT_REGISTER.md
├── RISK_MATRIX.md
├── NEXT_VALUE_SLICE.md
├── AGENT_HANDOFF.md
├── AUDIT_REPORT.md
└── evidence/
    ├── evidence-ledger.jsonl
    ├── command-outputs/
    └── screenshots-or-runtime-artifacts/
```

## Compact answer contract

Use for narrower questions or early-pass audits:

```markdown
## Current understanding

## Facts / assumptions / missing / blockers

## Evidence table
| Claim | Evidence | Evidence class | Limitation |
|---|---|---|---|

## Architecture / code findings
| ID | Domain | Severity | Claim | Evidence class | Business impact | Remediation |
|---|---|---|---|---|---|---|

## Risk matrix
| Risk | Likelihood | Impact | Confidence | Next verification |
|---|---:|---:|---:|---|

## Next value-centered improvement

## Honest status
```

## `AUDIT_SCOPE.md`

Purpose: define target, boundaries, goals, and evidence expectations.

Minimum sections:

- Target and artifact type.
- Business and technical goals.
- In scope.
- Out of scope.
- Unknown.
- Critical flows.
- Available evidence.
- Missing evidence.
- Claim limitations.

## `SYSTEM_BOUNDARY_MAP.md`

Purpose: make system boundaries visible.

Minimum sections:

- Apps and services.
- APIs and integrations.
- Data stores and file stores.
- Auth providers and trust boundaries.
- Jobs, workers, queues, schedulers.
- External dependencies.
- AI/model/tool boundaries where present.
- Runtime environments.

## `REPO_INVENTORY.md`

Minimum fields:

- Languages and approximate evidence.
- Package managers and lockfiles.
- Frameworks and runtime assumptions.
- Monorepo/polyrepo structure.
- Entry points.
- Build/test/dev commands.
- Generated/vendor/binary/demo/test code boundaries.
- Not-run checks.

## `ARCHITECTURE_MAP.md`

Minimum sections:

- Context view.
- Container/service view.
- Component/module view.
- Dependency direction.
- Data/integration view.
- Runtime/deployment view if evidence exists.
- Security/trust-boundary view.
- Drift and uncertainty.

## `AUDIT_REPORT.md`

Minimum sections:

- Executive summary.
- Scope and limitations.
- Top risks.
- Evidence summary.
- Domain findings.
- Risk matrix.
- Remediation roadmap.
- Next value slice.
- Residual uncertainty.

## `RISK_MATRIX.md`

Risk scoring should avoid false precision. Use qualitative buckets unless real data supports numeric scoring.

| Severity | Meaning |
|---|---|
| Extreme | Immediate compromise, data exposure, deployment blocker, or severe outage risk. |
| High | Likely serious outage, data loss, major security or critical delivery risk. |
| Elevated | Systemic design flaw that increases defect rate, slows delivery, or weakens controls. |
| Moderate | Maintainability, test, documentation, or local design issue without immediate critical risk. |
| Low | Minor isolated issue. |
| Info | Context or improvement suggestion without current risk claim. |

## `AGENT_HANDOFF.md`

Minimum sections:

- Goal.
- Current facts.
- Constraints.
- Files likely involved.
- Acceptance criteria.
- Tests to run.
- Evidence required for done.
- Forbidden assumptions.
- Rollback or safety notes.

## Finding YAML example

```yaml
id: FIND-AUD-001
domain: api
severity: Elevated
claim: API error responses are inconsistent across user-facing endpoints.
evidence:
  - src/api/users.ts uses {error: string}
  - src/api/orders.ts uses {message: string, code: number}
evidence_class: source-inspected
business_impact: clients need endpoint-specific error handling, increasing integration defects.
remediation: define shared error envelope and migrate endpoints behind compatibility plan.
owner_type: backend
verification_method: contract tests plus one real-boundary smoke against staging.
limitation: runtime behavior not verified.
```
