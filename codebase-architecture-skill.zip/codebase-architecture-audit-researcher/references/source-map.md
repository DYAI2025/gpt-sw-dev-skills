# Source Map

Use this file as a navigation map, not as proof that all external sources have been freshly verified. For current standards, versions, licenses, pricing, and tool capabilities, inspect official docs at audit time.

## Architecture and quality

| Source family | Type | Use in this skill | Source status | Confidence when verified | Caveat |
|---|---|---|---|---:|---|
| ISO/IEC/IEEE 42010 | Primary architecture-description standard | Stakeholders, concerns, viewpoints, architecture description structure | source_needed_primary | 5 | Describes architecture descriptions, not a full audit process by itself. |
| ISO/IEC 25010 / SQuaRE | Primary quality model | Quality taxonomy for functional suitability, performance, compatibility, interaction/usability, reliability, security, maintainability, flexibility/portability, safety | source_needed_primary | 5 | Thresholds and weights must be local to the system. |
| ATAM / SEI architecture evaluation | Primary/strong method source | Quality attribute scenarios, utility tree, sensitivity points, trade-offs, risk themes | source_needed_primary | 5 | Do not present from memory as fully sourced; verify official SEI material. |
| C4 model | Industry notation | Context/container/component/code-style architecture maps | official_docs_needed | 4 | Useful notation, not audit evidence by itself. |
| Lightweight architecture health check | Derived method | Fast architecture maturity and risk scan | derived_method | 3 | Must disclose heuristic nature. |

## Backend, domain, and deployment

| Source family | Type | Use in this skill | Source status | Confidence when verified | Caveat |
|---|---|---|---|---:|---|
| Domain-Driven Design and bounded contexts | Industry practice | Ubiquitous language, bounded contexts, context maps, aggregate boundaries | official_docs_needed | 4 | Requires domain input; service boundaries are not mechanically inferred. |
| Microsoft Learn domain analysis for microservices | Strong vendor/industry source | Practical DDD and microservice boundary guidance | official_docs_needed | 4 | Vendor source, but strong and operational. |
| Clean Architecture / Dependency Rule | Author/practice source | Dependency direction, use-case isolation, ports/adapters checks | official_docs_needed | 4 | Not a formal standard. |
| Twelve-Factor App | Methodology | Deployability, config, backing services, logs, build/release/run | official_docs_needed | 4 | Older stable source; extend carefully for containers and AI apps. |

## API and integration specifications

| Source family | Type | Use in this skill | Source status | Confidence when verified | Caveat |
|---|---|---|---|---:|---|
| OpenAPI Specification | Primary spec | HTTP API contract extraction, schema drift, auth scheme review | source_needed_primary | 5 | Verify latest supported spec version for tools. |
| AsyncAPI Specification | Primary spec | Event/message contract audit across queues, streams, WebSockets, MQTT, AMQP, Kafka-like systems | source_needed_primary | 5 | Do not infer runtime delivery guarantees from spec alone. |
| GraphQL Specification | Primary spec | Schema, query, mutation, subscription, introspection, validation review | source_needed_primary | 5 | Add GraphQL risks: complexity, authorization, N+1, introspection exposure. |
| gRPC documentation/specification | Primary docs/spec | Proto contracts, generated client/server boundaries, compatibility | source_needed_primary | 5 | Check generated code and deployment behavior separately. |

## Security, privacy, and supply chain

| Source family | Type | Use in this skill | Source status | Confidence when verified | Caveat |
|---|---|---|---|---:|---|
| OWASP ASVS | Primary security verification standard | Security requirement families and verification levels | source_needed_primary | 5 | Use versioned requirement IDs only after verification. |
| OWASP WSTG | Primary testing guide | Dynamic web security test scenarios | source_needed_primary | 5 | Runtime access required for dynamic claims. |
| OWASP SAMM | Primary maturity model | Secure SDLC maturity and governance | source_needed_primary | 5 | Organizational maturity, not code proof. |
| NIST SSDF SP 800-218 | Primary framework | Secure development practices, supplier/acquirer communication | source_needed_primary | 5 | High-level framework, not a scanner. |
| CycloneDX | Primary SBOM spec | SBOM/SaaSBOM, components, services, vulnerabilities, declarations | source_needed_primary | 5 | Completeness depends on ecosystem and generation method. |
| SPDX | Primary SBOM/license/provenance spec | License metadata, provenance, package/software identity | source_needed_primary | 5 | Verify version and profile support. |
| OSV | Official vulnerability ecosystem | Open-source vulnerability lookup | official_docs_needed | 4 | Vulnerability presence is not exploitability proof. |
| SLSA | Primary supply-chain framework | Source/build provenance and artifact assurance | source_needed_primary | 5 | Requires CI/build pipeline evidence. |
| OpenSSF Scorecard | Official project/tool | OSS repository security posture checks | official_docs_needed | 4 | Triage signal, not full security audit. |

## Frontend, UX, accessibility, and performance

| Source family | Type | Use in this skill | Source status | Confidence when verified | Caveat |
|---|---|---|---|---:|---|
| W3C WCAG | Primary accessibility standard | Accessibility success criteria and compatibility expectations | source_needed_primary | 5 | Legal applicability varies by jurisdiction. |
| Core Web Vitals / web.dev | Official performance docs | LCP, INP, CLS, field/lab distinction, thresholding | official_docs_needed | 4 | Lab data is not field data; Lighthouse is not production RUM. |
| Playwright/Cypress docs | Official tool docs | Browser automation and E2E evidence interpretation | official_docs_needed | 4 | Mocked browser tests are not real integration proof. |
| Lighthouse/PageSpeed/web-vitals | Official tool/docs | Frontend lab and field performance evidence | official_docs_needed | 4 | Use with measurement limitations. |

## Static, dynamic, and repository-history analysis

| Source family | Type | Use in this skill | Source status | Confidence when verified | Caveat |
|---|---|---|---|---:|---|
| Git documentation | Primary tool docs | log, blame, grep, bisect, path history, churn inputs | official_docs_needed | 5 | Metrics require careful interpretation. |
| DORA metrics | Research/industry | Delivery performance lenses and Goodhart warning | official_docs_needed | 4 | Do not compare unequal systems naively. |
| GitHub Linguist | Official project | Language detection, generated/vendor distinction | official_docs_needed | 4 | Inventory signal, not architecture proof. |
| CodeQL, Semgrep, SonarQube | Official tool docs | SAST, pattern analysis, quality metrics, code smells | official_docs_needed | 4 | Rule sets and language support change. |
| OSV-Scanner, Trivy, Syft, Dependency-Check, Snyk | Official tool docs needed | SCA, SBOM, dependency risk, container risk | official_docs_needed | 4 | Findings require triage and version/source freshness. |
| Code Maat / hotspot tools | Tool/method docs | Churn, temporal coupling, ownership risk | official_docs_needed | 3 | History metrics are biased without context. |

## User-provided source anchors

| Source | Use | Source status | Caveat |
|---|---|---|---|
| holistic German codebase analysis document | Five-phase audit model, ISO/CISQ framing, ATAM/lightweight checks, architecture linting, git forensics, DDD, frontend, report template | user_provided | Strong design input; external claims still need verification. |
| prior research synthesis on codebase audit skill | Source architecture, trigger set, output artifacts, failure gates, SOURCE_NEEDED policy | user_provided | Generated synthesis; use as blueprint, not proof. |
| software audit reference pack | Operational method cards, framework cards, tool-use catalog, bias guards, evidence ledger pattern | user_provided | Useful normalized reference pack; verify tools and standards at use time. |
