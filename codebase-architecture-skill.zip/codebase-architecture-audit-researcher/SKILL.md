---
name: codebase-architecture-audit-researcher
description: audits unknown software repositories, codebases, backend and frontend architecture, apis, data models, integrations, security, privacy, supply chain, runtime, tests, framework choices, compatibility, repo history, technical debt, fake functionality, dead code, and ai application controls. use when users ask for repository analysis, codebase audit, architecture map, risk matrix, evidence ledger, remediation roadmap, or developer and agent handoff.
---

# Codebase Architecture Audit Researcher

## When to use

Use this skill when the user asks to audit, understand, map, score, compare, troubleshoot, or plan remediation for a software repository, ZIP codebase, file tree, deployed frontend, backend/API service, integration layer, data model, AI-enabled app, or mixed system.

Typical triggers include: repository analysis, codebase audit, backend architecture review, frontend architecture review, API or integration audit, security or supply-chain audit, runtime readiness, test and quality review, dead code, fake buttons, mock-only functionality, compatibility and migration risk, repo history analysis, technical debt register, architecture map, risk matrix, remediation roadmap, or coding-agent handoff.

## When not to use

Do not use this skill for exploit instructions, credential misuse, malware, persistence, privilege escalation, or unauthorized access. For security work, stay in defensive analysis and safe remediation.

Do not claim production readiness, live API behavior, real auth behavior, performance, integration correctness, or deployment success from source inspection alone.

## Intake rules

1. Identify the available target: repository, ZIP, file tree, URL, deployed app, API spec, logs, CI artifacts, screenshots, or written description.
2. Define scope as `in_scope`, `out_of_scope`, and `unknown` before judging quality.
3. Identify critical flows: auth, onboarding, payments, admin, data import/export, public API, background jobs, AI tool calls, and core domain workflows.
4. List unavailable boundaries: no runtime, no credentials, no logs, no production data, no API contract, no tests, no git history, or no security scan.
5. Split all statements into `facts`, `assumptions`, `missing`, `blockers`, `risk_hypotheses`, and `verified_conclusions`.
6. If the user requests certainty that the evidence cannot support, state the limitation and downgrade the claim.

## Audit workflow

Follow these phases. Load the matching reference files only when needed.

1. **Phase 0 - Intake and system boundary**: create audit scope, boundary map, missing evidence register, and claim/evidence expectations.
2. **Phase 1 - Inventory and entrypoints**: detect languages, frameworks, package managers, monorepo shape, generated/vendor code, build/test/dev commands, and entrypoints.
3. **Phase 2 - Automated triage**: run or mark not-run for lint, typecheck, build, tests, SAST, dependency/SBOM, secret scan, complexity, duplication, and architecture graph checks.
4. **Phase 3 - Architecture deep dive**: inspect context/container/component/dependency views, DDD boundaries, Clean Architecture/ports-adapters direction, API contracts, data model, authorization boundaries, error model, coupling, cycles, and god modules.
5. **Phase 4 - Frontend, UX, and runtime behavior**: inspect routes, state, rendering, loading/error/empty/offline states, accessibility, responsive behavior, E2E tests, and performance evidence.
6. **Phase 5 - Security, privacy, and supply chain**: review authN/authZ, secrets, dependency risk, SBOM/licenses, OWASP/NIST alignment, permissions, and AI controls when present.
7. **Phase 6 - History and technical debt**: inspect churn, hotspots, temporal coupling, ownership, bus factor, firefighting, architecture drift, license drift, and test drift when git history exists.
8. **Phase 7 - Reporting and roadmap**: consolidate findings, classify risk, explain business impact, propose remediation, define next value slice, and create developer/agent handoff.

## Evidence classes

Use only these evidence classes:

`unverified`, `source-inspected`, `static-analysis`, `unit-only`, `integration`, `real-boundary-smoke`, `browser-live`, `production-observed`, `user-confirmed`, `fake-only`, `contradicted`.

Done-claim rules:

- Static analysis supports code-quality and candidate findings, not real runtime behavior.
- Unit-only evidence supports isolated logic, not integration.
- Mock-only or fake browser tests prove UI intent, not real API function.
- Runtime, deployment, auth, performance, and real integration claims require at least `real-boundary-smoke`.
- Production readiness requires production-like or production evidence plus explicit acceptance criteria.
- `contradicted` evidence blocks or reframes the claim.

## Finding contract

Every finding must include:

- `id`
- `domain`
- `severity`
- `claim`
- `evidence`
- `evidence_class`
- `business_impact`
- `remediation`
- `owner_type`
- `verification_method`
- `limitation`

Validate machine-readable findings against `schemas/audit-finding.schema.json`. Validate evidence ledger rows against `schemas/evidence-entry.schema.json`.

## Failure gates

Block the claim or mark it `unverified` when:

- no repository, ZIP, file tree, URL, or sufficient code context was provided;
- runtime access is missing but runtime behavior is requested;
- build, tests, or scans were not run but the user asks whether it works;
- tool outputs are missing but scores, CVEs, or compliance claims are requested;
- only mock, demo, fixture, or generated data exists;
- API contracts are absent but API compatibility is requested;
- security, license, or supply-chain claims lack SAST, SCA, SBOM, source, or command evidence;
- frontend performance lacks lab or field measurements;
- current tool capability, pricing, license, or version would require current official docs;
- the user asks for false certainty or total completeness.

## Tooling rules

Use capability-first tool selection from `references/tooling-matrix.md`.

- Do not say a tool was run unless there is command output, CI output, report artifact, screenshot, API response, or equivalent evidence.
- Prefer existing project scripts and CI commands before inventing new commands.
- Treat generated diagrams, dependency graphs, and static scans as evidence inputs, not final truth.
- Redact secrets. Never print full credentials. Report path, secret type, short hash/fingerprint, and rotation action.
- If current tool documentation is needed and unavailable, mark `SOURCE_NEEDED_PRIMARY` or `official_docs_needed`.

## Reporting format

For a full audit package, create this structure unless the user requests a narrower answer:

```text
software-audit-report/
├── AUDIT_SCOPE.md
├── SYSTEM_BOUNDARY_MAP.md
├── MISSING_EVIDENCE.md
├── REPO_INVENTORY.md
├── ENTRYPOINT_MAP.md
├── STATIC_ANALYSIS_SUMMARY.md
├── ARCHITECTURE_MAP.md
├── BACKEND_ASSESSMENT.md
├── FRONTEND_ASSESSMENT.md
├── API_INTEGRATION_AUDIT.md
├── DATA_MODEL_AUDIT.md
├── SECURITY_AND_PRIVACY_AUDIT.md
├── DEPENDENCY_AND_SUPPLY_CHAIN_AUDIT.md
├── RUNTIME_AND_PERFORMANCE_AUDIT.md
├── REPO_HISTORY_ANALYSIS.md
├── TECHNICAL_DEBT_REGISTER.md
├── RISK_MATRIX.md
├── NEXT_VALUE_SLICE.md
├── AGENT_HANDOFF.md
├── AUDIT_REPORT.md
└── evidence/
    ├── evidence-ledger.jsonl
    ├── command-outputs/
    └── screenshots-or-runtime-artifacts/
```

For compact answers, use:

1. Current understanding
2. Facts / assumptions / missing / blockers
3. Evidence table
4. Architecture / code findings
5. Risk matrix
6. Next value-centered improvement
7. Honest status

## Quality gate before final answer

Before responding:

1. Check that every finding has evidence and limitation.
2. Check that runtime, security, compatibility, and production claims are not overclaimed.
3. Check that tool outputs are not invented.
4. Check that SOURCE_NEEDED items are clearly marked.
5. Check for automation bias, coverage bias, diagram bias, recency bias, tool bias, and overconfidence.
6. If an output is incomplete, label it partial and state the missing evidence.

## Reference files

- `references/source-policy.md` - source hierarchy, confidence scale, SOURCE_NEEDED policy.
- `references/source-map.md` - curated standard, framework, and tool reference families.
- `references/domain-ontology.md` - audit entities, domains, and separation rules.
- `references/audit-method-framework.md` - detailed phase workflow and artifacts.
- `references/framework-cards.md` - ISO, ATAM, DDD, Clean Architecture, API, frontend, security, supply-chain, git, and AI control cards.
- `references/tooling-matrix.md` - tool categories, inputs, outputs, caveats, evidence classes, and source status.
- `references/evidence-taxonomy.md` - claim support rules and evidence class definitions.
- `references/output-contracts.md` - full package and compact response templates.
- `references/validation-rules.md` - required gates, schema rules, and report checks.
- `references/evaluation-plan.md` - regression scenarios for testing the skill.

## Examples

**User:** Audit this repository ZIP and tell me if it is production ready.  
**Behavior:** Build scope and inventory, inspect files, run available checks, mark runtime and production readiness `unverified` unless real-boundary or production evidence exists, then provide a remediation plan.

**User:** Find fake buttons and mock-only flows in this frontend.  
**Behavior:** Inspect routes and UI code, identify button handlers and API clients, separate static candidates from browser-live proof, require a running app or artifact for live confirmation.

**User:** Security audit this API.  
**Behavior:** Define scope, identify auth/data boundaries, use OWASP/NIST references as check families, run or mark not-run for SAST/SCA/SBOM/secrets, avoid compliance claims without sufficient evidence.
