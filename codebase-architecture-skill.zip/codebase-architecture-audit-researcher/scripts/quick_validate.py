#!/usr/bin/env python3
"""Validate the codebase-architecture-audit-researcher skill package."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None

REQUIRED_FILES = [
    "SKILL.md",
    "agents/openai.yaml",
    "references/source-policy.md",
    "references/source-map.md",
    "references/domain-ontology.md",
    "references/audit-method-framework.md",
    "references/framework-cards.md",
    "references/tooling-matrix.md",
    "references/evidence-taxonomy.md",
    "references/output-contracts.md",
    "references/validation-rules.md",
    "references/evaluation-plan.md",
    "schemas/audit-finding.schema.json",
    "schemas/evidence-entry.schema.json",
    "scripts/quick_validate.py",
]

EXPECTED_NAME = "codebase-architecture-audit-researcher"
FORBIDDEN_TEXT = ["TO" + "DO", "PLACE" + "HOLDER", "T" + "BD", "N" + "/A"]
EVIDENCE_CLASSES = {
    "unverified",
    "source-inspected",
    "static-analysis",
    "unit-only",
    "integration",
    "real-boundary-smoke",
    "browser-live",
    "production-observed",
    "user-confirmed",
    "fake-only",
    "contradicted",
}
FINDING_REQUIRED = {
    "id",
    "domain",
    "severity",
    "claim",
    "evidence",
    "evidence_class",
    "business_impact",
    "remediation",
    "owner_type",
    "verification_method",
    "limitation",
}
EVIDENCE_REQUIRED = {
    "id",
    "date",
    "claim",
    "evidence_class",
    "source",
    "result",
    "limitation",
    "supports_done",
}


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def parse_frontmatter(skill_md: Path):
    content = read_text(skill_md)
    match = re.match(r"^---\n(.*?)\n---\n", content, re.DOTALL)
    if not match:
        raise ValueError("SKILL.md must start with YAML frontmatter delimited by ---")
    if yaml is None:
        raise ValueError("pyyaml is required to validate YAML frontmatter")
    data = yaml.safe_load(match.group(1))
    if not isinstance(data, dict):
        raise ValueError("frontmatter must parse to a mapping")
    return data, content


def validate(root: Path) -> list[str]:
    errors: list[str] = []
    if not root.exists() or not root.is_dir():
        return [f"root is not a directory: {root}"]

    for rel in REQUIRED_FILES:
        if not (root / rel).exists():
            errors.append(f"missing required file: {rel}")

    skill_md = root / "SKILL.md"
    if skill_md.exists():
        try:
            fm, content = parse_frontmatter(skill_md)
            if fm.get("name") != EXPECTED_NAME:
                errors.append(f"frontmatter name must be {EXPECTED_NAME!r}")
            desc = fm.get("description")
            if not isinstance(desc, str) or len(desc.strip()) < 80:
                errors.append("frontmatter description must be a useful string of at least 80 characters")
            if isinstance(desc, str) and ("<" in desc or ">" in desc):
                errors.append("frontmatter description must not contain angle brackets")
            extra = set(fm) - {"name", "description", "license", "allowed-tools", "metadata"}
            if extra:
                errors.append("unexpected frontmatter keys: " + ", ".join(sorted(extra)))
            for needle in ["Evidence classes", "Failure gates", "Finding contract", "Reporting format"]:
                if needle not in content:
                    errors.append(f"SKILL.md missing section marker: {needle}")
        except Exception as exc:
            errors.append(f"frontmatter parse error: {exc}")

    for rel in REQUIRED_FILES:
        p = root / rel
        if p.exists() and p.suffix in {".md", ".yaml", ".yml", ".py", ".json"}:
            text = read_text(p)
            for bad in FORBIDDEN_TEXT:
                if bad in text:
                    errors.append(f"forbidden placeholder text {bad!r} in {rel}")

    for rel, required in [
        ("schemas/audit-finding.schema.json", FINDING_REQUIRED),
        ("schemas/evidence-entry.schema.json", EVIDENCE_REQUIRED),
    ]:
        p = root / rel
        if p.exists():
            try:
                schema = json.loads(read_text(p))
            except Exception as exc:
                errors.append(f"invalid json in {rel}: {exc}")
                continue
            actual = set(schema.get("required", []))
            missing = required - actual
            if missing:
                errors.append(f"{rel} missing required schema fields: {', '.join(sorted(missing))}")
            props = schema.get("properties", {})
            evidence_enum = props.get("evidence_class", {}).get("enum", [])
            if set(evidence_enum) != EVIDENCE_CLASSES:
                errors.append(f"{rel} evidence_class enum does not match required taxonomy")

    return errors


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    errors = validate(root)
    if errors:
        print("VALIDATION: FAIL")
        for error in errors:
            print(f"- {error}")
        return 1
    print("VALIDATION: PASS")
    print(f"root={root.resolve()}")
    print(f"required_files={len(REQUIRED_FILES)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
