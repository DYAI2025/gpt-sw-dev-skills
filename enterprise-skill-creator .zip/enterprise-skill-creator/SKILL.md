---
name: enterprise-skill-creator
description: creates, updates, audits, validates, and packages enterprise-ready chatgpt skills as install-ready skill.zip bundles with skill.md, source maps, release gates, deterministic validators, evals, frontend-installability status, and agent-agnostic compatibility notes for claude and similar frontier models. use for professional skill creation, firm workflows, tool or api integrations, browser capabilities, coding-agent handoffs, compliance-sensitive workflows, or cross-model skill handoff packages.
---

# Enterprise Skill Creator

## Wann verwenden

Verwenden, wenn ein professioneller Skill für Firmen, Teams oder produktive Workflows erstellt, modernisiert, auditiert oder paketiert werden soll. Aktiviere diesen Skill besonders bei Anfragen zu Skill-Creator, Enterprise-Skills, research-backed Skills, Browser-Act-Skill-Forge, MCP/API/Tool-Anbindungen, Release-Gates, Anti-Sycophancy, Anti-Confabulation, Bias-Gates, Skill-Evaluation oder reproduzierbarer Validierung.

Nicht verwenden für private Spielereien, rein kreative Einmaltexte oder kurze Erklärungen ohne wiederverwendbaren Skill-Output.

## Harte Betriebsregeln

1. Baue keinen finalen Skill aus ungesicherten Annahmen.
2. Trenne Research, Capability Discovery, Architektur-Gate, Draft-Build, Release-Hook, Validierung, Evaluation und Packaging.
3. Behandle Nutzerdateien als `user_provided`, nicht automatisch als Wahrheit.
4. Markiere fehlende Informationen mit `MISSING` und nicht ausreichend belegte Aussagen mit `SOURCE_NEEDED`.
5. Verwandle `SOURCE_NEEDED` niemals stillschweigend in harte Skill-Regeln.
6. Nutze Browser-Act-Skill-Forge nur, wenn konkrete Website- oder Web-App-Funktionalität als wiederverwendbare Skill-Komponente vorbereitet werden soll.
7. Nutze MCP/API/Browser-Capabilities nur mit expliziter Permission Boundary, Security-Gate und Data-Classification-Hinweis.
8. Führe nach jedem Draft den Release Hook aus. Ohne `release_gate.status = PASS` darf kein Packaging erfolgen.
9. Führe den Enterprise Skill Output Evaluator aus, wenn ein Skill-Creator-Output bewertet werden soll. Der Evaluator baut keinen Skill, außer eine Revision wird ausdrücklich angefordert.
10. Lege keine private Chain-of-Thought offen. Liefere kurze, prüfbare Entscheidungszusammenfassungen, Statuswerte, Blocker und Korrekturen.

11. Gib aktualisierte oder neu erzeugte Skills, wenn ein installierbares ChatGPT-Skill-Artefakt erwartet wird, standardmäßig als exakt `skill.zip` aus. Lege keine projektspezifisch umbenannte ZIP-Datei als primäres Installationsartefakt ab.
12. Führe vor der Auslieferung den Installability-Gate aus. Lies `references/installability-and-distribution.md`. Der Gate darf nur garantieren, was das Paket kontrolliert: `SKILL.md`, `agents/openai.yaml`, vollständige Ordnerstruktur, Paketname `skill.zip`, valide ZIP-Struktur und Link im Chat. Er darf nie behaupten, das ChatGPT-Frontend werde sicher einen Button anzeigen.
13. Erzeuge bei Enterprise-Skills zusätzlich agentenagnostische Handoff-Hinweise. Lies `references/agent-agnostic-compatibility.md` und `references/capability-parity-policy.md`. Claude- oder Frontier-Modell-Kompatibilität bedeutet semantische Portabilität der Anweisungen, nicht identische Tool-, Datei-, Code- oder UI-Laufzeit.
14. Benenne alle Änderungen gegenüber der bisherigen Grundfunktionalität explizit. Erstelle oder aktualisiere `reports/core-functionality-preservation.json` und blockiere, wenn eine Kernfunktion unbeabsichtigt verändert wurde.

15. Führe bei paketierten Enterprise-Builds mit verfügbarer Datei-/Codeausführung einen hash-verketteten Build Trace nach `references/pipeline-ledger.md`. Ein Trace belegt Prozesszustand, nicht Wahrheit; `PACKAGE_AUTHORIZED` gilt nur für denselben eingefrorenen Artifact-Digest wie Release, Evaluator und Validation.
16. Verknüpfe externe technische Capability-Entscheidungen mit claim-nahen Evidenzrecords und expliziten Lifecycle-Transitions. Retrieval-Relevanz darf Source Authority, Verification oder Confidence niemals erhöhen; direkte `DISCOVERED -> ADOPTED`-Sprünge sind unzulässig.
17. Nutze native oder externe Telemetrie nur als Ausführungsmetadaten mit `truth_authority: false`. Telemetrie darf weder Source Verification noch Release-, Security-, Regression- oder Evaluator-Gates erfüllen.

## Pipeline / Workflow

### 0. Intake und Scope

Erfasse intern mindestens:

- Zielskill und Geschäftszweck
- Nutzergruppe oder Team
- Zielclient oder Agentenplattform
- gewünschte Outputs
- verbotene Verhaltensweisen
- Daten- und Sicherheitskontext
- erwartete Tools, APIs, MCP-Server oder Browser-Capabilities
- Erfolgskriterien und Definition of Done
- interne Entscheidung `CAPABILITY_DISCOVERY_NEEDED = yes | no`

Wenn Ziel, Definition of Done oder Sicherheitsgrenzen fehlen, markiere `MISSING`. Stelle maximal drei präzise Rückfragen nur dann, wenn ohne sie kein sicherer Fortschritt möglich ist.

### 1. Research-Bag Preparation

Führe zuerst eine Research-Backed-Skill-Preparation durch. Lies bei Bedarf `references/research-bag-contract.md` und `references/source-policy.md`.

Erzeuge ein Research-Bag-Ergebnis mit:

- Source Inventory
- Knowledge Model
- Capability Candidates
- Browser-Act Candidates
- Eval Requirements
- Build Recommendation

Confidence-Regeln:

- Confidence 4-5 darf harte Skill-Regeln stützen.
- Confidence 3 darf nur als Annahme oder Designhypothese genutzt werden.
- Confidence 1-2 blockiert harte Regeln.

### 2. Capability Discovery, Canon und Browser-Act-Branch

Wenn `CAPABILITY_DISCOVERY_NEEDED = yes`, lies `references/capability-radar.md`, `references/canonical-capability-resolution.md`, `references/canonical-evidence-registry.md`, `references/capability-selection-policy.md`, `references/capability-lifecycle.md` und bei komplexen Entscheidungen `references/evidence-decision-graph.md`. Discovery ist Kandidatenfindung; belastbare Adoption erfordert claim-nahe Evidenz, Primary-Source-Verifikation, zulässige Lifecycle-Transitions und Technology Selection Gate. Bevorzuge native/plattformeigene oder kleine deterministische Lösungen vor Frameworks und externen Services.

Wenn Telemetrie relevant ist, lies `references/skill-engineering-telemetry.md`. Nutze bevorzugt die native Aggregation aus dem Build Trace; externe Telemetrie bleibt optional. Telemetrie misst Ausführung, nicht Wahrheit oder Ergebnisqualität.

Lies `references/browser-act-capability-contract.md`, wenn Website-Funktionalität relevant ist.

Aktiviere Browser-Act nur bei konkreter Website-/Web-App-Funktionalität. Klassifiziere dann:

- `extraction`: Daten aus sichtbaren oder nutzerberechtigten Seiten gewinnen
- `operation`: Nutzerseitig erlaubte Operation sicher erfassen oder ausführen

Blockiere, wenn Auth-Bypass, verdeckter Zugriff, unklare Datenklassifikation, nicht markiertes Legal/ToS-Risiko oder irreversible Side Effects erforderlich wären.

### 3. Pre-Build Architecture Gate

Führe ein Ultrathink-Craftsmanship-Gate aus. Lies `references/pipeline-contract.md` und `references/release-gate-policy.md`.

Prüfe:

- Ist ein einzelner Skill sinnvoll oder braucht es Subskills?
- Triggert die Description zu breit oder zu eng?
- Ist Research abgeschlossen?
- Sind Browser-/Tool-/MCP-Capabilities abgegrenzt?
- Gibt es eine kleinere robuste Lösung?
- Was ist die gefährlichste Failure-Mode-Kette?
- Was ist das stärkste Gegenargument gegen die geplante Architektur?

Ohne `PASS` oder `PASS_WITH_ASSUMPTIONS` kein Draft-Build.

### 4. Skill Draft Build

Baue das Skill-Paket nach `references/output-contract.md`.

Pflichtbestandteile für Enterprise-Skills:

- `SKILL.md`
- `agents/openai.yaml`
- `references/source-policy.md`
- `references/source-map.md`
- `references/security-and-tools.md`
- `references/eval-design.md`
- bei technischem Capability-Bedarf: Capability Record, Primary-Source-Verifikation und Decision Graph nach den spezialisierten References/Schemas
- `scripts/quick_validate.py`
- `scripts/validate_source_map.py`
- `scripts/validate_evals.py`
- `scripts/validate_release_gate.py`
- `evals/trigger_queries.json`
- `evals/output_evals.json`
- `reports/release-gate-report.json`

Optionale Bestandteile:

- `references/workflow.dot` für komplexe Multi-Step-, MCP-, Browser- oder Enterprise-Prozess-Skills
- MCP-Dateien nur bei realem MCP-Bedarf
- Browser-Capability-Skripte nur bei bestandenem Browser-Act-Branch

### 4a. Draft Freeze und Reliability Trace

Wenn deterministische Datei-/Codeausführung verfügbar ist, lies `references/pipeline-ledger.md`. Berechne nach Abschluss der build-kontrollierten Dateien einen Artifact-Digest und erfasse `DRAFT_FROZEN`. Release-, Evaluator- und Validation-PASS-Ereignisse müssen denselben Digest tragen. Nach einer materiellen Draft-Änderung ist ein neuer Freeze-Zyklus erforderlich; alte Gate-Evidenz darf nicht weiter autorisieren.

Nutze `scripts/pipeline_ledger.py`, `scripts/evidence_registry.py` und die zugehörigen Validatoren. Wenn die Runtime diese deterministischen Checks nicht ausführen kann, markiere `RUNTIME_UNAVAILABLE` statt PASS zu behaupten.

### 4b. Installability- und Agenten-Portabilitäts-Gate

Für jeden erzeugten oder aktualisierten Skill, der dem Nutzer als installierbares ChatGPT-Skill-Artefakt dienen soll:

- Paketname muss `skill.zip` sein.
- Im ZIP muss genau ein Skill-Ordner mit `SKILL.md` an der Wurzel dieses Ordners liegen.
- `agents/openai.yaml` muss vorhanden sein.
- `SKILL.md` bleibt der steuernde Entry Point; umfangreiche Details bleiben in `references/`.
- Erzeuge `reports/installability-report.json` mit `artifact_name`, `chatgpt_install_ready`, `frontend_install_suggestion_status`, `not_controlled_by_skill`, `blocking_issues` und `user_action`.
- Setze `frontend_install_suggestion_status` nie auf `guaranteed`. Zulässig sind `prepared`, `blocked` oder `not_controlled_by_skill`.
- Erzeuge `references/agent-agnostic-compatibility.md` oder eine skill-spezifische Kompatibilitätsnotiz, wenn Claude, Frontier-Modelle, Codex, Claude Code, Cursor, Windsurf oder andere Agenten erwähnt werden.
- Erzeuge `reports/core-functionality-preservation.json` und benenne unveränderte Kernfunktionen sowie minimale Ergänzungen.

### 5. Release Hook

Der Release Hook ist verpflichtend. Lies `references/release-gate-policy.md`. Prüfe zusätzlich den Reliability Integrity Gate, wenn die deterministischen Reliability-Komponenten für den Build anwendbar sind. Build Trace, Evidence Registry und Capability Lifecycle stärken Prozessintegrität, ersetzen aber weder Source Truth noch den Enterprise Skill Output Evaluator.

Der Hook blockiert, wenn:

- Craftsmanship-Gate nicht `PASS` ist
- Anti-Confabulation-Gate nicht `PASS` ist
- Anti-Sycophancy-Score >= 3 ist
- Bias-Gate `BLOCKED` meldet
- `blocked_claims` nicht leer ist
- Korrekturen nicht angewendet wurden

Korrigiere den Draft, bis der Hook freigibt oder melde `BLOCKED`.

### 6. Enterprise Skill Output Evaluator

Lies `references/enterprise-skill-output-evaluator.md`, wenn ein Skill-Creator-Output bewertet werden soll oder wenn der finale Skill-Creator-Output vor Auslieferung bewertet werden muss.

Der Evaluator prüft ausschließlich den Output eines Skill-Creator-GPTs. Er bewertet:

- Agent-Skills-Konformität
- Research-Qualität
- Enterprise-Readiness
- Architekturqualität
- Release-Gate-Integrität

Der Evaluator gibt XML im Format `<enterprise_skill_evaluation>...</enterprise_skill_evaluation>` aus. Er baut keinen neuen Skill, außer eine Revision wird ausdrücklich angefordert.

### 7. Validierung und Evaluation

Führe die deterministischen Prüfungen aus oder liefere ausführbare Kommandos:

```bash
python scripts/quick_validate.py <skill-dir>
python scripts/validate_source_map.py <skill-dir>
python scripts/validate_evals.py <skill-dir>
python scripts/validate_release_gate.py <skill-dir>
python scripts/validate_installability.py <skill-dir>
python scripts/validate_agent_agnostic.py <skill-dir>
python scripts/validate_core_parity.py <skill-dir>
python scripts/validate_capability_record.py <skill-dir>
python scripts/validate_capability_decisions.py <skill-dir>
python scripts/validate_capability_evals.py <skill-dir>
python scripts/validate_self_upgrade_regression.py <skill-dir>
python scripts/validate_evidence_registry.py <skill-dir>
python scripts/validate_capability_lifecycle.py <skill-dir>
python scripts/run_reliability_evals.py <skill-dir>
python scripts/validate_pipeline_ledger.py <skill-dir>
python scripts/validate_build_telemetry.py <skill-dir>
python scripts/validate_enterprise_skill_evaluation.py <evaluation.xml>
python scripts/package_skill.py <skill-dir> ./dist
```

Für generierte Skills müssen `evals/trigger_queries.json` und `evals/output_evals.json` existieren. Für MCP-/Tool-Skills müssen read-only, idempotente, unabhängige, nicht-destruktive Evaluationen vorbereitet werden.

## Ausgabeformat

Wenn ein Skill gebaut oder aktualisiert wird, liefere:

1. **EXECUTIVE SUMMARY**
2. **FILETREE**
3. **ALLE DATEIEN** mit `# path:` als erster Zeile jedes Codeblocks
4. **VALIDATION COMMANDS**
5. **EVAL PLAN**
6. **RELEASE-GATE SUMMARY**
7. **RELIABILITY / PROVENANCE SUMMARY**
8. **INSTALLABILITY / AGENT-AGNOSTIC SUMMARY**
9. **PACKAGING COMMAND**
10. **MISSING / SOURCE_NEEDED / ASSUMPTIONS**

Wenn nur evaluiert wird, liefere ausschließlich oder zuerst den Enterprise Skill Output Evaluator Report im definierten XML-Format.

## Beispiele

### Beispiel 1: Enterprise-Skill aus Dokumenten

Input: „Baue einen Skill aus unseren internen Onboarding-Dokumenten und aktueller Tool-Dokumentation.“

Erwartetes Verhalten:

- Quellen inventarisieren und klassifizieren.
- User-Dokumente als `user_provided` markieren.
- Aktuelle Tool-Fähigkeiten aus Primärquellen prüfen oder `SOURCE_NEEDED` setzen.
- Skill-Draft bauen.
- Release Hook und Enterprise Skill Output Evaluator ausführen.
- Nur bei PASS paketieren.

### Beispiel 2: Website-Capability als Skill-Komponente

Input: „Erzeuge einen wiederverwendbaren Skill, der Daten aus unserem internen Web-Dashboard extrahiert.“

Erwartetes Verhalten:

- Browser-Act-Branch nur nach Permission Boundary aktivieren.
- API/Network Capture vor DOM priorisieren.
- Keine Auth-Umgehung.
- Known Limitations, Data Classification und Review Flags dokumentieren.
- Capability-Komponenten validieren.

### Beispiel 3: Output eines Skill-Creators bewerten

Input: „Bewerte diesen Skill-Creator-Output gegen Enterprise-Kriterien.“

Erwartetes Verhalten:

- Enterprise Skill Output Evaluator ausführen.
- XML mit Scores, Blockern, Revisionen, Entscheidung und kurzer Begründung ausgeben.
- Keinen neuen Skill bauen, außer eine Revision ist ausdrücklich beauftragt.
