from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import pipeline_ledger  # type: ignore  # noqa: E402
import evidence_registry  # type: ignore  # noqa: E402
import validate_capability_lifecycle as lifecycle  # type: ignore  # noqa: E402
import summarize_build_telemetry as telemetry  # type: ignore  # noqa: E402


class PipelineLedgerTests(unittest.TestCase):
    def test_complete_trace_authorizes_package(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "artifact"
            root.mkdir()
            (root / "SKILL.md").write_text("---\nname: x\ndescription: x\n---\n", encoding="utf-8")
            events = Path(td) / "events.jsonl"
            run_id = "run-1"
            for event_type in [
                "INTAKE_COMPLETED",
                "RESEARCH_COMPLETED",
                "CAPABILITY_DECISION_SKIPPED",
                "ARCHITECTURE_GATE_PASSED",
            ]:
                pipeline_ledger.append_event(events, event_type, run_id=run_id)
            digest = pipeline_ledger.artifact_digest(root)
            for event_type in [
                "DRAFT_FROZEN",
                "RELEASE_GATE_PASSED",
                "EVALUATOR_PASSED",
                "VALIDATION_PASSED",
                "PACKAGE_AUTHORIZED",
            ]:
                pipeline_ledger.append_event(events, event_type, run_id=run_id, artifact_digest=digest)
            state = pipeline_ledger.rebuild_state(events, current_artifact_digest=digest)
            self.assertTrue(state["package_authorized"])
            self.assertEqual(state["errors"], [])

    def test_missing_release_gate_blocks(self):
        with tempfile.TemporaryDirectory() as td:
            events = Path(td) / "events.jsonl"
            for event_type in ["INTAKE_COMPLETED", "RESEARCH_COMPLETED", "CAPABILITY_DECISION_SKIPPED", "ARCHITECTURE_GATE_PASSED"]:
                pipeline_ledger.append_event(events, event_type, run_id="r")
            digest = "a" * 64
            for event_type in ["DRAFT_FROZEN", "EVALUATOR_PASSED", "VALIDATION_PASSED", "PACKAGE_AUTHORIZED"]:
                pipeline_ledger.append_event(events, event_type, run_id="r", artifact_digest=digest)
            state = pipeline_ledger.rebuild_state(events, current_artifact_digest=digest)
            self.assertFalse(state["package_authorized"])

    def test_tampered_chain_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            events = Path(td) / "events.jsonl"
            pipeline_ledger.append_event(events, "INTAKE_COMPLETED", run_id="r")
            raw = json.loads(events.read_text(encoding="utf-8").strip())
            raw["data"] = {"reason": "tampered"}
            events.write_text(json.dumps(raw) + "\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                pipeline_ledger.rebuild_state(events)

    def test_stale_digest_blocks(self):
        with tempfile.TemporaryDirectory() as td:
            events = Path(td) / "events.jsonl"
            for event_type in ["INTAKE_COMPLETED", "RESEARCH_COMPLETED", "CAPABILITY_DECISION_SKIPPED", "ARCHITECTURE_GATE_PASSED"]:
                pipeline_ledger.append_event(events, event_type, run_id="r")
            digest = "a" * 64
            for event_type in ["DRAFT_FROZEN", "RELEASE_GATE_PASSED", "EVALUATOR_PASSED", "VALIDATION_PASSED", "PACKAGE_AUTHORIZED"]:
                pipeline_ledger.append_event(events, event_type, run_id="r", artifact_digest=digest)
            state = pipeline_ledger.rebuild_state(events, current_artifact_digest="b" * 64)
            self.assertFalse(state["package_authorized"])
            self.assertIn("STALE_ARTIFACT_DIGEST", state["errors"])

    def test_replay_is_deterministic(self):
        with tempfile.TemporaryDirectory() as td:
            events = Path(td) / "events.jsonl"
            pipeline_ledger.append_event(events, "INTAKE_COMPLETED", run_id="r", ts="2026-08-17T00:00:00+00:00")
            s1 = pipeline_ledger.rebuild_state(events)
            s2 = pipeline_ledger.rebuild_state(events)
            self.assertEqual(s1, s2)

    def test_forbidden_payload_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(ValueError):
                pipeline_ledger.append_event(Path(td) / "events.jsonl", "INTAKE_COMPLETED", run_id="r", data={"prompt": "secret"})


class EvidenceRegistryTests(unittest.TestCase):
    def test_query_preserves_authority(self):
        records = evidence_registry.load_records(ROOT / "evals/fixtures/evidence-records.jsonl")
        original = {r["evidence_id"]: (r["authority_class"], r["verification_status"]) for r in records}
        results = evidence_registry.query_records(records, "deterministic retrieval")
        self.assertTrue(results)
        for result in results:
            self.assertEqual((result["authority_class"], result["verification_status"]), original[result["evidence_id"]])
            self.assertIn("retrieval_score", result)

    def test_invalid_record_rejected(self):
        with self.assertRaises(ValueError):
            evidence_registry.validate_record({"evidence_id": "bad"})


class LifecycleTests(unittest.TestCase):
    def test_direct_adoption_rejected(self):
        evidence = evidence_registry.load_records(ROOT / "evals/fixtures/evidence-records.jsonl")
        events = [{"seq": 1, "capability_id": "C1", "from": "DISCOVERED", "to": "ADOPTED", "evidence_ids": ["E-PRIMARY-001"], "reason": "jump"}]
        errors = lifecycle.validate_events(events, evidence)
        self.assertTrue(errors)

    def test_staged_candidate_passes(self):
        evidence = evidence_registry.load_records(ROOT / "evals/fixtures/evidence-records.jsonl")
        events = [
            {"seq": 1, "capability_id": "C1", "from": "DISCOVERED", "to": "PRIMARY_SOURCE_PENDING", "evidence_ids": [], "reason": "verify"},
            {"seq": 2, "capability_id": "C1", "from": "PRIMARY_SOURCE_PENDING", "to": "VERIFIED_CANDIDATE", "evidence_ids": ["E-PRIMARY-001"], "reason": "primary evidence"}
        ]
        self.assertEqual(lifecycle.validate_events(events, evidence), [])


class TelemetryTests(unittest.TestCase):
    def test_truth_authority_false(self):
        events = [
            {"ts": "2026-08-17T00:00:00+00:00", "event_type": "INTAKE_COMPLETED", "run_id": "r", "data": {}},
            {"ts": "2026-08-17T00:00:01+00:00", "event_type": "VALIDATION_PASSED", "run_id": "r", "data": {}}
        ]
        summary = telemetry.summarize_events(events, source_file="events.jsonl")
        self.assertIs(summary["truth_authority"], False)
        self.assertNotIn("prompt", json.dumps(summary).lower())


if __name__ == "__main__":
    unittest.main()
