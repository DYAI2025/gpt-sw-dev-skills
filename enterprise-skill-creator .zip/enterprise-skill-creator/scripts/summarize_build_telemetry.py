#!/usr/bin/env python3
"""Summarize observable build ledger events into non-authoritative telemetry."""
from __future__ import annotations

import argparse
import json
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any

from pipeline_ledger import read_events, verify_chain

FORBIDDEN_KEYS = {"prompt", "prompts", "body", "content", "credentials", "credential", "secret", "secrets", "tool_arguments", "arguments", "model_response", "response", "api_key", "password", "private_key"}


def _parse_ts(value: str) -> datetime | None:
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        return None


def summarize_events(events: list[dict[str, Any]], *, source_file: str) -> dict[str, Any]:
    if not events:
        return {
            "schema_version": 1,
            "run_id": None,
            "started_at": None,
            "ended_at": None,
            "duration_ms": None,
            "event_count": 0,
            "stage_counts": {},
            "validation_attempts": 0,
            "gate_failures": 0,
            "rework_events": 0,
            "source_files": [source_file],
            "truth_authority": False,
            "privacy_mode": "aggregate_metadata_only",
        }
    run_id = events[-1].get("run_id")
    run_events = [e for e in events if e.get("run_id") == run_id]
    counts = Counter(str(e.get("event_type")) for e in run_events)
    timestamps = [_parse_ts(str(e.get("ts", ""))) for e in run_events]
    timestamps = [t for t in timestamps if t is not None]
    duration_ms = None
    if len(timestamps) >= 2:
        duration_ms = max(0, int((max(timestamps) - min(timestamps)).total_seconds() * 1000))
    validation_attempts = sum(counts[k] for k in counts if k.startswith("VALIDATION_"))
    gate_failures = sum(counts[k] for k in counts if k.endswith("_FAILED") or k.endswith("_BLOCKED") or k.endswith("_REVISE"))
    rework_events = counts.get("DRAFT_REVISED", 0) + max(0, counts.get("DRAFT_FROZEN", 0) - 1)
    return {
        "schema_version": 1,
        "run_id": run_id,
        "started_at": min(timestamps).isoformat() if timestamps else None,
        "ended_at": max(timestamps).isoformat() if timestamps else None,
        "duration_ms": duration_ms,
        "event_count": len(run_events),
        "stage_counts": dict(sorted(counts.items())),
        "validation_attempts": validation_attempts,
        "gate_failures": gate_failures,
        "rework_events": rework_events,
        "source_files": [source_file],
        "truth_authority": False,
        "privacy_mode": "aggregate_metadata_only",
    }


def forbidden_key_in_summary(value: Any) -> str | None:
    if isinstance(value, dict):
        for key, child in value.items():
            if str(key).lower() in FORBIDDEN_KEYS:
                return str(key)
            hit = forbidden_key_in_summary(child)
            if hit:
                return hit
    elif isinstance(value, list):
        for child in value:
            hit = forbidden_key_in_summary(child)
            if hit:
                return hit
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("events")
    parser.add_argument("output")
    args = parser.parse_args()
    events_path = Path(args.events)
    events = read_events(events_path)
    verify_chain(events)
    summary = summarize_events(events, source_file=events_path.name)
    Path(args.output).write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"WROTE: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
