#!/usr/bin/env python3
"""Validate non-compensatory capability lifecycle transitions against evidence."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

from evidence_registry import load_records

STATES = {"DISCOVERED", "PRIMARY_SOURCE_PENDING", "VERIFIED_CANDIDATE", "EXPERIMENTAL", "ADOPTED", "REJECTED", "STALE", "BLOCKED"}
ALLOWED = {
    "DISCOVERED": {"PRIMARY_SOURCE_PENDING", "REJECTED", "BLOCKED"},
    "PRIMARY_SOURCE_PENDING": {"VERIFIED_CANDIDATE", "REJECTED", "BLOCKED"},
    "VERIFIED_CANDIDATE": {"EXPERIMENTAL", "ADOPTED", "REJECTED", "STALE", "BLOCKED"},
    "EXPERIMENTAL": {"ADOPTED", "VERIFIED_CANDIDATE", "REJECTED", "STALE", "BLOCKED"},
    "ADOPTED": {"STALE", "REJECTED", "BLOCKED"},
    "STALE": {"PRIMARY_SOURCE_PENDING", "VERIFIED_CANDIDATE", "REJECTED", "BLOCKED"},
    "BLOCKED": {"PRIMARY_SOURCE_PENDING", "REJECTED"},
    "REJECTED": set(),
}


def load_events(path: Path) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    for line_no, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not raw.strip():
            continue
        try:
            event = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid lifecycle JSON line {line_no}: {exc}") from exc
        events.append(event)
    return events


def validate_events(events: list[dict[str, Any]], evidence_records: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    evidence = {r["evidence_id"]: r for r in evidence_records}
    current: dict[str, str] = {}
    expected_seq = 1
    for event in events:
        if event.get("seq") != expected_seq:
            errors.append(f"SEQ:{expected_seq}")
        expected_seq += 1
        cid = event.get("capability_id")
        from_state = event.get("from")
        to_state = event.get("to")
        ids = event.get("evidence_ids", [])
        if not cid or from_state not in STATES or to_state not in STATES or not isinstance(ids, list) or not event.get("reason"):
            errors.append(f"MALFORMED:{cid or '?'}")
            continue
        if cid in current and current[cid] != from_state:
            errors.append(f"STATE_MISMATCH:{cid}:{current[cid]}->{from_state}")
        if to_state not in ALLOWED[from_state]:
            errors.append(f"ILLEGAL_TRANSITION:{cid}:{from_state}->{to_state}")
        missing_ids = [eid for eid in ids if eid not in evidence]
        if missing_ids:
            errors.append(f"UNKNOWN_EVIDENCE:{cid}:{','.join(missing_ids)}")
        referenced = [evidence[eid] for eid in ids if eid in evidence]
        if to_state == "VERIFIED_CANDIDATE":
            qualifying = [r for r in referenced if r["source_type"] == "primary" and r["verification_status"] in {"SOURCE_INSPECTED", "PRIMARY_VERIFIED", "RUNTIME_VERIFIED"} and r["confidence"] >= 3]
            if not qualifying:
                errors.append(f"INSUFFICIENT_VERIFIED_CANDIDATE_EVIDENCE:{cid}")
        if to_state == "ADOPTED":
            qualifying = [r for r in referenced if r["source_type"] == "primary" and r["verification_status"] in {"PRIMARY_VERIFIED", "RUNTIME_VERIFIED"} and r["confidence"] >= 4]
            if not qualifying:
                errors.append(f"INSUFFICIENT_ADOPTION_EVIDENCE:{cid}")
        current[cid] = to_state
    return errors


def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_capability_lifecycle.py <skill-dir>")
    root = Path(argv[1])
    events_path = root / "reports" / "capability-lifecycle-events.jsonl"
    evidence_path = root / "reports" / "canonical-evidence-records.jsonl"
    if not events_path.exists() or not evidence_path.exists():
        return fail("capability lifecycle events or canonical evidence records missing")
    try:
        events = load_events(events_path)
        evidence = load_records(evidence_path)
    except ValueError as exc:
        return fail(str(exc))
    errors = validate_events(events, evidence)
    if errors:
        return fail("; ".join(errors))
    print(f"PASS: capability lifecycle ({len(events)} transitions)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
