#!/usr/bin/env python3
"""Run static contract evals for capability-selection policy; does not claim model-runtime behavior."""
from __future__ import annotations
import json, sys
from pathlib import Path

def main(argv):
    if len(argv)!=2:
        print('usage: run_capability_policy_evals.py <skill-dir>', file=sys.stderr); return 1
    root=Path(argv[1])
    docs={p.name:p.read_text(encoding='utf-8') for p in (root/'references').glob('*.md')}
    skill=(root/'SKILL.md').read_text(encoding='utf-8')
    corpus='\n'.join(docs.values())+'\n'+skill
    checks={
      'CAP-001':['CAPABILITY_DISCOVERY_NEEDED = yes | no','Use `no`','Do not technicize'],
      'CAP-002':['RAG','Primary-Source-Verifikation','Technology Selection Gate'],
      'CAP-003':['secondary_discovery_source','SOURCE_NEEDED','primary-source'],
      'CAP-004':['native capability -> existing platform capability -> simple deterministic script -> small dependency -> framework -> external service'],
      'CAP-005':['CONTRADICTION','Do not adopt'],
      'CAP-006':['LLM confidence != evidence','model_confidence'],
      'CAP-007':['How was the build executed?','Was the result correct?','truth_authority: false'],
      'CAP-008':['data egress','external processing','no silent adoption'],
      'CAP-009':['Progressive Disclosure','no-radar path','core'],
      'CAP-010':['single-pass','recursive','baseline']
    }
    results=[]; overall=True
    for cid,terms in checks.items():
        missing=[t for t in terms if t not in corpus]
        status='PASS' if not missing else 'FAIL'
        overall &= not missing
        results.append({'id':cid,'status':status,'method':'static_contract','missing_terms':missing})
    report={'evaluation_type':'static_policy_contract','runtime_model_behavior_tested':False,'passed':overall,'results':results,'limitation':'Validates encoded policy/guard contracts, not stochastic model compliance in a separate ChatGPT runtime.'}
    (root/'reports/capability-eval-results.json').write_text(json.dumps(report,indent=2)+"\n",encoding='utf-8')
    print(('PASS' if overall else 'FAIL')+': capability policy evals '+str(sum(r['status']=='PASS' for r in results))+'/10')
    return 0 if overall else 1
if __name__=='__main__': raise SystemExit(main(sys.argv))
