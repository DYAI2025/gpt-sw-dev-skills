#!/usr/bin/env python3
"""Validate release-gate report including reliability-integrity preconditions."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_release_gate.py <skill-dir>")
    root = Path(argv[1])
    path = root / "reports" / "release-gate-report.json"
    if not path.exists():
        return fail("reports/release-gate-report.json missing")
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(f"invalid release gate JSON: {exc}")

    release = report.get("release_gate", {})
    craft = report.get("craftsmanship_gate", {})
    confab = report.get("anti_confabulation_gate", {})
    syco = report.get("anti_sycophancy", {})
    bias = report.get("bias_gate", {})
    reliability = report.get("reliability_gate", {})

    if release.get("status") != "PASS":
        return fail("release_gate.status must be PASS")
    if release.get("allowed_to_package") is not True:
        return fail("release_gate.allowed_to_package must be true")
    if craft.get("status") != "PASS":
        return fail("craftsmanship_gate.status must be PASS")
    if confab.get("status") != "PASS":
        return fail("anti_confabulation_gate.status must be PASS")
    blocked = confab.get("blocked_claims", [])
    if blocked:
        return fail("blocked_claims must be empty")
    score = syco.get("score")
    threshold = syco.get("threshold", 3)
    if not isinstance(score, int):
        return fail("anti_sycophancy.score must be an integer")
    if score >= threshold:
        return fail("anti_sycophancy score exceeds threshold")
    if syco.get("status") == "REBUILD":
        return fail("anti_sycophancy status REBUILD blocks packaging")
    if bias.get("status") == "BLOCKED":
        return fail("bias_gate.status BLOCKED")

    if reliability.get("status") != "PASS":
        return fail("reliability_gate.status must be PASS")
    expected = {
        "pipeline_trace_status": "PASS",
        "evidence_registry_status": "PASS",
        "capability_lifecycle_status": "PASS",
        "telemetry_status": "PASS",
        "reliability_evals_status": "PASS",
        "core_regression_status": "PASS",
    }
    for key, wanted in expected.items():
        if reliability.get(key) != wanted:
            return fail(f"reliability_gate.{key} must be {wanted}")
    if reliability.get("truth_authority_from_trace_or_telemetry") is not False:
        return fail("trace/telemetry must not have truth authority")
    print("PASS: release gate + reliability integrity")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
