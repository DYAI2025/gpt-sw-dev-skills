#!/usr/bin/env python3
"""Validate one-pass self-upgrade regression and baseline-preservation report."""
from __future__ import annotations
import json, sys
from pathlib import Path
def fail(m): print(f"FAIL: {m}",file=sys.stderr); return 1
def main(argv):
    if len(argv)!=2:return fail("usage: validate_self_upgrade_regression.py <skill-dir>")
    p=Path(argv[1])/'reports/self-upgrade-regression-report.json'
    if not p.exists():return fail("self-upgrade regression report missing")
    r=json.loads(p.read_text())
    checks=[(r.get('upgrade_pass_count')==1,'upgrade_pass_count must be 1'),(r.get('recursive_self_improvement') is False,'recursive self improvement must be false'),(r.get('baseline_retained') is True,'baseline must be retained'),(r.get('evaluator_modified') is False,'evaluator must remain unchanged'),(r.get('baseline_validators_passed') is True,'baseline validators must pass'),(r.get('candidate_validators_passed') is True,'candidate validators must pass'),(r.get('simple_skill_regression')=='PASS','simple skill regression must PASS'),(r.get('core_regression_detected') is False,'core regression detected'),(r.get('release_blocked') is False,'release still blocked')]
    for ok,msg in checks:
        if not ok:return fail(msg)
    print("PASS: one-pass self-upgrade regression"); return 0
if __name__=='__main__': raise SystemExit(main(sys.argv))
