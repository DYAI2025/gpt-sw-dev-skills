#!/usr/bin/env python3
"""Portable JSONL evidence registry with authority-preserving deterministic query."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any

REQUIRED = {
    "evidence_id", "source_id", "source_type", "source_role", "authority_class",
    "location", "claim", "pointer", "verification_status", "confidence",
    "content_sha256", "immutable_ref", "retrieved_at", "limitations", "local_path",
}
SOURCE_TYPES = {"primary", "secondary", "user_provided", "derived", "uncertain"}
AUTHORITY = {"canonical", "reference", "derived", "uncertain"}
VERIFY = {"UNVERIFIED", "SOURCE_INSPECTED", "PRIMARY_VERIFIED", "RUNTIME_VERIFIED", "CONTRADICTED"}
TOKEN_RE = re.compile(r"[A-Za-z0-9_./:-]+")


def validate_record(record: dict[str, Any]) -> None:
    if not isinstance(record, dict):
        raise ValueError("evidence record must be an object")
    missing = REQUIRED - set(record)
    if missing:
        raise ValueError("missing evidence fields: " + ", ".join(sorted(missing)))
    if not isinstance(record["evidence_id"], str) or not record["evidence_id"]:
        raise ValueError("evidence_id must be non-empty string")
    if record["source_type"] not in SOURCE_TYPES:
        raise ValueError("invalid source_type")
    if record["authority_class"] not in AUTHORITY:
        raise ValueError("invalid authority_class")
    if record["verification_status"] not in VERIFY:
        raise ValueError("invalid verification_status")
    if not isinstance(record["confidence"], int) or not 1 <= record["confidence"] <= 5:
        raise ValueError("confidence must be integer 1-5")
    if not isinstance(record["limitations"], list):
        raise ValueError("limitations must be an array")
    content_hash = record["content_sha256"]
    if content_hash is not None and (not isinstance(content_hash, str) or not re.fullmatch(r"[0-9a-f]{64}", content_hash)):
        raise ValueError("content_sha256 must be null or lowercase sha256")
    if record["verification_status"] == "PRIMARY_VERIFIED" and record["source_type"] != "primary":
        raise ValueError("PRIMARY_VERIFIED requires source_type primary")
    if record["authority_class"] == "derived" and record["source_type"] != "derived":
        raise ValueError("derived authority_class requires derived source_type")


def load_records(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        raise ValueError(f"evidence registry missing: {path}")
    records: list[dict[str, Any]] = []
    ids: set[str] = set()
    for line_no, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not raw.strip():
            continue
        try:
            record = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid JSON line {line_no}: {exc}") from exc
        validate_record(record)
        if record["evidence_id"] in ids:
            raise ValueError(f"duplicate evidence_id: {record['evidence_id']}")
        ids.add(record["evidence_id"])
        records.append(record)
    if not records:
        raise ValueError("evidence registry must not be empty")
    return records


def _tokens(text: str) -> list[str]:
    return [t.lower() for t in TOKEN_RE.findall(text)]


def query_records(records: list[dict[str, Any]], query: str, limit: int = 10) -> list[dict[str, Any]]:
    qtokens = _tokens(query)
    if not qtokens:
        return []
    scored: list[tuple[int, str, dict[str, Any]]] = []
    for record in records:
        haystack = " ".join(str(record.get(k, "")) for k in ("evidence_id", "source_id", "source_role", "location", "claim", "pointer"))
        tokens = _tokens(haystack)
        score = sum(tokens.count(q) for q in qtokens)
        if score <= 0:
            continue
        result = dict(record)
        result["retrieval_score"] = score
        scored.append((score, record["evidence_id"], result))
    scored.sort(key=lambda item: (-item[0], item[1]))
    return [item[2] for item in scored[: max(0, limit)]]


def verify_local_hash(record: dict[str, Any]) -> tuple[bool | None, str]:
    local_path = record.get("local_path")
    expected = record.get("content_sha256")
    if not local_path or not expected:
        return None, "HASH_NOT_AVAILABLE"
    path = Path(local_path)
    if not path.exists() or not path.is_file():
        return False, "LOCAL_PATH_MISSING"
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    return actual == expected, actual


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="cmd", required=True)
    p_validate = sub.add_parser("validate")
    p_validate.add_argument("registry")
    p_query = sub.add_parser("query")
    p_query.add_argument("registry")
    p_query.add_argument("query")
    p_query.add_argument("--limit", type=int, default=10)
    args = parser.parse_args()
    try:
        records = load_records(Path(args.registry))
        if args.cmd == "validate":
            print(f"PASS: evidence registry ({len(records)} records)")
            return 0
        results = query_records(records, args.query, args.limit)
        print(json.dumps(results, indent=2, ensure_ascii=False))
        return 0
    except ValueError as exc:
        print(f"FAIL: {exc}", file=__import__("sys").stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
