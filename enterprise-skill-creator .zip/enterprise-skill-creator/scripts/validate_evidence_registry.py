#!/usr/bin/env python3
"""Validate canonical evidence registry and authority-preserving query behavior."""
from __future__ import annotations

import sys
from pathlib import Path

from evidence_registry import load_records, query_records


def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_evidence_registry.py <skill-dir>")
    root = Path(argv[1])
    report_path = root / "reports" / "canonical-evidence-records.jsonl"
    fixture_path = root / "evals" / "fixtures" / "evidence-records.jsonl"
    try:
        records = load_records(report_path)
        fixtures = load_records(fixture_path)
    except ValueError as exc:
        return fail(str(exc))
    original = {r["evidence_id"]: (r["authority_class"], r["verification_status"], r["confidence"]) for r in fixtures}
    results = query_records(fixtures, "deterministic retrieval")
    if not results:
        return fail("evidence query fixture returned no results")
    for item in results:
        before = original[item["evidence_id"]]
        after = (item["authority_class"], item["verification_status"], item["confidence"])
        if before != after:
            return fail("retrieval modified authority/verification/confidence")
        if not isinstance(item.get("retrieval_score"), int):
            return fail("retrieval_score missing")
    print(f"PASS: evidence registry ({len(records)} records; authority-preserving query)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
