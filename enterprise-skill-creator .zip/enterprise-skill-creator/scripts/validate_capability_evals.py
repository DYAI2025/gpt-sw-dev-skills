#!/usr/bin/env python3
"""Validate the required ten capability-discovery/self-upgrade evaluation contracts."""
from __future__ import annotations
import json, sys
from pathlib import Path
REQ={f"CAP-{i:03d}" for i in range(1,11)}
def fail(m): print(f"FAIL: {m}",file=sys.stderr); return 1
def main(argv):
    if len(argv)!=2:return fail("usage: validate_capability_evals.py <skill-dir>")
    p=Path(argv[1])/'evals/capability-discovery-cases.json'
    if not p.exists():return fail("capability-discovery-cases.json missing")
    data=json.loads(p.read_text()); ids={x.get('id') for x in data if isinstance(x,dict)}
    if ids!=REQ:return fail("expected exactly CAP-001..CAP-010")
    for x in data:
        if not x.get('input') or not isinstance(x.get('expected'),list) or not x['expected']:return fail(f"invalid eval: {x.get('id')}")
    print("PASS: capability eval contracts (10/10)"); return 0
if __name__=='__main__': raise SystemExit(main(sys.argv))
