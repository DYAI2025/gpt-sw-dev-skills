#!/usr/bin/env python3
"""Validate typed Skill Architecture Decision Graph structure and evidence separation."""
from __future__ import annotations
import json, sys
from pathlib import Path
NT={"REQUIREMENT","CONSTRAINT","FACT","ASSUMPTION","CAPABILITY_CANDIDATE","EVIDENCE","RISK","CONTRADICTION","DECISION","REJECTED_OPTION","VALIDATION_RESULT"}
ET={"REQUIRES","SUPPORTS","CONTRADICTS","VERIFIED_BY","SELECTED_BECAUSE","REJECTED_BECAUSE","DEPENDS_ON","INVALIDATED_BY"}
def fail(m): print(f"FAIL: {m}",file=sys.stderr); return 1
def main(argv):
    if len(argv)!=2:return fail("usage: validate_capability_decisions.py <skill-dir>")
    root=Path(argv[1]); p=root/'reports/self-upgrade-decision-graph.json'; sp=root/'schemas/architecture-decision-graph.schema.json'
    if not p.exists() or not sp.exists():return fail("decision graph or schema missing")
    g=json.loads(p.read_text()); nodes=g.get('nodes',[]); edges=g.get('edges',[])
    ids=set()
    for n in nodes:
        if n.get('type') not in NT:return fail(f"invalid node type: {n.get('type')}")
        if not n.get('id') or n['id'] in ids:return fail("missing/duplicate node id")
        if 'model_confidence' in n:return fail("model_confidence must not drive architecture graph")
        ids.add(n['id'])
    for e in edges:
        if e.get('type') not in ET:return fail(f"invalid edge type: {e.get('type')}")
        if e.get('from') not in ids or e.get('to') not in ids:return fail("edge references unknown node")
    if not any(n.get('type')=='EVIDENCE' for n in nodes) or not any(n.get('type')=='DECISION' for n in nodes):return fail("graph needs EVIDENCE and DECISION nodes")
    print("PASS: capability decision graph"); return 0
if __name__=='__main__': raise SystemExit(main(sys.argv))
