#!/usr/bin/env python3
"""Run deterministic reliability evals for Enterprise Skill Creator upgrade."""
from __future__ import annotations

import copy
import json
import sys
import tempfile
from pathlib import Path

import evidence_registry
import pipeline_ledger
import summarize_build_telemetry as telemetry
import validate_capability_lifecycle as lifecycle

EXPECTED_IDS = {f"REL-{i:03d}" for i in range(1, 12)}


def _pipeline_fixture(events_path: Path, digest: str = "a" * 64, include_release: bool = True) -> None:
    run_id = "eval-run"
    for et in ["INTAKE_COMPLETED", "RESEARCH_COMPLETED", "CAPABILITY_DECISION_SKIPPED", "ARCHITECTURE_GATE_PASSED"]:
        pipeline_ledger.append_event(events_path, et, run_id=run_id, ts=f"2026-08-17T00:00:0{len(pipeline_ledger.read_events(events_path))}+00:00")
    pipeline_ledger.append_event(events_path, "DRAFT_FROZEN", run_id=run_id, artifact_digest=digest, ts="2026-08-17T00:00:04+00:00")
    if include_release:
        pipeline_ledger.append_event(events_path, "RELEASE_GATE_PASSED", run_id=run_id, artifact_digest=digest, ts="2026-08-17T00:00:05+00:00")
    pipeline_ledger.append_event(events_path, "EVALUATOR_PASSED", run_id=run_id, artifact_digest=digest, ts="2026-08-17T00:00:06+00:00")
    pipeline_ledger.append_event(events_path, "VALIDATION_PASSED", run_id=run_id, artifact_digest=digest, ts="2026-08-17T00:00:07+00:00")
    pipeline_ledger.append_event(events_path, "PACKAGE_AUTHORIZED", run_id=run_id, artifact_digest=digest, ts="2026-08-17T00:00:08+00:00")


def run_case(case: dict, root: Path) -> tuple[bool, str]:
    cid = case["id"]
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        if cid == "REL-001":
            events = tmp / "events.jsonl"; _pipeline_fixture(events)
            state = pipeline_ledger.rebuild_state(events, current_artifact_digest="a" * 64)
            return state["package_authorized"], str(state)
        if cid == "REL-002":
            events = tmp / "events.jsonl"; _pipeline_fixture(events, include_release=False)
            state = pipeline_ledger.rebuild_state(events, current_artifact_digest="a" * 64)
            return (not state["package_authorized"] and any("INVALID_GATE_ORDER" in e or "RELEASE" in e for e in state["errors"] + state["missing_stages"])), str(state)
        if cid == "REL-003":
            events = tmp / "events.jsonl"; _pipeline_fixture(events)
            lines = events.read_text(encoding="utf-8").splitlines()
            obj = json.loads(lines[2]); obj["data"] = {"reason": "tamper"}; lines[2] = json.dumps(obj)
            events.write_text("\n".join(lines) + "\n", encoding="utf-8")
            try:
                pipeline_ledger.rebuild_state(events)
                return False, "tampered chain accepted"
            except ValueError:
                return True, "tampered chain rejected"
        if cid == "REL-004":
            events = tmp / "events.jsonl"; _pipeline_fixture(events)
            state = pipeline_ledger.rebuild_state(events, current_artifact_digest="b" * 64)
            return (not state["package_authorized"] and "STALE_ARTIFACT_DIGEST" in state["errors"]), str(state)
        if cid == "REL-005":
            events = tmp / "events.jsonl"; _pipeline_fixture(events)
            a = pipeline_ledger.rebuild_state(events, current_artifact_digest="a" * 64)
            b = pipeline_ledger.rebuild_state(events, current_artifact_digest="a" * 64)
            return a == b, "deterministic" if a == b else "state mismatch"
        if cid == "REL-006":
            records = evidence_registry.load_records(root / "evals/fixtures/evidence-records.jsonl")
            before = {r["evidence_id"]: (r["authority_class"], r["verification_status"], r["confidence"]) for r in records}
            results = evidence_registry.query_records(records, "deterministic retrieval")
            ok = bool(results) and all((r["authority_class"], r["verification_status"], r["confidence"]) == before[r["evidence_id"]] for r in results)
            return ok, f"results={len(results)}"
        if cid == "REL-007":
            try:
                evidence_registry.validate_record({"evidence_id": "bad"})
                return False, "invalid record accepted"
            except ValueError:
                return True, "invalid record rejected"
        if cid == "REL-008":
            records = evidence_registry.load_records(root / "evals/fixtures/evidence-records.jsonl")
            events = [{"seq":1,"capability_id":"C1","from":"DISCOVERED","to":"ADOPTED","evidence_ids":["E-PRIMARY-001"],"reason":"jump"}]
            errors = lifecycle.validate_events(events, records)
            return bool(errors), ";".join(errors)
        if cid == "REL-009":
            records = evidence_registry.load_records(root / "evals/fixtures/evidence-records.jsonl")
            events = [
                {"seq":1,"capability_id":"C1","from":"DISCOVERED","to":"PRIMARY_SOURCE_PENDING","evidence_ids":[],"reason":"verify"},
                {"seq":2,"capability_id":"C1","from":"PRIMARY_SOURCE_PENDING","to":"VERIFIED_CANDIDATE","evidence_ids":["E-PRIMARY-001"],"reason":"primary evidence"}
            ]
            errors = lifecycle.validate_events(events, records)
            return not errors, ";".join(errors)
        if cid == "REL-010":
            events = [
                {"ts":"2026-08-17T00:00:00+00:00","event_type":"INTAKE_COMPLETED","run_id":"r","data":{}},
                {"ts":"2026-08-17T00:00:01+00:00","event_type":"VALIDATION_PASSED","run_id":"r","data":{}}
            ]
            summary = telemetry.summarize_events(events, source_file="events.jsonl")
            ok = summary["truth_authority"] is False and telemetry.forbidden_key_in_summary(summary) is None
            return ok, json.dumps(summary, sort_keys=True)
        if cid == "REL-011":
            try:
                pipeline_ledger.append_event(tmp / "events.jsonl", "INTAKE_COMPLETED", run_id="r", data={"prompt":"secret"})
                return False, "forbidden payload accepted"
            except ValueError:
                return True, "forbidden payload rejected"
    return False, "unknown case"


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("usage: run_reliability_evals.py <skill-dir>", file=sys.stderr); return 1
    root = Path(argv[1])
    cases_path = root / "evals/reliability-cases.json"
    if not cases_path.exists():
        print("FAIL: reliability cases missing", file=sys.stderr); return 1
    cases = json.loads(cases_path.read_text(encoding="utf-8"))
    ids = {c.get("id") for c in cases if isinstance(c, dict)}
    if ids != EXPECTED_IDS:
        print("FAIL: expected exactly REL-001..REL-011", file=sys.stderr); return 1
    results = []
    passed = True
    for case in cases:
        ok, detail = run_case(case, root)
        passed = passed and ok
        results.append({"id": case["id"], "scenario": case["scenario"], "status": "PASS" if ok else "FAIL", "detail": detail})
    report = {
        "evaluation_type": "deterministic_reliability_suite",
        "passed": passed,
        "case_count": len(results),
        "results": results,
        "limitations": ["Deterministic local evals validate encoded reliability behavior, not stochastic cross-runtime model quality."],
    }
    out = root / "reports/reliability-eval-results.json"
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(("PASS" if passed else "FAIL") + f": reliability evals {sum(r['status']=='PASS' for r in results)}/{len(results)}")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
