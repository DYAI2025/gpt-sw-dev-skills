#!/usr/bin/env python3
"""Validate native build telemetry as aggregate, non-authoritative metadata."""
from __future__ import annotations

import json
import sys
from pathlib import Path

from pipeline_ledger import read_events, verify_chain
from summarize_build_telemetry import forbidden_key_in_summary, summarize_events

REQUIRED = {"schema_version","run_id","started_at","ended_at","duration_ms","event_count","stage_counts","validation_attempts","gate_failures","rework_events","source_files","truth_authority","privacy_mode"}


def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_build_telemetry.py <skill-dir>")
    root = Path(argv[1])
    events_path = root / "reports" / "reliability-upgrade-events.jsonl"
    summary_path = root / "reports" / "build-telemetry-summary.json"
    if not events_path.exists() or not summary_path.exists():
        return fail("build telemetry source or summary missing")
    try:
        events = read_events(events_path)
        verify_chain(events)
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        expected = summarize_events(events, source_file=events_path.name)
    except Exception as exc:
        return fail(str(exc))
    missing = REQUIRED - set(summary)
    if missing:
        return fail("telemetry summary missing fields: " + ", ".join(sorted(missing)))
    if summary != expected:
        return fail("telemetry summary is not reproducible from build trace")
    if summary.get("truth_authority") is not False:
        return fail("telemetry truth_authority must be false")
    hit = forbidden_key_in_summary(summary)
    if hit:
        return fail(f"forbidden telemetry field: {hit}")
    print(f"PASS: build telemetry ({summary['event_count']} events, truth_authority=false)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
