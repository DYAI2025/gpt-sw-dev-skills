#!/usr/bin/env python3
"""Validate capability-record schema presence and normalized capability records."""
from __future__ import annotations
import json, sys
from pathlib import Path
REQ={"capability_id","name","category","purpose","discovery_source","official_repository","official_documentation","implementation_language","runtime_requirements","license","deployment_model","local_first","network_required","data_egress","external_processing","mcp_support","api_support","cli_support","maintenance_status","latest_verified_version","latest_verified_commit","verified_at","security_notes","privacy_notes","supply_chain_notes","skill_fit","integration_complexity","source_quality","evidence_strength","verification_status","known_limitations","adoption_status"}
ADOPT={"DISCOVERED","PRIMARY_SOURCE_PENDING","VERIFIED_CANDIDATE","EXPERIMENTAL","ADOPTED","REJECTED","STALE","BLOCKED"}
VERIFY={"UNVERIFIED","PARTIAL_PRIMARY","PRIMARY_VERIFIED","RUNTIME_VERIFIED","CONTRADICTED"}
def fail(m): print(f"FAIL: {m}",file=sys.stderr); return 1
def main(argv):
    if len(argv)!=2:return fail("usage: validate_capability_record.py <skill-dir>")
    root=Path(argv[1]); sp=root/'schemas/capability-record.schema.json'; rp=root/'reports/capability-records.json'
    if not sp.exists() or not rp.exists():return fail("capability schema or records report missing")
    schema=json.loads(sp.read_text()); sreq=set(schema.get('required',[]))
    if REQ-sreq:return fail("schema missing fields: "+", ".join(sorted(REQ-sreq)))
    records=json.loads(rp.read_text())
    if not isinstance(records,list) or not records:return fail("capability records must be non-empty list")
    for r in records:
        missing=REQ-set(r)
        if missing:return fail(f"{r.get('capability_id','?')} missing: {', '.join(sorted(missing))}")
        if r['adoption_status'] not in ADOPT:return fail("invalid adoption_status")
        if r['verification_status'] not in VERIFY:return fail("invalid verification_status")
        if r['adoption_status']=='ADOPTED' and r['verification_status'] not in {'PRIMARY_VERIFIED','RUNTIME_VERIFIED'}:return fail("ADOPTED requires primary/runtime verification")
    print("PASS: capability records"); return 0
if __name__=='__main__': raise SystemExit(main(sys.argv))
