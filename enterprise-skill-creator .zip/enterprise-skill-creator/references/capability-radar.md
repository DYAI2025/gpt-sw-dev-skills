# Capability Radar

## Purpose

Capability Radar is an optional discovery layer for technically relevant skill builds. It discovers candidate libraries, frameworks, APIs, MCP servers, evaluators, observability systems, memory/RAG components, structured-output tools, safety tools, serving systems, and similar building blocks. Discovery is not adoption.

## Activation

Set `CAPABILITY_DISCOVERY_NEEDED = yes | no` during Intake.

Use `yes` when the requested skill materially depends on external technical capability, including API, MCP, RAG, agents, observability, LLM evaluation, memory, data extraction, safety, prompt evaluation, structured output, model hosting, vector search, embeddings, or browser automation.

Use `no` for simple writing conventions, static formatting, and small organizational workflows with no external technical component. Do not technicize a skill merely because frameworks exist.

## Discovery source classes

- `primary`: official repository, official documentation, specification, package registry owned/attested by the project, release notes, vendor documentation.
- `secondary_discovery_source`: curated lists and catalogues used only to discover names/categories.
- `secondary`: explanatory material used for context, never to override primary evidence.
- `user_provided`, `derived`, `uncertain`: follow `references/source-policy.md`.

`KalyanKS-NLP/llm-engineer-toolkit` is a `secondary_discovery_source`. A listing there never verifies production readiness, maintenance, security, version, license, runtime behavior, or fit.

## Workflow

1. Derive capability needs from requirements and constraints.
2. Prefer the smallest solution ladder: native capability -> existing platform capability -> deterministic script -> small dependency -> framework -> external service.
3. Discover a bounded candidate set; default 3-5 candidates per need unless evidence justifies fewer.
4. Normalize each serious candidate using `schemas/capability-record.schema.json`.
5. Send serious candidates to Canonical Capability Resolver for primary-source verification.
6. Record evidence, contradictions, risks, decisions, and rejections in the Skill Architecture Decision Graph.
7. Run the Technology Selection Gate before recommending or embedding a capability.

## Discovery is not verification

- semantic similarity != evidence
- popularity != evidence
- GitHub stars != architectural fit
- README claim != runtime verification
- LLM confidence != evidence

A candidate may remain `DISCOVERED` or `PRIMARY_SOURCE_PENDING` indefinitely. It must not silently become a hard architectural dependency.
