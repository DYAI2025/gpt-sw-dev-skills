# Browser-Act Capability Contract

Use this contract only when a concrete website or web-app capability should become a reusable skill component.

## Activation criteria

Activate the Browser-Act branch when at least one is true:

- The user asks to reuse a website workflow as a skill.
- Research identifies a web page, internal API, network request or DOM flow that can become a skill component.
- The user needs repeated extraction or operation over visible/permitted web data.

Do not activate for normal web research, general source discovery or content summarization.

## Capability types

| Type | Meaning | Required safety |
|---|---|---|
| `extraction` | Reads data visible to or permitted for the user | Permission boundary, data classification, pagination/coverage tests |
| `operation` | Performs or prepares a user-side operation | HAR/offline/dry-run safety, side-effect review, explicit permission |

## Required output

```yaml
browser_capability_output:
  capability_id: B001
  target_site: string
  type: extraction | operation
  selected_strategy: api | network_capture | dom | ai_workflow | composite
  verification_status: pass | partial | failed
  permission_boundary:
    requires_login: true | false
    visible_to_user: true | false
    user_permitted: true | false
    bypass_attempted: false
  scripts:
    - path: scripts/example.py
      purpose: string
      params:
        - name: keyword
          type: string
      verification:
        python_outputs_valid_js: true | false
        browser_eval_passed: true | false
        error_case_returns_json_error: true | false
  output_schema:
    type: json
    fields:
      - name: string
        nullable: true | false
  known_limitations:
    - string
  enterprise_review:
    data_classification_needed: true | false
    tos_review_needed: true | false
    rate_limit_notes: string
```

## Gates

Block when:

- Auth bypass would be required.
- Data classification is missing.
- ToS/legal review risk is obvious but not marked.
- No reproducible verification path exists.
- A proposed operation can have irreversible or third-party-harmful side effects.

## Output integration

Browser-generated scripts belong in `scripts/` only after verification. Website capability details belong in `references/browser-capabilities.md` or a domain-specific reference file. The final SKILL.md should invoke the scripts, not embed long JS snippets.
