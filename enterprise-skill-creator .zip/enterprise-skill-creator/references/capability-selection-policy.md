# Capability Selection Policy

## Technology Selection Gate

Before an external capability is recommended or embedded, evaluate:

1. requirement fit
2. primary-source availability
3. current maintenance state
4. license
5. runtime compatibility
6. language compatibility
7. installation complexity
8. local vs SaaS deployment
9. network requirements
10. data egress
11. security implications
12. privacy implications
13. supply-chain implications
14. MCP/API/CLI interface
15. evaluation strategy
16. fallback/replacement strategy

Gate outcome is exactly one of: `ADOPT`, `EXPERIMENT`, `REJECT`, `SOURCE_NEEDED`, `BLOCKED`.

## Simplicity Gate

Use this preference order unless a requirement proves a more complex option necessary:

`native capability -> existing platform capability -> simple deterministic script -> small dependency -> framework -> external service`

Framework breadth, popularity, ecosystem size, stars, or marketing claims are not positive evidence of fit. At equal requirement coverage, prefer lower operational surface and easier replacement.

## Adoption states

`DISCOVERED`, `PRIMARY_SOURCE_PENDING`, `VERIFIED_CANDIDATE`, `EXPERIMENTAL`, `ADOPTED`, `REJECTED`, `STALE`, `BLOCKED`.

`ADOPTED` requires a passed Technology Selection Gate and no unresolved contradiction on a material requirement. `EXPERIMENTAL` requires an explicit bounded evaluation plan and may not be presented as a proven production dependency.

## Contradiction handling

If an official README and current API/source/test evidence conflict, create a `CONTRADICTION` node. Prefer evidence closest to actual current behavior for runtime claims. Do not adopt until the contradiction is resolved or the disputed feature is removed from the requirement.

## Lifecycle enforcement

Treat the adoption state as a transition history, not just a label. Use `references/capability-lifecycle.md` and `scripts/validate_capability_lifecycle.py` when external capabilities are evaluated. Direct `DISCOVERED -> ADOPTED` is invalid. `ADOPTED` requires qualifying primary evidence and all existing fit/security/privacy/license/runtime gates.

