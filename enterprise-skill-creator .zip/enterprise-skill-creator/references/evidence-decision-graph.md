# Skill Architecture Decision Graph

## Purpose

Use a typed evidence/decision graph when capability selection or architecture contains multiple claims, constraints, alternatives, contradictions, or verification steps. The pattern is inspired by dependency-graph reasoning systems, but model confidence is not evidence.

## Node types

`REQUIREMENT`, `CONSTRAINT`, `FACT`, `ASSUMPTION`, `CAPABILITY_CANDIDATE`, `EVIDENCE`, `RISK`, `CONTRADICTION`, `DECISION`, `REJECTED_OPTION`, `VALIDATION_RESULT`.

## Edge types

`REQUIRES`, `SUPPORTS`, `CONTRADICTS`, `VERIFIED_BY`, `SELECTED_BECAUSE`, `REJECTED_BECAUSE`, `DEPENDS_ON`, `INVALIDATED_BY`.

## Hard separation

Maintain separate fields for:

- `source_quality`
- `evidence_strength`
- `verification_status`
- `contradiction_status`

Do not use averaged or self-declared LLM confidence to satisfy any of these fields. `model_confidence` should normally be omitted; if retained for research, it has no authority in hard architecture gates.

## Decision requirements

An `ADOPT` decision must trace back to at least one requirement and at least one primary-source evidence node for every material external capability claim. A `REJECT` decision should preserve the rejected option and the reason so later builds do not rediscover the same dead end without new evidence.

Validate graph shape with `scripts/validate_capability_decisions.py` and `schemas/architecture-decision-graph.schema.json`.
