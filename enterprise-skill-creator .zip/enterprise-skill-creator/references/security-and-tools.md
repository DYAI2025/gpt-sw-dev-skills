# Security and Tool Policy

## General rule

Enterprise skills must use least privilege, explicit scope and conservative defaults. No skill may imply that a client-side field such as `allowed-tools` is a complete security boundary unless this is verified for the target runtime.

## Prohibited defaults

Do not include:

- secrets, credentials, tokens or private keys
- destructive shell commands as defaults
- `git push --force`, `--no-verify`, broad delete commands or direct commits to protected branches
- hidden scraping, auth bypass, captcha bypass or circumvention of access controls
- unbounded batch execution without rate, retry and stop conditions

## Tool and script gates

Every script must document:

- purpose
- inputs
- outputs
- failure behavior
- whether it reads or writes files
- whether it calls network or external APIs
- whether it can affect third parties

## MCP/API gates

For MCP, API or connector skills document:

- authentication model
- consent requirement
- data classification
- rate-limit expectations if known
- logging or audit expectations
- write/destructive boundaries
- read-only evaluation mode

## Browser-Act gates

Browser capabilities are allowed only when:

- the user can see or is permitted to operate the relevant data or action
- no authentication bypass is required
- ToS/legal/data-classification risks are marked
- operations have a dry-run or explicit approval path when side effects are possible

## External capability security gate

For every serious external capability candidate classify network requirement, data egress, external processing, credential/auth model, local-vs-SaaS deployment, supply-chain surface, update/install mechanism, and replacement path. Attractive functionality does not override privacy or security boundaries. If data egress or external processing is unclear, outcome is `SOURCE_NEEDED` or `BLOCKED`, not silent adoption.

Security rule: no silent adoption of a capability with unresolved data egress, external processing, credential, or supply-chain implications.

## Reliability trace and telemetry data minimization

Pipeline ledger and native telemetry artifacts must not store full prompts, document bodies, credentials, secrets, API keys, private keys, full tool argument bodies or model responses. Prefer IDs, hashes, timestamps, status codes, counts and redacted pointers. A trace proves recorded process state only; it is not a security or correctness guarantee.

