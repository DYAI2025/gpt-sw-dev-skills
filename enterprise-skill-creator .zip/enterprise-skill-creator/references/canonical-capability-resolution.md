# Canonical Capability Resolver

## Purpose

The Canonical Capability Resolver converts discovery candidates into provenance-preserving normalized records. It generalizes the architecture pattern used by canonical-document systems: authoritative sources -> source adapters -> parsers/normalizers -> normalized records -> searchable local representation -> small deterministic query interface.

This package adopts the pattern, not the Web3 domain content and not the `web3-docs` runtime as a dependency.

## Authority pipeline

1. **Source adapter** identifies an official source and captures immutable or versioned pointers where possible.
2. **Parser/normalizer** extracts only fields required by the Capability Record.
3. **Normalized record** retains provenance per claim.
4. **Local representation** may be JSON/JSONL/SQLite or another deterministic store; semantic search is optional navigation only.
5. **Query interface** returns records plus source pointers and verification status; it must not synthesize missing evidence.

## Supported source types

- official Git repository and tagged release
- official documentation
- official API/OpenAPI/AsyncAPI/GraphQL/MCP specification
- official package registry metadata such as PyPI/npm/crates when attributable to the project
- release notes/changelog
- standards/specifications
- manufacturer/vendor documentation

## Provenance minimum

For every material claim capture when available:

- source location
- source type
- source role/trust class
- version/tag
- commit or immutable digest
- verified/retrieved time
- relevant pointer (file, section, line, endpoint, schema path)
- evidence strength
- contradiction status

Unavailable dynamic metadata is `MISSING` or `SOURCE_NEEDED`; never guessed.

## Canon is not semantic search

Semantic search can locate relevant text. Canon determines which source is authoritative for a claim. Retrieval ranking must not raise a source's authority class.

## Source-laundering block

The following chain is invalid for verification:

`curated list -> blog -> LLM summary -> verified claim`

Discovery must return to primary sources. A README can support project-stated capability, but runtime-sensitive or security-sensitive claims may require code, tests, release artifacts, or direct execution evidence.

## Executable evidence integration

When capability evidence is material, use `references/canonical-evidence-registry.md`, `schemas/evidence-record.schema.json` and `scripts/evidence_registry.py`. The registry operationalizes provenance while preserving the rule that retrieval relevance cannot promote authority or verification.

For this package, `reports/canonical-evidence-records.jsonl` is the inspected evidence set used by the lifecycle/reliability validators.

