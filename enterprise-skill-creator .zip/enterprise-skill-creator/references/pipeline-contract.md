# Enterprise Skill Creator Pipeline Contract

## Pipeline overview

```text
Intake
-> Research-Bag Preparation
-> Capability Discovery / Canon / Lifecycle when needed
-> Pre-Build Architecture Gate
-> Draft Build
-> Draft Freeze + Build Trace
-> Release Hook
-> Enterprise Skill Output Evaluator
-> Deterministic Validation
-> Package Authorization
-> Packaging
```

The build trace proves process state only. Source truth, substantive quality and runtime effectiveness remain separate gates.

## Phase 0 - Intake

Capture goal, teams/users, target runtime, required outputs, forbidden behavior, data sensitivity, tools/integrations, success criteria and `CAPABILITY_DISCOVERY_NEEDED`.

Block or mark `MISSING` when goal, Definition of Done or security boundary is absent.

Record `INTAKE_COMPLETED` when deterministic trace execution is available.

## Phase 1 - Research-Bag Preparation

Produce the Research-Bag defined in `references/research-bag-contract.md`. No hard rule may come from Confidence 1-2 or unresolved `SOURCE_NEEDED`.

Record `RESEARCH_COMPLETED` only after the Research-Bag gate is satisfied.

## Phase 2 - Capability Discovery, Canon and Lifecycle

If capability discovery is needed:

1. discover candidates through `references/capability-radar.md`;
2. normalize serious candidates into Capability Records;
3. create claim-level evidence records using `references/canonical-evidence-registry.md`;
4. record capability state transitions using `references/capability-lifecycle.md`;
5. run the Technology Selection Gate;
6. preserve rejected/stale candidates and reasons.

If no technical capability is needed, record `CAPABILITY_DECISION_SKIPPED` with a reason. Otherwise record `CAPABILITY_DECISION_COMPLETED` after selection/rejection decisions are evidence-linked.

Browser-Act remains conditional and follows `references/browser-act-capability-contract.md`.

## Phase 3 - Pre-Build Architecture Gate

Return:

```yaml
ultrathink_gate:
  status: PASS | PASS_WITH_ASSUMPTIONS | BLOCKED_SOURCE_NEEDED | BLOCKED_SECURITY | BLOCKED_SCOPE
  selected_architecture: string
  strongest_counterargument: string
  failure_mode_chain: string
  bias_flags: [string]
  required_revision: [string]
  build_decision: proceed | revise_research | reduce_scope | stop
```

No draft build without `PASS` or `PASS_WITH_ASSUMPTIONS`. Record `ARCHITECTURE_GATE_PASSED` only when this gate permits build.

## Phase 4 - Draft Build

Create the full skill directory according to `references/output-contract.md`. Keep SKILL.md as the control plane; place detailed rules in references and deterministic behavior in scripts.

## Phase 4a - Draft Freeze and Reliability Trace

When code/file execution is available:

1. compute the build-controlled artifact digest with `scripts/pipeline_ledger.py digest`;
2. record `DRAFT_FROZEN` with that digest;
3. do not treat later gate results from a different digest as valid;
4. if the draft changes materially, record/reconstruct a new freeze cycle rather than reusing old gate evidence.

If deterministic trace execution is unavailable, mark `TRACE_RUNTIME_UNAVAILABLE`; do not fabricate a cryptographic trace or package authorization.

## Phase 5 - Release Hook

Run Craftsmanship, Anti-Confabulation, Anti-Sycophancy and Bias gates. The release report must also summarize Reliability Integrity when the deterministic mechanisms apply.

Record `RELEASE_GATE_PASSED` against the frozen artifact digest only after the Release Hook passes.

## Phase 6 - Enterprise Skill Output Evaluator

Evaluate the Skill-Creator output using `references/enterprise-skill-output-evaluator.md`. `BLOCKED`, `REBUILD` or `REVISE` prevents package authorization.

Record `EVALUATOR_PASSED` only for a PASS decision against the frozen digest.

## Phase 7 - Deterministic Validation

Run applicable validators, including reliability validators when the package contains the corresponding components. A validator failure is not repair authority by itself; resolve scope/applicability before changing the target.

Record `VALIDATION_PASSED` only when all applicable hard validators pass against the frozen digest.

## Phase 8 - Package Authorization and Packaging

Rebuild the pipeline state from the event ledger. Authorize packaging only if:

- required pre-draft stages exist;
- event hash chain is valid;
- latest draft digest matches current build-controlled artifact digest;
- release, evaluator and validation pass events occur in order on that digest;
- no hard reliability/release blocker remains.

Then record `PACKAGE_AUTHORIZED`, replay/validate state, and run the package script. The package script still re-runs validators; the event ledger does not replace validation.
