# Research-Bag Contract

The Research-Bag prepares skill-building input. It does not replace the Enterprise Skill Creator and does not by itself authorize final packaging.

## Required output

```yaml
research_bag_output:
  capability_discovery_needed: yes | no
  source_inventory:
    - source_id: S001
      title: string
      type: primary | secondary | user_provided | derived | uncertain
      location: string
      purpose: string
      reliability: string
      limitations: string
      confidence_default: 1-5
      recommended_use: rule | context | inspiration | blocked
  knowledge_model:
    core_terms:
      - term: string
        definition: string
        confidence: 1-5
    operational_rules:
      - rule: string
        source_ids: [string]
        confidence: 1-5
    assumptions:
      - assumption: string
        reason: string
    missing:
      - item: string
        blocking: true | false
    source_needed:
      - claim: string
        required_source_type: primary | secondary
  capability_candidates:
    - id: C001
      type: knowledge | method | rule | workflow | script | api | mcp | browser_act | eval | validator
      description: string
      evidence: [string]
      recommended_destination: SKILL.md | references | scripts | evals | browser_capabilities
      confidence: 1-5
  browser_act_candidates:
    - id: B001
      target_site: string
      capability_type: extraction | operation
      goal: string
      permission_boundary: visible_to_user | user_permitted | requires_login | prohibited
      needs_browser_forge: true | false
  eval_requirements:
    trigger_evals_required: true | false
    output_evals_required: true | false
    mcp_evals_required: true | false
    browser_capability_tests_required: true | false
  build_recommendation:
    status: proceed | proceed_with_assumptions | research_more | browser_forge_required | blocked
    reason: string
```

## Blocking rules

- `build_recommendation.status = blocked` stops the pipeline.
- `source_needed` items may not become hard instructions.
- `confidence < 4` may not support non-negotiable enterprise rules.
- `browser_act_candidates` with `permission_boundary = prohibited` stop Browser-Act capability generation.

## Technical capability escalation

When `capability_discovery_needed = yes`, generic capability candidates are discovery inputs only. Normalize serious external candidates with the Capability Record, verify them via Canonical Capability Resolver, and route adoption through the Technology Selection Gate and Decision Graph. When `no`, do not run the Radar merely to make the skill look more sophisticated.
