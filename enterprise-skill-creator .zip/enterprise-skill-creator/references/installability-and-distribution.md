# Installability and Distribution Policy

## Purpose

This policy makes generated skills maximally install-ready for ChatGPT-style skill surfaces while avoiding false claims about UI behavior that the skill package cannot control.

## Hard distinction

A skill package can control:

- the presence of `SKILL.md`;
- valid YAML frontmatter with `name` and `description`;
- `agents/openai.yaml` metadata;
- supporting `references/`, `scripts/`, `evals/`, `assets/`, and `reports/`;
- deterministic validators;
- the final distributable file name `skill.zip`;
- a direct chat artifact link to `skill.zip`.

A skill package cannot control:

- whether a ChatGPT client renders a "Jetzt installieren" or equivalent button;
- whether a workspace permits skill installation;
- whether a plan, region, admin policy, enterprise setting, experiment flag, or client version exposes installation;
- whether a third-party platform accepts the package.

## Required output for generated skills

When the user expects an installable skill, the Enterprise Skill Creator must return a packaged archive named exactly:

```text
skill.zip
```

It must also create `reports/installability-report.json` in the generated skill with this shape:

```json
{
  "artifact_name": "skill.zip",
  "chatgpt_install_ready": true,
  "frontend_install_suggestion_status": "prepared",
  "not_controlled_by_skill": [
    "client ui rendering",
    "workspace installation permissions",
    "plan or feature availability"
  ],
  "blocking_issues": [],
  "user_action": "Use the ChatGPT install prompt if shown; otherwise upload or import skill.zip through the available skill management surface."
}
```

## Allowed statuses

`frontend_install_suggestion_status` may only be:

- `prepared`: package is shaped for installability and linked in chat;
- `blocked`: package failed validation or exceeds constraints;
- `not_controlled_by_skill`: the request asks the skill to guarantee a UI behavior it cannot control.

Do not use `guaranteed`.

## skillpunkt.de / SKILL.md interpretation

If the user says "Skillpunkt.de" in a skill-packaging context, interpret it as `SKILL.md` unless the user explicitly means a domain or publishing platform. If a domain or external platform is meant, mark platform behavior as `SOURCE_NEEDED` until API, upload, authentication, review, and permission requirements are inspected.
