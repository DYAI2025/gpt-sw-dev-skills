# Capability Parity and Core Preservation Policy

## Purpose

This policy prevents feature additions from changing the core behavior of an existing skill without explicit disclosure.

## Core functionality that must remain unchanged in this Enterprise Skill Creator update

The following core functions are preserved:

1. Intake and scope capture.
2. Research-Bag Preparation.
3. Capability Discovery.
4. Browser-Act branch with permission boundary.
5. Pre-Build Architecture Gate.
6. Draft Build with progressive disclosure.
7. Release Hook with craftsmanship, anti-confabulation, anti-sycophancy, and bias gates.
8. Enterprise Skill Output Evaluator XML behavior.
9. Deterministic validation, evals, and packaging.
10. Source-policy discipline: `user_provided`, `MISSING`, `SOURCE_NEEDED`, and confidence scoring.

## Minimal additions in this update

Only bounded additions that preserve the existing pipeline are allowed. Existing installability/portability additions remain. This self-upgrade additionally allows:

1. Installability Gate for `skill.zip` packaging and ChatGPT install-readiness reporting.
2. Explicit statement that frontend install buttons are not controlled by the skill package.
3. Agent-agnostic/Claude-compatible handoff guidance with runtime limitations.
4. Core-functionality preservation report.
5. Validators for installability, agent-agnostic report presence, and core parity.

## Blockers

Block packaging if:

- existing core phases are removed or renamed without explicit migration note;
- the skill claims to guarantee a ChatGPT frontend install button;
- Claude or frontier-model compatibility is claimed without limitations;
- `skill.zip` is not the primary installable artifact when installability is requested;
- new compatibility claims override source, security, or release-gate rules.

6. Optional Capability Radar with explicit no-radar path.
7. Canonical Capability Resolver pattern with primary-source provenance.
8. Skill Architecture Decision Graph separating evidence from model confidence.
9. Optional telemetry adapter contract with no truth authority and no mandatory runtime dependency.
10. Capability schemas, validators, ten focused evals, and a one-pass self-upgrade regression report.

These additions do not replace Research-Bag, Browser-Act, Release Hook, Output Evaluator, installability, agent-agnostic handoff, or existing validators.

## Self-improvement safety

For self-updates of Enterprise Skill Creator, retain a baseline copy through the final Release Gate, perform exactly one single-pass upgrade, and prohibit recursive self-improvement. Do not change the source and its evaluator in the same pass without an old-vs-new comparison. A new version may not justify itself solely through its own evaluation.
