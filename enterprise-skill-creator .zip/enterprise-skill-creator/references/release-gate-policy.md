# Release-Gate Policy

Every generated enterprise skill draft must pass the applicable release gates before final packaging or delivery.

## Craftsmanship Gate

Check scope coherence, responsibility separation, Progressive Disclosure, trigger quality, strongest counterargument, failure-mode chain and smallest robust slice.

Valid status: `PASS` or a blocking architecture/overengineering/scope/failure-mode status.

## Anti-Confabulation Gate

Inspect external/current/quantitative/comparative/legal/medical/financial/API/MCP/tool/security claims. Use supported/inferable/unverified/do-not-claim discipline. Unverified hard claims block packaging.

## Anti-Sycophancy Gate

Score 0-5. Score >= 3 blocks packaging and requires rebuild/deep revision.

## Bias Gate

Check confirmation bias, overconfidence, tool bias, authority bias, cultural bias and user-thesis laundering. `BLOCKED` prevents packaging.

## Reliability Integrity Gate

This gate strengthens process integrity but never substitutes for source truth or substantive evaluation.

When deterministic file/code execution is available and the package uses the reliability components, require:

- `pipeline_trace_status: PASS` — hash chain, stage order and current artifact digest are valid;
- `evidence_registry_status: PASS | NOT_APPLICABLE` — provenance records validate when external technical capability claims drive architecture;
- `capability_lifecycle_status: PASS | NOT_APPLICABLE` — no unsupported state jumps/adoption;
- `telemetry_status: PASS | NOT_EMITTED` — any emitted telemetry is reproducible, aggregate-only and `truth_authority:false`;
- `reliability_evals_status: PASS` — deterministic positive/negative reliability cases pass;
- `core_regression_status: PASS` — legacy core package checks still pass.

`RUNTIME_UNAVAILABLE` is acceptable for advisory/non-packaged work only. It is not equivalent to PASS and cannot justify deterministic package authorization.

## Stop rule

Stop packaging if any condition is true:

- release status is not PASS;
- package permission is false;
- Craftsmanship or Anti-Confabulation is not PASS;
- Anti-Sycophancy score >= threshold;
- Bias Gate is BLOCKED;
- blocked claims are non-empty;
- an applicable Reliability Integrity hard check is not PASS;
- current build-controlled artifact digest no longer matches the frozen draft used by downstream gate events.

## Required report fields

`reports/release-gate-report.json` must retain the existing gate sections and add `reliability_gate` for packages using this upgraded reliability architecture.
