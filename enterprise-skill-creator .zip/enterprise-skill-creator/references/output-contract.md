# Enterprise Skill Output Contract

## Required package shape

```text
<skill-name>/
├── SKILL.md
├── agents/
│   └── openai.yaml
├── references/
├── scripts/
├── evals/
├── reports/
└── schemas/        # when deterministic structured contracts are used
```

## SKILL.md frontmatter

Use only `name` and `description` unless a target runtime explicitly supports more fields.

```yaml
---
name: lower-case-hyphen-name
description: trigger-rich lowercase description without angle brackets
---
```

Rules:

- `name` matches the folder name and `^[a-z0-9]+(?:-[a-z0-9]+)*$`.
- `description` explains what the Skill does and when to use it.
- Do not put undocumented platform claims into frontmatter.

## Progressive Disclosure

SKILL.md is the control plane. Use references for long policies, source maps, security rules, eval design, browser/MCP/API details, reliability contracts and edge cases. Use scripts for deterministic checks and repeatable utilities.

## Reliability artifacts

For packaged enterprise builds when deterministic file/code execution is available, produce a build trace and state using the Pipeline Ledger contract. Do not claim package authorization from prose alone.

When external technical capabilities materially influence architecture, also produce/maintain:

- claim-level evidence records or equivalent provenance linked to capability decisions;
- lifecycle transitions for external capability adoption/rejection/staleness;
- deterministic checks that prevent unsupported direct adoption.

Telemetry is optional. If emitted, it must use `truth_authority: false` and aggregate/redacted metadata only.

If the runtime cannot execute deterministic trace/index checks, mark the limitation explicitly and do not fabricate PASS output.

## Chat response format when returning a skill

1. Executive summary
2. FILETREE
3. All files when the user explicitly needs inline source, otherwise the complete packaged artifact plus a concise change summary
4. Validation commands/results
5. Eval plan/results
6. Release-gate summary
7. Reliability / provenance summary when applicable
8. Installability / agent-agnostic summary
9. Packaging command/result
10. MISSING / SOURCE_NEEDED / ASSUMPTIONS
