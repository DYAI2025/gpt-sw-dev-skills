# Source Map

This source map records the sources used to design the Enterprise Skill Creator. It is a project reference, not proof that external platforms behave as described today.

## S001 - User-provided Enterprise Skill Creator system instruction
- type: `user_provided`
- location: conversation upload / system_instruction
- purpose: Normative architecture for Enterprise Skill Creator pipeline.
- reliability: Strong as user requirement; external standards inside it remain user-provided unless separately verified.
- limitations: Does not itself prove current platform behavior.
- use_in_skill: Defines pipeline phases, release gates, evaluator dimensions and output expectations.
- confidence_default: 4 for internal process requirements; 2 for external platform claims.

## S002 - Research-Backed Skill Builder project skill
- type: `user_provided`
- location: project skill instructions
- purpose: Source inventory, confidence scoring, SOURCE_NEEDED/MISSING discipline and post-generation audit.
- reliability: Strong as internal project method.
- limitations: Does not replace external primary-source verification.
- use_in_skill: Phase 1 Research-Bag Preparation.
- confidence_default: 4.

## S003 - Browser-Act Skill Forge project skill
- type: `user_provided`
- location: project skill instructions and uploaded reference files
- purpose: Website functionality exploration, API-first discovery, DOM fallback, scripts and reusable browser-capability skills.
- reliability: Strong as internal capability-forge method.
- limitations: Requires browser-act availability, permission boundaries and site-specific verification.
- use_in_skill: Conditional Browser-Act branch.
- confidence_default: 4 for internal method; 2 for any target-site behavior until verified.

## S004 - Ultrathink Craftsmanship and Anti-Confabulation references
- type: `user_provided`
- location: project skill instructions and uploaded references
- purpose: Architecture gate, failure-mode analysis, anti-confabulation claim labels and post-draft release hook.
- reliability: Strong as internal quality policy.
- limitations: Does not verify external claims by itself.
- use_in_skill: Pre-build and release-gate checks.
- confidence_default: 4.

## S005 - Universal Bias Self Check / Metacognitive Bias Guardian
- type: `user_provided`
- location: project references
- purpose: Bias, hallucination, sycophancy and overconfidence review.
- reliability: Strong as internal quality policy.
- limitations: Requires evidence; cannot transform unsupported claims into facts.
- use_in_skill: Bias gate and Anti-Sycophancy score.
- confidence_default: 4.

## S006 - Enterprise Skill Output Evaluator instruction
- type: `user_provided`
- location: current user message
- purpose: Defines evaluator identity, dimensions, XML output and decision values.
- reliability: Strong as user-provided evaluator contract.
- limitations: Evaluator scores are judgment outputs unless backed by inspected files and validator results.
- use_in_skill: `references/enterprise-skill-output-evaluator.md` and `assets/enterprise-skill-output-evaluator-system-instruction.xml`.
- confidence_default: 4.

## S007 - Skill Creator packaging instruction
- type: `user_provided`
- location: loaded skill instructions `skills://skill-creator/skill.md`
- purpose: Defines skill package shape, `SKILL.md`, `agents/openai.yaml`, progressive loading, and mandatory `skill.zip` packaging behavior for ChatGPT skill installation flows.
- reliability: Strong as internal skill-creation workflow guidance; not proof that every ChatGPT client will render an install button.
- limitations: UI rendering, workspace permissions, plan availability, and frontend experiments are outside package control.
- use_in_skill: Installability Gate, package naming rule, and no-false-UI-guarantee rule.
- confidence_default: 4 for package generation behavior; 2 for frontend UI behavior.

## S008 - User request for installability and agent-agnostic compatibility
- type: `user_provided`
- location: current conversation request
- purpose: Adds requirement that generated skills should be prepared for ChatGPT install suggestions, `SKILL.md`-based skill packaging, and Claude/frontier-model compatibility while preserving prior core behavior.
- reliability: Strong as product requirement; unsupported platform behavior remains unverified.
- limitations: Does not prove OpenAI or third-party platform APIs allow forcing an install suggestion.
- use_in_skill: Capability parity report, installability policy, and agent-agnostic compatibility policy.
- confidence_default: 4 for requirement; 2 for platform-side behavior.

## S009 - Cross-framework skill portability research
- type: `secondary`
- location: public research search result, SkCC paper metadata
- purpose: Supports the architectural principle that cross-framework skill portability benefits from separating skill semantics from platform-specific formatting and security analysis.
- reliability: Secondary research context from public paper metadata; not an implementation standard for this skill.
- limitations: Not an official OpenAI or Anthropic compatibility guarantee; do not convert results into hard platform claims.
- use_in_skill: Background rationale for agent-agnostic compatibility design.
- confidence_default: 3.


## S010 - Self-upgrade mission for capability discovery
- type: `user_provided`
- location: current conversation attachment `Eingefügter Text.txt`
- purpose: Defines this single-pass self-improvement scope, required capability model, Canon, Decision Graph, telemetry boundary, evals, and release rule.
- reliability: Strong as project requirement; referenced external repositories still require independent verification.
- limitations: Does not itself prove current repository behavior.
- use_in_skill: Capability Radar, Canonical Capability Resolver, Decision Graph, telemetry contract, regression gate.
- confidence_default: 4 for requirements; 2 for external claims before verification.

## S011 - KalyanKS-NLP/llm-engineer-toolkit
- type: `secondary`
- source_role: `secondary_discovery_source`
- location: official GitHub repository `KalyanKS-NLP/llm-engineer-toolkit`, verified 2026-08-16
- purpose: Seed categories and candidate names for Capability Radar.
- reliability: Useful curated discovery inventory; repository describes itself as a curated list of 120+ LLM libraries.
- limitations: A listing does not verify project claims, current maintenance, security, license, compatibility, or architectural fit.
- use_in_skill: Discovery only; never direct adoption evidence.
- confidence_default: 3 for candidate existence/category; 1 for downstream technology claims.

## S012 - dioptx/web3-docs
- type: `primary`
- source_role: `architecture_reference`
- location: official project repository/package metadata; PyPI release 0.2.1 attests tag v0.2.1 at commit `337e322663947b820696d5c58efe70dec2fb0c44`, verified 2026-08-16
- purpose: Architecture pattern for authoritative upstream sources, local normalization/indexing, and deterministic resolution.
- reliability: Primary project source for its own architecture and release metadata.
- limitations: Web3 data/content is out of scope and the package is not adopted as a runtime dependency.
- use_in_skill: Canonical Capability Resolver pattern only.
- confidence_default: 5 for observed project architecture/release metadata; 3 for generalized design inference.

## S013 - dioptx/mcp-atom-of-thoughts
- type: `primary`
- source_role: `architecture_reference`
- location: official GitHub repository, verified 2026-08-16
- purpose: Typed-node dependency graph and decomposition pattern.
- reliability: Primary project source for its own graph/tool design.
- limitations: Its model-confidence and conclusion-termination logic is explicitly not adopted as evidence logic.
- use_in_skill: Decision Graph structure only.
- confidence_default: 5 for observed graph pattern; 3 for generalized design inference.

## S014 - dioptx/cctime
- type: `primary`
- source_role: `architecture_reference`
- location: official GitHub repository, verified 2026-08-16
- purpose: Execution telemetry concepts: session duration, tool/subagent phases, token/cost estimates, JSON exports.
- reliability: Primary project source for its own stated behavior.
- limitations: Claude Code JSONL oriented; no claim of truth/correctness; latest release/version not established in this audit.
- use_in_skill: Optional telemetry adapter design only; no dependency.
- confidence_default: 4 for documented telemetry features; 2 for unverified runtime/version details.

## S015 - luoyuctl/agenttrace
- type: `primary`
- source_role: `capability_candidate`
- location: official GitHub repository, verified 2026-08-16
- purpose: Comparison candidate for local-first multi-agent execution telemetry.
- reliability: Primary project source for its own supported log formats and privacy/estimate boundaries.
- limitations: Not installed or adopted; release/version suitability must be reverified at actual use time.
- use_in_skill: Telemetry comparison example only.
- confidence_default: 4 for documented feature scope; 2 for deployment suitability until project-specific verification.

## S016 - Uploaded Weft snapshot
- type: `user_provided`
- source_role: `architecture_reference`
- location: `weft-main.zip` supplied in the conversation and locally extracted for analysis
- purpose: Event-sourcing, workflow state transition, projection/replay and guard patterns.
- reliability: Source-inspected snapshot; 103 selected core tests passed locally in this upgrade analysis.
- limitations: Local snapshot/test evidence only; Claude-specific hooks are not treated as portable ChatGPT capabilities.
- use_in_skill: Hash-chained Pipeline Ledger architecture pattern, independently reimplemented with Python standard library.
- confidence_default: 4 for observed snapshot behavior; 3 for generalized architecture inference.

## S017 - Uploaded Canon Resolver snapshot
- type: `user_provided`
- source_role: `architecture_reference`
- location: `canon-resolver(1).zip` supplied in the conversation and locally extracted for analysis
- purpose: Canonical/reference separation, normalized evidence records, provenance and resolution patterns.
- reliability: Source-inspected snapshot; 10 selected resolver/manifest/provider tests passed locally.
- limitations: No LICENSE file was present in the supplied snapshot; no direct code is copied into this skill.
- use_in_skill: Canonical Evidence Registry design only.
- confidence_default: 4 for observed snapshot behavior; 3 for generalized design inference.

## S018 - Uploaded LLM Technology Radar snapshot
- type: `user_provided`
- source_role: `architecture_reference`
- location: `dyai-llm-technology-radar(1).zip` supplied in the conversation and locally extracted for analysis
- purpose: Candidate record, non-compensatory gate and lifecycle discipline.
- reliability: Source-inspected snapshot; 14 candidate records passed its local validator and the index renderer ran successfully.
- limitations: No LICENSE file was present in the supplied snapshot; candidate ranking is not adoption evidence.
- use_in_skill: Explicit Capability Lifecycle transition gate, independently implemented.
- confidence_default: 4 for observed snapshot contracts; 3 for generalized design inference.

## S019 - Uploaded cctime snapshot
- type: `user_provided`
- source_role: `architecture_reference`
- location: `cctime-main.zip` supplied in the conversation and locally extracted for analysis
- purpose: Execution/session timing and rework/tool activity telemetry concepts.
- reliability: Source-inspected snapshot; analyzer/types compiled with locally available TypeScript 5.8.3.
- limitations: Full npm test suite was not run in this upgrade; pricing/model-cost logic is not adopted.
- use_in_skill: Native aggregate Build Telemetry derived from the skill's own pipeline ledger.
- confidence_default: 4 for inspected telemetry concepts; 2 for unverified runtime/provider details.

## S020 - Uploaded web3-docs snapshot
- type: `user_provided`
- source_role: `architecture_reference`
- location: `web3-docs-main.zip` supplied in the conversation and locally extracted for analysis
- purpose: Parser -> normalized record -> local index/query architecture and query-sanitization pattern.
- reliability: Source-inspected snapshot; 62 selected parser/DB/enrichment/polish tests passed locally.
- limitations: Web3 content and MCP runtime are out of scope; source authority must remain separate from retrieval rank.
- use_in_skill: Portable JSONL Evidence Registry and deterministic authority-preserving query behavior.
- confidence_default: 4 for observed snapshot behavior; 3 for generalized design inference.
