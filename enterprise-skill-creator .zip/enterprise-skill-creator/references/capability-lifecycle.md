# Capability Lifecycle and Non-Compensatory Adoption Gate

## Purpose

Make the existing Capability Radar adoption states auditable as explicit transitions. A high score, popularity signal, model preference or retrieval match cannot compensate for a missing verification stage.

## States

Use the existing states:

`DISCOVERED -> PRIMARY_SOURCE_PENDING -> VERIFIED_CANDIDATE -> EXPERIMENTAL -> ADOPTED`

Side states:

- `REJECTED`
- `STALE`
- `BLOCKED`

Not every capability must pass through `EXPERIMENTAL`; a deterministic/local capability with sufficient primary evidence may move from `VERIFIED_CANDIDATE` to `ADOPTED`. Direct `DISCOVERED -> ADOPTED` is prohibited.

## Evidence gates

### `VERIFIED_CANDIDATE`

Require at least one referenced evidence record that is:

- `source_type: primary`;
- verification status `SOURCE_INSPECTED`, `PRIMARY_VERIFIED`, or `RUNTIME_VERIFIED`;
- confidence at least 3.

### `ADOPTED`

Require at least one referenced evidence record that is:

- `source_type: primary`;
- verification status `PRIMARY_VERIFIED` or `RUNTIME_VERIFIED`;
- confidence at least 4.

These are necessary, not sufficient. Security, privacy, license, compatibility and requirement-fit gates still apply.

## Staleness

`ADOPTED -> STALE` is valid when a material source, version, runtime assumption or compatibility fact is no longer current enough. A stale capability cannot remain treated as adopted without a re-verification path.

## Transition record

Store transitions as JSONL with:

- `seq`;
- `capability_id`;
- `from`;
- `to`;
- `evidence_ids`;
- `reason`.

## Verification

Use:

```bash
python scripts/validate_capability_lifecycle.py <skill-dir>
```

The package sample/current transition evidence is `reports/capability-lifecycle-events.jsonl`.
