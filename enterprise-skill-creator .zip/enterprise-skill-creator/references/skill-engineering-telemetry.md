# Skill Engineering Telemetry

## Status

`NATIVE_AGGREGATE_AVAILABLE` for build-trace metadata; external telemetry providers remain optional comparison/adaptation candidates.

## Purpose boundary

Telemetry answers: **How was the build executed?** It does not answer: **Was the result correct?**

`truth_authority` is always `false`.

Telemetry can reveal operational signals such as repeated validation attempts, failed gates, re-freezes/rework and elapsed build time. These signals can support retrospective or process improvement, but cannot satisfy source verification, release truth, security correctness, regression correctness or evaluator scores.

## Native telemetry

Prefer the smallest solution: summarize the Enterprise Skill Creator's own pipeline ledger before adding an external telemetry dependency.

Use:

```bash
python scripts/summarize_build_telemetry.py <events.jsonl> <summary.json>
python scripts/validate_build_telemetry.py <skill-dir>
```

The summary contains only aggregate metadata:

```yaml
build_telemetry:
  run_id: string | null
  started_at: string | null
  ended_at: string | null
  duration_ms: integer | null
  event_count: integer
  stage_counts: object
  validation_attempts: integer
  gate_failures: integer
  rework_events: integer
  source_files: [local-file-name]
  truth_authority: false
  privacy_mode: aggregate_metadata_only
```

Do not infer hidden reasoning quality from these counts. Do not set a universal loop/rework threshold without empirical calibration.

## External provider boundary

`cctime`, `agenttrace`, or another provider may still be evaluated when the host has richer execution traces and a concrete need. Route every provider through Capability Radar, Canonical Evidence Registry, Capability Lifecycle and Technology Selection Gate.

Do not make npm/npx, Rust binaries, hosted telemetry or transcript readers mandatory for core Enterprise Skill Creator behavior.

## Privacy default

Never export full prompts, source documents, credentials, personal data, full tool argument bodies, model responses, secrets or private keys by default. Use IDs, counts, timestamps, reason codes and redacted pointers.

Dynamic model pricing/cost tables are not embedded as hard truth. If cost analysis is required, verify current provider pricing separately and mark estimates as estimates.
