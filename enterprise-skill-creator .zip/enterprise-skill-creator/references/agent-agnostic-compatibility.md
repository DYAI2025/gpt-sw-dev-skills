# Agent-Agnostic Compatibility Policy

## Purpose

Generated enterprise skills should preserve their core method across ChatGPT, Claude, Claude Code, Codex-like agents, Cursor, Windsurf, and similar frontier-model workflows when this is requested or beneficial.

## Compatibility definition

Agent-agnostic compatibility means:

- the workflow is expressed in portable natural-language instructions;
- core invariants are separated from platform-specific execution;
- tool assumptions are explicit;
- scripts are deterministic and runnable outside a single chat client when possible;
- outputs use stable file names and schemas;
- unsupported runtime behavior is marked as `MISSING` or `SOURCE_NEEDED`.

It does not mean:

- identical tool availability;
- identical filesystem access;
- identical browser, connector, or code execution capabilities;
- identical UI install surfaces;
- identical safety, memory, or context-window behavior.

## Required generated files when cross-agent support is requested

For generated enterprise skills, include at least one of:

- `references/agent-agnostic-compatibility.md` for policy and runtime notes;
- `agents/claude.md` for Claude-oriented handoff instructions;
- `agents/frontier-model-handoff.md` for generic frontier-model use;
- `reports/agent-compatibility-report.json` for machine-readable compatibility status.

## Required report shape

```json
{
  "agent_agnostic_ready": true,
  "tested_runtimes": [],
  "portable_components": ["SKILL.md", "references", "scripts", "evals"],
  "runtime_specific_components": ["agents/openai.yaml"],
  "not_guaranteed": ["tool availability", "frontend install UI", "connector permissions"],
  "claude_notes": "Use SKILL.md as the primary instruction document; load references only when relevant; run scripts in a local shell if available."
}
```

## Cross-model phrasing rule

Write "Claude-compatible handoff" or "frontier-model portable workflow" only when the generated package includes clear runtime limitations. Do not write "fully identical behavior across models" unless the same task has been evaluated in those runtimes.
