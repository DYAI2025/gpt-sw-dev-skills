# Source Policy

## Purpose

Use this policy whenever a skill is built from documents, images, notes, web research, standards, APIs, repositories, tools, MCP servers, browser capabilities, or mixed evidence. The policy prevents source laundering: user-provided or model-derived material must not be silently upgraded into factual authority.

## Source classes

| Class | Definition | Allowed use |
|---|---|---|
| `primary` | Official standard, specification, product documentation, original dataset, source repository, legal/regulatory text | May define operational rules if current enough |
| `secondary` | Expert explanation, textbook, reputable article, curated teaching material | Context and interpretation; do not override primary sources |
| `user_provided` | Files, notes, PDFs, screenshots, tables, internal rules or claims supplied by the user | Project context; verify before factual hardening |
| `derived` | OCR, summaries, mindmaps, model-generated extraction, transformed data | Navigation only; check against originals |
| `uncertain` | Unattributed, contradictory, incomplete, or unverifiable material | Do not convert into rules without `SOURCE_NEEDED` |


## Discovery source role

A `secondary_discovery_source` is a role applied to a source whose purpose is candidate discovery rather than verification. Store its base `type` as `secondary` and `source_role: secondary_discovery_source` when a schema only supports the existing source classes. It may suggest names/categories but may not support a hard technology claim without primary-source follow-up.

Authority and retrieval are separate: semantic similarity, popularity, stars, README prominence, and model confidence do not raise evidence authority.

## Required source map fields

```yaml
source_id:
  title: string
  type: primary | secondary | user_provided | derived | uncertain
  location: string
  purpose: string
  reliability: string
  limitations: string
  use_in_skill: string
  confidence_default: 1-5
```

## MISSING and SOURCE_NEEDED

Use `MISSING` when required information is absent.
Use `SOURCE_NEEDED` when information exists but is not adequately supported by reliable evidence.

Never invent:

- standards or version numbers
- API parameters or endpoint behavior
- legal, medical, financial or safety rules
- security guarantees
- market metrics or demand estimates
- tool or MCP capabilities

## Confidence scale

| Score | Meaning | Allowed usage |
|---:|---|---|
| 5 | Directly supported by primary source and current enough | Hard rule or requirement |
| 4 | Supported by strong source or convergent evidence | Recommendation or rule with evidence |
| 3 | Plausible but indirect or incomplete evidence | Assumption only |
| 2 | Weak, conflicting, old, or context-specific evidence | Do not operationalize without warning |
| 1 | Unsupported, speculative, or contradicted | Block or mark SOURCE_NEEDED |

## Claim discipline

Split outputs into:

1. `fact`: source-backed statement.
2. `inference`: explicit reasoning from facts.
3. `recommendation`: design or workflow choice based on goal and constraints.

A recommendation may be useful without being a fact, but it must not pretend to be one.

## Current-information rule

If a claim can change over time, use web or connector search where available. If search is unavailable, mark dynamic claims as `SOURCE_NEEDED`.
