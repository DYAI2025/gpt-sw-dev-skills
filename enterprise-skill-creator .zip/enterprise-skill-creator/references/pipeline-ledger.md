# Deterministic Build Pipeline Ledger

## Purpose

Use the pipeline ledger to prove **process state**, not substantive correctness. It adapts the useful event-sourcing/replay pattern from the inspected Weft snapshot into a host-neutral, standard-library-only build trace.

The ledger answers:

- which required build stages were recorded;
- in what order they occurred;
- whether the trace was modified after the fact;
- whether release/evaluation/validation results apply to the same frozen draft;
- whether packaging was actually authorized.

It does **not** prove that sources are true, requirements are correct, tests are sufficient, or model reasoning is correct.

## Event model

Use `scripts/pipeline_ledger.py` and `schemas/pipeline-event.schema.json`.

Every event contains:

- monotonic `seq`;
- `run_id`;
- `event_type`;
- timestamp;
- optional `artifact_digest`;
- evidence IDs when relevant;
- minimal non-sensitive `data`;
- `prev_hash` and `event_hash`.

The event hash uses canonical JSON and SHA-256. A malformed line, sequence gap, previous-hash mismatch or event-hash mismatch is a hard validation failure. Do not silently skip corrupt events.

## Privacy boundary

Never place prompts, document bodies, credentials, secrets, API keys, full tool arguments, model responses or private keys into ledger `data`. The native append function rejects common raw-content key names.

Prefer IDs, statuses, reason codes, counts and redacted pointers.

## Build-stage contract

Before draft freeze, require:

1. `INTAKE_COMPLETED`
2. `RESEARCH_COMPLETED`
3. one of `CAPABILITY_DECISION_COMPLETED` or `CAPABILITY_DECISION_SKIPPED`
4. `ARCHITECTURE_GATE_PASSED`
5. `DRAFT_FROZEN`

After the latest `DRAFT_FROZEN`, require in order:

1. `RELEASE_GATE_PASSED`
2. `EVALUATOR_PASSED`
3. `VALIDATION_PASSED`
4. `PACKAGE_AUTHORIZED`

A revision must create a new `DRAFT_FROZEN`; downstream gate evidence from an older draft must not authorize the revised artifact.

## Artifact digest

`scripts/pipeline_ledger.py digest <skill-dir>` hashes build-controlled files while excluding `reports/`, `dist/`, caches and compiled bytecode. Reports are excluded to avoid self-reference because release/eval/trace reports are written after the draft is frozen.

All post-freeze pass events must carry the same digest as the latest `DRAFT_FROZEN`. If the current build-controlled artifact digest differs, report `STALE_ARTIFACT_DIGEST` and block package authorization.

## Runtime boundary

When file/code execution is available, use the deterministic ledger for packaged enterprise outputs. When it is unavailable, state `TRACE_RUNTIME_UNAVAILABLE`; do not fabricate event hashes, validator output or package authorization.

## Verification

Use:

```bash
python scripts/validate_pipeline_ledger.py <skill-dir>
```

For this Enterprise Skill Creator package the current upgrade trace is stored in:

- `reports/reliability-upgrade-events.jsonl`
- `reports/reliability-upgrade-state.json`
