# Evaluation Design

## Evaluation layers

Enterprise skills require at least two evaluation layers.

### Trigger evaluations

Stored in `evals/trigger_queries.json`.

Each item contains:

```json
{
  "query": "user-like prompt",
  "should_trigger": true,
  "reason": "why this should or should not activate"
}
```

Include positive and negative cases. Negative cases should be near misses.

### Output evaluations

Stored in `evals/output_evals.json`.

Each item contains:

```json
{
  "id": "OUT-001",
  "prompt": "realistic task",
  "expected_properties": ["property A", "property B"],
  "failure_modes": ["what would fail"]
}
```

### MCP/tool evaluations

When a skill depends on MCP or tool calls, create read-only, independent, non-destructive, idempotent tasks with single verifiable answers. Do not ask tasks whose answers depend on dynamic current state unless the time window is fixed and stable.

### Browser-capability evaluations

For browser-generated capabilities, include:

- script output test
- browser eval test
- error-case test returning `{"error": true, "message": "..."}`
- pagination or list-coverage test when applicable

## Acceptance rules

A skill may not be packaged for enterprise use unless:

- trigger evaluations exist
- output evaluations exist
- release gate passed
- validators pass
- unresolved SOURCE_NEEDED items are not converted into hard rules

### Capability discovery evaluations

When the creator itself or its capability-selection layer changes, `evals/capability-discovery-cases.json` must cover: skip-radar, technology discovery, primary-source gate, simplicity, conflicting evidence, model-confidence anti-pattern, telemetry anti-pattern, data-egress security, simple-skill regression, and single-pass self-reference.

## Reliability evaluations

When the reliability architecture is present, add deterministic positive and negative cases for event-chain integrity, gate order, stale artifact digests, authority-preserving evidence retrieval, capability lifecycle transitions and telemetry privacy/truth-boundary behavior. These checks validate encoded process controls, not stochastic model quality.

