# Frontier Model Handoff Template

Use this template inside generated skills when the user requests Claude or model-agnostic compatibility.

## Runtime assumptions

- Primary instruction source: `SKILL.md`.
- Supporting references: load only when relevant.
- Scripts: run only in a local or agent runtime with filesystem and Python access.
- Tool access: verify per runtime; do not assume parity.
- UI install behavior: not controlled by the skill package.

## Claude / similar model usage

1. Paste or load `SKILL.md` as the controlling instruction document.
2. Attach or expose `references/` as selectively readable support material.
3. Run scripts from `scripts/` locally if the model runtime cannot execute files.
4. Preserve output contracts exactly.
5. Keep all `MISSING` and `SOURCE_NEEDED` labels intact.
