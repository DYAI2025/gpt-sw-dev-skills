# Canonical Evidence Registry

## Purpose

Make claim provenance executable. This reference combines the canonical-source separation already used by Enterprise Skill Creator with the inspected normalized-record/local-query pattern from Canon Resolver and web3-docs.

The registry is a **navigation and verification aid**. Retrieval relevance never increases source authority, evidence confidence or verification status.

## Record contract

Use `schemas/evidence-record.schema.json`. A material record contains:

- `evidence_id` and `source_id`;
- source type and source role;
- `authority_class`: `canonical`, `reference`, `derived`, or `uncertain`;
- source location and precise pointer;
- the bounded claim the source supports;
- `verification_status`;
- confidence 1-5;
- immutable ref and/or content SHA-256 when available;
- retrieval date;
- limitations;
- optional local path for hash verification.

`PRIMARY_VERIFIED` is valid only for `source_type: primary`.

## Query rule

`scripts/evidence_registry.py query` performs deterministic token retrieval over JSONL records and adds only `retrieval_score`.

It must preserve unchanged:

- `authority_class`;
- `verification_status`;
- `confidence`.

This is a hard anti-source-laundering invariant:

`retrieval relevance != authority != verification`.

## Storage choice

JSONL is the default because it is transparent, portable and dependency-free. SQLite/FTS or other indexes may be added later only when corpus size creates a measured need. They remain retrieval accelerators, not authority engines.

## Capability integration

When external technical capabilities influence architecture, link capability lifecycle events and decision-graph nodes to evidence IDs from the registry. `ADOPTED` requires the stronger evidence conditions defined in `references/capability-lifecycle.md`.

## Verification

Use:

```bash
python scripts/validate_evidence_registry.py <skill-dir>
```

The current package evidence registry is `reports/canonical-evidence-records.jsonl`.
