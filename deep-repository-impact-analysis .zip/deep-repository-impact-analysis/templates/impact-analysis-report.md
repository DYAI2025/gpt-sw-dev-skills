# Impact Analysis Report

Use FACT, INFERENCE, VALUE_HYPOTHESIS, RECOMMENDATION, ASSUMPTION, and BLOCKER labels.

## EXECUTIVE_DECISION_SUMMARY

Record the executive decision summary with stable IDs, evidence references, limitations, and confidence where applicable.

## COMPACT_FEATURE_DESCRIPTION

Record the compact feature description with stable IDs, evidence references, limitations, and confidence where applicable.

## USER_VALUE_AND_PURPOSE

Record the user value and purpose with stable IDs, evidence references, limitations, and confidence where applicable.

## CURRENT_STATE

Record the current state with stable IDs, evidence references, limitations, and confidence where applicable.

## TARGET_STATE

Record the target state with stable IDs, evidence references, limitations, and confidence where applicable.

## ANALYSIS_SCOPE_AND_CAPABILITIES

Record the analysis scope and capabilities with stable IDs, evidence references, limitations, and confidence where applicable.

## FOUR_VIEW_NAVIGATOR

Record the four view navigator with stable IDs, evidence references, limitations, and confidence where applicable.

## DEPENDENCY_INVENTORY

Record the dependency inventory with stable IDs, evidence references, limitations, and confidence where applicable.

## IMPACT_RADIUS_BY_DIMENSION

Record the impact radius by dimension with stable IDs, evidence references, limitations, and confidence where applicable.

## CRITICAL_PATHS

Record the critical paths with stable IDs, evidence references, limitations, and confidence where applicable.

## DECISION_NODES

Record the decision nodes with stable IDs, evidence references, limitations, and confidence where applicable.

## IMPLEMENTATION_PATHS

Record the implementation paths with stable IDs, evidence references, limitations, and confidence where applicable.

## RECOMMENDATION

Record the recommendation with stable IDs, evidence references, limitations, and confidence where applicable.

## SMALLEST_EFFECTIVE_SLICE

Record the smallest effective slice with stable IDs, evidence references, limitations, and confidence where applicable.

## VALIDATION_AND_TEST_SUPERSET

Record the validation and test superset with stable IDs, evidence references, limitations, and confidence where applicable.

## ROLLOUT_AND_ROLLBACK

Record the rollout and rollback with stable IDs, evidence references, limitations, and confidence where applicable.

## COVERAGE_VECTOR

Record the coverage vector with stable IDs, evidence references, limitations, and confidence where applicable.

## RISK_VECTOR

Record the risk vector with stable IDs, evidence references, limitations, and confidence where applicable.

## COMPLEXITY_VECTOR

Record the complexity vector with stable IDs, evidence references, limitations, and confidence where applicable.

## EVIDENCE_LEDGER

Record the evidence ledger with stable IDs, evidence references, limitations, and confidence where applicable.

## CONTRADICTIONS_AND_UNKNOWNS

Record the contradictions and unknowns with stable IDs, evidence references, limitations, and confidence where applicable.

## BLOCKERS_AND_HUMAN_GATES

Record the blockers and human gates with stable IDs, evidence references, limitations, and confidence where applicable.

## NEXT_VERIFICATION_ACTIONS

Record the next verification actions with stable IDs, evidence references, limitations, and confidence where applicable.

## MACHINE_READABLE_REPORT

Record the machine readable report with stable IDs, evidence references, limitations, and confidence where applicable.
