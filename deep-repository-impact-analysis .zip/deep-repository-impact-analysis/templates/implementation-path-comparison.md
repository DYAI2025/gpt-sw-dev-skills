
# Implementation path comparison

| field | WIRKSAM_EINFACH | EMPFOHLEN | PREMIUM | STOP_OR_REFRAME |
|---|---|---|---|---|
| value hypothesis | smallest testable value | balanced value and resilience | highest justified quality | value or safety premise is unresolved |
| user experience | describe | describe | describe | describe the reframed problem |
| architecture delta | list | list | list | none or research-only |
| critical dependencies | IDs | IDs | IDs | blocking IDs |
| evidence basis | evidence IDs | evidence IDs | evidence IDs | blocker evidence IDs |
| validation and test superset | IDs | IDs | IDs | next experiment |
| rollout and rollback | steps | steps | steps | no production rollout |
| reasons to choose | list | list | list | list |
| reasons not to choose | list | list | list | list |

A weighted total is advisory. Critical boundaries, irreversible actions, legal constraints, external consumers, and hard contradictions override totals.
