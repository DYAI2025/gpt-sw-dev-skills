
# Feature brief

## Problem and users
State the user problem, affected users, current journey, and measurable outcome.

## Value hypothesis
Record expected value, evidence, confidence, disconfirming signal, and smallest value test.

## Current and target state
Describe behavior, states, contracts, data, permissions, operations, rollout, and non-goals.

## Atomic subchanges
For each subchange assign an ID, change-type IDs, affected behavior, likely seeds, and acceptance criteria.

## Open decisions
List decision IDs, available options, constraints, evidence needed, and human owner.
