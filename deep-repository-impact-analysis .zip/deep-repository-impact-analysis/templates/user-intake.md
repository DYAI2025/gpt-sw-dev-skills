
# User intake

Record each item explicitly. Use `MISSING` rather than guessing.

## Change identity

- change_id:
- change_mode:
- compact_feature_description:
- problem_statement:
- target_users:
- desired_user_outcome:
- business_or_product_value:

## State and scope

- current_state:
- intended_target_state:
- known_scope:
- explicit_non_goals:
- proposed_files_or_components:
- repository_snapshot:
- comparison_baseline:

## Capabilities and constraints

- available_tools:
- permissions:
- license_constraints:
- deployment_context:
- risk_tolerance:
- time_or_budget_constraints:
- known_decisions:
- open_questions:
- missing:
- assumptions_with_ids:
