
# Four-view navigator

Use the same IDs in every view.

## USER_JOURNEY_VIEW

| journey_step_id | actor | current_experience | target_experience | goal_ids | evidence_ids | assumptions | risks |
|---|---|---|---|---|---|---|---|
| JOURNEY-001 | analyst | manual export | requested export | GOAL-001 | EV-001 | ASM-001 | RISK-001 |

## TECHNICAL_SYSTEM_FLOW_VIEW

| flow_step_id | source_entity | edge_id | target_entity | contract_or_data | evidence_ids | limitations |
|---|---|---|---|---|---|---|
| FLOW-001 | ENT-API | EDG-001 | ENT-WORKER | export command | EV-001 | runtime not observed |

## DECISION_NAVIGATOR_VIEW

| decision_id | question | option_ids | recommended_option | evidence_ids | human_gate | revisit_condition |
|---|---|---|---|---|---|---|
| DEC-001 | execution mode | OPT-A; OPT-B | OPT-B | EV-001 | architecture owner | representative load profile |

## IMPLEMENTATION_PATH_VIEW

| path_id | user_value | architecture_delta | decision_ids | risk_ids | test_ids | rollout_ids | evidence_ids |
|---|---|---|---|---|---|---|---|
| EMPFOHLEN | asynchronous export | API plus worker | DEC-001 | RISK-001 | TEST-001 | ROLL-001 | EV-001 |
