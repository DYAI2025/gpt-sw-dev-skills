
from __future__ import annotations
import json, sys
from _common import root_from, fail, ok
root=root_from(sys.argv)
for rel in ['agents/agent-agnostic-notes.md','references/agent-agnostic-compatibility.md','reports/agent-compatibility-report.json']:
    if not (root/rel).is_file(): fail('missing '+rel)
r=json.loads((root/'reports/agent-compatibility-report.json').read_text(encoding='utf-8'))
if not r.get('agent_agnostic_ready') or r.get('tested_runtimes')!=[]: fail('portability status must be prepared but not runtime-tested')
if 'identical behavior across models' not in r.get('not_guaranteed',[]): fail('runtime parity limitation missing')
ok('agent-agnostic handoff is explicit and bounded')
