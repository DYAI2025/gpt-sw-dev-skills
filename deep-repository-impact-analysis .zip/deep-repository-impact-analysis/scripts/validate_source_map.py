
from __future__ import annotations
import sys
from _common import root_from, fail, ok
root=root_from(sys.argv)
t=(root/'references/source-map.md').read_text(encoding='utf-8')
fields=['source_id','title','file_or_location','source_class','purpose','supported_claims','reliability','limitations','freshness_or_version','use_in_skill','default_confidence_1_to_5']
for f in fields:
    if f not in t: fail('source map field missing '+f)
if 'SRC-018' not in t or 'duplicate' not in t.lower(): fail('duplicate source treatment missing')
if not (root/'reports/source-inventory.json').is_file(): fail('source inventory report missing')
ok('source map has required fields and duplicate treatment')
