
from __future__ import annotations
import json
from pathlib import Path


def root_from(argv):
    import sys
    return Path(argv[1] if len(argv) > 1 else '.').resolve()


def load_json(path):
    with Path(path).open(encoding='utf-8') as f:
        return json.load(f)


def fail(message):
    raise SystemExit('FAIL: ' + message)


def ok(message):
    print('PASS: ' + message)
