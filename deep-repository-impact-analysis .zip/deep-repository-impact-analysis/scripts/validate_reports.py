from __future__ import annotations
import json, sys
from _common import root_from, fail, ok
root=root_from(sys.argv)
required=['build-report.md','validation-report.json','release-gate-report.json','installability-report.json','source-audit-report.md','source-inventory.json','conflict-ledger.md','requirements-traceability.csv','quality-gate-report.json','agent-compatibility-report.json','core-functionality-preservation.json','enterprise-skill-evaluation.xml','eval-results.json','created-files-summary.md','visualization-render-check.json']
for name in required:
    if not (root/'reports'/name).is_file(): fail('missing report '+name)
release=json.loads((root/'reports/release-gate-report.json').read_text(encoding='utf-8'))
if release.get('repository_efficacy')!='UNVERIFIED': fail('repository efficacy boundary missing')
evals=json.loads((root/'reports/eval-results.json').read_text(encoding='utf-8'))
if evals.get('behavioral_host_evals_executed') is not False: fail('host eval execution must remain false')
if evals.get('deterministic_eval_contract_validation')!='PASS': fail('eval contract validation not PASS')
ok('required reports exist with honest maturity boundaries')
