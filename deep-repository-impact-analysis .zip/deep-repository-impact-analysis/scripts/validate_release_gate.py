
from __future__ import annotations
import json, sys
from _common import root_from, fail, ok
root=root_from(sys.argv)
r=json.loads((root/'reports/release-gate-report.json').read_text(encoding='utf-8'))
checks=[r['release_gate']['status']=='PASS',r['release_gate']['allowed_to_package'] is True,r['craftsmanship_gate']['status']=='PASS',r['anti_confabulation_gate']['status']=='PASS',not r['anti_confabulation_gate']['blocked_claims'],r['anti_sycophancy']['score']<r['anti_sycophancy']['threshold'],r['bias_gate']['status']=='PASS']
if not all(checks): fail('release gate is not PASS')
ok('release gate permits packaging')
