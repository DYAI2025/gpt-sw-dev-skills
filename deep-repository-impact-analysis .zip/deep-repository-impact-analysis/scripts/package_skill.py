
from __future__ import annotations
import shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
out=Path(sys.argv[2] if len(sys.argv)>2 else './dist').resolve()
subprocess.run([sys.executable,str(root/'scripts/quick_validate.py'),str(root)],check=True)
out.mkdir(parents=True,exist_ok=True)
zip_path=out/'skill.zip'
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob('*')):
        if not p.is_file(): continue
        rel=p.relative_to(root)
        if any(part in {'dist','__pycache__','.git'} for part in rel.parts): continue
        z.write(p,Path(root.name)/rel)
with tempfile.TemporaryDirectory() as td:
    dest=Path(td)
    with zipfile.ZipFile(zip_path) as z: z.extractall(dest)
    entries=[p for p in dest.iterdir() if p.is_dir()]
    if len(entries)!=1 or entries[0].name!=root.name: raise SystemExit('fresh extraction root invalid')
    subprocess.run([sys.executable,str(entries[0]/'scripts/quick_validate.py'),str(entries[0])],check=True)
print(zip_path)
