from __future__ import annotations
import sys, xml.etree.ElementTree as ET
from _common import root_from, fail, ok
root=root_from(sys.argv)
path=root/'reports/enterprise-skill-evaluation.xml'
try: doc=ET.parse(path).getroot()
except Exception as exc: fail('evaluation XML invalid: '+str(exc))
if doc.tag!='enterprise_skill_evaluation': fail('wrong evaluation root')
for tag in ['spec_compliance','research_quality','enterprise_readiness','architecture_quality','release_gate_integrity']:
    n=doc.find('scores/'+tag)
    if n is None or int(n.text)<4: fail('evaluation score below 4: '+tag)
if doc.findtext('decision') not in {'PASS','PASS_WITH_MINOR_REVISIONS'}: fail('evaluation decision not releasable')
ok('enterprise skill evaluation XML validates with all scores at least 4')
