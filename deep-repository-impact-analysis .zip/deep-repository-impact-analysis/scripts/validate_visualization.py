
from __future__ import annotations
import re, sys
from _common import root_from, fail, ok
root=root_from(sys.argv)
path=root/'templates/decision-navigator.html'
if not path.is_file(): fail('missing decision-navigator.html')
t=path.read_text(encoding='utf-8')
for token in ['viewFilter','pathFilter','riskFilter','evidenceFilter','componentFilter','<noscript>','@media print','aria-live','Legend','data-view','data-path','data-risk','data-evidence','data-component','EV-001']:
    if token not in t: fail('visualization missing '+token)
for bad in ['https://','http://','src="//','href="//']:
    if bad in t: fail('external network dependency found: '+bad)
for label in ['CURRENT','TARGET','VERIFIED','ASSUMPTION','RISK','UNKNOWN']:
    if label not in t: fail('visual language label missing '+label)
ok('offline HTML has filters, evidence links, labels, accessibility, print, and no-script fallback')
