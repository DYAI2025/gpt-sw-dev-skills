
from __future__ import annotations
import re, sys
from _common import root_from, load_json, fail, ok

root=root_from(sys.argv)
required=['change-types.json','methods.json','dependency-types.json','entity-types.json','edge-types.json','evidence-classes.json','claim-statuses.json','value-dimensions.json','risk-dimensions.json','complexity-dimensions.json','forbidden-claims.json']
for name in required:
    path=root/'catalogs'/name
    if not path.is_file(): fail('missing catalog '+name)
    data=load_json(path)
    ids=[str(x.get('id','')) for x in data.get('items',[])]
    if not ids or len(ids)!=len(set(ids)): fail('empty or duplicate IDs in '+name)
ct=load_json(root/'catalogs/change-types.json')['items']
if [x['id'] for x in ct] != [f'CT{i:02d}' for i in range(1,18)]: fail('CT01-CT17 sequence invalid')
ms=load_json(root/'catalogs/methods.json')['items']
if [x['id'] for x in ms] != [f'M{i:02d}' for i in range(1,27)]: fail('M01-M26 sequence invalid')
deps=load_json(root/'catalogs/dependency-types.json')['items']
if [x['id'] for x in deps] != [f'DEP-{i:02d}' for i in range(1,25)]: fail('DEP-01 through DEP-24 sequence invalid')
ok('11 catalogs parse, IDs are unique, and canonical sequences are complete')
