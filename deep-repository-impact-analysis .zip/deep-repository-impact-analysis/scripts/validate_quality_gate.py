from __future__ import annotations
import json, sys
from _common import root_from, fail, ok
root=root_from(sys.argv)
r=json.loads((root/'reports/quality-gate-report.json').read_text(encoding='utf-8'))
criteria=r.get('criteria',[])
if len(criteria)<30: fail('quality gate has fewer than 30 criteria')
for c in criteria:
    if c.get('score',0)<4 or c.get('status')!='PASS': fail('P0 quality criterion failed: '+str(c.get('id')))
if r.get('p0_blockers') or r.get('overall_status')!='PASS': fail('quality gate blocked')
ok('30 P0 quality criteria score at least 4 and pass')
