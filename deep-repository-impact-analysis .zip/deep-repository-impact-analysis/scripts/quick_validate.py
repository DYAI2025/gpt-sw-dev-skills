
from __future__ import annotations
import json, subprocess, sys
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
scripts=root/'scripts'
validators=['validate_catalogs.py', 'validate_schemas.py', 'validate_references.py', 'validate_evals.py', 'validate_visualization.py', 'validate_source_map.py', 'validate_no_overclaims.py', 'validate_installability.py', 'validate_release_gate.py', 'validate_agent_agnostic.py', 'validate_core_parity.py', 'validate_no_placeholders.py', 'validate_quality_gate.py', 'validate_enterprise_skill_evaluation.py', 'validate_traceability.py', 'validate_reports.py']
results=[]
for name in validators:
    p=subprocess.run([sys.executable,str(scripts/name),str(root)],text=True,capture_output=True)
    results.append({'validator':name,'returncode':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()})
    print((p.stdout or p.stderr).strip())
    if p.returncode!=0:
        print(json.dumps({'status':'FAIL','results':results},indent=2))
        raise SystemExit(p.returncode)
manifest=scripts/'verify_manifest.py'
if (root/'reports/sha256-manifest.txt').is_file():
    p=subprocess.run([sys.executable,str(manifest),str(root)],text=True,capture_output=True)
    results.append({'validator':'verify_manifest.py','returncode':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()})
    print((p.stdout or p.stderr).strip())
    if p.returncode!=0: raise SystemExit(p.returncode)
print(json.dumps({'status':'PASS','validator_count':len(results),'results':results},indent=2))
