
from __future__ import annotations
import hashlib, sys
from _common import root_from, fail, ok
root=root_from(sys.argv)
manifest=root/'reports/sha256-manifest.txt'
if not manifest.is_file(): fail('SHA-256 manifest missing')
for lineno,line in enumerate(manifest.read_text(encoding='utf-8').splitlines(),1):
    if not line.strip(): continue
    digest, rel=line.split('  ',1)
    path=root/rel
    if not path.is_file(): fail(f'manifest line {lineno} missing file {rel}')
    actual=hashlib.sha256(path.read_bytes()).hexdigest()
    if actual!=digest: fail(f'manifest mismatch {rel}')
ok('SHA-256 manifest verifies')
