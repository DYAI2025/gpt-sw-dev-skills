
from __future__ import annotations
import re, sys
from _common import root_from, fail, ok
root=root_from(sys.argv)
required=['architecture.md','evidence-and-claim-model.md','dependency-taxonomy.md','propagation-and-critical-paths.md','decision-model.md','visualization-contract.md','capability-and-adapter-policy.md','degradation-policy.md','benchmark-and-evaluation.md','security-and-permissions.md','source-policy.md','source-map.md','glossary.md','output-contract.md','research-status-and-maturity.md','agent-agnostic-compatibility.md','core-functionality-preservation.md']
for name in required:
    if not (root/'references'/name).is_file(): fail('missing reference '+name)
skill=(root/'SKILL.md').read_text(encoding='utf-8')
for rel in re.findall(r'`((?:references|catalogs|schemas|templates|scripts|evals|reports)/[^`]+)`', skill):
    if not (root/rel).exists(): fail('SKILL.md references missing path '+rel)
for dep in [f'DEP-{i:02d}' for i in range(1,25)]:
    if dep not in (root/'catalogs/dependency-types.json').read_text(encoding='utf-8'): fail('missing dependency ID '+dep)
ok('required references exist and SKILL.md local links resolve')
