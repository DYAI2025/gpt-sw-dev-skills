
from __future__ import annotations
import json, sys
from _common import root_from, fail, ok
try:
    from jsonschema import Draft202012Validator, FormatChecker
except Exception as exc:
    fail('jsonschema package is required: '+str(exc))
root=root_from(sys.argv)
expected=['analysis-job.schema.json','capability-manifest.schema.json','adapter-run.schema.json','evidence-record.schema.json','impact-claim.schema.json','entity.schema.json','edge.schema.json','dependency-coverage.schema.json','decision-node.schema.json','implementation-path.schema.json','impact-analysis-report.schema.json','benchmark-case.schema.json','reproducibility-envelope.schema.json']
for name in expected:
    path=root/'schemas'/name
    if not path.is_file(): fail('missing schema '+name)
    obj=json.loads(path.read_text(encoding='utf-8'))
    Draft202012Validator.check_schema(obj)
    examples=obj.get('examples',[])
    if not examples: fail('schema lacks representative example: '+name)
    Draft202012Validator(obj,format_checker=FormatChecker()).validate(examples[0])
ok('13 Draft 2020-12 schemas and representative instances validate')
