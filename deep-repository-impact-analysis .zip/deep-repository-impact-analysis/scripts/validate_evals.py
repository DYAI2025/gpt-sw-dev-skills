
from __future__ import annotations
import json, sys
from _common import root_from, load_json, fail, ok
root=root_from(sys.argv)
required_fields={'eval_id','scenario','inputs','available_capabilities','expected_behavior','forbidden_claims','required_output_fields','pass_criteria','severity'}
ids=[]; count=0
for name in ['orchestration-cases.jsonl','degradation-cases.jsonl','adversarial-cases.jsonl','visualization-cases.jsonl','benchmark-cases.jsonl']:
    path=root/'evals'/name
    if not path.is_file(): fail('missing eval file '+name)
    for lineno,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
        if not line.strip(): continue
        obj=json.loads(line)
        missing=required_fields-set(obj)
        if missing: fail(f'{name}:{lineno} missing {sorted(missing)}')
        ids.append(obj['eval_id']); count+=1
if count < 25: fail('fewer than 25 mandatory scenarios')
if len(ids)!=len(set(ids)): fail('duplicate eval IDs')
triggers=load_json(root/'evals/trigger_queries.json')
if len(triggers.get('should_trigger',[]))<8 or len(triggers.get('should_not_trigger',[]))<5: fail('insufficient trigger queries')
outputs=load_json(root/'evals/output_evals.json')
if len(outputs.get('evals',[]))<5: fail('insufficient output evals')
ok(f'{count} JSONL scenarios plus trigger and output evals validate')
