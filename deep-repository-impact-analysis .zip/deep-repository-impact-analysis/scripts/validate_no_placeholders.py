
from __future__ import annotations
import re, sys
from _common import root_from, fail, ok
root=root_from(sys.argv)
patterns=[r'(?i)\bTODO\b',r'(?i)\bTBD\b',r'(?i)lorem ipsum',r'(?i)insert here',r'<your[-_ ]']
viol=[]
for path in root.rglob('*'):
    if not path.is_file() or path.suffix.lower() not in {'.md','.json','.jsonl','.csv','.yaml','.html'}: continue
    text=path.read_text(encoding='utf-8',errors='replace')
    for p in patterns:
        if re.search(p,text): viol.append(str(path.relative_to(root)))
if viol: fail('placeholder markers found in '+', '.join(sorted(set(viol))))
ok('no prohibited placeholder markers found')
