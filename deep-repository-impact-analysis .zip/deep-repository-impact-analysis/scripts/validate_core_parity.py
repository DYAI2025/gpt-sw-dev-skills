
from __future__ import annotations
import json, sys
from _common import root_from, fail, ok
root=root_from(sys.argv)
r=json.loads((root/'reports/core-functionality-preservation.json').read_text(encoding='utf-8'))
required=['intake and scope manifest','change normalization','analyzer selection','evidence extraction','canonical impact graph','typed propagation','multidimensional risk and coverage','validation gates','human and machine reporting','read-only security posture']
if r.get('status')!='PASS' or r.get('unintended_changes'): fail('core parity report blocked')
for item in required:
    if item not in r.get('preserved_core_functions',[]): fail('missing preserved core function '+item)
ok('core functionality preservation report passes')
