from __future__ import annotations
import hashlib, sys
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
manifest=root/'reports/sha256-manifest.txt'
lines=[]
for p in sorted(root.rglob('*')):
    if not p.is_file() or p==manifest or '__pycache__' in p.parts or 'dist' in p.parts: continue
    lines.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(root).as_posix())
manifest.write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(manifest)
