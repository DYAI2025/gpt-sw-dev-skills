from __future__ import annotations
import csv, sys
from _common import root_from, fail, ok
root=root_from(sys.argv)
path=root/'reports/requirements-traceability.csv'
rows=list(csv.DictReader(path.open(encoding='utf-8')))
if len(rows)<18: fail('traceability has fewer than 18 rows')
for row in rows:
    for key in ['requirement_id','requirement','artifacts','validation']:
        if not row.get(key): fail('empty traceability field '+key)
    for rel in [x.strip() for x in row['artifacts'].split(';')]:
        if not (root/rel).exists(): fail('traceability references missing artifact '+rel)
ok('requirements traceability has '+str(len(rows))+' resolvable rows')
