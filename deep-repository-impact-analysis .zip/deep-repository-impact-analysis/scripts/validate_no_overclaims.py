
from __future__ import annotations
import re, sys
from _common import root_from, fail, ok
root=root_from(sys.argv)
patterns={
 'all_dependencies_found':r'(?i)\b(?:we|the analysis|this skill) (?:found|covers|covered) all (?:real-world )?dependencies\b',
 'guaranteed_safe_tests':r'(?i)\b(?:the|this) minimal safe test set is guaranteed\b',
 'production_proven':r'(?i)\brepository (?:precision|recall|efficacy) (?:is|was) proven\b',
 'install_button':r'(?i)\bfrontend install (?:button|prompt) is guaranteed\b',
 'identical_models':r'(?i)\bidentical behavior across (?:all )?models (?:is|was) (?:guaranteed|proven)\b',
}
violations=[]
for path in [root/'SKILL.md',root/'README.md']+list((root/'references').glob('*.md'))+list((root/'reports').glob('*.md')):
    text=path.read_text(encoding='utf-8')
    for pid,pat in patterns.items():
        if re.search(pat,text): violations.append(f'{pid}:{path.relative_to(root)}')
if violations: fail('overclaim patterns: '+', '.join(violations))
report=(root/'reports/release-gate-report.json').read_text(encoding='utf-8')
if 'UNVERIFIED' not in report: fail('release report lacks efficacy limitation')
ok('no positive hard-overclaim patterns found')
