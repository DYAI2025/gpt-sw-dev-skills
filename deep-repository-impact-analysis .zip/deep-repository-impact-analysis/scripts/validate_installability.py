
from __future__ import annotations
import json, re, sys
from _common import root_from, fail, ok
root=root_from(sys.argv)
if root.name!='deep-repository-impact-analysis': fail('folder name mismatch')
text=(root/'SKILL.md').read_text(encoding='utf-8')
m=re.match(r'^---\nname: ([a-z0-9-]+)\ndescription: (.+?)\n---',text,re.S)
if not m: fail('frontmatter invalid or has unsupported fields')
if m.group(1)!=root.name: fail('frontmatter name mismatch')
if '<' in m.group(2) or '>' in m.group(2): fail('description contains angle brackets')
if not (root/'agents/openai.yaml').is_file(): fail('agents/openai.yaml missing')
rep=json.loads((root/'reports/installability-report.json').read_text(encoding='utf-8'))
if rep.get('artifact_name')!='skill.zip' or rep.get('frontend_install_suggestion_status')=='guaranteed': fail('installability report invalid')
ok('installable package shape and bounded installability report validate')
