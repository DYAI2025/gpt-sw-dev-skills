# Deep Repository Impact Analysis

`deep-repository-impact-analysis` is an installable, host-neutral skill package for evidence-grounded software change impact analysis and decision-to-delivery planning.

## What it does

It normalizes a change request, negotiates available capabilities, scans 24 dependency categories, builds typed evidence paths, preserves critical boundaries, compares three implementation paths, and emits human-readable, machine-readable, and interactive outputs.

## What it does not prove

This package is a validated orchestration foundation. It does not include imaginary analyzer implementations and does not prove repository precision, recall, scale, safe minimal test selection, or production runtime coverage. External analyzers remain separately deployable and must provide versioned capability and evidence envelopes.

## Maturity

- `research_status`: foundation reconciled; volatile tool claims rechecked against official sources on 2026-08-03.
- `prototype_status`: installable skill package built and structurally validated.
- `evidence_status`: package structure, schemas, catalogs, JSONL, references, HTML, reports, and archive validated.
- `maturity_gate`: G0.
- `repository_efficacy`: unverified.

## Install or import

Use the packaged `skill.zip` through the skill management surface available in the target client. The package cannot guarantee a client-side install button, workspace permission, plan availability, or third-party runtime support.

## Local validation

```bash
python scripts/quick_validate.py .
python scripts/package_skill.py . ./dist
```

See `reports/validation-report.json`, `reports/release-gate-report.json`, and `reports/installability-report.json` for bounded claims.
