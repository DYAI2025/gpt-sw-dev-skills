# Created files summary

The G0 package contains 94 files before the SHA-256 manifest is added.

| area | file_count | purpose |
|---|---:|---|
| root | 2 | Skill entry point and README |
| agents | 2 | Host metadata and portable handoff |
| assets | 1 | Local icon |
| references | 17 | Policies, architecture, source map, and contracts |
| catalogs | 11 | Canonical IDs and dimensions |
| schemas | 13 | Draft 2020-12 machine contracts |
| templates | 8 | Human, JSONL, CSV, and offline HTML output templates |
| evals | 7 | Orchestration, degradation, adversarial, visualization, benchmark, trigger, and output eval definitions |
| scripts | 20 | Deterministic validation and packaging helpers |
| reports | 13 | Build, source, traceability, quality, release, portability, and installability evidence |

External analyzers, persistent graph stores, CI services, and runtime adapters are intentionally not bundled.
