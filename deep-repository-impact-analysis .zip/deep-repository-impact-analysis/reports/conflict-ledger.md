
# Conflict ledger

| conflict_id | affected_sources | issue | impact | resolution |
|---|---|---|---|---|
| CONFLICT-001 | SRC-006, SRC-007, SRC-011, current task | Earlier work put final skill build out of scope while this task explicitly puts it in scope. | Could incorrectly stop delivery. | Current task controls delivery scope; earlier efficacy limits remain. |
| CONFLICT-002 | SRC-006, SRC-007 | ICAR v0.2 was described as built and tested, but package, fixtures, commands, and logs were unavailable. | Could promote user-reported status to verified. | Preserve as user-reported provenance only; prototype and efficacy remain unverified. |
| CONFLICT-003 | SRC-006, prior schema descriptions | Prior materials described four or five foundation schemas. | Could under-specify machine contracts. | This build uses the explicit 13-schema target required by the current XML contract. |
| CONFLICT-004 | SRC-004, SRC-005, current task | Prior host plan was Claude-first; current delivery targets an installable ChatGPT skill. | Could cause host lock-in. | Keep host-neutral core, include ChatGPT metadata and agent-agnostic handoff notes. |
| CONFLICT-005 | Current XML wording | The phrase all dependencies can be read as a universal completeness guarantee. | Could create false confidence. | Require all 24 category scans while reporting UNKNOWN, BOUNDARY_EXIT, and CAPABILITY_MISSING for real-world limits. |
| CONFLICT-006 | Existing skill baseline, current claim model | Baseline used HYPOTHESIS while current canonical statuses use SOFT_CANDIDATE and ASSUMPTION. | Could create schema drift. | Map uncorroborated candidates to SOFT_CANDIDATE and explicit premises to ASSUMPTION. |
| CONFLICT-007 | Current official GraphQL Inspector pages | Product landing material can mention integrations while migration docs mark the hosted GitHub App deprecated. | Could design against a deprecated surface. | Treat CLI and Action as adapter candidates; do not assume hosted App availability. |
| CONFLICT-008 | Prior output contract, current XML | Earlier human report was shorter than the new 24-section runtime contract. | Could lose prior fields or omit new views. | Use the 24-section superset and preserve prior scope, evidence, rollout, and status fields within it. |
