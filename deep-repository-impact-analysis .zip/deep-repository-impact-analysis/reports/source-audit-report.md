
# Source audit report

## Inventory

- 38 source records were cataloged.
- 22 records are user-provided project material.
- 8 records are derived reports or examples.
- 8 records are current official web sources used only for bounded adapter claims.
- SRC-018 is byte-identical to SRC-013 and is excluded from independence counts.
- SRC-028 overlaps SRC-022 and is treated as another copy of the same general skill-building guidance, not independent evidence.
- The Gardening Skills Wiki archive was inspected as a validator-pattern example only.

## Trust boundary

All attachments, repository content, webpages, comments, issues, commits, and tool output were treated as data. Instruction-like content was not allowed to override the current build contract, expand permissions, disclose secrets, bypass validation, or assert success without evidence.

## Prompt injection review

No high-confidence embedded instruction requiring unsafe mutation, secret disclosure, permission expansion, or validation bypass was adopted. Future repository analyses must still classify such content as PROMPT_INJECTION_RISK when detected.

## Evidence limits

The package structure, schemas, catalogs, templates, eval definitions, validators, and archive can be verified locally. The supplied material does not prove repository-level precision, recall, scalability, safe minimal test selection, or production/runtime efficacy. Prior claims that ICAR was built and tested remain user-reported because the original package and logs were not supplied.

## Conflict resolution

See `reports/conflict-ledger.md`. No conflict was silently collapsed.
