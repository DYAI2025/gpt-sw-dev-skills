# Source policy

## Source classes

- `PRIMARY`: standards, specifications, official license text, original research, official tool or repository documentation.
- `SECONDARY`: books, surveys, high-quality explanations, expert articles.
- `USER_PROVIDED`: project requirements, notes, blueprints, claims, uploaded artifacts.
- `DERIVED`: model reports, summaries, transformed tables, HTML renditions, audits.
- `UNCERTAIN`: incomplete, contradictory, stale, unattributed, or unverifiable material.

## Source precedence

1. Current task contract defines delivery scope.
2. Requirements, architecture, blueprint, critical-path, lexical, and adapter policies define the normative foundation.
3. Traceability, roadmap, validation, and research status define state and evidence limits.
4. Source ledgers and current official overlays define the research basis.
5. Analysis reports are derived and not independent proof.
6. Prompt-engineering and example packages are design inspiration, not repository-efficacy evidence.

## Source-map fields

Each row includes source ID, title, file or location, class, purpose, supported claims, reliability, limitations, freshness/version, use in skill, and default confidence 1–5.

## Confidence

- 5: directly inspected primary source or deterministic local result with bounded scope.
- 4: strong primary/secondary support or corroborated project evidence.
- 3: plausible user-provided or derived evidence requiring qualification.
- 2: incomplete or weakly attributable evidence.
- 1: unreliable or contradicted evidence.

Hard enterprise rules require confidence 4–5 or a direct task requirement. Confidence 3 is an assumption or design hypothesis. Confidence 1–2 cannot support hard rules.

## Volatile claims

Verify current versions, licenses, plans, API/CLI behavior, languages, deprecations, and platform limits from current primary sources when the claim affects a decision. Label `FILE_SUPPORTED`, `CURRENTLY_VERIFIED`, `CHANGED_SINCE_FILE`, `SOURCE_NEEDED`, or `UNVERIFIED`.

## Conflict handling

Do not silently reconcile. Create a `CONFLICT-ID`, list affected sources, impact, chosen resolution or open state, and verification action.
