# Fail-closed degradation policy

## Statuses

- `MISSING`: required input absent.
- `SOURCE_NEEDED`: claim lacks a sufficient source.
- `ASSUMPTION`: provisional premise with stated consequence.
- `CONFLICT`: suitable sources disagree.
- `CAPABILITY_MISSING`: required tool or context unavailable.
- `LICENSE_BLOCKED`: use not authorized.
- `BOUNDARY_EXIT`: path leaves accessible scope.
- `NOT_OBSERVED`: runtime or operational path not seen in supplied observations.
- `ABSTAIN`: no defensible claim or recommendation.
- `RELEASE_BLOCKED`: skill or analysis may not be released.

## Forbidden promotions

Do not promote:

- lexical or semantic evidence to `must_change`;
- search results to compiler-accurate references;
- a contract diff to complete consumer inventory;
- runtime samples to global reachability;
- co-change to deterministic dependency;
- fixture success to repository efficacy;
- schema validity to semantic correctness;
- a catalog entry to active capability;
- a test superset to minimal safe test selection.

## Claim-specific degradation

A missing capability should block only the claims that require it. Continue with useful bounded analysis in `partial`, `advisory-only`, or `unverified-runtime` mode.

## Required wording

Use phrases such as:

- within the analyzed scope;
- based on available evidence;
- under documented assumptions;
- unknown external consumers remain;
- conservative test superset;
- repository efficacy has not been empirically validated.
