# Glossary

- **Change impact analysis**: identification of potential consequences of a change and what may need modification.
- **Blast radius**: practical description of the reachable technical, product, operational, and organizational effect surface.
- **Seed**: entity or artifact from which impact propagation begins.
- **Evidence**: an observed, sourced record bound to scope, snapshot, method, and limitations.
- **Claim**: an assertion evaluated from supporting and refuting evidence.
- **Boundary exit**: a path that leaves the visible or authorized system.
- **Coverage vector**: multidimensional account of analyzed and unknown evidence domains.
- **Critical path**: an impact path retained regardless of score because it crosses a severe boundary or carries unique evidence.
- **Capability manifest**: machine-readable declaration of a tool or adapter's authorized, versioned, tested, scoped capabilities.
- **Conservative test superset**: set of tests chosen to reduce miss risk without claiming formal minimality.
- **Decision node**: explicit choice with options, constraints, consequences, evidence, and re-evaluation conditions.
- **WIRKSAM_EINFACH**: smallest responsible path with testable user value.
- **EMPFOHLEN**: best evidence-supported balance under explicit priorities and constraints.
- **PREMIUM**: highest justified quality path with greater cost and validation.
- **STOP_OR_REFRAME**: decision not to implement as framed.
- **G0–G7**: maturity gates from validated foundation to runtime and enterprise evidence.
