# Propagation and critical-path retention

## Graph

Use a typed directed multigraph. Nodes follow `schemas/entity.schema.json`; edges follow `schemas/edge.schema.json`. Preserve repository, snapshot, ownership, lifecycle, generated status, evidence IDs, temporal validity, limitations, criticality, and reversibility.

## Traversal

- Apply change-type-specific forward and backward direction rules.
- Keep hard, soft, runtime-observed, historical, semantic, and conflicting paths distinguishable.
- Condense strongly connected components for traversal while preserving original members and edges.
- Use score decay only for prioritization.
- Never prune a path solely because it is long or low-scoring when a retention rule applies.

## Critical domains

- public APIs and SDKs;
- event schemas and external consumers;
- data migrations and destructive writes;
- authentication, authorization, permissions;
- sensitive data and security sinks;
- deployment, rollback, production boundaries;
- explicitly relevant legal and compliance controls.

## Mandatory retention

Retain a path when it crosses a critical boundary, contains conflicting hard evidence, exits the known system, reaches an unknown consumer, represents an irreversible operation, or is the sole support or refutation for a severe claim.

Preserve at least:

1. strongest hard-evidence path;
2. shortest critical-boundary path;
3. strongest independent corroborating path;
4. strongest refuting or conflicting path;
5. representative soft-evidence path.

## Verification

Each material impact needs at least one inspectable path from a confirmed seed or an explicit compatibility rule. If the path cannot be reproduced from evidence IDs, downgrade or remove the claim.
