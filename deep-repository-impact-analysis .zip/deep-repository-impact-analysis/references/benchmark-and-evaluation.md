# Benchmark and evaluation

## Separate evaluation layers

- orchestration behavior;
- deterministic bootstrap fixtures;
- adapter conformance;
- representative repository pilots;
- benchmark calibration;
- runtime and enterprise observation.

Passing one layer does not imply another.

## Ground-truth layers

Use GT-0 through GT-6 without treating any layer as complete truth:

- `GT-0`: synthetic fixture truth;
- `GT-1`: compiler/build/contract truth for modeled artifacts;
- `GT-2`: adjudicated repository artifacts and expert labels;
- `GT-3`: implementation diff and review outcome;
- `GT-4`: test, build, and deployment outcomes;
- `GT-5`: runtime-observed behavior and incidents;
- `GT-6`: post-release product and operational outcomes.

## Leakage controls

- separate benchmark design from ordinary analysis;
- hide outcomes used for scoring;
- version repository snapshots and labels;
- prevent model access to answer keys during prediction;
- track source overlap and derivation groups;
- report unresolved adjudication.

## Metrics

Evaluate precision, recall, severity-weighted misses, false-green rate, cry-wolf rate, critical-path retention, calibration, abstention quality, coverage, runtime cost, and explanation reproducibility.

## Package evals

The JSONL cases in `evals/` test orchestration and degradation policy. They are fixtures, not repository-effectiveness evidence. `evals/trigger_queries.json` tests discovery intent and `evals/output_evals.json` defines output assertions.

## Maturity gates

- G0 foundation and source audit accepted;
- G1 host behavior and orchestration evals executed and passed;
- G2 deterministic bootstrap fixtures executed and passed;
- G3 real build and contract adapter runs;
- G4 precise symbol or deep semantic evidence;
- G5 representative repository pilots;
- G6 benchmark calibration;
- G7 runtime and enterprise observation.
