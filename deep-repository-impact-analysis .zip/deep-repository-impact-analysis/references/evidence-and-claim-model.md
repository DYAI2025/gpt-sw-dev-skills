# Evidence and claim model

## Evidence classes

Use the canonical list in `catalogs/evidence-classes.json`. Hard evidence classes are suitable only within their modeled scope. Runtime evidence is observed, not global. Historical, lexical, semantic, human-provided, and derived evidence require explicit limitations.

## Evidence record

Every record includes:

- `evidence_id`, `source_id`, `repository_snapshot`;
- `tool_or_method`, `tool_version`, `configuration_hash`, `execution_context`;
- `entity_or_edge`, `raw_pointer`, `observed_fact`;
- `evidence_class`, `confidence`, `limitations`, `timestamp`.

Validate with `schemas/evidence-record.schema.json`.

## Impact claim

Every claim includes:

- `claim_id`, text and type;
- affected entities;
- supporting and refuting evidence IDs;
- independence groups;
- status and confidence;
- scope, limitations, consequence if wrong, and verification recommendation.

Validate with `schemas/impact-claim.schema.json`.

## Independence rule

Reports, HTML views, summaries, and transformed tables derived from one origin remain one evidence group. Do not count them as independent corroboration.

## Claim discipline

- `VERIFIED`: directly supported within declared scope.
- `CORROBORATED`: supported by independent evidence groups.
- `SUPPORTED`: sufficient bounded support without direct proof of the whole claim.
- `INFERRED`: logical consequence, not directly observed.
- `SOFT_CANDIDATE`: candidate requiring stronger evidence.
- `ASSUMPTION`: needed premise without proof.
- `CONFLICTING`: suitable sources disagree.
- `REFUTED`: suitable evidence contradicts the claim.
- `UNKNOWN`: evidence insufficient.
- `SOURCE_NEEDED`: a source class is required before asserting.
- `ABSTAIN`: do not decide under current evidence.

## Prohibitions

- Absence of counterevidence is not positive proof.
- Lexical or semantic similarity is not `must_change`.
- Co-change history is not a necessary dependency.
- Sampled traces do not establish global reachability or unreachability.
- A tool name does not establish capability.
- Fixture and structural validation do not establish repository efficacy.
