# Agent-agnostic compatibility

The core method is portable natural-language instruction plus stable schemas, catalogs, templates, evals, and deterministic scripts.

## Portable components

- `SKILL.md` and references;
- JSON catalogs and schemas;
- Markdown, CSV, JSONL, and HTML templates;
- validators and package script;
- evidence, claim, graph, decision, and maturity rules.

## Runtime-specific components

- `agents/openai.yaml`;
- shell, browser, connector, repository, and network availability;
- approval UI and workspace permissions;
- memory, persistence, and context behavior.

## Handoff

Claude Code or another coding agent should load `SKILL.md`, inspect only relevant references, run deterministic scripts locally, and preserve read-only and approval gates. A generic frontier model without file execution can still apply the method but must label validator and packaging capabilities missing.

No identical behavior across models is claimed without runtime-specific evaluation.
