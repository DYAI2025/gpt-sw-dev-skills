# Capability and adapter policy

## Principle

Tools are replaceable adapters. A tool name is not a capability.

## Activation gate

Set an adapter `ACTIVE` only when all are documented:

- authorization and allowed license;
- tool version and configuration hash;
- required build or runtime context;
- adapter conformance result;
- canonical output schema validation;
- coverage and limitations;
- at least one real successful run bound to a snapshot.

Otherwise use `PLANNED`, `AVAILABLE_UNVERIFIED`, `LICENSE_BLOCKED`, `CAPABILITY_MISSING`, or `FAILED`.

## Adapter tiers

1. `BOOTSTRAP`: inventory, paths, lexical search, syntax, imports, Git history.
2. `BOUNDARY`: build graph, OpenAPI, GraphQL, Protobuf, events, coverage, migrations, IaC.
3. `PRECISE_OR_DEEP`: SCIP/LSP, SAST, CPG, dataflow, taint, where available and lawful.
4. `ENTERPRISE`: runtime, multi-repository, persistent graph, CI policies, production observation.

## Current bounded tool notes

Official documentation was rechecked on 2026-08-03. These notes are discovery guidance, not activation:

- Sourcegraph precise navigation requires uploaded indexes; search-based navigation is a fallback; language and cross-repository support vary by indexer and build integration.
- Semgrep Community Edition and Semgrep-maintained rules have separate license boundaries; actual use requires current license review.
- CodeQL use depends on repository type, plan, and terms; private automated analysis requires an authorized entitlement.
- Nx Gradle support and experimental Maven support provide project/task graph evidence, not behavior proof.
- GraphQL Inspector CLI and Action remain available; its hosted App is deprecated.
- Buf CLI breaking checks and private BSR instance enforcement are distinct capabilities.
- oasdiff evaluates declared OpenAPI contracts and provides machine-readable output; it does not inventory all consumers.
- bazel-diff has active releases, but every adapter run must pin a version.

## Degradation

When capability is missing, do not substitute an LLM guess. Block dependent claims and state which additional capability would change the result.
