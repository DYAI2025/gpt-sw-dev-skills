# Dependency-First Gate

Before recommendation, scan every category in `catalogs/dependency-types.json`.

## Per-category record

For each `DEP-01` through `DEP-24`, emit:

```yaml
category_id: DEP-01
status: ANALYZED | PARTIAL | NOT_APPLICABLE | CAPABILITY_MISSING | NO_EVIDENCE | BOUNDARY_EXIT
inspected_scope: []
evidence_ids: []
discovered_entities: []
discovered_edges: []
limitations: []
unknowns: []
required_next_capability: []
```

## Status semantics

- `ANALYZED`: available evidence and required methods were applied to the declared scope.
- `PARTIAL`: some relevant scope or capability was unavailable.
- `NOT_APPLICABLE`: the category does not apply, with a stated reason.
- `CAPABILITY_MISSING`: a required method or execution context is absent.
- `NO_EVIDENCE`: the category was inspected but no supporting evidence was found; this is not proof of no dependency.
- `BOUNDARY_EXIT`: the path leaves the accessible system or reaches an unknown external consumer.

## Coverage rule

Category completion is mandatory. Real-world completeness is never assumed. End with a vector showing analyzed, partial, unavailable, boundary-exit, and unknown areas.

## Lexical bootstrap

For each term record token-boundary matches, normalized variants, document frequency, total count, file-type distribution, code/string/comment/path/symbol context, generated/vendor/test/docs share, case and acronym ambiguity, and term origin. Lexical output remains `SOFT_CANDIDATE` until corroborated.
