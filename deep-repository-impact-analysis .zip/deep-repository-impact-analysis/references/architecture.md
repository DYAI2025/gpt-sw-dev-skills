# Architecture

## Decision

Use a host-neutral skill control plane with separately deployable analyzer, evidence, graph, benchmark, persistence, CI, and runtime services. The package defines contracts and orchestration; it does not pretend to implement external analyzers.

## Planes

1. **Skill control plane** — intake, change classification, method routing, permissions, degradation, human gates.
2. **Analysis job plane** — snapshot binding, state, idempotency, retry, cancellation, resume, reproducibility.
3. **Analyzer data plane** — read-only lexical, syntax, symbol, build, contract, data, test, history, infrastructure, and runtime adapters.
4. **Entity and evidence plane** — canonical identities, evidence records, claims, provenance, conflicts, coverage, boundary exits.
5. **Propagation and decision plane** — typed traversal, critical-path retention, value/risk/complexity vectors, options, test supersets, abstention.
6. **Benchmark and calibration plane** — GT-0 through GT-6, hidden outcomes, leakage control, adapter conformance, repository evaluation.
7. **Governance and operations plane** — licenses, secrets, privacy, decisions, evidence ledger, approval, release gates.

## Host model

```text
core: SKILL.md, references, catalogs, schemas, templates, evals, scripts
host: agents/openai.yaml and runtime-specific handoff notes
external: analyzers, graph store, evidence store, CI, runtime observation
```

## Rejected architectures

- prompt-only analyzer;
- monolithic universal analyzer;
- LLM-generated graph treated as hard evidence;
- one-dimensional coverage or risk score;
- host-specific knowledge embedded only in one client;
- mutable evidence without snapshot and configuration identity.

## Status separation

Always maintain:

```text
research_status != prototype_status != evidence_status
```

A specification does not prove implementation. Implementation does not prove effectiveness. Fixture success does not prove repository accuracy. Schema validity does not prove domain fitness.
