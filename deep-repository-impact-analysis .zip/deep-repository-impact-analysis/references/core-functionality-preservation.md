
# Core functionality preservation

The prior skill baseline already provided intake, change normalization, analyzer planning, evidence extraction, canonical graph modeling, typed propagation, multidimensional risk/coverage, validation gates, reporting, and read-only security behavior. This build preserves those functions.

Additions are limited to the current contract: complete 24-category dependency gate, four coupled views, dynamic value model, three implementation paths plus optional stop/reframe, 13 canonical schemas, expanded catalogs and evals, offline HTML visualization, release/installability/portability reports, and deterministic archive verification.

Terminology migration: prior `HYPOTHESIS` content maps to `SOFT_CANDIDATE` when it is an uncorroborated candidate and to `ASSUMPTION` when it is an explicit premise.
