
# Research, prototype, evidence, and maturity status

Maintain three independent status fields:

- `research_status`: completeness of formal research artifacts;
- `prototype_status`: existence and inspected state of implementation;
- `evidence_status`: strongest evidence actually inspected.

Maturity gates:

- G0: foundation and package contracts validated;
- G1: host behavior evals executed;
- G2: deterministic bootstrap fixtures executed;
- G3: real build and contract adapter runs;
- G4: precise symbol or deep semantic evidence;
- G5: representative repository validation;
- G6: benchmark calibration;
- G7: operational/runtime observation.

Never promote a higher gate from documentation alone. This delivered package is G0. It contains eval definitions but no executed host or repository benchmark evidence.
