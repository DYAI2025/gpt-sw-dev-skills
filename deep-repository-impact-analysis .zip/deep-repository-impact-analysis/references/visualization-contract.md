# Visualization contract

## Required views

1. `SYSTEM_CONTEXT_MAP`
2. `DEPENDENCY_IMPACT_GRAPH`
3. `USER_JOURNEY_IMPACT_MAP`
4. `TECHNICAL_SYSTEM_FLOW`
5. `DECISION_NAVIGATOR`
6. `IMPLEMENTATION_PATH_COMPARISON`
7. `VALUE_IMPACT_MATRIX`
8. `TEST_AND_ROLLOUT_MAP`
9. `EVIDENCE_AND_UNCERTAINTY_OVERLAY`

Provide Mermaid when supported and a textual fallback. When file creation is available, produce a self-contained HTML view based on `templates/decision-navigator.html`.

## Coupling rules

Selecting a decision or path must reveal the affected journey step, technical components, dependency paths, evidence, assumptions, option effects, value/risk/complexity dimensions, tests, and rollout gates. Use stable IDs in DOM attributes and report objects.

## Offline and privacy requirements

- no external scripts, fonts, analytics, or network calls;
- no secret transmission;
- meaningful content without JavaScript;
- filters for view, path, risk, evidence class, and component;
- evidence IDs visible and searchable;
- paths independently toggleable;
- print styles;
- accessible labels, keyboard-operable controls, landmarks, headings, and text descriptions.

## Visual language

Color is never the only channel. Add labels, symbols, line styles, or patterns.

- gray + `CURRENT`;
- blue + `TARGET`;
- green + `VERIFIED`;
- yellow + `ASSUMPTION`;
- orange + `RISK`;
- red + `BLOCKER`;
- violet + `UNKNOWN`.

Path labels: `WE`, `REC`, `PREM`, and `STOP`.
