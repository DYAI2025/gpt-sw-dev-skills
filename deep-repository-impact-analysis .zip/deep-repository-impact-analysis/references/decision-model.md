# Decision and recommendation model

## Four coupled views

All views use shared IDs for goals, journey steps, entities, edges, evidence, claims, decisions, implementation paths, risks, tests, rollout steps, and blockers.

1. `USER_JOURNEY_VIEW`
2. `TECHNICAL_SYSTEM_FLOW_VIEW`
3. `DECISION_NAVIGATOR_VIEW`
4. `IMPLEMENTATION_PATH_VIEW`

## Value model

Use all required value dimensions from `catalogs/value-dimensions.json`. Add a domain-specific dimension only with a rationale. Show weightings and sensitivity. Hard constraints override weighted totals.

## Implementation paths

Generate:

- `WIRKSAM_EINFACH`: least technical effort that still yields testable user value;
- `EMPFOHLEN`: best evidence-supported balance across value, quality, risk, effort, transparency, and future optionality;
- `PREMIUM`: highest justified quality with greater integration and validation cost;
- `STOP_OR_REFRAME`: optional when value is unclear, a blocker exists, or risk is disproportionate.

Do not select the recommended path from a total score alone. Review critical paths, external consumers, irreversible actions, security and privacy constraints, assumptions, and unknown boundaries first.

## Claim labels in narrative output

- `FACT`
- `INFERENCE`
- `VALUE_HYPOTHESIS`
- `RECOMMENDATION`
- `ASSUMPTION`
- `BLOCKER`

## Required runtime sections

1. EXECUTIVE_DECISION_SUMMARY
2. COMPACT_FEATURE_DESCRIPTION
3. USER_VALUE_AND_PURPOSE
4. CURRENT_STATE
5. TARGET_STATE
6. ANALYSIS_SCOPE_AND_CAPABILITIES
7. FOUR_VIEW_NAVIGATOR
8. DEPENDENCY_INVENTORY
9. IMPACT_RADIUS_BY_DIMENSION
10. CRITICAL_PATHS
11. DECISION_NODES
12. IMPLEMENTATION_PATHS
13. RECOMMENDATION
14. SMALLEST_EFFECTIVE_SLICE
15. VALIDATION_AND_TEST_SUPERSET
16. ROLLOUT_AND_ROLLBACK
17. COVERAGE_VECTOR
18. RISK_VECTOR
19. COMPLEXITY_VECTOR
20. EVIDENCE_LEDGER
21. CONTRADICTIONS_AND_UNKNOWNS
22. BLOCKERS_AND_HUMAN_GATES
23. NEXT_VERIFICATION_ACTIONS
24. MACHINE_READABLE_REPORT

## Recommendation checklist

Answer:

- Which user problem is addressed and how?
- What evidence supports the value?
- Which technical changes are required?
- Which critical dependencies are touched?
- Which risks remain?
- Which alternative was rejected and why?
- What is the smallest value-bearing test?
- What must be verified before implementation?
- What must be verified before production?
- When should the work stop or be reframed?
