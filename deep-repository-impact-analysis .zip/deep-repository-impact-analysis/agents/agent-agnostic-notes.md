# Agent-agnostic notes

Use `SKILL.md` as the portable control plane. Load references only when relevant and run deterministic scripts in a local shell when available.

## Portable invariants

- dependency-first analysis before recommendation;
- evidence and claim separation;
- capability manifests and fail-closed degradation;
- critical-path retention;
- four coupled views and three implementation paths;
- read-only default and explicit mutation approval;
- honest maturity and efficacy limits.

## Runtime-specific boundaries

- ChatGPT metadata lives in `agents/openai.yaml`.
- Claude Code, Codex-like agents, Cursor, Windsurf, CLI agents, and MCP services may differ in filesystem, shell, connector, browser, approval, persistence, and UI capabilities.
- No runtime is assumed to provide identical tools or install surfaces.
- When a capability is absent, emit `CAPABILITY_MISSING` and block dependent claims.
