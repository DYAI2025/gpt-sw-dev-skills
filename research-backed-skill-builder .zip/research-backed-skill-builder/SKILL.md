---
name: research-backed-skill-builder
description: researches, organizes, and validates information before building or updating ChatGPT skills. Use when a user asks to create a skill from documents, PDFs, images, notes, web sources, repositories, tool documentation, MCP servers, market/domain research, or mixed source material, and the skill must include source strategy, reference organization, confidence scoring, hallucination controls, evaluation scenarios, and a complete package structure.
---

# Research-Backed Skill Builder

## Wann verwenden

Verwenden, wenn ein Skill nicht nur aus einer spontanen Beschreibung gebaut werden soll, sondern aus recherchierten, geprüften oder vom Nutzer bereitgestellten Informationen entstehen muss.

Typische Trigger:
- „baue/erstelle/aktualisiere einen Skill aus diesen Dokumenten“
- „recherchiere zuerst und schreibe dann den Skill“
- „ordne die Dateien als Referenz für einen Skill“
- „mache daraus ein Skill-Paket“
- „erstelle einen Skill mit Quellenstrategie, Confidence-Score, Audit und Tests“
- „baue einen Skill für ein Fachgebiet, Tool, API, MCP-Server oder Dokumentkorpus“

Nicht verwenden, wenn der Nutzer nur eine einmalige Antwort, eine kurze Zusammenfassung oder eine kreative Textvariante ohne wiederverwendbaren Skill verlangt.

## Leitprinzip

Baue keinen Skill aus ungesicherten Annahmen. Erzeuge zuerst eine belastbare Wissens- und Quellenstruktur, trenne Fakten von Ableitungen und Spekulationen, und übersetze erst danach die wiederholbare Logik in ein Skill-Paket.

## Workflow / Anweisungen

### 1. Auftrag normalisieren

1. Extrahiere:
   - Ziel des Skills
   - spätere Trigger des Skills
   - erwartete Inputs
   - erwartete Outputs
   - benötigte Tools oder Konnektoren
   - Sicherheits- und Quellenanforderungen
   - Zielformat des Pakets
2. Wenn zentrale Angaben fehlen, stelle höchstens drei Rückfragen. Frage nur, wenn ohne Antwort ein unsicherer oder falscher Skill entstehen würde.
3. Leite einen stabilen Namen im hyphen-case ab, falls der Nutzer keinen Namen vorgibt.

### 2. Quellen inventarisieren

1. Erstelle ein Quelleninventar für alle verfügbaren Materialien:
   - Nutzerdateien
   - PDFs und Bilder
   - Tabellen und CSVs
   - vorhandene SKILL.md- oder Skill-Pakete
   - Webquellen
   - Tool- oder API-Dokumentation
2. Klassifiziere jede Quelle:
   - `primary`: offizielle Spezifikation, Standard, API-Dokumentation, Originaldaten
   - `secondary`: Fachartikel, Lehrmaterial, kuratierte Erklärung
   - `user_provided`: Nutzerwissen, Notizen, interne Dokumente
   - `derived`: Zusammenfassung, Mindmap, Transkription, OCR, Modellableitung
   - `uncertain`: Quelle ohne klare Herkunft oder überprüfbare Basis
3. Dokumentiere für jede Quelle:
   - Zweck im Skill
   - Verlässlichkeit
   - bekannte Grenzen
   - wann sie nachgeladen werden soll

### 3. Recherche durchführen

1. Nutze Webrecherche, wenn:
   - Informationen aktuell sein können,
   - Standards, APIs, Versionen oder Regeln betroffen sind,
   - externe Quellenstrategie verlangt wird,
   - Nutzer ausdrücklich „recherchieren“, „prüfen“, „aktuell“ oder „Web“ verlangt.
2. Nutze bevorzugt Primärquellen:
   - offizielle Dokumentation
   - Standards und Spezifikationen
   - Hersteller- oder Projektquellen
   - wissenschaftliche Arbeiten nur für Forschungsclaims
3. Verwende Sekundärquellen nur zur Einordnung, nicht als alleinige Basis für operative Regeln.
4. Markiere unbelegte oder unvollständige Informationen konsequent mit `SOURCE_NEEDED` oder `MISSING`.

### 4. Wissensarchitektur bauen

Ordne Informationen in progressive Referenzschichten:

1. `SKILL.md` enthält nur Kernverhalten, Trigger, Workflow, Ausgabeformat und Verweise.
2. `references/source-policy.md` enthält Quellenhierarchie, Belegregeln, MISSING/SOURCE_NEEDED-Policy und Confidence-Skala.
3. `references/source-map.md` enthält Inventar und Zweck der Quellen.
4. `references/domain-ontology.md` enthält stabile Begriffe, Taxonomien und Abgrenzungen.
5. `references/validation-rules.md` enthält prüfbare Regeln, Failure-Gates und Audit-Schritte.
6. `references/evaluation-plan.md` enthält Testfälle und Evaluationslogik.
7. `scripts/` enthält nur deterministische Prüfungen, die wiederholt sinnvoll ausführbar sind.

### 5. Skill-Paket entwerfen

1. Erzeuge mindestens:
   - `<skill-name>/SKILL.md`
   - `<skill-name>/agents/openai.yaml`
2. Ergänze Referenzen nur, wenn sie den Skill robuster machen.
3. Vermeide Wissensdumps in `SKILL.md`; lagere umfangreiche Details in `references/` aus.
4. Schreibe Frontmatter strikt:
   - `name`: lowercase hyphen-case
   - `description`: dritte Person, beschreibt Zweck und Trigger, keine spitzen Klammern
5. Halte die Beschreibung such- und triggerstark, aber nicht überladen.

### 6. Confidence und Halluzinationsschutz erzwingen

Nutze diese feste Confidence-Skala:

| Score | Bedeutung | Auslieferungsregel |
|---|---|---|
| 5 | Primärquelle direkt belegt und aktuell genug | verwendbar |
| 4 | starke Quelle oder mehrere unabhängige Quellen | verwendbar mit normaler Sicherheit |
| 3 | plausibel, aber indirekt oder nur teilweise belegt | als Annahme kennzeichnen |
| 2 | schwach belegt, widersprüchlich oder kontextabhängig | nicht als Regel verwenden |
| 1 | unbelegt, spekulativ oder potentiell falsch | blockieren oder SOURCE_NEEDED |

Pflichtregeln:
- Keine konkreten Zahlen, Normen, APIs, Versionen, Rechts-/Medizin-/Finanzclaims ohne Quelle.
- Keine kulturellen, sprachlichen oder historischen Behauptungen ohne Trennung von Fakt, Tradition, Interpretation und Designentscheidung.
- Keine Nutzerdokumente als automatisch wahr behandeln; sie sind `user_provided`, bis sie geprüft wurden.
- Keine Pseudo-Expertise: Wenn eine Regel nicht sicher ist, markiere `SOURCE_NEEDED`.

### 7. Post-Generation-Audit durchführen

Vor der Auslieferung des Skill-Pakets prüfe:

1. Ist der Skill als Verzeichnis mit `SKILL.md` und `agents/openai.yaml` installierbar?
2. Sind alle Referenzen direkt aus `SKILL.md` erreichbar?
3. Sind Quellenstrategie, MISSING/SOURCE_NEEDED-Policy und Confidence-Skala vorhanden?
4. Sind Domain-Abgrenzungen operational, nicht nur narrativ?
5. Gibt es mindestens drei realistische Testszenarien?
6. Gibt es klare Failure-Gates?
7. Sind Web- oder Toolabhängigkeiten als „wenn verfügbar“ formuliert und nicht erfunden?
8. Wurden Placeholders, TODOs, leere Dateien und unklare Versprechen entfernt?

### 8. Antwort ausgeben

Wenn ein Skill gebaut oder aktualisiert wird, liefere immer:

1. `FILETREE`
2. `ALLE DATEIEN` mit jeder Datei in eigenem Codeblock und erster Zeile `# path: ...`
3. optional `Bash-Installer`
4. `Packaging-Hinweis` mit:
   - `python quick_validate.py <pfad/zum/skill-ordner>`
   - `python package_skill.py <pfad/zum/skill-ordner> [optional: ./dist]`

Wenn ein ZIP erzeugt wurde, verlinke es zusätzlich.

## Ausgabeformat für Recherche-Ergebnisse innerhalb des Skills

Verwende bei Skill-Entwurfsarbeit dieses interne Zwischenformat:

```text
SOURCE MAP
- Quelle:
  - Typ:
  - Zweck:
  - Verlässlichkeit:
  - Grenzen:
  - Skill-Verwendung:

KNOWLEDGE MODEL
- Kernbegriffe:
- Abgrenzungen:
- operative Regeln:
- offene Punkte:

SKILL DESIGN
- Name:
- Trigger:
- Inputs:
- Outputs:
- Referenzen:
- Validierung:

AUDIT
- Confidence:
- SOURCE_NEEDED:
- MISSING:
- Failure-Gates:
```

## Beispiele

### Beispiel 1: Skill aus PDFs und Webquellen

Nutzer: „Erstelle einen Skill aus diesen PDFs über japanische Typografie. Recherchiere Standards dazu.“

Erwartetes Verhalten:
- Nutzer-PDFs inventarisieren.
- Web-Primärquellen zu JLReq, Unicode und Sprach-Tags recherchieren.
- Nutzer-PDFs als `user_provided` markieren, Standards als `primary`.
- Regeln zu Kinsoku, Yakumono, Han-Unification und Font-/Language-Tagging als Referenzen auslagern.
- Skill mit Confidence-Skala, SOURCE_NEEDED-Policy und Post-Generation-Audit bauen.

### Beispiel 2: MCP-Server-Skill

Nutzer: „Baue einen Skill, der hilft, Evaluations für einen MCP-Server zu schreiben.“

Erwartetes Verhalten:
- MCP-Dokumentation inventarisieren.
- Tool-Schemata prüfen, ohne destruktive Calls zu nutzen.
- Evaluationen mit read-only, unabhängigen, stabilen Fragen entwerfen.
- `references/evaluation-plan.md` mit XML-Format, Qualitätskriterien und Anti-Patterns aufnehmen.

### Beispiel 3: Skill aus unsicheren Notizen

Nutzer: „Baue einen Skill aus meinen Marktbeobachtungen.“

Erwartetes Verhalten:
- Notizen als `user_provided` und nicht als Fakt behandeln.
- Aktuelle Marktdaten recherchieren, wenn Web verfügbar ist.
- Alle dynamischen Zahlen mit Datum und Quelle versehen.
- Empfehlungen nur mit Confidence und Unsicherheitsmarkierung ausgeben.
