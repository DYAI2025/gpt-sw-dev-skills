#!/usr/bin/env python3
"""Minimal local validator for ChatGPT-style skill packages.

This validator is intentionally conservative. It checks structure and common
source-discipline requirements for research-backed skills. It does not replace
platform validation.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

NAME_RE = re.compile(r"^name:\s*([a-z0-9]+(?:-[a-z0-9]+)*)\s*$", re.MULTILINE)
DESC_RE = re.compile(r"^description:\s*(.+?)\s*$", re.MULTILINE)

REQUIRED_PHRASES = [
    "SOURCE_NEEDED",
    "MISSING",
    "Confidence",
    "Post-Generation-Audit",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_dir", help="Path to a skill directory")
    return parser.parse_args()


def fail(message: str) -> None:
    print(f"FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)


def main() -> int:
    args = parse_args()
    root = Path(args.skill_dir)
    if not root.exists() or not root.is_dir():
        fail(f"not a directory: {root}")

    skill_md = root / "SKILL.md"
    if not skill_md.exists():
        fail("SKILL.md not found")

    agent_yaml = root / "agents" / "openai.yaml"
    if not agent_yaml.exists():
        fail("agents/openai.yaml not found")

    text = skill_md.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        fail("SKILL.md must start with YAML frontmatter")

    name_match = NAME_RE.search(text)
    if not name_match:
        fail("frontmatter name missing or invalid hyphen-case")

    if name_match.group(1) != root.name:
        fail(f"directory name '{root.name}' does not match skill name '{name_match.group(1)}'")

    desc_match = DESC_RE.search(text)
    if not desc_match:
        fail("frontmatter description missing")

    description = desc_match.group(1)
    if "<" in description or ">" in description:
        fail("description must not contain angle brackets")

    missing = [phrase for phrase in REQUIRED_PHRASES if phrase not in text]
    if missing:
        fail("missing required research-safety phrases: " + ", ".join(missing))

    references = root / "references"
    if references.exists():
        empty_files = [p for p in references.rglob("*") if p.is_file() and p.stat().st_size == 0]
        if empty_files:
            fail("empty reference files: " + ", ".join(str(p) for p in empty_files))

    print(f"PASS: {root}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
