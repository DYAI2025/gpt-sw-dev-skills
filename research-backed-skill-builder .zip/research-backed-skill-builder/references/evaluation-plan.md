# Evaluation Plan for Research-Backed Skills

## Evaluation goals

A research-backed skill is acceptable only if another model can use it to:

1. find relevant source material,
2. distinguish primary evidence from notes or summaries,
3. refuse unsupported claims,
4. produce the promised output format,
5. audit its own output before final delivery.

## Baseline failure scenarios

Use these scenarios before and after writing the skill.

### Scenario 1: User PDFs as false authority

Input: The user supplies a polished PDF containing strong historical claims and asks for a skill.

Expected failure without this skill:
- The agent treats the PDF as factual authority.
- The agent copies claims into SKILL.md without source hierarchy.
- No SOURCE_NEEDED markers appear.

Expected pass:
- The PDF is classified as `user_provided`.
- Historical claims are separated from operational workflow rules.
- The skill requires verification before using claims as facts.

### Scenario 2: Current API or tool documentation

Input: The user asks for a skill based on a tool or MCP server whose API may change.

Expected failure without this skill:
- The agent relies on memory.
- It invents tool parameters or endpoint behavior.
- It writes no evaluation plan.

Expected pass:
- The agent checks current documentation when available.
- It marks missing details.
- It includes read-only, stable, independent evaluation tasks when relevant.

### Scenario 3: Multimodal design reference

Input: The user provides screenshots, infographics and PDFs and asks for a design-audit skill.

Expected failure without this skill:
- The agent ignores visuals or summarizes them loosely.
- It fails to identify image-based rules.
- It omits post-generation visual audit.

Expected pass:
- The agent inventories images as `user_provided` or `derived`.
- It turns visuals into candidate validation rules.
- It adds a post-generation audit step with failure gates.

## MCP-style evaluation template

When the generated skill involves MCP tools, create an XML evaluation file with 10 tasks:

```xml
<evaluation>
  <qa_pair>
    <question>Find the completed project whose retrospective mentions customer onboarding friction. What was the project lead's role? Respond with the role title only.</question>
    <answer>Product Manager</answer>
  </qa_pair>
</evaluation>
```

Rules for MCP-style evaluations:
- Questions are read-only and non-destructive.
- Questions are independent.
- Answers are stable.
- Answers are single values that can be checked by direct string comparison.
- Questions require multi-step exploration, not exact keyword search.

## Skill acceptance checklist

A skill passes only if all items are true:

- `SKILL.md` exists and has valid frontmatter.
- `agents/openai.yaml` exists.
- The trigger description is specific.
- Source hierarchy exists.
- MISSING/SOURCE_NEEDED policy exists.
- Confidence scale exists.
- Domain ontology or terminology map exists when the domain is non-trivial.
- Validation or audit rules exist.
- At least three tests or pressure scenarios exist.
- No TODOs, empty references or unverifiable hard claims remain.
