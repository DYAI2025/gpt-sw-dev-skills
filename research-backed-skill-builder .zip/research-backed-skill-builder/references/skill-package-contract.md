# Skill Package Contract

## Required structure

Every generated package must contain at least:

```text
<skill-name>/
├── SKILL.md
└── agents/
    └── openai.yaml
```

Use optional directories only when they reduce ambiguity or improve repeatability:

```text
<skill-name>/
├── references/   # long source policies, domain ontologies, validation rules
├── scripts/      # deterministic validators or helper utilities
└── assets/       # templates or non-reasoning assets
```

## Frontmatter rules

`SKILL.md` must begin with YAML frontmatter:

```yaml
---
name: lower-case-hyphen-name
description: third-person trigger and purpose description without angle brackets
---
```

Rules:
- `name` must match `^[a-z0-9]+(?:-[a-z0-9]+)*$`.
- `description` must explain when to use the skill and what it does.
- Do not include unsupported fields unless the target platform explicitly accepts them.

## Core SKILL.md sections

Use these sections unless there is a strong reason not to:

1. `## Wann verwenden`
2. `## Workflow / Anweisungen`
3. `## Ausgabeformat`
4. `## Beispiele`

For research-heavy skills add:
- `## Quellenstrategie`
- `## Confidence und Halluzinationsschutz`
- `## Post-Generation-Audit`

## Packaging response format

When returning a package in chat, use:

1. `FILETREE`
2. `ALLE DATEIEN`
3. optional `Bash-Installer`
4. `Packaging-Hinweis`

Each file block must start with:

```text
# path: <skill-name>/<relative-file>
```

## Progressive disclosure rule

Keep `SKILL.md` as the control plane. Move details to direct references if:
- the content is longer than 100 lines,
- it is domain-specific and not always needed,
- it is tabular,
- it is a source registry,
- it is an evaluation suite,
- it is executable logic.

Avoid nested reference chains. Every important reference must be directly named in `SKILL.md`.
