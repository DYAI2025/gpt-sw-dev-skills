# Japanese Typography and Shichu Suimei Research Notes

These notes organize the provided Japanese typography and astrology-related materials as a reference base for future skills. They are not a final factual authority. Treat them as project-specific source inventory and candidate ontology.

## 1. Japanese script architecture

Candidate ontology from the provided files:

- `hiragana`: soft, rounded phonographic script; grammar, particles, native Japanese words.
- `katakana`: angular phonographic script; loanwords, emphasis, technical or foreign terms.
- `kanji`: logographic / meaning-bearing characters; semantic density and cultural form.
- `romaji`: Latin letters; international names, acronyms and pragmatic global labels.

Candidate typography categories:

- `mincho-tai`: serif-like Japanese type category, associated with books, newspapers and formal tone.
- `gothic-tai`: sans-serif-like category, modern and legible for headings/UI.
- `kaisho`, `gyosho`, `reisho`, `tensho`, `sosho`: calligraphic or historical styles requiring context-specific validation.

Validation need:
- Confirm exact typographic claims against JLReq, font foundry documentation or Japanese typography references.
- Do not infer cultural effect directly from style without marking it as design interpretation.

## 2. Layout and punctuation rules

Candidate rules from the visual corpus:

- Japanese text may be horizontal (`yokogaki`) or vertical (`tategaki`).
- Vertical text normally flows top-to-bottom, with columns progressing right-to-left.
- Certain punctuation and marks rotate or change layout behavior in vertical writing.
- `kinsoku shori` governs line-start and line-end restrictions.
- `yakumono` includes punctuation and related typographic signs.
- `chōonpu` marks prolonged sound in katakana and must not be confused with a horizontal dash or the kanji for one in vertical layout.
- `nakaguro` separates items, foreign names or components in some contexts.

Validation need:
- Use W3C JLReq as primary source for Japanese layout and line composition.
- Use Unicode data for codepoints, variation sequences and Han source mappings.
- Use language tagging and font audit for Japanese glyph rendering.

## 3. Common western design errors to block

Candidate failure gates:

- Pseudo-Japanese or gibberish slogans.
- Random kanji used as decoration.
- Chinese fonts or Chinese glyph forms used for Japanese text without intent.
- Mixing Japanese and Latin fonts without kerning and baseline strategy.
- Treating kanji, kana and Latin as interchangeable visual ornaments.
- Using chop-suey/wonton-style Latin fonts as a substitute for Japanese typography.
- Omitting semantic validation of Japanese text in poster generation.

## 4. Shichu Suimei / BaZi / Gogyō caution

The provided astrology-related files contain a useful conceptual structure but require strict separation:

- `BaZi`: Chinese-origin four pillars / eight characters context.
- `Shichū Suimei`: Japanese development and terminology.
- `Gogyō`: Japanese five phases / five elements terminology.
- `Jukkan`: ten heavenly stems.
- `Jūnishi`: twelve earthly branches.
- `Meishiki`: chart layout.

Hard rule:
- Do not present metaphysical or psychological interpretations as verified fact.
- Mark interpretations as tradition-specific, school-specific, symbolic or creative unless independently sourced.
- Separate Japanese terminology from Chinese terminology.

## 5. Suggested future reference files for a dedicated Japanese skill

If building a dedicated Japanese typography/Shichū Suimei skill, create these references:

```text
references/
├── source-policy.md
├── script-ontology.md
├── yakumono-kinsoku-rules.md
├── unicode-glyph-validation.md
├── font-language-tagging.md
├── shichu-suimei-bazi-boundaries.md
├── poster-generation-audit.md
└── evaluation-plan.md
```

## 6. Failure gates for a dedicated Japanese poster skill

Set `FAIL` when:

- no source strategy exists,
- Japanese and Chinese systems are merged without distinction,
- pseudo-Japanese is not blocked,
- Han-Unification and glyph variants are not checked,
- image/poster output is not audited after generation,
- generated Japanese text is not semantically verified,
- no MISSING/SOURCE_NEEDED policy exists,
- confidence scoring is absent.
