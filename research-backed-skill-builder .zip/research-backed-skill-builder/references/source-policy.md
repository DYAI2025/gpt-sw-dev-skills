# Source Policy for Research-Backed Skill Building

## Purpose

Use this policy whenever a skill is built from documents, images, notes, web research, standards, APIs, repositories, or mixed evidence. The policy prevents source laundering: user-provided or model-derived material must not be silently upgraded into factual authority.

## Source classes

| Class | Definition | Use in skill |
|---|---|---|
| `primary` | Official standard, specification, product documentation, original dataset, source repository, legal/regulatory text | May define operational rules if current enough |
| `secondary` | Expert explanation, textbook, reputable article, curated teaching material | Use for context; do not override primary sources |
| `user_provided` | Files, notes, PDFs, screenshots, tables or claims supplied by the user | Treat as project context; verify before factual hardening |
| `derived` | OCR, summaries, mindmaps, model-generated extraction, transformed data | Use as navigation layer only; check against originals |
| `uncertain` | Unattributed, contradictory, incomplete, or unverifiable material | Do not convert into rules without explicit SOURCE_NEEDED |

## Required source map fields

For every source, record:

```text
source_id:
  title:
  type: primary | secondary | user_provided | derived | uncertain
  location:
  purpose:
  reliability:
  limitations:
  use_in_skill:
  confidence_default: 1-5
```

## MISSING and SOURCE_NEEDED policy

Use `MISSING` when required information is absent.

Use `SOURCE_NEEDED` when information exists but is not adequately supported by reliable evidence.

Do not invent:
- standards or version numbers
- API parameters
- legal, medical, financial or safety rules
- linguistic readings or translations
- cultural or historical claims
- market metrics or demand estimates

## Confidence scale

| Score | Meaning | Allowed usage |
|---|---|---|
| 5 | Directly supported by primary source and current enough | Rule or hard requirement |
| 4 | Supported by strong source or convergent evidence | Recommendation or rule with citation |
| 3 | Plausible but indirect or incomplete evidence | Mark as assumption |
| 2 | Weak, conflicting, old, or context-specific evidence | Do not operationalize without warning |
| 1 | Unsupported, speculative, or contradicted | Block or mark SOURCE_NEEDED |

## Claim discipline

Split outputs into three claim types:

1. `fact`: source-backed statement.
2. `inference`: explicit reasoning from facts.
3. `recommendation`: design or workflow choice based on goal and constraints.

A recommendation may be useful without being a fact, but it must not pretend to be one.

## Current-information rule

If the answer depends on information that can change after the knowledge cutoff, use web or connector search where available. Examples:
- software APIs
- product capabilities
- standards versions
- legal/regulatory requirements
- prices, rankings, market demand, SEO metrics
- current tool support

If search is unavailable, state the limitation and mark dynamic claims as `SOURCE_NEEDED`.
