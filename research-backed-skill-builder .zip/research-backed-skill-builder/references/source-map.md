# Source Map for the Attached Corpus

This file organizes the current project materials as reusable references for future skill construction. It does not treat user-provided material as automatically true. It assigns a role and default confidence to each source.

## A. Skill-building meta-references

### evaluation.md
- type: `user_provided`
- purpose: Criteria for MCP-server evaluations: read-only tasks, independent questions, stable answers, direct string comparison, XML output.
- reliability: Strong as a project convention; not an external standard unless separately sourced.
- use_in_skill: Load when building skills that include tool/MCP evaluation plans.
- confidence_default: 4 for internal process rules, 2 for claims about external MCP ecosystems.

### self_bias_check.md / universal-bias-self-check/SKILL.md
- type: `user_provided`
- purpose: Self-audit pattern for hallucination checks, claim classification, bias identification and answer revision.
- reliability: Strong as a project policy.
- use_in_skill: Load when a new skill needs a final audit block or confidence discipline.
- confidence_default: 4 for internal process rules.

### skill-building-orchestrator.md
- type: `user_provided`
- purpose: Orchestrator pattern for building, testing and packaging skills with FILETREE, files, installer and packaging commands.
- reliability: Strong as project convention.
- use_in_skill: Load when building or updating any Skill-Trainer-compatible package.
- confidence_default: 4 for package-format rules.

### skill.md / SKILL.md variants
- type: `user_provided`
- purpose: Existing skill-builder contracts and examples of SKILL.md structure.
- reliability: Useful but potentially duplicative; reconcile conflicts by the active project contract.
- use_in_skill: Compare for frontmatter, references, examples and packaging conventions.
- confidence_default: 3 unless confirmed by current platform rules.

### persuasion-principles.md
- type: `user_provided`
- purpose: Guidance on using authority, commitment and social proof in discipline-enforcing skills.
- reliability: Process design reference; claims about studies require external verification if surfaced as facts.
- use_in_skill: Load when a skill must enforce non-negotiable behavior.
- confidence_default: 3 for external research claims, 4 for internal writing heuristics.

### graphviz-conventions.dot
- type: `user_provided`
- purpose: Visual grammar for process diagrams: diamonds for questions, boxes for actions, plaintext for commands, octagons for warnings, double circles for entry/exit.
- reliability: Strong as internal style convention.
- use_in_skill: Load when a skill should emit process maps or flowcharts.
- confidence_default: 4.

## B. Japanese typography and writing-system corpus

### Japanese_Script_Architecture.pdf
- type: `user_provided`
- purpose: Visual teaching material about kanji, hiragana, katakana, rōmaji, dakuten, handakuten, sokuon, zenkaku, yakumono, chōonpu, tategaki/yokogaki, kinsoku and western adaptation errors.
- reliability: Useful as a project-specific visual ontology; verify operational rules against primary sources such as W3C JLReq and Unicode.
- use_in_skill: Load when building Japanese typography, poster-audit or localization skills.
- confidence_default: 3.

### Japanische_Typografie_fuer_westliche_Designer.jpg
- type: `user_provided`
- purpose: Infographic summarizing common western design errors, three script pillars, vertical/horizontal layout, punctuation and Han-unification warnings.
- reliability: Useful as design checklist; not sufficient as primary standard.
- use_in_skill: Load for quick poster/design audit criteria.
- confidence_default: 3.

### Übersicht japanischer Satzzeichen und ihre Anwendung - Table 1.csv
- type: `user_provided`
- purpose: Tabular reference for Japanese punctuation and usage.
- reliability: Useful if internally consistent; verify against JLReq for hard rules.
- use_in_skill: Convert into yakumono validation table if building a typography validator.
- confidence_default: 3.

### NotebookLM Mind Map (14).png
- type: `derived`
- purpose: Mindmap of Japanese type categories, writing systems, mincho/gothic styles, kaisho/gyosho/reisho/tensho/sosho, writing directions, zenkaku and Han-unification issues.
- reliability: Navigation aid only.
- use_in_skill: Use as structure for a domain ontology, then verify each rule.
- confidence_default: 2.

## C. Shichū Suimei / BaZi / Gogyō corpus

### Das_Meishiki_Manuskript.pdf and Das_Meishiki_Manuskript (1).pdf
- type: `user_provided`
- purpose: Visual material on Jūnishi, the 12 earthly branches, animal metaphors, Japanese boar vs. Chinese pig distinction, seasonal/botanical cycle interpretations and symbolic cards.
- reliability: Useful as creative/project concept; several historical and symbolic claims require external source verification.
- use_in_skill: Load for poster concept, ontology draft or claims-to-verify list.
- confidence_default: 2.

### The_Jukkan_Matrix.pdf
- type: `user_provided`
- purpose: Visual teaching material on Jukkan, five elements, yin/yang polarity, ten heavenly stems, archetypal interpretations, sōshō and sōkoku cycles.
- reliability: Useful as internal conceptual model; metaphysical/psychological interpretations require caveats.
- use_in_skill: Load for Shichū Suimei ontology drafts and audit rules separating fact, tradition and interpretation.
- confidence_default: 2.

### Architecture_of_Fate.pdf
- type: `user_provided`
- purpose: Visual material linking BaZi, Shichū Suimei, Meishiki layout, Sanchū Suimei, Gogyō, Jukkan phonetics, Jūnishi, Kimon, Tsiūhensei and ritual typography.
- reliability: Useful as project vision; needs strict verification and separation of cultural, historical and interpretive layers.
- use_in_skill: Load when building a Japanese astrology/poster workflow, but enforce SOURCE_NEEDED for strong historical claims.
- confidence_default: 2.

### NotebookLM Mind Map (15).png
- type: `derived`
- purpose: Mindmap contrasting Japanese Shichū Suimei and Chinese BaZi: terminology, glyph differences, phonetics, 12th earthly branch, symbolic differences and syncretism.
- reliability: Navigation aid only.
- use_in_skill: Use as checklist for Japan/China separation, not as evidence.
- confidence_default: 2.

## D. Prior skill examples and project notes

### Sprintplanning Skill Miro.txt
- type: `user_provided`
- purpose: Example of a complete operational skill with SKILL.md, agents/openai.yaml, references and scripts.
- reliability: Useful implementation example.
- use_in_skill: Load when modeling a multi-file skill with scripts and reference playbooks.
- confidence_default: 4 for packaging pattern.

### SIP Skill Analyse.txt
- type: `user_provided`
- purpose: Skill analysis notes.
- reliability: Internal review material.
- use_in_skill: Load only when relevant to skill evaluation or improvement.
- confidence_default: 3.

### japan_typografie-1.zip
- type: `user_provided`
- purpose: Prior attempted package for Japanese typography references.
- reliability: Failed formal skill validation in the prior audit; treat as raw reference material, not a valid skill.
- use_in_skill: Unpack only to salvage content into references/ after validation.
- confidence_default: 2.

## E. Recommended external primary sources for Japanese typography skills

Use these categories as primary sources when web access is available:
- W3C JLReq for Japanese layout, line composition, yakumono, vertical/horizontal writing and kinsoku.
- Unicode UAX #38 for Unihan database, IRG sources, Japanese source mappings and Jōyō/Jinmeiyō properties.
- Unicode UTS #37 for Ideographic Variation Database and IVS.
- W3C Internationalization material for language tagging and language-sensitive font selection.
