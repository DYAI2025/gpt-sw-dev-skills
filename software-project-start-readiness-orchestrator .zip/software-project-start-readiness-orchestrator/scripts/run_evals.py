#!/usr/bin/env python3
"""Run deterministic, in-process evaluation and fixture checks.

The suite uses only local synthetic fixtures. It never contacts or mutates Jira.
"""
from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict, deque
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from _common import ensure_unique, load_json, validate_schema
from build_jira_manifest import build_manifest
from classify_project import classify


def evidence_errors(data: dict[str, Any], schema: Path) -> list[str]:
    errors = validate_schema(data, schema)
    facts = data.get("facts", [])
    errors += ensure_unique((item.get("id", "") for item in facts), "evidence id")
    for item in facts:
        item_id = item.get("id", "UNKNOWN")
        state = item.get("status")
        confidence = item.get("confidence", 0)
        if state == "VERIFIED" and (confidence < 4 or not item.get("source_refs")):
            errors.append(f"{item_id}: VERIFIED requires confidence >=4 and source_refs")
        if state == "DERIVED" and not item.get("derived_from"):
            errors.append(f"{item_id}: DERIVED requires derived_from")
        if state == "ASSUMPTION" and (not item.get("test_or_resolution") or not item.get("expires_at")):
            errors.append(f"{item_id}: ASSUMPTION requires test_or_resolution and expires_at")
        if state in {"MISSING", "SOURCE_NEEDED", "CONFLICT", "BLOCKER"} and confidence > 3:
            errors.append(f"{item_id}: unresolved state cannot have confidence >3")
    return errors


def artifact_errors(data: dict[str, Any], schema: Path) -> list[str]:
    errors = validate_schema(data, schema)
    items = data.get("artifacts", [])
    errors += ensure_unique((item.get("id", "") for item in items), "artifact id")
    for item in items:
        item_id = item.get("id", "UNKNOWN")
        if item.get("applicability_class") == "mandatory" and item.get("applicability_state") != "required":
            errors.append(f"{item_id}: mandatory artifact must be required")
        if item.get("applicability_class") == "conditional" and item.get("applicability_state") == "not_applicable" and not item.get("not_applicable_rationale"):
            errors.append(f"{item_id}: conditional not_applicable requires rationale")
    return errors


def traceability_errors(data: dict[str, Any], schema: Path) -> list[str]:
    errors = validate_schema(data, schema)
    nodes = data.get("nodes", [])
    links = data.get("links", [])
    errors += ensure_unique((node.get("id", "") for node in nodes), "node id")
    node_map = {node.get("id"): node for node in nodes}
    graph: dict[str, set[str]] = defaultdict(set)
    for link in links:
        source, target = link.get("source"), link.get("target")
        if source not in node_map:
            errors.append(f"link source not found: {source}")
        if target not in node_map:
            errors.append(f"link target not found: {target}")
        if source in node_map and target in node_map and link.get("status") != "superseded":
            graph[source].add(target)
            graph[target].add(source)
    for outcome in data.get("critical_outcomes", []):
        start = outcome.get("outcome_node_id")
        if start not in node_map:
            errors.append(f"critical outcome node not found: {start}")
            continue
        seen, queue = {start}, deque([start])
        while queue:
            current = queue.popleft()
            for neighbour in graph[current]:
                if neighbour not in seen:
                    seen.add(neighbour)
                    queue.append(neighbour)
        reachable_types = {node_map[node_id].get("type") for node_id in seen}
        missing = [required for required in outcome.get("required_node_types", []) if required not in reachable_types]
        if missing:
            errors.append(f"{start}: missing reachable node types {missing}")
    return errors


def gate_errors(data: dict[str, Any], schema: Path) -> list[str]:
    errors = validate_schema(data, schema)
    state = data.get("state")
    open_blockers = [item for item in data.get("hard_blockers", []) if item.get("status") == "open"]
    authority = data.get("authorized_decision", {})
    if open_blockers and state != "BLOCKED":
        errors.append("open hard blockers require state BLOCKED")
    if state == "APPROVED":
        if authority.get("decision") != "APPROVED":
            errors.append("APPROVED requires authorized decision APPROVED")
        if authority.get("decider") in {None, "", "MISSING"} or authority.get("authority_evidence") in {None, "", "MISSING"}:
            errors.append("APPROVED requires decider and authority evidence")
    if state == "CONDITIONAL_APPROVAL" and not data.get("conditions"):
        errors.append("conditional approval requires conditions")
    return errors


def jira_errors(data: dict[str, Any], schema: Path) -> list[str]:
    errors = validate_schema(data, schema)
    operations = data.get("operations", [])
    errors += ensure_unique((item.get("idempotency_key", "") for item in operations), "idempotency key")
    write_actions = {"create", "update", "link", "transition"}
    for item in operations:
        if item.get("action") in write_actions:
            if not item.get("rollback_or_compensation"):
                errors.append(f"{item.get('id')}: write action lacks rollback/compensation")
            if not item.get("verification"):
                errors.append(f"{item.get('id')}: write action lacks verification")
    if data.get("mode") == "apply":
        authority = data.get("authorization", {})
        if authority.get("vision_status") != "VISION_CONFIRMED":
            errors.append("apply requires VISION_CONFIRMED")
        if authority.get("gate_state") not in {"APPROVED", "CONDITIONAL_APPROVAL"}:
            errors.append("apply requires an approved gate")
        if authority.get("mutation_authorized") is not True:
            errors.append("apply requires explicit mutation authorization")
        if authority.get("authorized_decision_ref") in {None, "", "MISSING"}:
            errors.append("apply requires authorized decision reference")
        if authority.get("authorized_by") in {None, "", "MISSING"}:
            errors.append("apply requires authorized_by")
        if any(item.get("action") == "blocked" for item in operations):
            errors.append("apply contains blocked operations")
    return errors


def verify_readback(manifest: dict[str, Any], snapshot: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    results = snapshot.get("operation_results", {})
    for operation in manifest.get("operations", []):
        if operation.get("action") in {"create", "update", "link", "transition"}:
            if results.get(operation.get("id")) != operation.get("desired_state"):
                errors.append(f"read-back mismatch for {operation.get('id')}")
    return errors


def eval_asset_errors(eval_dir: Path) -> tuple[list[str], dict[str, int]]:
    errors: list[str] = []
    counts: dict[str, int] = {}
    files = {
        "trigger": ("trigger_queries.json", 10),
        "non_trigger": ("non_trigger_queries.json", 10),
        "output": ("output_evals.json", 10),
        "interview": ("interview_scenarios.json", 6),
        "gate": ("gate_scenarios.json", 6),
        "jira_capability": ("jira_capability_scenarios.json", 6),
        "regression": ("regression_cases.json", 15),
    }
    for label, (name, minimum) in files.items():
        data = load_json(eval_dir / name)
        counts[label] = len(data) if isinstance(data, list) else 0
        if counts[label] < minimum:
            errors.append(f"{label} eval count below {minimum}")
    pressure = (eval_dir / "pressure_scenarios.md").read_text(encoding="utf-8")
    counts["pressure"] = len(re.findall(r"^##\s+P-\d+", pressure, flags=re.MULTILINE))
    if counts["pressure"] < 10:
        errors.append("pressure eval count below 10")
    pairs = ET.parse(eval_dir / "jira_read_only_evals.xml").findall(".//qa_pair")
    counts["jira_read_only"] = len(pairs)
    if counts["jira_read_only"] < 10:
        errors.append("Jira read-only eval count below 10")
    return errors, counts


def cli() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("eval_dir", nargs="?", default="evals")
    parser.add_argument("--output", help="optional JSON report path")
    args = parser.parse_args()
    eval_dir = Path(args.eval_dir).resolve()
    root = eval_dir.parent
    fixtures = eval_dir / "fixtures"
    schemas = root / "schemas"

    checks: list[dict[str, Any]] = []

    def record(name: str, problems: list[str]) -> None:
        checks.append({"name": name, "status": "PASS" if not problems else "FAIL", "errors": problems})

    asset_problems, counts = eval_asset_errors(eval_dir)
    record("evaluation asset coverage", asset_problems)

    profile_input = load_json(fixtures / "classification-input.json")
    profile = classify(profile_input)
    profile_problems = validate_schema(profile, schemas / "project-profile.schema.json")
    if profile.get("overall_profile") != "S3":
        profile_problems.append("classification fixture must escalate overall profile to S3")
    record("dimensional classification", profile_problems)

    evidence = load_json(fixtures / "fact-register.valid.json")
    record("valid evidence ledger", evidence_errors(evidence, schemas / "evidence-ledger.schema.json"))
    artifact = load_json(fixtures / "artifact-register.valid.json")
    record("valid artifact register", artifact_errors(artifact, schemas / "artifact-register.schema.json"))
    trace = load_json(fixtures / "traceability.valid.json")
    record("complete traceability fixture", traceability_errors(trace, schemas / "traceability.schema.json"))

    approved_gate = load_json(fixtures / "gate-record.valid-approved.json")
    blocked_gate = load_json(fixtures / "gate-record.valid-blocked.json")
    record("approved gate fixture", gate_errors(approved_gate, schemas / "gate-record.schema.json"))
    record("blocked gate fixture", gate_errors(blocked_gate, schemas / "gate-record.schema.json"))

    dry_manifest = load_json(fixtures / "jira-manifest.valid-dry-run.json")
    apply_manifest = load_json(fixtures / "jira-manifest.valid-apply.json")
    record("valid Jira dry-run manifest", jira_errors(dry_manifest, schemas / "jira-manifest.schema.json"))
    record("valid Jira apply manifest", jira_errors(apply_manifest, schemas / "jira-manifest.schema.json"))
    valid_readback = load_json(fixtures / "jira-readback.valid.json")
    record("valid Jira read-back", verify_readback(apply_manifest, valid_readback))

    generated_manifest = build_manifest(profile, load_json(fixtures / "jira-sandbox-snapshot.json"))
    generated_problems = jira_errors(generated_manifest, schemas / "jira-manifest.schema.json")
    if not generated_manifest.get("unsupported_actions"):
        generated_problems.append("S3-on-J2 synthetic snapshot should expose a hierarchy capability blocker")
    record("generated dry-run manifest", generated_problems)

    negative_evidence = load_json(fixtures / "negative/fact-register.invalid.json")
    negative_evidence_problems = evidence_errors(negative_evidence, schemas / "evidence-ledger.schema.json")
    record("negative evidence fixture rejected", [] if negative_evidence_problems else ["invalid evidence fixture unexpectedly passed"])

    negative_manifest = load_json(fixtures / "negative/jira-manifest.invalid-apply.json")
    negative_manifest_problems = jira_errors(negative_manifest, schemas / "jira-manifest.schema.json")
    record("negative apply fixture rejected", [] if negative_manifest_problems else ["invalid apply fixture unexpectedly passed"])

    invalid_readback = load_json(fixtures / "negative/jira-readback.invalid.json")
    mismatch = verify_readback(apply_manifest, invalid_readback)
    record("negative read-back fixture rejected", [] if mismatch else ["mismatching read-back unexpectedly passed"])

    failed = [item for item in checks if item["status"] != "PASS"]
    payload = {
        "status": "PASS" if not failed else "FAIL",
        "eval_counts": counts,
        "check_count": len(checks),
        "checks": checks,
        "failed_checks": failed,
        "fixture_policy": "local synthetic fixtures only; no live Jira mutation",
    }
    text = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        Path(args.output).write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    return 0 if payload["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(cli())
