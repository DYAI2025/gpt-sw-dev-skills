#!/usr/bin/env python3
"""Compare a Jira provisioning manifest with a local read-back snapshot.

The script is read-only. It never contacts Jira. The snapshot must map
operation IDs to the observed post-apply state under ``operation_results``.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from _common import load_json, main_guard


def normalize(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: normalize(val) for key, val in sorted(value.items())}
    if isinstance(value, list):
        return [normalize(item) for item in value]
    return value


def cli() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", help="local Jira manifest JSON")
    parser.add_argument("readback_snapshot", help="local read-back snapshot JSON")
    parser.add_argument("--output", help="optional report JSON path")
    args = parser.parse_args()

    manifest = load_json(args.manifest)
    readback = load_json(args.readback_snapshot)
    results: list[dict[str, Any]] = []
    failures = 0
    incomplete = 0

    for operation in manifest.get("operations", []):
        operation_id = str(operation.get("id", "UNKNOWN"))
        action = operation.get("action")
        expected = normalize(operation.get("desired_state"))
        actual = normalize(readback.get("operation_results", {}).get(operation_id))

        if action in {"none"}:
            status = "NO_CHANGE_REQUIRED"
            matched = normalize(operation.get("observed_state")) == expected or actual == expected
            if not matched:
                incomplete += 1
        elif action in {"manual", "blocked"}:
            status = "NOT_APPLIED"
            matched = False
            incomplete += 1
        else:
            matched = actual == expected
            status = "VERIFIED" if matched else "MISMATCH"
            if not matched:
                failures += 1

        results.append(
            {
                "operation_id": operation_id,
                "action": action,
                "status": status,
                "matched": matched,
                "expected": expected,
                "actual": actual,
            }
        )

    completion_allowed = failures == 0 and incomplete == 0 and bool(results)
    report = {
        "status": "PASS" if failures == 0 else "FAIL",
        "manifest_version": manifest.get("manifest_version"),
        "verified_operations": results,
        "failure_count": failures,
        "incomplete_count": incomplete,
        "completion_claim_allowed": completion_allowed,
    }
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        Path(args.output).write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    main_guard(cli)
