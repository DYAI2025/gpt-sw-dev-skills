#!/usr/bin/env python3
"""Validate a fact register against schema and truth-status invariants."""
from __future__ import annotations
import argparse
from pathlib import Path
from _common import load_json, validate_schema, emit, main_guard, ensure_unique

def cli():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument("file"); ap.add_argument("--schema"); args=ap.parse_args()
    data=load_json(args.file); schema=Path(args.schema) if args.schema else Path(__file__).parents[1]/"schemas/fact-register.schema.json"
    errors=validate_schema(data,schema); warnings=[]
    facts=data.get("facts",[]) if isinstance(data,dict) else []
    errors += ensure_unique((f.get("id","") for f in facts),"fact id")
    for f in facts:
        fid=f.get("id","UNKNOWN"); status=f.get("status"); confidence=f.get("confidence",0); sources=f.get("source_refs",[])
        if status == "VERIFIED" and (confidence < 4 or not sources): errors.append(f"{fid}: VERIFIED requires confidence >=4 and source_refs")
        if status=="DERIVED" and not f.get("derived_from"): errors.append(f"{fid}: DERIVED requires derived_from")
        if status=="ASSUMPTION" and (not f.get("test_or_resolution") or not f.get("expires_at")): errors.append(f"{fid}: ASSUMPTION requires test_or_resolution and expires_at")
        if status in {"MISSING","SOURCE_NEEDED","CONFLICT","BLOCKER"} and confidence>3: errors.append(f"{fid}: unresolved status cannot have confidence >3")
        if status=="NOT_APPLICABLE" and not f.get("notes"): errors.append(f"{fid}: NOT_APPLICABLE requires rationale in notes")
        if f.get("criticality") in {"high","critical"} and status in {"MISSING","SOURCE_NEEDED","CONFLICT"}: warnings.append(f"{fid}: unresolved high-impact fact should be treated as a blocker by the gate")
    return emit("PASS" if not errors else "FAIL",errors,warnings,fact_count=len(facts))
if __name__=="__main__": main_guard(cli)
