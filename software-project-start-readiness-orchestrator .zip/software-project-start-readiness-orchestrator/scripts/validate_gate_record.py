#!/usr/bin/env python3
"""Validate a gate record and prevent approval with unresolved hard blockers."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
from pathlib import Path
from _common import load_json, validate_schema, emit, main_guard
CRITICAL_DOMAINS={"Governance and Ownership","Funding and Capacity","Security/Privacy/Safety/Compliance","Architecture and Data","Quality and Validation","Operations and Release","Jira/Tooling Readiness"}
def cli():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument("file"); ap.add_argument("--schema"); args=ap.parse_args()
    data=load_json(args.file); schema=Path(args.schema) if args.schema else Path(__file__).parents[1]/"schemas/gate-record.schema.json"
    errors=validate_schema(data,schema); warnings=[]
    state=data.get("state"); open_blockers=[b for b in data.get("hard_blockers",[]) if b.get("status")=="open"]
    auth=data.get("authorized_decision",{}); domains=data.get("evidence_domains",[])
    if open_blockers and state!="BLOCKED": errors.append("open hard blockers require state BLOCKED")
    if state=="APPROVED":
        if open_blockers: errors.append("APPROVED cannot contain open hard blockers")
        if auth.get("decision")!="APPROVED": errors.append("APPROVED requires authorized decision APPROVED")
        if auth.get("decider") in {None,"","MISSING"} or auth.get("authority_evidence") in {None,"","MISSING"}: errors.append("APPROVED requires decider and authority evidence")
        for d in domains:
            if d.get("domain") in CRITICAL_DOMAINS and (d.get("state") in {"NOT_MET","UNKNOWN"} or d.get("confidence",0)<4): errors.append(f"critical domain not approval-ready: {d.get('domain')}")
    if state=="CONDITIONAL_APPROVAL":
        if auth.get("decision")!="CONDITIONAL_APPROVAL": errors.append("conditional approval requires matching authorized decision")
        if not data.get("conditions"): errors.append("conditional approval requires explicit conditions")
        for c in data.get("conditions",[]):
            if c.get("status")=="breached": errors.append(f"condition breached: {c.get('id')}")
    valid_until=data.get("valid_until")
    if state in {"APPROVED","CONDITIONAL_APPROVAL"} and not valid_until: errors.append("approval requires valid_until")
    if valid_until:
        try:
            dt=datetime.fromisoformat(valid_until.replace('Z','+00:00'))
            if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
            if dt < datetime.now(timezone.utc) and state not in {"EXPIRED","REVOKED"}: warnings.append("gate validity is in the past and should be EXPIRED")
        except ValueError: pass
    return emit("PASS" if not errors else "FAIL",errors,warnings,state=state,open_blocker_count=len(open_blockers))
if __name__=="__main__": main_guard(cli)
