#!/usr/bin/env python3
"""Validate and package one skill directory as skill.zip plus SHA-256 file."""
from __future__ import annotations
import argparse
import hashlib
import subprocess
import sys
import zipfile
from pathlib import Path
from _common import resolve_skill_dir, main_guard

EXCLUDED_NAMES={"__pycache__",".DS_Store","skill.zip","skill.zip.sha256"}
EXCLUDED_SUFFIXES={".pyc",".pyo"}

def include(path: Path) -> bool:
    return not any(part in EXCLUDED_NAMES for part in path.parts) and path.suffix not in EXCLUDED_SUFFIXES

def sha256(path: Path) -> str:
    digest=hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024*1024),b""):
            digest.update(chunk)
    return digest.hexdigest()

def cli() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("skill_dir", help="skill directory to package")
    ap.add_argument("output_dir", nargs="?", default="./dist", help="destination directory")
    args=ap.parse_args()
    root=resolve_skill_dir(args.skill_dir)
    out=Path(args.output_dir).resolve(); out.mkdir(parents=True,exist_ok=True)

    validator=root/"scripts/validate_skill_package.py"
    proc=subprocess.run([sys.executable,str(validator),str(root)],capture_output=True,text=True,timeout=120)
    if proc.returncode:
        print(proc.stdout or proc.stderr,file=sys.stderr)
        return 1

    archive=out/"skill.zip"
    checksum=out/"skill.zip.sha256"
    for path in (archive,checksum):
        if path.exists(): path.unlink()
    with zipfile.ZipFile(archive,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zf:
        for path in sorted(root.rglob("*")):
            if path.is_file() and include(path):
                zf.write(path,Path(root.name)/path.relative_to(root))

    with zipfile.ZipFile(archive) as zf:
        names=zf.namelist()
        roots={name.split("/",1)[0] for name in names if name and not name.startswith("__MACOSX")}
        if roots!={root.name} or f"{root.name}/SKILL.md" not in names or f"{root.name}/agents/openai.yaml" not in names:
            print("archive root validation failed",file=sys.stderr)
            return 1

    digest=sha256(archive)
    checksum.write_text(f"{digest}  skill.zip\n",encoding="ascii")

    install_validator=root/"scripts/validate_installability.py"
    proc=subprocess.run([sys.executable,str(install_validator),str(root),"--archive",str(archive),"--checksum",str(checksum)],capture_output=True,text=True,timeout=60)
    if proc.returncode:
        print(proc.stdout or proc.stderr,file=sys.stderr)
        return 1
    print(str(archive))
    print(str(checksum))
    print(digest)
    return 0

if __name__=="__main__": main_guard(cli)
