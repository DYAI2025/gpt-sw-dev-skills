#!/usr/bin/env python3
"""Run the canonical local validation suite for the complete skill package."""
from __future__ import annotations

import argparse
import json
import py_compile
import re
import subprocess
import sys
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from _common import emit, main_guard, parse_frontmatter, resolve_skill_dir

EXPECTED_NAME = "software-project-start-readiness-orchestrator"
EXPECTED_DESCRIPTION = (
    "researches, plans, generates, audits, gates, and provisions project-start foundations for software and product initiatives. "
    "use when requests involve project initiation, project charters, product vision, scaled agile setup, readiness or go-no-go gates, "
    "architecture, security, privacy, quality, operations, traceability, jira or confluence bootstrap, or controlled approval before implementation begins."
)

REQUIRED_FILES = {
    "SKILL.md",
    "README.md",
    "CHANGELOG.md",
    "LICENSE-NOTICE.md",
    "agents/openai.yaml",
    # References required by the user contract.
    "references/source-policy.md",
    "references/source-map.md",
    "references/source-map.json",
    "references/requirements-traceability.md",
    "references/project-classification.md",
    "references/adaptive-interview.md",
    "references/product-vision-gate.md",
    "references/artifact-catalog.md",
    "references/operating-model-router.md",
    "references/governance-and-decision-rights.md",
    "references/start-gate-model.md",
    "references/traceability-model.md",
    "references/jira-provisioning.md",
    "references/jira-field-and-workflow-model.md",
    "references/security-privacy-safety-compliance.md",
    "references/quality-test-and-acceptance.md",
    "references/operations-release-and-handover.md",
    "references/visualization-rules.md",
    "references/coding-agent-handoff.md",
    "references/validation-rules.md",
    "references/compatibility-notes.md",
    "references/security-and-tools.md",
    "references/eval-design.md",
    "references/agent-agnostic-compatibility.md",
    # Templates.
    "templates/initiative-intake.md",
    "templates/project-charter.md",
    "templates/lean-business-case.md",
    "templates/product-vision.md",
    "templates/product-goal-and-outcomes.md",
    "templates/project-profile.md",
    "templates/artifact-register.md",
    "templates/decision-rights.md",
    "templates/stakeholder-register.md",
    "templates/evidence-ledger.md",
    "templates/traceability-matrix.md",
    "templates/requirements-and-nfr.md",
    "templates/architecture-context.md",
    "templates/architecture-decision-record.md",
    "templates/threat-model.md",
    "templates/privacy-screening.md",
    "templates/quality-and-test-strategy.md",
    "templates/operational-readiness.md",
    "templates/risk-register.md",
    "templates/assumption-register.md",
    "templates/issue-register.md",
    "templates/dependency-register.md",
    "templates/decision-register.md",
    "templates/exception-register.md",
    "templates/readiness-report.md",
    "templates/gate-record.json",
    "templates/jira-provisioning-manifest.yaml",
    # Schemas.
    "schemas/project-profile.schema.json",
    "schemas/evidence-ledger.schema.json",
    "schemas/artifact-register.schema.json",
    "schemas/traceability.schema.json",
    "schemas/gate-record.schema.json",
    "schemas/jira-manifest.schema.json",
    # Deterministic scripts required by the prompt.
    "scripts/classify_project.py",
    "scripts/validate_skill_package.py",
    "scripts/validate_artifact_register.py",
    "scripts/validate_evidence_ledger.py",
    "scripts/validate_traceability.py",
    "scripts/validate_gate_record.py",
    "scripts/validate_jira_manifest.py",
    "scripts/build_jira_manifest.py",
    "scripts/verify_jira_state.py",
    "scripts/run_evals.py",
    "scripts/package_skill.py",
    # Evals.
    "evals/trigger_queries.json",
    "evals/non_trigger_queries.json",
    "evals/output_evals.json",
    "evals/interview_scenarios.json",
    "evals/pressure_scenarios.md",
    "evals/gate_scenarios.json",
    "evals/jira_capability_scenarios.json",
    "evals/jira_read_only_evals.xml",
    "evals/regression_cases.json",
    # Human-facing reports required by the prompt.
    "reports/source-audit.md",
    "reports/requirements-coverage.md",
    "reports/architecture-gate.md",
    "reports/validation-report.md",
    "reports/evaluation-report.md",
    "reports/installability-report.md",
    "reports/portability-report.md",
    "reports/bias-and-confabulation-audit.md",
    "reports/release-decision.md",
    # Enterprise gate reports.
    "reports/research-bag.json",
    "reports/pre-build-architecture-gate.json",
    "reports/release-gate-report.json",
    "reports/installability-report.json",
    "reports/agent-compatibility-report.json",
    "reports/core-functionality-preservation.json",
    "reports/enterprise-skill-evaluation.xml",
    # Editable visualization sources and rendered derivatives.
    "assets/templates/gate-flow.dot",
    "assets/templates/traceability-structure.dot",
    "assets/templates/decision-escalation-path.dot",
    "assets/rendered/gate-flow.svg",
    "assets/rendered/traceability-structure.svg",
    "assets/rendered/decision-escalation-path.svg",
}

SUB_VALIDATORS = [
    "validate_source_map.py",
    "validate_evals.py",
    "validate_release_gate.py",
    "validate_agent_agnostic.py",
    "validate_core_parity.py",
    "validate_no_placeholders.py",
    "validate_dot.py",
]


def run(command: list[str]) -> tuple[int, str]:
    process = subprocess.run(command, capture_output=True, text=True)
    detail = process.stdout.strip() or process.stderr.strip()
    return process.returncode, detail


def validate_yaml(path: Path) -> str | None:
    try:
        import yaml  # type: ignore

        yaml.safe_load(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return f"invalid YAML {path}: {exc}"
    return None


def cli() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_dir")
    args = parser.parse_args()
    root = resolve_skill_dir(args.skill_dir)
    errors: list[str] = []
    warnings: list[str] = []

    if root.name != EXPECTED_NAME:
        errors.append(f"folder name must be {EXPECTED_NAME}; got {root.name}")

    for relative in sorted(REQUIRED_FILES):
        path = root / relative
        if not path.is_file():
            errors.append(f"missing required file: {relative}")
        elif path.stat().st_size == 0:
            errors.append(f"empty required file: {relative}")

    skill_path = root / "SKILL.md"
    body = ""
    if skill_path.is_file():
        try:
            frontmatter, body = parse_frontmatter(skill_path)
        except ValueError as exc:
            errors.append(str(exc))
            frontmatter = {}
        if set(frontmatter) != {"name", "description"}:
            errors.append("SKILL.md frontmatter must contain exactly name and description")
        if frontmatter.get("name") != EXPECTED_NAME:
            errors.append("SKILL.md name does not match the required skill name")
        if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", frontmatter.get("name", "")):
            errors.append("SKILL.md name is not valid hyphen-case")
        if len(frontmatter.get("name", "")) > 64:
            errors.append("SKILL.md name exceeds 64 characters")
        if frontmatter.get("description") != EXPECTED_DESCRIPTION:
            errors.append("SKILL.md description differs from the binding build prompt")
        if len(body.splitlines()) > 500:
            errors.append("SKILL.md body exceeds 500 lines")
        references = set(
            match.rstrip(".,;:)")
            for match in re.findall(
                r"(?<![A-Za-z0-9_./-])((?:references|templates|scripts|assets|schemas|evals|reports)/[A-Za-z0-9_./-]+)",
                body,
            )
        )
        for reference in sorted(references):
            if not (root / reference).exists():
                errors.append(f"broken SKILL.md reference: {reference}")

    json_documents: dict[Path, Any] = {}
    for path in sorted(root.rglob("*.json")):
        try:
            json_documents[path] = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            errors.append(f"invalid JSON {path.relative_to(root)}: {exc}")
    for path in sorted(root.rglob("*.xml")):
        try:
            ET.parse(path)
        except Exception as exc:
            errors.append(f"invalid XML {path.relative_to(root)}: {exc}")
    for path in sorted(root.rglob("*.yaml")) + sorted(root.rglob("*.yml")):
        problem = validate_yaml(path)
        if problem:
            errors.append(problem.replace(str(root) + "/", ""))

    try:
        import jsonschema  # type: ignore
        for path in sorted((root / "schemas").glob("*.json")):
            if path in json_documents:
                try:
                    jsonschema.Draft202012Validator.check_schema(json_documents[path])
                except Exception as exc:
                    errors.append(f"invalid JSON Schema {path.relative_to(root)}: {exc}")
    except ImportError:
        warnings.append("jsonschema unavailable; schema meta-validation skipped")

    for path in sorted((root / "scripts").glob("*.py")):
        try:
            py_compile.compile(str(path), doraise=True)
        except Exception as exc:
            errors.append(f"Python compile failed {path.relative_to(root)}: {exc}")

    required_metadata = [
        "Dokument-ID", "Projekt-/Produkt-ID", "Owner", "Accountable Approver",
        "Status", "Version", "Effective Date", "Next Review Date",
        "Quellen/Evidenz", "Confidence", "Annahmen/Konflikte",
        "Traceability-Links", "Vertraulichkeit/Datenklassifikation",
        "Freigabestatus", "Änderungshistorie",
    ]
    for path in sorted((root / "templates").glob("*.md")):
        if path.name == "README.md":
            continue
        text = path.read_text(encoding="utf-8")
        missing = [item for item in required_metadata if item not in text]
        if missing:
            errors.append(f"template {path.relative_to(root)} lacks control metadata: {missing}")

    try:
        from _common import load_data, validate_schema
        for instance_rel, schema_rel in [
            ("templates/gate-record.json", "schemas/gate-record.schema.json"),
            ("templates/jira-provisioning-manifest.yaml", "schemas/jira-manifest.schema.json"),
        ]:
            instance_path, schema_path = root / instance_rel, root / schema_rel
            if instance_path.is_file() and schema_path.is_file():
                errors.extend(
                    f"{instance_rel}: {problem}"
                    for problem in validate_schema(load_data(instance_path), schema_path)
                )
    except ValueError as exc:
        errors.append(str(exc))

    # Source-map invariants.
    source_map = json_documents.get(root / "references/source-map.json", {})
    sources = source_map.get("sources", []) if isinstance(source_map, dict) else []
    source_ids = [item.get("id") for item in sources if isinstance(item, dict)]
    if len(source_ids) != len(set(source_ids)):
        errors.append("source-map contains duplicate source IDs")
    for source in sources:
        if source.get("type") not in {"primary", "secondary", "user_provided", "derived", "uncertain"}:
            errors.append(f"invalid source type for {source.get('id')}")
        confidence = source.get("confidence")
        if not isinstance(confidence, int) or not 1 <= confidence <= 5:
            errors.append(f"invalid confidence for {source.get('id')}")
        if source.get("recommended_use") == "rule" and isinstance(confidence, int) and confidence < 4:
            errors.append(f"source {source.get('id')} cannot support a hard rule")

    # Eval counts and contract shape.
    eval_counts = {
        "trigger": len(json_documents.get(root / "evals/trigger_queries.json", [])),
        "non_trigger": len(json_documents.get(root / "evals/non_trigger_queries.json", [])),
        "output": len(json_documents.get(root / "evals/output_evals.json", [])),
        "interview": len(json_documents.get(root / "evals/interview_scenarios.json", [])),
        "gate": len(json_documents.get(root / "evals/gate_scenarios.json", [])),
        "jira_capability": len(json_documents.get(root / "evals/jira_capability_scenarios.json", [])),
        "regression": len(json_documents.get(root / "evals/regression_cases.json", [])),
    }
    minima = {"trigger": 10, "non_trigger": 10, "output": 10, "interview": 6, "gate": 6, "jira_capability": 6, "regression": 15}
    for label, minimum in minima.items():
        if eval_counts[label] < minimum:
            errors.append(f"eval coverage {label} requires at least {minimum}; got {eval_counts[label]}")
    pressure_text = (root / "evals/pressure_scenarios.md").read_text(encoding="utf-8") if (root / "evals/pressure_scenarios.md").is_file() else ""
    pressure_count = len(re.findall(r"^##\s+P-\d+", pressure_text, flags=re.MULTILINE))
    if pressure_count < 10:
        errors.append(f"pressure evals require at least 10 scenarios; got {pressure_count}")
    try:
        jira_pairs = ET.parse(root / "evals/jira_read_only_evals.xml").findall(".//qa_pair")
    except Exception:
        jira_pairs = []
    if len(jira_pairs) < 10:
        errors.append(f"Jira read-only evals require at least 10 pairs; got {len(jira_pairs)}")

    # Release, installability, portability, and core-preservation gates.
    release = json_documents.get(root / "reports/release-gate-report.json", {})
    if release.get("release_gate", {}).get("status") != "PASS":
        errors.append("release gate status must be PASS")
    if release.get("release_gate", {}).get("allowed_to_package") is not True:
        errors.append("release gate must allow packaging")
    if release.get("craftsmanship_gate", {}).get("status") != "PASS":
        errors.append("craftsmanship gate must PASS")
    if release.get("anti_confabulation_gate", {}).get("status") != "PASS" or release.get("anti_confabulation_gate", {}).get("blocked_claims"):
        errors.append("anti-confabulation gate must PASS with no blocked claims")
    syc = release.get("anti_sycophancy", {})
    if syc.get("status") != "PASS" or syc.get("score", 99) >= syc.get("threshold", 3):
        errors.append("anti-sycophancy gate failed")
    if release.get("bias_gate", {}).get("status") != "PASS":
        errors.append("bias gate must PASS")

    installability = json_documents.get(root / "reports/installability-report.json", {})
    if installability.get("artifact_name") != "skill.zip":
        errors.append("installability artifact_name must be skill.zip")
    if installability.get("frontend_install_suggestion_status") == "guaranteed":
        errors.append("frontend install UI cannot be guaranteed")

    compatibility = json_documents.get(root / "reports/agent-compatibility-report.json", {})
    if compatibility.get("agent_agnostic_ready") is not True:
        errors.append("agent-agnostic report is not ready")
    if not compatibility.get("not_guaranteed"):
        errors.append("agent-agnostic report must state runtime limitations")

    parity = json_documents.get(root / "reports/core-functionality-preservation.json", {})
    if parity.get("unintended_core_changes"):
        errors.append("core-functionality report contains unintended changes")
    if parity.get("status") != "PASS":
        errors.append("core-functionality preservation must PASS")

    # Reject unfinished authoring markers but allow the explicit runtime statuses MISSING/SOURCE_NEEDED.
    marker_pattern = re.compile(r"\b(TODO|TBD|FIXME|PLACEHOLDER)\b|lorem ipsum|insert (text|content|name) here", re.IGNORECASE)
    for path in sorted(root.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts or path.suffix.lower() not in {".md", ".json", ".yaml", ".yml", ".py", ".xml", ".dot"}:
            continue
        if path.name in {"validate_no_placeholders.py", "quick_validate.py"}:
            continue
        if marker_pattern.search(path.read_text(encoding="utf-8", errors="replace")):
            errors.append(f"unfinished authoring marker in {path.relative_to(root)}")

    all_files = [path for path in root.rglob("*") if path.is_file() and "__pycache__" not in path.parts]
    for path in all_files:
        if path.stat().st_size == 0:
            errors.append(f"empty file: {path.relative_to(root)}")

    return emit(
        "PASS" if not errors else "FAIL",
        errors,
        warnings,
        skill=str(root),
        file_count=len(all_files),
        required_file_count=len(REQUIRED_FILES),
        eval_counts={**eval_counts, "pressure": pressure_count, "jira_read_only": len(jira_pairs)},
    )


if __name__ == "__main__":
    main_guard(cli)
