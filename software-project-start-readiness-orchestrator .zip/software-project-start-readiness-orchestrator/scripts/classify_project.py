#!/usr/bin/env python3
"""Classify a project into S0-S3 profiles from local JSON evidence.

Reads one JSON input and writes JSON to stdout or --output. No network calls.
Unknown critical facts remain blockers rather than being guessed.
"""
from __future__ import annotations
import argparse, json
from datetime import datetime, timezone
from pathlib import Path
from _common import load_json, main_guard

RANK = {"S0": 0, "S1": 1, "S2": 2, "S3": 3}

def raise_profile(profiles, domain, target, reason, triggers):
    if RANK[target] > RANK[profiles[domain]]:
        profiles[domain] = target
    triggers.append(f"{domain}:{target}: {reason}")

def classify(data):
    project_id = str(data.get("project_id", "MISSING"))
    profiles = {k: "S0" for k in ["delivery","security","privacy","safety","operations","commercial"]}
    triggers=[]; blockers=[]; assumptions=[]; dimensions=[]
    def value(name, default=None, critical=False):
        if name not in data:
            status = "BLOCKER" if critical else "ASSUMPTION"
            dimensions.append({"name":name,"value":default,"evidence_status":status,"source_refs":[],"notes":"input missing"})
            (blockers if critical else assumptions).append(f"{name} is missing")
            return default
        status = data.get("evidence_status", {}).get(name, "USER_STATED")
        dimensions.append({"name":name,"value":data[name],"evidence_status":status,"source_refs":data.get("source_refs",{}).get(name,[]),"notes":""})
        return data[name]
    team_count=value("team_count",1)
    production=value("production_bound",False)
    integrations=value("critical_integration_count",0)
    migration=value("migration_or_coexistence",False)
    sensitive=value("sensitive_data",False, critical=production)
    high_risk=value("likely_high_risk_processing",False)
    internet=value("internet_exposed",False)
    privileged=value("privileged_actions",False)
    safety=value("safety_impact",False)
    regulated=value("regulated_or_contractually_controlled",False)
    availability=value("availability_tier","low")
    vendors=value("critical_vendor_count",0)
    investment=value("material_investment_or_external_commitment",False)
    ai_autonomy=value("high_impact_ai_autonomy",False)
    if production: raise_profile(profiles,"delivery","S1","production-bound delivery",triggers); raise_profile(profiles,"operations","S1","production-bound service",triggers)
    if isinstance(team_count,int) and team_count>1: raise_profile(profiles,"delivery","S2","multiple teams",triggers)
    if isinstance(integrations,int) and integrations>=2: raise_profile(profiles,"delivery","S2","multiple critical integrations",triggers)
    if migration: raise_profile(profiles,"delivery","S2","migration or coexistence",triggers); raise_profile(profiles,"operations","S2","migration rollback and recovery",triggers)
    if internet or privileged: raise_profile(profiles,"security","S2","internet exposure or privileged actions",triggers)
    if sensitive and (internet or privileged): raise_profile(profiles,"security","S3","sensitive data with exposed or privileged path",triggers)
    if sensitive: raise_profile(profiles,"privacy","S2","sensitive/personal data",triggers)
    if high_risk: raise_profile(profiles,"privacy","S3","likely high-risk processing",triggers)
    if safety: raise_profile(profiles,"safety","S3","safety-affecting behavior",triggers)
    if regulated: raise_profile(profiles,"delivery","S2","regulated or contractually controlled",triggers)
    if availability in {"high","critical"}: raise_profile(profiles,"operations","S2" if availability=="high" else "S3",f"availability tier {availability}",triggers)
    if isinstance(vendors,int) and vendors>0: raise_profile(profiles,"commercial","S2","critical supplier dependency",triggers)
    if isinstance(vendors,int) and vendors>=3: raise_profile(profiles,"commercial","S3","multiple critical suppliers",triggers)
    if investment: raise_profile(profiles,"delivery","S2","material investment or external commitment",triggers)
    if ai_autonomy: raise_profile(profiles,"security","S3","high-impact autonomous behavior",triggers)
    overall=max(profiles.values(),key=lambda p:RANK[p])
    rationale=triggers[:] or ["bounded exploration with no escalation trigger"]
    return {
      "project_id":project_id,
      "classified_at":datetime.now(timezone.utc).isoformat(),
      "overall_profile":overall,
      "domain_profiles":profiles,
      "dimensions":dimensions,
      "escalation_triggers":triggers,
      "rationale":rationale,
      "assumptions":assumptions,
      "blockers":blockers,
      "approved_by":None,
      "approved_at":None
    }

def cli():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("input", help="local JSON file with project classification facts")
    ap.add_argument("--output", help="optional output JSON path")
    args=ap.parse_args()
    result=classify(load_json(args.input))
    text=json.dumps(result,ensure_ascii=False,indent=2)+"\n"
    if args.output: Path(args.output).write_text(text,encoding="utf-8")
    else: print(text,end="")
    return 0
if __name__=="__main__": main_guard(cli)
