#!/usr/bin/env python3
"""Render all DOT files with Graphviz when available; otherwise report skipped."""
from __future__ import annotations
import argparse, shutil, subprocess, tempfile
from pathlib import Path
from _common import emit, main_guard

def cli():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument("skill_dir"); args=ap.parse_args(); root=Path(args.skill_dir); dot=shutil.which('dot'); errors=[]; warnings=[]; files=list(root.rglob('*.dot'))
    if not dot: warnings.append('Graphviz dot not available; syntax rendering skipped'); return emit('PASS',errors,warnings,dot_files=len(files))
    with tempfile.TemporaryDirectory() as tmp:
        for p in files:
            out=Path(tmp)/(p.stem+'.svg')
            proc=subprocess.run([dot,'-Tsvg',str(p),'-o',str(out)],capture_output=True,text=True)
            if proc.returncode!=0: errors.append(f"{p.relative_to(root)}: {proc.stderr.strip()}")
    return emit('PASS' if not errors else 'FAIL',errors,warnings,dot_files=len(files))
if __name__=='__main__': main_guard(cli)
