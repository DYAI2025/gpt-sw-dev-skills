#!/usr/bin/env python3
"""Validate installability report, package root, and optional checksum."""
from __future__ import annotations
import argparse
import hashlib
import re
import zipfile
from pathlib import Path
from _common import load_json, emit, main_guard

def file_hash(path: Path) -> str:
    digest=hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda:handle.read(1024*1024),b""):
            digest.update(chunk)
    return digest.hexdigest()

def cli() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("skill_dir")
    ap.add_argument("--archive")
    ap.add_argument("--checksum")
    args=ap.parse_args()
    root=Path(args.skill_dir).resolve(); errors=[]; warnings=[]
    report=load_json(root/"reports/installability-report.json")
    if report.get("artifact_name")!="skill.zip": errors.append("artifact_name must be skill.zip")
    if report.get("frontend_install_suggestion_status") not in {"prepared","blocked","not_controlled_by_skill"}: errors.append("invalid frontend_install_suggestion_status")
    if str(report.get("frontend_install_suggestion_status")).lower()=="guaranteed": errors.append("frontend install UI cannot be guaranteed")
    for path in (root/"SKILL.md",root/"agents/openai.yaml"):
        if not path.is_file(): errors.append(f"missing {path.relative_to(root)}")

    archive_path=None
    if args.archive:
        archive_path=Path(args.archive)
        if archive_path.name!="skill.zip": errors.append("primary archive must be named skill.zip")
        if not archive_path.is_file(): errors.append(f"archive not found: {archive_path}")
        else:
            try:
                with zipfile.ZipFile(archive_path) as zf:
                    bad=zf.testzip()
                    if bad: errors.append(f"corrupt archive member: {bad}")
                    names=zf.namelist()
                    roots={name.split("/",1)[0] for name in names if name and not name.startswith("__MACOSX")}
                    if roots!={root.name}: errors.append(f"archive must contain exactly root {root.name}; got {sorted(roots)}")
                    if f"{root.name}/SKILL.md" not in names: errors.append("archive lacks root SKILL.md")
                    if f"{root.name}/agents/openai.yaml" not in names: errors.append("archive lacks agents/openai.yaml")
                    if any("/__pycache__/" in name or name.endswith((".pyc",".pyo")) for name in names): errors.append("archive contains Python cache files")
            except zipfile.BadZipFile as exc:
                errors.append(f"invalid ZIP: {exc}")

    if args.checksum:
        checksum_path=Path(args.checksum)
        if checksum_path.name!="skill.zip.sha256": errors.append("checksum file must be named skill.zip.sha256")
        if not checksum_path.is_file(): errors.append(f"checksum not found: {checksum_path}")
        elif archive_path and archive_path.is_file():
            text=checksum_path.read_text(encoding="ascii").strip()
            match=re.fullmatch(r"([0-9a-f]{64})\s+\*?skill\.zip",text)
            if not match: errors.append("checksum file has invalid format")
            elif match.group(1)!=file_hash(archive_path): errors.append("checksum does not match skill.zip")

    return emit("PASS" if not errors else "FAIL",errors,warnings,chatgpt_install_ready=report.get("chatgpt_install_ready"))

if __name__=="__main__": main_guard(cli)
