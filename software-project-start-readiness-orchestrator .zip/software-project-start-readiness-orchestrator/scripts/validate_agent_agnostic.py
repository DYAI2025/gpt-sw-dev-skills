#!/usr/bin/env python3
"""Validate agent-agnostic compatibility report and runtime limitations."""
from __future__ import annotations
import argparse
from pathlib import Path
from _common import load_json, emit, main_guard

def cli():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument("skill_dir"); args=ap.parse_args(); root=Path(args.skill_dir); errors=[]
    report=load_json(root/"reports/agent-compatibility-report.json")
    if report.get("agent_agnostic_ready") is not True: errors.append("agent_agnostic_ready must be true")
    for field in ["portable_components","runtime_specific_components","not_guaranteed"]:
        if not isinstance(report.get(field),list) or not report[field]: errors.append(f"{field} must be a non-empty list")
    if not (root/"references/agent-agnostic-compatibility.md").is_file(): errors.append("missing compatibility reference")
    joined=' '.join(report.get("not_guaranteed",[])).lower()
    for concept in ["tool","install","permission"]:
        if concept not in joined: errors.append(f"not_guaranteed should cover {concept}")
    return emit("PASS" if not errors else "FAIL",errors,[],tested_runtimes=report.get("tested_runtimes",[]))
if __name__=="__main__": main_guard(cli)
