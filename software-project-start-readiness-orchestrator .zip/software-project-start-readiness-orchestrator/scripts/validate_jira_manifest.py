#!/usr/bin/env python3
"""Validate a Jira provisioning manifest and enforce mutation gates."""
from __future__ import annotations
import argparse
from pathlib import Path
from _common import load_data, validate_schema, emit, main_guard, ensure_unique
WRITE_ACTIONS={"create","update","link","transition"}
def cli():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument("file"); ap.add_argument("--schema"); args=ap.parse_args()
    data=load_data(args.file); schema=Path(args.schema) if args.schema else Path(__file__).parents[1]/"schemas/jira-provisioning.schema.json"
    errors=validate_schema(data,schema); warnings=[]
    ops=data.get("operations",[]) if isinstance(data,dict) else []
    errors+=ensure_unique((op.get("idempotency_key","") for op in ops),"idempotency key")
    for op in ops:
        if op.get("action") in WRITE_ACTIONS:
            if not op.get("rollback_or_compensation"): errors.append(f"{op.get('id')}: write action lacks rollback/compensation")
            if not op.get("verification"): errors.append(f"{op.get('id')}: write action lacks read-back verification")
    if data.get("mode")=="apply":
        auth=data.get("authorization",{})
        if auth.get("vision_status")!="VISION_CONFIRMED": errors.append("apply requires VISION_CONFIRMED")
        if auth.get("gate_state") not in {"APPROVED","CONDITIONAL_APPROVAL"}: errors.append("apply requires approved gate state")
        if not auth.get("mutation_authorized"): errors.append("apply requires explicit mutation authorization")
        if auth.get("authorized_decision_ref") in {None,"","MISSING"}: errors.append("apply requires authorized decision reference")
        if auth.get("authorized_by") in {None,"","MISSING"}: errors.append("apply requires authorized_by")
        if data.get("target_site") in {None,"","MISSING"}: errors.append("apply requires concrete target_site")
        blocked=[op.get("id") for op in ops if op.get("action")=="blocked"]
        if blocked: errors.append(f"apply contains blocked operations: {blocked}")
    if data.get("mode")=="dry-run" and data.get("authorization",{}).get("mutation_authorized"):
        warnings.append("dry-run manifest marks mutation_authorized=true; no writes are permitted in dry-run mode")
    return emit("PASS" if not errors else "FAIL",errors,warnings,operation_count=len(ops),mode=data.get("mode"))
if __name__=="__main__": main_guard(cli)
