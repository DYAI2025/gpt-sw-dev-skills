#!/usr/bin/env python3
"""Validate reports/release-gate-report.json against enterprise stop rules."""
from __future__ import annotations
import argparse
from pathlib import Path
from _common import load_json, emit, main_guard

def cli():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument("skill_dir"); args=ap.parse_args(); data=load_json(Path(args.skill_dir)/"reports/release-gate-report.json"); errors=[]
    rg=data.get("release_gate",{}); craft=data.get("craftsmanship_gate",{}); anti=data.get("anti_confabulation_gate",{}); syc=data.get("anti_sycophancy",{}); bias=data.get("bias_gate",{})
    if rg.get("status")!="PASS": errors.append("release_gate.status must be PASS")
    if rg.get("allowed_to_package") is not True: errors.append("allowed_to_package must be true")
    if craft.get("status")!="PASS": errors.append("craftsmanship_gate must PASS")
    if anti.get("status")!="PASS": errors.append("anti_confabulation_gate must PASS")
    if anti.get("blocked_claims"): errors.append("blocked_claims must be empty")
    if syc.get("score",99)>=syc.get("threshold",3): errors.append("anti-sycophancy score is at or above threshold")
    if syc.get("status")!="PASS": errors.append("anti-sycophancy status must PASS")
    if bias.get("status")!="PASS": errors.append("bias gate must PASS")
    if data.get("final_decision")!="proceed_to_validation": errors.append("final_decision must proceed_to_validation")
    return emit("PASS" if not errors else "FAIL",errors,[],skill_name=data.get("skill_name"))
if __name__=="__main__": main_guard(cli)
