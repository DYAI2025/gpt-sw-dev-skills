#!/usr/bin/env python3
"""Validate an evidence ledger against the evidence-ledger schema and truth invariants."""
from __future__ import annotations
import argparse
from pathlib import Path
from _common import load_json, validate_schema, emit, ensure_unique, main_guard


def cli() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('file')
    parser.add_argument('--schema')
    args = parser.parse_args()
    data = load_json(args.file)
    schema = Path(args.schema) if args.schema else Path(__file__).parents[1] / 'schemas/evidence-ledger.schema.json'
    errors = validate_schema(data, schema)
    warnings = []
    facts = data.get('facts', []) if isinstance(data, dict) else []
    errors += ensure_unique((x.get('id', '') for x in facts), 'evidence id')
    for item in facts:
        item_id = item.get('id', 'UNKNOWN')
        state = item.get('status')
        confidence = item.get('confidence', 0)
        sources = item.get('source_refs', [])
        if state == 'VERIFIED' and (confidence < 4 or not sources):
            errors.append(f'{item_id}: VERIFIED requires confidence >=4 and source_refs')
        if state == 'DERIVED' and not item.get('derived_from'):
            errors.append(f'{item_id}: DERIVED requires derived_from')
        if state == 'ASSUMPTION' and (not item.get('test_or_resolution') or not item.get('expires_at')):
            errors.append(f'{item_id}: ASSUMPTION requires test_or_resolution and expires_at')
        if state in {'MISSING','SOURCE_NEEDED','CONFLICT','BLOCKER'} and confidence > 3:
            errors.append(f'{item_id}: unresolved state cannot have confidence >3')
        if state == 'NOT_APPLICABLE' and not item.get('notes'):
            errors.append(f'{item_id}: NOT_APPLICABLE requires rationale')
        if item.get('criticality') in {'high','critical'} and state in {'MISSING','SOURCE_NEEDED','CONFLICT'}:
            warnings.append(f'{item_id}: unresolved high-impact evidence must become a gate blocker')
    return emit('PASS' if not errors else 'FAIL', errors, warnings, evidence_count=len(facts))


if __name__ == '__main__':
    main_guard(cli)
