#!/usr/bin/env python3
"""Shared deterministic helpers for the project-readiness skill validators.

The module reads local files only. It performs no network calls and no writes
outside paths explicitly supplied by the caller.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any, Iterable


def load_data(path: str | Path) -> Any:
    """Load JSON or YAML from a local file with clear failure messages."""
    p = Path(path)
    if not p.is_file():
        raise ValueError(f"file not found: {p}")
    text = p.read_text(encoding="utf-8")
    try:
        return json.loads(text)
    except json.JSONDecodeError as json_error:
        if p.suffix.lower() not in {".yaml", ".yml"}:
            raise ValueError(f"invalid JSON in {p}: {json_error}") from json_error
        try:
            import yaml  # type: ignore
        except ImportError as exc:
            raise ValueError(
                f"{p} is not JSON-compatible YAML and PyYAML is unavailable"
            ) from exc
        try:
            return yaml.safe_load(text)
        except Exception as yaml_error:
            raise ValueError(f"invalid YAML in {p}: {yaml_error}") from yaml_error


def load_json(path: str | Path) -> Any:
    p = Path(path)
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError(f"file not found: {p}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON in {p}: {exc}") from exc


def validate_schema(data: Any, schema_path: str | Path) -> list[str]:
    """Validate with jsonschema when available; otherwise enforce core shape."""
    schema = load_json(schema_path)
    try:
        import jsonschema  # type: ignore
    except ImportError:
        return _fallback_validate(data, schema, path="$", errors=[])

    validator = jsonschema.Draft202012Validator(schema)
    errors = []
    for error in sorted(validator.iter_errors(data), key=lambda e: list(e.absolute_path)):
        location = "$"
        if error.absolute_path:
            location += "." + ".".join(str(x) for x in error.absolute_path)
        errors.append(f"{location}: {error.message}")
    return errors


def _fallback_validate(data: Any, schema: dict[str, Any], path: str, errors: list[str]) -> list[str]:
    expected = schema.get("type")
    allowed_types = expected if isinstance(expected, list) else [expected] if expected else []
    if allowed_types and not _matches_type(data, allowed_types):
        errors.append(f"{path}: expected {allowed_types}, got {type(data).__name__}")
        return errors
    if "enum" in schema and data not in schema["enum"]:
        errors.append(f"{path}: {data!r} is not in {schema['enum']}")
    if isinstance(data, dict):
        for key in schema.get("required", []):
            if key not in data:
                errors.append(f"{path}: missing required property {key}")
        properties = schema.get("properties", {})
        for key, value in data.items():
            if key in properties:
                _fallback_validate(value, properties[key], f"{path}.{key}", errors)
        if schema.get("additionalProperties") is False:
            for key in data:
                if key not in properties:
                    errors.append(f"{path}: unexpected property {key}")
    elif isinstance(data, list):
        if len(data) < schema.get("minItems", 0):
            errors.append(f"{path}: expected at least {schema['minItems']} items")
        item_schema = schema.get("items")
        if isinstance(item_schema, dict):
            for index, value in enumerate(data):
                _fallback_validate(value, item_schema, f"{path}[{index}]", errors)
    elif isinstance(data, str):
        if len(data) < schema.get("minLength", 0):
            errors.append(f"{path}: string shorter than {schema['minLength']}")
        pattern = schema.get("pattern")
        if pattern and not re.search(pattern, data):
            errors.append(f"{path}: value does not match {pattern}")
    elif isinstance(data, (int, float)) and not isinstance(data, bool):
        if "minimum" in schema and data < schema["minimum"]:
            errors.append(f"{path}: value below minimum {schema['minimum']}")
        if "maximum" in schema and data > schema["maximum"]:
            errors.append(f"{path}: value above maximum {schema['maximum']}")
    return errors


def _matches_type(value: Any, allowed: Iterable[str]) -> bool:
    checks = {
        "object": lambda v: isinstance(v, dict),
        "array": lambda v: isinstance(v, list),
        "string": lambda v: isinstance(v, str),
        "integer": lambda v: isinstance(v, int) and not isinstance(v, bool),
        "number": lambda v: isinstance(v, (int, float)) and not isinstance(v, bool),
        "boolean": lambda v: isinstance(v, bool),
        "null": lambda v: v is None,
    }
    return any(checks.get(t, lambda _v: True)(value) for t in allowed)


def parse_frontmatter(skill_md: str | Path) -> tuple[dict[str, str], str]:
    p = Path(skill_md)
    text = p.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        raise ValueError(f"{p}: missing opening YAML frontmatter delimiter")
    end = text.find("\n---\n", 4)
    if end < 0:
        raise ValueError(f"{p}: missing closing YAML frontmatter delimiter")
    raw = text[4:end]
    body = text[end + 5 :]
    values: dict[str, str] = {}
    for line in raw.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if ":" not in line:
            raise ValueError(f"{p}: malformed frontmatter line: {line}")
        key, value = line.split(":", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values, body


def emit(status: str, errors: list[str], warnings: list[str] | None = None, **extra: Any) -> int:
    warnings = warnings or []
    payload = {"status": status, "errors": errors, "warnings": warnings, **extra}
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if status == "PASS" else 1


def ensure_unique(values: Iterable[str], label: str) -> list[str]:
    seen: set[str] = set()
    errors: list[str] = []
    for value in values:
        if value in seen:
            errors.append(f"duplicate {label}: {value}")
        seen.add(value)
    return errors


def resolve_skill_dir(path: str | Path) -> Path:
    p = Path(path).resolve()
    if not p.is_dir():
        raise ValueError(f"skill directory not found: {p}")
    return p


def main_guard(fn) -> None:
    try:
        code = fn()
    except ValueError as exc:
        print(json.dumps({"status": "FAIL", "errors": [str(exc)], "warnings": []}, indent=2))
        code = 1
    except KeyboardInterrupt:
        print(json.dumps({"status": "FAIL", "errors": ["interrupted"], "warnings": []}, indent=2))
        code = 130
    raise SystemExit(code)
