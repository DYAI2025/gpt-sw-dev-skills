#!/usr/bin/env python3
"""Render local Graphviz DOT files to SVG or PNG.

Reads only the supplied DOT files and writes only to the supplied output
folder. Requires the local `dot` executable and performs no network calls.
"""
from __future__ import annotations
import argparse, shutil, subprocess
from pathlib import Path
from _common import main_guard

def cli():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('input', help='DOT file or directory containing DOT files')
    ap.add_argument('output_dir', help='output directory')
    ap.add_argument('--format', choices=['svg','png'], default='svg')
    args=ap.parse_args()
    dot=shutil.which('dot')
    if not dot: raise ValueError('Graphviz dot executable is not available')
    src=Path(args.input); out=Path(args.output_dir); out.mkdir(parents=True,exist_ok=True)
    files=[src] if src.is_file() else sorted(src.glob('*.dot'))
    if not files: raise ValueError(f'no DOT files found at {src}')
    for p in files:
        target=out/f'{p.stem}.{args.format}'
        proc=subprocess.run([dot,f'-T{args.format}',str(p),'-o',str(target)],capture_output=True,text=True)
        if proc.returncode: raise ValueError(f'Graphviz failed for {p}: {proc.stderr.strip()}')
        print(target)
    return 0
if __name__=='__main__': main_guard(cli)
