#!/usr/bin/env python3
"""Validate an artifact register and optionally require gate-ready artifacts."""
from __future__ import annotations
import argparse
from pathlib import Path
from _common import load_json, validate_schema, emit, main_guard, ensure_unique

def cli():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument("file"); ap.add_argument("--schema"); ap.add_argument("--require-ready",action="store_true"); args=ap.parse_args()
    data=load_json(args.file); schema=Path(args.schema) if args.schema else Path(__file__).parents[1]/"schemas/artifact-register.schema.json"
    errors=validate_schema(data,schema); warnings=[]; blockers=[]
    items=data.get("artifacts",[]) if isinstance(data,dict) else []
    errors+=ensure_unique((x.get("id","") for x in items),"artifact id")
    for item in items:
        aid=item.get("id","UNKNOWN"); cls=item.get("applicability_class"); state=item.get("applicability_state"); status=item.get("status")
        if cls=="mandatory" and state!="required": errors.append(f"{aid}: mandatory artifact must be required")
        if cls=="conditional" and state=="not_applicable" and not item.get("not_applicable_rationale"): errors.append(f"{aid}: conditional not_applicable requires rationale")
        if state=="required" and status in {"missing","blocked"}: blockers.append(f"{aid}: required artifact is {status}")
        if state=="required" and not item.get("owner"): errors.append(f"{aid}: required artifact needs owner")
        if state=="required" and not item.get("approver"): errors.append(f"{aid}: required artifact needs approver")
    if args.require_ready and blockers: errors += blockers
    else: warnings += blockers
    return emit("PASS" if not errors else "FAIL",errors,warnings,artifact_count=len(items),readiness_blockers=blockers)
if __name__=="__main__": main_guard(cli)
