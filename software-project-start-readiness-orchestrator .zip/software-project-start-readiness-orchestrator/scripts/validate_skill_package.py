#!/usr/bin/env python3
"""Validate the complete skill package with the canonical local validator."""
from __future__ import annotations
import argparse
import subprocess
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('skill_dir', nargs='?', default='.')
    args = parser.parse_args()
    root = Path(args.skill_dir).resolve()
    validator = root / 'scripts' / 'quick_validate.py'
    if not validator.is_file():
        print('{"status":"FAIL","errors":["scripts/quick_validate.py not found"]}')
        return 1
    return subprocess.call([sys.executable, str(validator), str(root)])


if __name__ == '__main__':
    raise SystemExit(main())
