#!/usr/bin/env python3
"""Validate traceability schema, references, and critical-outcome coverage."""
from __future__ import annotations
import argparse
from collections import defaultdict, deque
from pathlib import Path
from _common import load_json, validate_schema, emit, main_guard, ensure_unique

def cli():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument("file"); ap.add_argument("--schema"); ap.add_argument("--require-complete",action="store_true"); args=ap.parse_args()
    data=load_json(args.file); schema=Path(args.schema) if args.schema else Path(__file__).parents[1]/"schemas/traceability.schema.json"
    errors=validate_schema(data,schema); warnings=[]; broken=[]
    nodes=data.get("nodes",[]) if isinstance(data,dict) else []; links=data.get("links",[]) if isinstance(data,dict) else []
    errors+=ensure_unique((n.get("id","") for n in nodes),"node id")
    node_map={n.get("id"):n for n in nodes}; graph=defaultdict(set)
    for link in links:
        s,t=link.get("source"),link.get("target")
        if s not in node_map: errors.append(f"link source not found: {s}")
        if t not in node_map: errors.append(f"link target not found: {t}")
        if s in node_map and t in node_map and link.get("status")!="superseded": graph[s].add(t); graph[t].add(s)
        if link.get("status")=="broken": broken.append(f"broken link {s} -> {t}")
    for outcome in data.get("critical_outcomes",[]):
        start=outcome.get("outcome_node_id")
        if start not in node_map: errors.append(f"critical outcome node not found: {start}"); continue
        seen={start}; q=deque([start])
        while q:
            cur=q.popleft()
            for nxt in graph[cur]:
                if nxt not in seen: seen.add(nxt); q.append(nxt)
        types={node_map[n]["type"] for n in seen}
        missing=[t for t in outcome.get("required_node_types",[]) if t not in types]
        if missing: broken.append(f"{start}: missing reachable node types {missing}")
    if args.require_complete and broken: errors+=broken
    else: warnings+=broken
    return emit("PASS" if not errors else "FAIL",errors,warnings,node_count=len(nodes),link_count=len(links),traceability_gaps=broken)
if __name__=="__main__": main_guard(cli)
