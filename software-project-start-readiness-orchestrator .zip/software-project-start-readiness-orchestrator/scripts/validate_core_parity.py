#!/usr/bin/env python3
"""Validate that core project-readiness functions were preserved."""
from __future__ import annotations
import argparse
from pathlib import Path
from _common import load_json, emit, main_guard
REQUIRED={"adaptive interview","source and confidence discipline","vision confirmation gate","S0-S3 tailoring","operating-model routing","artifact planning and generation","cross-document audit","G0-G6 start-gate model","Jira capability preflight and dry-run","explicit mutation gate and read-back","Scrum, Kanban, and coding-agent preparation","traceability from objective to benefit"}
def cli():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument("skill_dir"); args=ap.parse_args(); report=load_json(Path(args.skill_dir)/"reports/core-functionality-preservation.json"); errors=[]
    preserved=set(report.get("preserved_core_functions",[])); missing=sorted(REQUIRED-preserved)
    if missing: errors.append(f"missing preserved core functions: {missing}")
    if report.get("unintended_core_changes"): errors.append("unintended_core_changes must be empty")
    if not report.get("minimal_additions"): errors.append("minimal_additions must be documented")
    return emit("PASS" if not errors else "FAIL",errors,[],preserved_count=len(preserved))
if __name__=="__main__": main_guard(cli)
