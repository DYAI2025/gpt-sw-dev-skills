#!/usr/bin/env python3
"""Validate the Enterprise Skill Output Evaluator XML report."""
from __future__ import annotations
import argparse
from xml.etree import ElementTree as ET
from _common import emit, main_guard

def cli():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument("file"); args=ap.parse_args(); errors=[]
    try: root=ET.parse(args.file).getroot()
    except Exception as exc: return emit("FAIL",[f"invalid XML: {exc}"],[])
    if root.tag!="enterprise_skill_evaluation": errors.append("wrong root element")
    scores=root.find("scores")
    if scores is None: errors.append("missing scores")
    else:
        for name in ["spec_compliance","research_quality","enterprise_readiness","architecture_quality","release_gate_integrity"]:
            try: value=int(scores.findtext(name,"0"))
            except ValueError: value=0
            if value<4 or value>5: errors.append(f"{name} must be 4 or 5 for release")
    decision=root.findtext("decision","")
    if decision not in {"PASS","PASS_WITH_MINOR_REVISIONS"}: errors.append(f"non-release decision: {decision}")
    blocking=[(x.text or '').strip() for x in root.findall('./blocking_issues/item')]
    blocking=[x for x in blocking if x and x!="NONE"]
    if blocking: errors.append(f"blocking issues present: {blocking}")
    return emit("PASS" if not errors else "FAIL",errors,[],decision=decision)
if __name__=="__main__": main_guard(cli)
