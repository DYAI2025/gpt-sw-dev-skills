#!/usr/bin/env python3
"""Validate trigger, output, interview, pressure, gate, Jira, and regression eval assets."""
from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from _common import emit, ensure_unique, load_json, main_guard


def require_fields(item: dict[str, Any], fields: list[str], label: str, errors: list[str]) -> None:
    missing = [field for field in fields if field not in item or item[field] in (None, "", [])]
    if missing:
        errors.append(f"{label} missing fields: {missing}")


def load_list(path: Path, label: str, errors: list[str]) -> list[dict[str, Any]]:
    try:
        data = load_json(path)
    except ValueError as exc:
        errors.append(str(exc))
        return []
    if not isinstance(data, list):
        errors.append(f"{label} must be a JSON list")
        return []
    if not all(isinstance(item, dict) for item in data):
        errors.append(f"{label} must contain objects only")
        return []
    return data


def cli() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_dir")
    args = parser.parse_args()
    root = Path(args.skill_dir)
    eval_dir = root / "evals"
    errors: list[str] = []
    warnings: list[str] = []

    triggers = load_list(eval_dir / "trigger_queries.json", "trigger_queries.json", errors)
    non_triggers = load_list(eval_dir / "non_trigger_queries.json", "non_trigger_queries.json", errors)
    outputs = load_list(eval_dir / "output_evals.json", "output_evals.json", errors)
    interviews = load_list(eval_dir / "interview_scenarios.json", "interview_scenarios.json", errors)
    gates = load_list(eval_dir / "gate_scenarios.json", "gate_scenarios.json", errors)
    jira_caps = load_list(eval_dir / "jira_capability_scenarios.json", "jira_capability_scenarios.json", errors)
    regressions = load_list(eval_dir / "regression_cases.json", "regression_cases.json", errors)

    if len(triggers) < 10:
        errors.append("at least 10 should-trigger queries are required")
    if len(non_triggers) < 10:
        errors.append("at least 10 should-not-trigger queries are required")
    for index, item in enumerate(triggers):
        require_fields(item, ["query", "reason"], f"trigger {index}", errors)
        if item.get("should_trigger") is not True:
            errors.append(f"trigger {index} must set should_trigger=true")
    for index, item in enumerate(non_triggers):
        require_fields(item, ["query", "reason"], f"non-trigger {index}", errors)
        if item.get("should_trigger") is not False:
            errors.append(f"non-trigger {index} must set should_trigger=false")

    if len(outputs) < 10:
        errors.append("at least 10 output evaluations are required")
    errors += ensure_unique((str(item.get("id", "")) for item in outputs), "output eval id")
    for item in outputs:
        require_fields(
            item,
            ["id", "prompt", "expected_properties", "failure_modes", "minimum_pass"],
            f"output eval {item.get('id', 'UNKNOWN')}",
            errors,
        )

    if len(interviews) < 6:
        errors.append("at least 6 interview/tailoring scenarios are required")
    errors += ensure_unique((str(item.get("id", "")) for item in interviews), "interview id")
    for item in interviews:
        require_fields(
            item,
            ["id", "input", "expected_behavior", "expected_artifacts", "forbidden_response", "pass_criteria"],
            f"interview {item.get('id', 'UNKNOWN')}",
            errors,
        )

    if len(gates) < 6:
        errors.append("at least 6 gate scenarios are required")
    errors += ensure_unique((str(item.get("id", "")) for item in gates), "gate scenario id")
    for item in gates:
        require_fields(
            item,
            ["id", "input", "expected_state", "forbidden", "pass_criteria"],
            f"gate scenario {item.get('id', 'UNKNOWN')}",
            errors,
        )
        if "expected_blockers" not in item or not isinstance(item.get("expected_blockers"), list):
            errors.append(f"gate scenario {item.get('id', 'UNKNOWN')} must contain expected_blockers as a list")

    if len(jira_caps) < 6:
        errors.append("at least 6 Jira capability scenarios are required")
    errors += ensure_unique((str(item.get("id", "")) for item in jira_caps), "Jira capability scenario id")
    for item in jira_caps:
        require_fields(
            item,
            ["id", "input", "expected", "forbidden", "pass_criteria"],
            f"Jira capability scenario {item.get('id', 'UNKNOWN')}",
            errors,
        )

    if len(regressions) < 15:
        errors.append("at least 15 regression cases are required")
    errors += ensure_unique((str(item.get("id", "")) for item in regressions), "regression id")
    for item in regressions:
        require_fields(item, ["id", "case", "must", "must_not"], f"regression {item.get('id', 'UNKNOWN')}", errors)

    pressure_path = eval_dir / "pressure_scenarios.md"
    if not pressure_path.is_file():
        errors.append("missing pressure_scenarios.md")
        pressure_count = 0
    else:
        pressure_text = pressure_path.read_text(encoding="utf-8")
        pressure_count = len(re.findall(r"^##\s+P-\d+", pressure_text, flags=re.MULTILINE))
        if pressure_count < 10:
            errors.append("at least 10 pressure/adversarial scenarios are required")
        lower_pressure = pressure_text.lower()
        for label, alternatives in {
            "expected behavior/artifacts/blockers": ["expected behavior", "erwartetes verhalten"],
            "forbidden response": ["forbidden response", "verbotene reaktion"],
            "pass criterion": ["pass criterion", "pass-kriterium"],
        }.items():
            if not any(term in lower_pressure for term in alternatives):
                errors.append(f"pressure scenarios must document {label}")

    xml_path = eval_dir / "jira_read_only_evals.xml"
    pairs: list[ET.Element] = []
    try:
        pairs = ET.parse(xml_path).findall(".//qa_pair")
    except Exception as exc:
        errors.append(f"invalid jira_read_only_evals.xml: {exc}")
    if len(pairs) < 10:
        errors.append("at least 10 stable read-only Jira QA pairs are required")
    destructive = re.compile(
        r"\b(create|update|delete|transition|close|assign|write|modify|edit|move)\b",
        flags=re.IGNORECASE,
    )
    for index, pair in enumerate(pairs):
        question = (pair.findtext("question") or "").strip()
        answer = (pair.findtext("answer") or "").strip()
        if not question or not answer:
            errors.append(f"Jira QA pair {index} lacks question or answer")
        if destructive.search(question):
            errors.append(f"Jira QA pair {index} is not read-only: {question}")

    fixture = eval_dir / "fixtures/jira-sandbox-snapshot.json"
    if not fixture.is_file():
        errors.append("missing fixed Jira sandbox snapshot")
    else:
        try:
            snapshot = load_json(fixture)
            if snapshot.get("synthetic") is not True:
                errors.append("Jira sandbox snapshot must declare synthetic=true")
        except ValueError as exc:
            errors.append(str(exc))

    return emit(
        "PASS" if not errors else "FAIL",
        errors,
        warnings,
        should_trigger=len(triggers),
        should_not_trigger=len(non_triggers),
        output_evals=len(outputs),
        interview_scenarios=len(interviews),
        pressure_scenarios=pressure_count,
        gate_scenarios=len(gates),
        jira_capability_scenarios=len(jira_caps),
        jira_read_only_pairs=len(pairs),
        regression_cases=len(regressions),
    )


if __name__ == "__main__":
    main_guard(cli)
