#!/usr/bin/env python3
"""Reject unfinished authoring markers while allowing intentional MISSING states."""
from __future__ import annotations
import argparse, re
from pathlib import Path
from _common import emit, main_guard
PATTERNS=[r"\bTODO\b",r"\bTBD\b",r"\bFIXME\b",r"lorem ipsum",r"insert (text|content|name) here",r"\bPLACEHOLDER\b"]
SKIP={"skill.zip"}
def cli():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument("skill_dir"); args=ap.parse_args(); root=Path(args.skill_dir); errors=[]
    for p in root.rglob('*'):
        if not p.is_file() or p.name in SKIP or p.resolve() in {Path(__file__).resolve(), (Path(__file__).parent/'quick_validate.py').resolve()} or '__pycache__' in p.parts: continue
        if p.suffix.lower() not in {'.md','.json','.yaml','.yml','.py','.xml','.dot'}: continue
        text=p.read_text(encoding='utf-8',errors='replace')
        for pattern in PATTERNS:
            if re.search(pattern,text,re.I): errors.append(f"{p.relative_to(root)} contains unfinished marker matching {pattern}")
    return emit("PASS" if not errors else "FAIL",errors,[])
if __name__=="__main__": main_guard(cli)
