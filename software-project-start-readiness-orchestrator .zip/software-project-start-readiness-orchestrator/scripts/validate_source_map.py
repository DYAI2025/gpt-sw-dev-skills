#!/usr/bin/env python3
"""Validate the machine-readable source map and confidence discipline."""
from __future__ import annotations
import argparse
from pathlib import Path
from _common import load_json, emit, main_guard, ensure_unique
ALLOWED={"primary","secondary","user_provided","derived","uncertain"}
def cli():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument("skill_dir"); args=ap.parse_args()
    p=Path(args.skill_dir)/"references/source-map.json"; data=load_json(p); errors=[]; warnings=[]
    sources=data.get("sources",[]); errors+=ensure_unique((s.get("id","") for s in sources),"source id"); ids={s.get("id") for s in sources}
    for s in sources:
        sid=s.get("id","UNKNOWN")
        if s.get("type") not in ALLOWED: errors.append(f"{sid}: invalid source type")
        c=s.get("confidence");
        if not isinstance(c,int) or not 1<=c<=5: errors.append(f"{sid}: confidence must be 1-5")
        for field in ["title","location","purpose","reliability","limitations","recommended_use"]:
            if not s.get(field): errors.append(f"{sid}: missing {field}")
        if s.get("recommended_use")=="rule" and isinstance(c,int) and c<4: errors.append(f"{sid}: confidence <4 cannot support hard rule")
    for claim in data.get("verified_design_claims",[]):
        if claim.get("confidence",0)<4: errors.append(f"hard design claim below confidence 4: {claim.get('claim')}")
        missing=[x for x in claim.get("source_ids",[]) if x not in ids]
        if missing: errors.append(f"claim references unknown sources: {missing}")
    if not data.get("source_needed_at_runtime"): warnings.append("no runtime source-needed items recorded")
    return emit("PASS" if not errors else "FAIL",errors,warnings,source_count=len(sources))
if __name__=="__main__": main_guard(cli)
