#!/usr/bin/env python3
"""Build a schema-valid Jira dry-run manifest from a project profile and a local capability snapshot.

The script performs no network calls and never mutates Jira. It deliberately
marks unsupported or unverified platform operations as blocked or manual.
"""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from _common import load_json, main_guard


def profile_to_jira(overall_profile: str) -> str:
    return {
        "S0": "J1",
        "S1": "J1",
        "S2": "J2",
        "S3": "J3",
        "S0_EXPLORATION": "J1",
        "S1_SINGLE_TEAM": "J1",
        "S2_MULTI_TEAM": "J2",
        "S3_ENTERPRISE_REGULATED_CRITICAL": "J3",
    }.get(overall_profile, "J1")


def observed_hierarchy_depth(observed: dict[str, Any]) -> int:
    hierarchy = observed.get("hierarchy", [])
    if isinstance(hierarchy, list):
        levels = [item.get("level") for item in hierarchy if isinstance(item, dict)]
        integer_levels = [level for level in levels if isinstance(level, int)]
        return max(integer_levels, default=1)
    capabilities = observed.get("capabilities", {})
    if isinstance(capabilities, dict) and capabilities.get("custom_hierarchy_above_epic"):
        return int(capabilities.get("verified_levels_above_epic", 2))
    return 1


def choose_effective_profile(desired: str, observed_depth: int) -> tuple[str, list[str]]:
    blockers: list[str] = []
    if desired == "J3" and observed_depth < 3:
        blockers.append(
            "BLOCKED_CAPABILITY_UNKNOWN: J3 requires several verified levels above the delivery Epic/Feature level"
        )
        return ("J2" if observed_depth >= 2 else "J1"), blockers
    if desired == "J2" and observed_depth < 2:
        blockers.append(
            "BLOCKED_CAPABILITY_UNKNOWN: J2 requires a verified level above the delivery Epic/Feature level"
        )
        return "J1", blockers
    return desired, blockers


def build_manifest(profile: dict[str, Any], observed: dict[str, Any]) -> dict[str, Any]:
    overall = str(profile.get("overall_profile", "S1"))
    desired = profile_to_jira(overall)
    depth = observed_hierarchy_depth(observed)
    effective, blockers = choose_effective_profile(desired, depth)

    site_info = observed.get("site", {}) if isinstance(observed.get("site"), dict) else {}
    target_site = str(observed.get("target_site") or site_info.get("url") or "MISSING")
    plan = str(observed.get("plan") or site_info.get("plan") or "MISSING")
    management_type = str(
        observed.get("management_type") or site_info.get("management_type") or "MISSING"
    )
    project_key = str(observed.get("project_key") or "MISSING")
    project_name = str(observed.get("project_name") or site_info.get("name") or "MISSING")
    observed_at = str(
        observed.get("captured_at")
        or observed.get("observed_at")
        or datetime.now(timezone.utc).isoformat()
    )

    hierarchy_action = "blocked" if blockers else "none"
    operation_status = "blocked" if blockers else "verified"
    project_id = str(profile.get("project_id", "MISSING"))

    return {
        "manifest_version": "1.0",
        "mode": "dry-run",
        "target_site": target_site,
        "observed_at": observed_at,
        "authorization": {
            "vision_status": "VISION_DRAFT",
            "gate_state": "DRAFT",
            "authorized_decision_ref": "MISSING",
            "mutation_authorized": False,
            "authorized_by": "MISSING",
        },
        "project": {
            "action": "reuse" if project_key != "MISSING" else "manual",
            "key": project_key,
            "name": project_name,
            "management_type": management_type,
            "plan": plan,
        },
        "hierarchy_profile": effective,
        "issue_types": [],
        "fields": [],
        "workflows": [],
        "permissions": [],
        "components": [],
        "versions": [],
        "boards": [],
        "plans": [],
        "automations": [],
        "seed_items": [],
        "links": [],
        "operations": [
            {
                "id": "OP-HIERARCHY-001",
                "category": "hierarchy",
                "target_ref": None,
                "desired_state": {"profile": desired},
                "observed_state": {
                    "profile": effective,
                    "verified_depth": depth,
                    "raw": observed.get("hierarchy", []),
                },
                "action": hierarchy_action,
                "idempotency_key": f"hierarchy:{project_id}:{desired}",
                "required_permission": (
                    "verified Jira administration permission when a platform hierarchy change is required"
                ),
                "risk_level": "high" if desired == "J3" else "medium",
                "rollback_or_compensation": (
                    "Do not mutate in dry-run. For a later authorized platform change, preserve the observed hierarchy and parent-link inventory before apply."
                ),
                "verification": (
                    "Read back the hierarchy and representative parent relationships, then compare them with the approved manifest."
                ),
                "evidence": blockers,
                "status": operation_status,
            }
        ],
        "validation_queries": [
            "Read project metadata and management type.",
            "Read work-item types and hierarchy levels.",
            "Read required field metadata and permissions before any apply operation.",
        ],
        "rollback_actions": ["No mutation occurs in dry-run mode."],
        "unsupported_actions": blockers,
    }


def cli() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project_profile", help="project-profile JSON file")
    parser.add_argument("--observed", help="local Jira capability/read-back snapshot JSON")
    parser.add_argument("--output", help="optional output JSON path")
    args = parser.parse_args()

    profile = load_json(args.project_profile)
    observed = load_json(args.observed) if args.observed else {}
    manifest = build_manifest(profile, observed)
    text = json.dumps(manifest, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        Path(args.output).write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    return 0


if __name__ == "__main__":
    main_guard(cli)
