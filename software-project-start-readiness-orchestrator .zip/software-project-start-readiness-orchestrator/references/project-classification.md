# Projektklassifikation und Tailoring

## Grundsatz

Klassifiziere dimensionsbezogen. Teamgröße allein entscheidet nicht. Das Gesamtprofil steuert Koordination; einzelne Domänen dürfen ein höheres Kontrollprofil erhalten.

## Profile

| Profil | Charakter | Mindesttiefe |
|---|---|---|
| `S0` | Exploration, Spike, Prototyp, zeitlich begrenzte Machbarkeit ohne Produktionszusage | Hypothese, Owner, Timebox, sichere Grenzen, Evidenz, Risiko, Mess- und Stop-Kriterium |
| `S1` | ein Team, begrenzte Änderung, niedrige bis mittlere Betriebsrisiken | Charter-lite, Vision, Requirements/NFR, Architekturkontext, Screening, Test, Release/Betrieb, Jira-Manifest, Gate |
| `S2` | mehrere Teams, Plattform, wesentliche Integrationen, Migration oder Investition | Business Case, Benefits, Governance, Views, Schnittstellen, Dependencies, Quality und Operational Readiness |
| `S3` | Enterprise, reguliert, hochkritisch, safety-/security-relevant oder mehrere kritische Lieferanten | formale Assurance, Compliance-Traceability, unabhängige Reviews, unveränderbare Evidenz und autorisierte Residualrisiken |

## Dimensionen

Bewerte mindestens:

- Nutzer- und Geschäftsimpact;
- Produktions- und Verfügbarkeitskritikalität;
- Datenklasse und Privacy-Risiko;
- Security-Exposition und Privilegien;
- Safety- oder physischer Impact;
- regulatorische/vertragliche Bindung;
- Team-, Domänen- und Integrationszahl;
- Migration, Koexistenz und Datenreconciliation;
- Lieferanten- und Lock-in-Risiko;
- Investitions- und Außenverpflichtung;
- Autonomiegrad von KI oder Automatisierung;
- Reversibilität und Rollbackfähigkeit.

## Deterministische Eskalationsregeln

- Setze mindestens `security: S3`, wenn internetexponierte privilegierte oder hochsensible Verarbeitung vorliegt und kritische Folgen plausibel sind.
- Setze mindestens `privacy: S3`, wenn eine DPIA wahrscheinlich erforderlich ist oder besonders schutzwürdige Daten in großem Umfang betroffen sind.
- Setze mindestens `safety: S3`, wenn Software sicherheitsrelevante physische Entscheidungen beeinflusst.
- Setze mindestens `operations: S2`, wenn produktive Verfügbarkeit, Wiederherstellung oder On-call erforderlich ist.
- Setze mindestens `delivery: S2`, wenn mehrere Teams oder kritische Cross-System-Dependencies koordiniert werden müssen.
- Setze mindestens `commercial: S2`, wenn ein kritischer externer Anbieter, langfristiger Lock-in oder wesentliche Beschaffung erforderlich ist.
- Ein `S0` darf nicht stillschweigend in Produktion übergehen. Übergang erfordert Reclassification und neues Gate.

Diese Regeln setzen die Mindesttiefe, nicht automatisch die vollständige Dokumentmenge. Das Artefaktregister entscheidet weiter über `mandatory`, `conditional` und `optional`.

## Ergebnisformat

```json
{
  "overall_profile": "S1",
  "domain_profiles": {
    "delivery": "S1",
    "security": "S3",
    "privacy": "S2",
    "operations": "S1",
    "commercial": "S1"
  },
  "dimensions": [],
  "escalation_triggers": [],
  "rationale": [],
  "assumptions": [],
  "blockers": []
}
```

## Tailoring-Regeln

- Wähle den minimal hinreichenden Evidenzsatz.
- Dokumentiere jedes ausgelöste bedingte Artefakt.
- `NOT_APPLICABLE` benötigt Triggerprüfung, Begründung und Approver.
- Verwende kompakte kombinierte Dokumente in S0/S1, wenn Identität, Ownership, Version und Traceability erhalten bleiben.
- Verwende formale getrennte Nachweise in S2/S3, wenn unabhängige Review-, Audit- oder Freigabepfade erforderlich sind.
