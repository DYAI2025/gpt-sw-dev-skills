# Source Map

Reviewed: 2026-07-26

## Source inventory

| ID | Type | Confidence | Recommended use | Title | Limits |
|---|---|---:|---|---|---|
| U1 | user_provided | 4 | rule | Auftrag: Enterprise-Skill fuer vollstaendige Software-Projektvorbereitung | does not itself verify external platform or legal claims |
| U2 | user_provided | 4 | rule | Proposed Skill design specification | external claims require primary-source check |
| U3 | user_provided | 4 | rule | Complete artifact catalog with applicability rules | organization-specific applicability still required |
| U4 | user_provided | 4 | rule | Jira bootstrap and taxonomy | dynamic Jira facts must be rechecked |
| U5 | user_provided | 4 | rule | Start gate and audit model | organizational decision rights remain project-specific |
| P1 | primary | 5 | rule | Agent Skills Specification | client-specific installation behavior is outside the package |
| P2 | primary | 5 | rule | Atlassian: Configure the work type hierarchy | must be rechecked for the target site and date |
| P3 | primary | 5 | rule | Jira Cloud REST API v3 | permissions and endpoint availability vary |
| P4 | primary | 5 | rule | WCAG 2.2 | legal applicability varies by jurisdiction |
| P5 | primary | 5 | rule | NIST SP 800-218 SSDF v1.1 | v1.2 existed only as draft at review date; recheck later |
| P6 | primary | 5 | rule | European Commission DPIA guidance | does not replace authorized legal or DPO review |
| P7 | primary | 5 | rule | Scrum Guide 2020 | does not define enterprise project initiation or Jira taxonomy |
| P8 | primary | 5 | context | LeSS Rules | hybrid deviations must be explicit |
| P9 | primary | 5 | context | Scaled Agile Framework official guidance | not universal agile practice |
| P10 | primary | 5 | context | ISO/IEC/IEEE 42010:2022 | full normative text may require licensed access |
| P11 | primary | 5 | context | ISO/IEC 25010:2023 | must be translated into measurable scenarios |
| P12 | primary | 5 | context | ISO 31000:2018 | tailor scales and governance |
| T1 | primary | 5 | rule | Atlassian_Rovo connector schema inspected in this runtime | available actions can change by workspace and connector version |
| U6 | user_provided | 3 | context | Detailed templates for scaled software-project artifacts | contains noisy export markup, WCAG 2.1 wording, universal 80 percent coverage example, and SAFe-specific assumptions |
| U7 | user_provided | 3 | context | Architecture and documentation structure for scaled software projects | relies partly on secondary sources and silently synthesizes frameworks; not authoritative as a canonical method |
| U8 | user_provided | 4 | rule | MCP Server Evaluation Guide | MCP-specific portions apply only when a fixed tool fixture exists |
| U9 | user_provided | 4 | rule | Universal bias self-check | classification does not itself verify external facts |
| U10 | user_provided | 4 | rule | Graphviz conventions | syntax validation still depends on Graphviz availability |
| U11 | user_provided | 4 | rule | Skill-building orchestrator and writing-skills guidance | platform-specific claims are not assumed |
| U12 | user_provided | 3 | context | Persuasion principles for skill design | persuasion is not evidence and must not override truth or user autonomy |
| P13 | primary | 5 | rule | Atlassian Jira Cloud Projects REST API v3 | requires target-site feature and permission checks; connector exposure differs from REST availability |
| P14 | primary | 5 | rule | Atlassian Jira Cloud Issues REST API v3 | limits and permissions must be rechecked at runtime |
| P15 | primary | 5 | rule | NIST SSDF publications status | must be rechecked after future publication changes |

## Runtime SOURCE_NEEDED

- client-specific skill installation surface and tool availability
- current Jira limits and target-site supported operations before any provisioning
- organization-specific authority, security, privacy, architecture, quality, procurement and retention policies
- organization-specific license for public redistribution of this package
- project-specific legal, regulatory, contractual and safety applicability
- target Jira site, plan, management type, limits, hierarchy, permissions and APIs
- target repository paths, commands, APIs and runtime evidence before coding-agent handoff

## Claim rule

Confidence 4–5 may support hard rules. Confidence 3 is context or an explicit assumption. Confidence 1–2 cannot justify approval or mutation.
