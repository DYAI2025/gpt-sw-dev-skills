# Qualität, Test und Accessibility

## Risikobasierte Qualitätsstrategie

Leite Testtiefe und Qualitätsziele aus Nutzerimpact, Architektur, Technologie, Daten, Security, Privacy, Safety, Betriebsrisiko und Fehlerhistorie ab. Erzwinge keine universelle Code-Coverage-Zahl.

## Integrierte Teststrategie

Definiere:

- Risiken und Qualitätsziele;
- Teststufen und Testarten;
- automatisierte und manuelle Nachweise;
- Testdaten, Datenschutz und Umgebungen;
- Contract-, Integration-, System- und End-to-End-Tests;
- Security-, Accessibility-, Performance-, Resilience- und Recovery-Tests nach Anwendbarkeit;
- Entry-/Exit-Kriterien;
- Defect Severity, Waiver-Autorität und Release-Schwellen;
- Owner, Tools, Evidenzaufbewahrung und Traceability.

## Akzeptanz

Trenne:

- fachliche Akzeptanz;
- Product-Outcome-Validierung;
- technische und architektonische Akzeptanz;
- Security-/Privacy-/Compliance-/Safety-Assurance;
- Accessibility;
- Betriebs- und Release-Akzeptanz.

Benenne für jede Klasse einen Accountable Approver.

## Accessibility

Prüfe bei digitalen Benutzeroberflächen die aktuell anwendbare WCAG-Version und rechtliche/vertragliche Vorgaben. Zum Reviewdatum empfiehlt W3C WCAG 2.2 als aktuelle Zielversion; bei konkreter Anwendung neu prüfen.

Dokumentiere Scope, Konformitätsziel, Assistive Technologies, manuelle und automatisierte Tests, Ausnahmen, Owner und Evidenz. Automatisierte Checks allein belegen keine vollständige Accessibility.

## Performance und Capacity

Definiere reale Workload-Modelle, Volumen, Concurrency, Datenmengen, SLO-relevante Schwellen, Testumgebung, Profiling, Skalierungsgrenzen und Kostenwirkung.

## Resilience und Recovery

Teste plausible Fehler, Dependency-Ausfälle, Retry-/Timeout-Verhalten, Degradation, Backup/Restore, Failover, RTO/RPO und Rollback. Ein dokumentierter Plan ohne geplanten oder ausgeführten Nachweis ist nur teilweise erfüllt.
