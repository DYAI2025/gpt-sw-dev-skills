# Architektur und ADRs

## Architekturgrundlage

Beschreibe für jedes Produktions- oder integrationsrelevante System:

- Systemgrenze und Zweck;
- Stakeholder und Concerns;
- externe Akteure und Systeme;
- Constraints und Qualitätsziele;
- logische, Laufzeit-, Deployment-, Daten-, Integrations-, Security- und Betriebsviews nach Anwendbarkeit;
- Entscheidungen, Alternativen, Rationale und Konsequenzen;
- bekannte Risiken, Annahmen und offene Spikes.

Diagramme ohne benannte Concerns, Entscheidungen und Rationale sind keine ausreichende Architekturgrundlage.

## ADR-Minimum

Jede materielle Entscheidung enthält:

- ADR-ID, Titel, Status und Datum;
- Kontext und Entscheidungsfrage;
- Constraints und Entscheidungskriterien;
- mindestens eine realistische Alternative;
- Entscheidung und Begründung;
- positive und negative Konsequenzen;
- Risiken, Security-/Privacy-/Operations-Auswirkungen;
- Verifikations- oder Fitness-Funktion;
- Owner, Approver und Supersession.

## Build/Buy/Reuse

Prüfe Kosten, Time-to-Learn, Lock-in, Security, Privacy, Compliance, Datenrechte, Betriebsfähigkeit, Support, Exit und Reversibilität. Eine Herstellerbehauptung ersetzt keinen projektspezifischen Nachweis.

## Schnittstellen

Für APIs, Events und Dateien dokumentiere:

- Owner und Consumer;
- Vertrag und Versionierung;
- Authentisierung/Autorisierung;
- Idempotenz, Fehler- und Retry-Semantik;
- Datenklassifikation und Retention;
- Kompatibilität, Deprecation und Contract Tests;
- Observability und Incident Ownership.

## Migration und Koexistenz

Erzeuge bei betroffenen Beständen:

- Inventar und Datenqualität;
- Mapping und Transformation;
- Parallelbetrieb oder Cutover;
- Reconciliation und Akzeptanz;
- Rollback/Restore;
- Aufbewahrung und Löschung;
- Decommission- und Exit-Kriterien.

## Architektur-Gate

Ein relevantes oder kritisches System ist nicht delivery-ready, wenn Systemgrenze, kritische Schnittstelle, Datenownership, Migration oder zentrale Architekturentscheidung ungeklärt und unowned ist.
