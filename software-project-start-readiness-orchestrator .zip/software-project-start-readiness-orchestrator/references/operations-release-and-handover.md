# Betrieb, Release und Operational Readiness

## Produktionsverantwortung

Produktive Software benötigt vor Delivery Start mindestens einen identifizierten Service Owner und einen plausiblen Pfad für Support, Observability, Incident Response, Release und Rollback. Vor Release müssen diese Nachweise funktionsfähig und akzeptiert sein.

## Service-Modell

Dokumentiere:

- Servicegrenze und Owner;
- Supportzeiten, Supportstufen und Eskalation;
- Abhängigkeiten und Lieferanten;
- SLI, SLO, Error Budget sowie SLA/OLA nur bei realer Vereinbarung;
- Kapazität, Kostenowner und Limits;
- Datenaufbewahrung und Audit.

## Observability

Definiere Logs, Metrics, Traces, Events, Dashboards, Alerting, Audit Trails, Korrelation, Retention und Zugriff. Verknüpfe kritische User Journeys und NFRs mit messbaren Signalen.

## Incident und Problem

Definiere Severity, Rollen, On-call, Kommunikation, Security-/Privacy-Eskalation, Statusseite, Wiederherstellung, Post-Incident Learning und Problem-Ownership.

## Runbooks

Mindestens nach Bedarf:

- Deploy und Rollback;
- Start/Stop/Restart;
- Diagnose kritischer Fehlerbilder;
- Backup und Restore;
- Failover und Disaster Recovery;
- Credential-/Key-Rotation;
- Datenreconciliation;
- Decommission.

## Release

Ein Release Record enthält Scope, Artefaktversionen, Tests, Security/Privacy/Quality-Evidenz, Migration, Feature Flags, Rollback, Monitoring, Owner, Kommunikationsplan, offene Risiken und autorisierte Entscheidung.

Sprint Review, Merge oder CI-Grünstatus sind keine alleinige Release-Freigabe.

## Operational Readiness Review

Prüfe Ownership, Support, SLOs, Observability, Incident, Runbooks, Capacity, Security, Privacy, Backup/Restore, DR, Migration, Rollback, Training, Dokumentation und offene Risiken.

## Handover und Benefits

- Erfasse die Annahme durch den Service Owner.
- Übertrage Residualverpflichtungen mit Owner und Termin.
- Messe reale Outcomes gegen Baseline und Ziel.
- Markiere Attributionseinschränkungen und entscheide Fortführung, Pivot, Skalierung oder Beendigung.
