# Jira field and workflow model

## Capability-first rule

Discover actual work types, required fields, hierarchy levels, workflows, screens, schemes, permissions, link types, plans, automation limits, and dependent apps before proposing changes. Do not invent IDs.

## Minimal delivery fields

- summary and description;
- parent;
- accountable owner/assignee;
- status and resolution;
- priority;
- acceptance criteria;
- release/version;
- component/service;
- controlled requirement/document link;
- test/evidence link;
- typed dependencies;
- security/data classification when applicable.

Reuse existing fields when semantics match. Avoid global custom fields for one-project convenience. Maintain a field dictionary with ID, name, meaning, allowed values, owner, context, and deprecation status.

## Workflow families

### Portfolio/investment

`Draft → Triage → Analysis → Ready for Decision → Approved → In Execution → Measuring Benefits → Done`, with `Rejected` and `Parked` paths.

### Delivery

`Backlog → Ready → In Progress → In Review → Integrated → Done`, with a reversible `Blocked` state.

### Risk

`Identified → Assessed → Treating → Monitoring → Closed`, with authorized `Accepted`.

### Assumption

`Proposed → Validating → Confirmed | Disproved | Expired`.

### Decision

`Proposed → Under Review → Decided → Superseded`.

### Exception

`Requested → Assessed → Approved with Expiry | Rejected → Expired/Closed`.

Keep lifecycle state separate from test evidence. Do not create a status for every activity.

## Link semantics

Prefer `blocks`, `depends_on`, `implements`, `validates`, `mitigates`, `realizes`, and `supersedes`; use generic `relates_to` only when no stronger relation applies.

## Automation governance

Every automation requires owner, purpose, trigger, permissions, failure handling, audit trail, test, and rollback/deactivation. Never overwrite controlled approvals silently.
