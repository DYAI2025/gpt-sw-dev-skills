# Agentenagnostische Kompatibilität

## Bedeutung

Der Kernworkflow ist als portable natürliche Sprache, stabile Schemas und deterministische Python-Skripte formuliert. Er kann an ChatGPT, Claude, Claude Code, Codex-artige Agenten, Cursor, Windsurf und ähnliche Laufzeiten übergeben werden.

Kompatibilität bedeutet nicht identische:

- Tool-, Browser-, Dateisystem- oder Netzwerkfähigkeit;
- Connector- und Jira-Berechtigung;
- Kontext-, Memory- oder Sicherheitsarchitektur;
- Installationsoberfläche;
- Laufzeitergebnisse ohne Evaluation.

## Portabler Kern

- `SKILL.md` als Control Plane;
- `references/` als progressive Fachmodule;
- `assets/templates/` als kontrollierte Ausgabestrukturen;
- `schemas/` als stabile Datenverträge;
- `scripts/` als lokale deterministische Prüfungen;
- `evals/` als Verhaltens- und Triggervertrag.

## Laufzeitspezifisch

- `agents/openai.yaml` ist Metadaten für OpenAI-nahe Skilloberflächen.
- Jira-, Confluence-, GitHub-, Browser- oder MCP-Aktionen müssen pro Client neu gemappt werden.
- Nicht vorhandene Tools führen zu `MANUAL_OR_EXTERNAL_ADAPTER_REQUIRED`, nicht zu simuliertem Erfolg.

## Handoff

1. Lade `SKILL.md` als primäre Instruktion.
2. Lade Referenzen nur für den aktiven Modus.
3. Mappe Tools auf gleichwertige Read-/Write-Fähigkeiten und dokumentiere Abweichungen.
4. Führe Validatoren in einer lokalen Python-Umgebung aus, wenn möglich.
5. Wiederhole Trigger- und Output-Evals in der Ziellaufzeit.
6. Behaupte keine Parität, bevor die Ziellaufzeit evaluiert wurde.
