# Validierungsregeln

## Ebenen

1. Paketstruktur und Frontmatter;
2. Syntax von JSON, JSON-kompatiblem YAML, XML, DOT und Python;
3. Quellen- und Confidence-Disziplin;
4. Vollständigkeit der Evals;
5. Fachliche Artefakt- und Gate-Regeln;
6. Installability, Agenten-Portabilität und Kernfunktions-Erhalt;
7. Release Hook und Enterprise Output Evaluator.

## Harte Paketblocker

- fehlende `SKILL.md` oder `agents/openai.yaml`;
- ungültiger oder nicht zum Ordner passender Name;
- fehlende Pflichtreferenzen, Schemas, Templates, Validatoren oder Evals;
- kaputte relative Referenzen;
- ungültiges JSON/XML/Python/DOT;
- leere Dateien oder unbereinigte Autorenmarker;
- `SOURCE_NEEDED` als unmarkierte harte Regel;
- fehlgeschlagener Release Hook;
- ZIP ohne genau einen Skill-Root;
- Installations- oder Runtimegarantien, die das Paket nicht kontrolliert.

## Fachliche Blocker

- erfundene Projektdaten;
- unbestätigte Vision vor Jira-Apply;
- fehlende Autorität oder Residualrisiko-Akzeptanz;
- Scorewashing trotz Hard Blocker;
- unbekannte kritische Security-/Privacy-/Safety-/Compliance-Lage;
- fehlende Test-/Acceptance- oder Produktionsbetriebsgrundlage;
- Jira-Apply ohne Preflight, Manifest, Dry Run, explizite Erlaubnis und Rollback;
- Coding-Agent-Auftrag mit erfundenem Repository-Kontext.

## Pflichtkommandos

```bash
python scripts/quick_validate.py software-project-start-readiness-orchestrator
python scripts/validate_source_map.py software-project-start-readiness-orchestrator
python scripts/validate_evals.py software-project-start-readiness-orchestrator
python scripts/validate_release_gate.py software-project-start-readiness-orchestrator
python scripts/validate_installability.py software-project-start-readiness-orchestrator
python scripts/validate_agent_agnostic.py software-project-start-readiness-orchestrator
python scripts/validate_core_parity.py software-project-start-readiness-orchestrator
python scripts/validate_enterprise_skill_evaluation.py software-project-start-readiness-orchestrator/reports/enterprise-skill-evaluation.xml
```

Zusätzlich kompiliere alle Python-Skripte, validiere alle JSON-Schemas und rendere `references/workflow.dot` mit Graphviz, wenn verfügbar.

## Releaseentscheidung

`RELEASE_READY` ist nur zulässig, wenn:

- alle deterministischen Hard Checks bestehen;
- Release Gate `PASS` und `allowed_to_package=true` ist;
- Enterprise Evaluation `PASS` oder `PASS_WITH_MINOR_REVISIONS` nach angewandten Revisionen meldet;
- keine blockierten Claims verbleiben;
- Paket `skill.zip` reproduzierbar erzeugt wurde.

Nicht ausgeführte Live-Jira-Mutationen sind kein Paketblocker, solange sie nicht behauptet werden und Runtime-Preflight/Apply-Gates vollständig vorhanden sind.
