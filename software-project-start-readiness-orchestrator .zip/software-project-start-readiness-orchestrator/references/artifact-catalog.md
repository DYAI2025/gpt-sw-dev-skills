# Complete artifact catalog with applicability rules

## 1. Purpose

This catalog defines the information that may be required before a software initiative begins delivery. It is not a mandate to create every document. The Skill shall derive a **minimum sufficient evidence set** from project size, criticality, data sensitivity, regulation, supplier exposure, and operational impact.

## 2. Scaling profiles

| Profile | Typical context | Default governance depth |
|---|---|---|
| `S0 — Exploration` | Spike, discovery, prototype, technical feasibility study; no production data or production commitment | Lean hypothesis, owner, timebox, safety constraints, evidence and stop criteria |
| `S1 — Single-team delivery` | One product team, bounded change, low-to-medium operational risk | Charter-lite, outcome, backlog, architecture baseline, risk/security screening, test and release plan |
| `S2 — Multi-team / product initiative` | Several teams, shared platform, cross-team dependencies, meaningful investment | Full project constitution, dependency and decision governance, target architecture, integrated test and operational readiness |
| `S3 — Enterprise / regulated / critical` | Portfolio investment, regulated data, safety/security criticality, multiple suppliers or business units | Formal governance, assurance, compliance traceability, independent review where required, staged approvals and immutable evidence |

The profile is a starting point. A small project handling highly sensitive data may require `S3` controls in security and privacy while remaining `S1` in delivery coordination.

## 3. Applicability classes

- **M — Mandatory baseline:** required for every initiative, though `S0/S1` may use a compact combined document.
- **C — Conditional:** required when an applicability trigger is true.
- **O — Optional:** useful when it materially improves decisions or coordination.

Every conditional artifact must record either `required` with its trigger or `not_applicable` with a rationale and approver.

## 4. Universal document metadata

Every controlled document shall contain:

- stable document ID and title;
- project/product identifier;
- owner and accountable approver;
- status and version;
- effective date and next review date;
- source and evidence references;
- confidence and unresolved assumptions;
- linked requirements, decisions, risks, tests, and Jira work items;
- superseded document reference;
- concise change log;
- confidentiality and data-classification label;
- approval record or digital signature reference where required.

## 5. Artifact catalog

### A. Intake, classification, and operating model

| Artifact | Class | Trigger / purpose | Minimum content | Start-gate evidence |
|---|---:|---|---|---|
| Initiative intake | M | Every request | problem, requester, affected users, urgency, constraints, known evidence | signed intake record |
| Project/product boundary decision | M | Every request | enduring product boundary, temporary project boundary, owning organization, lifecycle | named product and project owners |
| Project profile and tailoring record | M | Every request | scale profile, criticality, data class, regulation, supplier exposure, operational tier | approved applicability matrix |
| Operating-model decision | M | Every request | chosen primary model: Scrum, Kanban, LeSS, SAFe, hybrid; justified deviations | decision record with consequences |
| Evidence and source inventory | M | Every request | source type, owner, date, reliability, limitations, confidence | no critical claim without evidence |

### B. Mandate, strategy, and benefits

| Artifact | Class | Trigger / purpose | Minimum content | Start-gate evidence |
|---|---:|---|---|---|
| Project charter or charter-lite | M | Establishes authority and boundary | mandate, sponsor, project lead, objectives, high-level scope, funding/capacity envelope, decision authority | sponsor approval |
| Business case / Lean Business Case | C | Meaningful investment, external commitment, portfolio work | options, costs, benefits, risks, assumptions, MVP, stop/pivot criteria | investment decision |
| Product vision and Product Goal | M | Product-related delivery | target users, problem, desired future state, measurable Product Goal | Product Owner approval |
| Benefits map and realization plan | C | Claimed financial/operational/public value | outcomes, leading/lagging indicators, baseline, target, benefits owner, measurement dates | benefits owner accepts measurement |
| Strategic alignment map | C | Portfolio/programme context | objectives/OKRs, contribution, conflicts, strategic constraints | portfolio owner approval |
| Scope and exclusions | M | Every initiative | in scope, out of scope, interfaces, assumptions, acceptance boundary | sponsor/product owner approval |

### C. Governance, organization, and communication

| Artifact | Class | Trigger / purpose | Minimum content | Start-gate evidence |
|---|---:|---|---|---|
| Governance and decision-rights matrix | M | Every initiative | forums, decisions, proposer, decider, veto/assurance roles, residual-risk acceptor, escalation | all critical decisions have an authority |
| Responsibility model | M | Every initiative | accountable owners for product, project, architecture, security, privacy, data, quality, service, suppliers | no unowned mandatory domain |
| Stakeholder register and engagement plan | M | Every initiative | influence, impact, needs, engagement method, cadence, owner | critical stakeholders identified |
| Communication and reporting plan | C | Multi-team, external or executive reporting | audiences, reports, cadence, channels, confidentiality | reporting owner and calendar |
| Change-control and exception policy | C | Controlled baselines, contractual/regulatory scope | change classes, thresholds, approval, emergency path, expiry | approved control path |
| Assurance and independent review plan | C | Regulated, critical, high-value | assurance scope, reviewers, independence, evidence, timing | reviewers assigned |

### D. Discovery, customer evidence, and product design

| Artifact | Class | Trigger / purpose | Minimum content | Start-gate evidence |
|---|---:|---|---|---|
| Problem and opportunity brief | M | Every initiative | user/business problem, affected population, current alternatives, evidence strength | evidence confidence at least acceptable |
| User/customer research synthesis | C | User-facing or workflow-changing product | participants, methods, findings, limitations, consent/privacy constraints | traceable findings |
| Personas/JTBD or service actors | O | Multiple user groups or service roles | goals, context, constraints, non-users, accessibility needs | linked to requirements |
| Assumption and experiment backlog | M | Uncertainty exists | assumption, risk if false, experiment, metric, deadline, owner | critical assumptions have tests or are accepted |
| Outcome roadmap | C | Multi-increment delivery | outcomes, hypotheses, dependencies, decision points, not fixed feature promises | roadmap linked to benefits |
| UX/service blueprint | C | Complex user journey or cross-channel service | actors, touchpoints, backstage processes, failure points | validated critical flows |

### E. Requirements and traceability

| Artifact | Class | Trigger / purpose | Minimum content | Start-gate evidence |
|---|---:|---|---|---|
| Requirements baseline / PRD / SRS | M | Every delivery initiative; depth tailored | functional outcomes, constraints, assumptions, acceptance, priorities, source | reviewed and testable requirements |
| Non-functional requirement catalog | M | Every production-bound system | quality attributes, measurable scenarios, thresholds, evidence method | no critical NFR left qualitative |
| Data requirements and lifecycle | C | Data creation, ingestion, transformation, analytics | data owners, sources, quality, retention, deletion, lineage, residency | data owner approval |
| Interface and integration contract inventory | C | External/internal integrations | systems, owners, API/event/file contract, versioning, auth, failure handling | interface owners accept contracts |
| End-to-end traceability model | M | Every initiative | objective → outcome → requirement → work item → test → release → metric | representative trace path verified |
| Regulatory/compliance obligations matrix | C | Legal, contractual or standard obligations | obligation, applicability, control, evidence, owner, reviewer | no unresolved mandatory obligation |

Use ISO/IEC 25010 quality characteristics as a quality-model reference, then tailor measurable scenarios rather than copying generic labels.

### F. Architecture and technical strategy

| Artifact | Class | Trigger / purpose | Minimum content | Start-gate evidence |
|---|---:|---|---|---|
| Architecture context and stakeholder concerns | M | Every software system | system boundary, actors, external systems, concerns, constraints | architect and owners agree boundary |
| Architecture views and models | C | `S2/S3`, material technical complexity | logical, runtime, deployment, data, security, integration and operations views as applicable | views answer named concerns |
| Architecture Decision Records | M | Material decisions | context, options, decision, rationale, consequences, status, supersession | critical decisions recorded |
| Build/buy/reuse assessment | C | Product/platform/vendor choice | alternatives, cost, lock-in, security, compliance, exit path | decision authority approval |
| Technology and dependency baseline | M | Every implementation | languages, frameworks, runtime, supported versions, dependencies, lifecycle risk | no unsupported critical component |
| API/event/data contract strategy | C | Integration or platform | compatibility, versioning, idempotency, schema ownership, error semantics | contract tests planned |
| Migration/coexistence/decommission strategy | C | Existing data/system affected | cutover, rollback, reconciliation, parallel run, retention, decommission | migration owner and rollback criteria |
| Architecture validation / fitness functions | C | Important architectural qualities | automated or manual checks for boundaries, security, performance, resilience | validation is executable or scheduled |
| Technical-debt policy | C | Long-lived product/multi-team | classification, budget, ownership, expiry, remediation threshold | debt is visible and governed |

Architecture descriptions should conform to a declared convention and identify stakeholders, concerns, viewpoints, views, decisions, and rationale rather than merely presenting diagrams.

### G. Security, privacy, safety, and compliance

| Artifact | Class | Trigger / purpose | Minimum content | Start-gate evidence |
|---|---:|---|---|---|
| Security and privacy applicability screening | M | Every initiative | data, users, trust boundaries, exposure, legal triggers, criticality | accountable security/privacy review |
| Data inventory and classification | C | Any non-trivial data processing | data categories, sensitivity, owner, location, retention, sharing | classification approved |
| Threat model and abuse-case analysis | C | Production, internet-facing, privileged, sensitive or high-impact | assets, actors, trust boundaries, threats, mitigations, residual risk | critical threats owned |
| Privacy impact screening / DPIA | C | Personal data; DPIA where likely high risk | purposes, necessity, proportionality, risks, controls, consultation | completed before high-risk processing |
| Secure development control profile | C | Production-bound software | selected SSDF practices, code review, testing, secrets, dependencies, release integrity | controls assigned and evidenced |
| Identity and access model | C | Authentication/authorization | identities, roles, least privilege, privileged access, joiner/mover/leaver, audit | owner accepts access model |
| Software supply-chain and SBOM plan | C | Third-party packages, containers or firmware | inventory, provenance, scanning, SBOM format, signing/attestation, patch SLA | dependency risk process active |
| Vulnerability and incident response plan | C | Production service | intake, severity, remediation targets, disclosure, emergency change, communication | security/service owners assigned |
| Safety case / hazard analysis | C | Safety-affecting systems | hazards, severity, controls, verification, residual risk authority | safety authority approval |
| Residual-risk acceptance record | C | Any unresolved material risk | risk, controls, exposure, expiry, compensating actions, authorized acceptor | valid acceptance authority |

### H. Quality engineering and validation

| Artifact | Class | Trigger / purpose | Minimum content | Start-gate evidence |
|---|---:|---|---|---|
| Quality management plan | C | `S2/S3`, regulated or high criticality | standards, quality objectives, reviews, defect policy, evidence retention | quality owner approval |
| Integrated test strategy | M | Every delivery initiative | test levels, risk basis, automation, environments, test data, entry/exit criteria, ownership | critical risks mapped to tests |
| Acceptance strategy | M | Every initiative | business, product, technical, security, accessibility and operational acceptance | accountable acceptors named |
| Accessibility plan | C | User interface/content where accessibility applies | target standard (normally WCAG 2.2), scope, testing method, assistive technology, exceptions | owner and test evidence plan |
| Performance and capacity test plan | C | Load/latency/scale material | workload model, targets, environment, thresholds, profiling and capacity actions | measurable scenarios approved |
| Resilience and recovery test plan | C | Production service with continuity needs | fault scenarios, backup/restore, failover, RTO/RPO, chaos/game days if justified | service owner approves tests |
| Test-data and environment plan | C | Data/environment complexity | synthetic/masked data, privacy, refresh, parity, dependencies, ownership | environments and data available |
| Defect and quality-risk policy | M | Every implementation | severity, triage, escape criteria, waiver authority, release thresholds | no undefined release threshold |

Do not mandate a universal code-coverage percentage. Define coverage and testing depth from risk, architecture, language, and defect history.

### I. Delivery system and engineering enablement

| Artifact | Class | Trigger / purpose | Minimum content | Start-gate evidence |
|---|---:|---|---|---|
| Team topology and capacity plan | M | Every initiative | teams, skills, ownership boundaries, capacity, critical gaps, onboarding | capacity is funded and available |
| Delivery roadmap / release strategy | M | Every implementation | increments, milestones, release options, feature flags, dependencies, decision points | first increment is feasible |
| Repository and branching policy | M | Code delivery | repositories, ownership, review rules, protected branches, contribution model | repository controls ready |
| CI/CD and environment baseline | M | Production-bound software | build, test, artifact, deployment, approvals, environments, separation | pipeline path defined and owned |
| Configuration and secrets strategy | C | Runtime configuration/secrets | stores, rotation, access, environment separation, audit, emergency use | no secrets in source or tickets |
| Definition of Ready policy | O | Team finds explicit readiness useful | minimal, outcome-focused entry criteria; never a central approval bureaucracy | team agreement |
| Multi-level Definition of Done | M | Every increment | team, integrated system and release/operation evidence as applicable | shared and testable DoD |
| Dependency and integration plan | C | Multiple teams/systems | dependency owner, required date, confidence, integration cadence, fallback | critical path validated |

### J. Operations and service readiness

| Artifact | Class | Trigger / purpose | Minimum content | Start-gate evidence |
|---|---:|---|---|---|
| Service ownership and support model | M for production | service owner, support tiers, hours, contacts, responsibilities, handover | operator accepts ownership path |
| Service objectives | C | Production service | SLI, SLO, error budget, SLA/OLA where contractual, measurement source | measurable and owned objectives |
| Observability and audit plan | M for production | logs, metrics, traces, events, dashboards, alerting, audit evidence, retention | critical journeys observable |
| Incident, problem and escalation model | M for production | severity, roles, on-call, communication, post-incident learning | response owners and channels ready |
| Runbook catalog | C | Operated service | deploy, rollback, restart, recovery, known failure modes, diagnostics | minimum runbooks identified |
| Backup/restore and disaster-recovery plan | C | Persistent/critical data or service | backup policy, restore test, RTO/RPO, dependencies, recovery authority | restore test scheduled or completed |
| Capacity, performance and cost model | C | Material scale/cloud spend | demand model, limits, scaling, budget alerts, cost ownership | owner accepts thresholds |
| Operational Readiness Review | M for production | service before production | controls, monitoring, support, resilience, security, docs, training, open risks | formal ORR decision |
| Decommission and exit plan | C | Replacement, supplier/cloud dependency | retention, export, archival, shutdown, contract exit, user communication | exit path is feasible |

### K. Risk, dependency, decision, and control records

| Artifact | Class | Trigger / purpose | Minimum content | Start-gate evidence |
|---|---:|---|---|---|
| Risk register | M | Every initiative | cause-event-impact, likelihood, impact, exposure, response, owner, due date, residual risk | critical risks treated or accepted |
| Assumption register | M | Every initiative | assumption, evidence, falsification condition, owner, expiry | critical assumptions tested/accepted |
| Issue log | M | Every initiative | current issue, impact, action, owner, date, escalation | no unowned critical issue |
| Dependency register | C | External/cross-team prerequisites | provider, consumer, deliverable, date, confidence, fallback, owner | critical dependencies committed |
| Decision log | M | Every initiative | decision, authority, options, rationale, consequences, date, supersession | major decisions traceable |
| Experiment register | C | High uncertainty | hypothesis, method, metric, threshold, result, decision | outcome affects plan |
| Exception/waiver register | C | Departures from policy/baseline | rule, rationale, risk, compensating control, approver, expiry | no permanent silent exception |

These may share one controlled system, but their semantics and lifecycle states must remain distinct.

### L. Commercial, supplier, legal, and financial controls

| Artifact | Class | Trigger / purpose | Minimum content | Start-gate evidence |
|---|---:|---|---|---|
| Funding and cost baseline | M | Every initiative | funding source, capacity/cost envelope, contingency, approval, forecast cadence | funds/capacity approved |
| Procurement and supplier plan | C | External purchase/service | procurement route, evaluation, due diligence, contract owner, lead times | procurement path feasible |
| Vendor risk and dependency assessment | C | Critical supplier/service | security, privacy, resilience, concentration, roadmap, support, exit | risk owner accepts exposure |
| Licensing and intellectual-property review | C | Third-party/open-source/content/data | licenses, obligations, attribution, redistribution, patents, data rights | legal/IP review complete where needed |
| Data-processing and contractual controls | C | Personal/confidential data with third parties | DPA, sub-processors, residency, breach duties, deletion, audit rights | contract controls in place |
| Financial benefits and value tracking | C | Business case claims value | baseline, forecast, actuals, attribution limits, owner | measurement mechanism defined |

### M. Start, release, handover, and benefits gates

| Artifact | Class | Trigger / purpose | Minimum content | Gate evidence |
|---|---:|---|---|---|
| Discovery authorization | C | Paid/material discovery | question, timebox, budget, safe boundaries, evidence, stop criteria | discovery decision |
| Project constitution approval | M | Before material delivery commitment | mandate, owners, scope, governance, funding, risk profile | constitution gate record |
| Delivery-start readiness report | M | Before implementation starts | artifact status, blockers, residual risks, Jira capability, decision | start-gate record |
| Release-readiness report | C | Before production release | test, security, operations, migration, rollback, approvals | release decision |
| Operational handover record | C | New/changed production service | ownership, runbooks, monitoring, support, training, open risks | service acceptance |
| Benefits review | C | Benefit claim exists | actual outcomes, variance, lessons, next decision | benefits owner review |
| Closure and knowledge-transfer report | C | Temporary project closes | deliverables, residual work, decisions, archives, contracts, lessons | sponsor/project lead closure |

## 6. Minimum baseline by profile

### S0 — Exploration

- initiative intake;
- project/product boundary;
- owner and decision authority;
- problem/hypothesis;
- evidence/source inventory;
- timebox, budget/capacity, safe operating constraints;
- assumptions/risks;
- experiment and stop criteria;
- outcome record.

An `S0` item must not silently become production delivery. Transition to `S1+` requires reclassification and a new gate.

### S1 — Single-team delivery

All `S0` elements plus:

- charter-lite and measurable outcome;
- Product Goal and scope/exclusions;
- responsibility/decision-rights model;
- requirements and NFR baseline;
- architecture context and ADRs;
- security/privacy screening;
- integrated test strategy and acceptance;
- repository/CI/CD/environment baseline;
- risk, assumption, issue and decision records;
- release strategy;
- service owner/observability/incident model for production;
- Jira provisioning manifest;
- delivery-start gate.

### S2 — Multi-team / product initiative

All `S1` elements plus:

- full business case and benefits realization;
- stakeholder/communication governance;
- architecture views and interface contracts;
- dependency and integration governance;
- data and migration strategy;
- quality plan;
- operational readiness plan;
- supplier controls where applicable;
- integrated roadmap and multi-team Jira plan;
- independent or cross-functional readiness review.

### S3 — Enterprise / regulated / critical

All `S2` elements plus applicable:

- formal assurance and compliance matrix;
- DPIA, threat model, safety/hazard case;
- secure development control profile and supply-chain evidence;
- independent architecture/security/privacy/quality reviews;
- evidence retention and immutable approval records;
- formal release and operational handover gates;
- residual-risk acceptance by authorized executives/functions;
- benefits and post-implementation assurance reviews.

## 7. Traceability rule

The Skill shall prove at least one complete trace for every critical outcome:

`Strategic objective → business outcome → Product Goal → requirement/hypothesis → architecture decision/control → Jira work item → acceptance/test evidence → release → operational metric → realized benefit`

A hyperlink alone is not sufficient. The relationship type and responsible owner must be explicit.
