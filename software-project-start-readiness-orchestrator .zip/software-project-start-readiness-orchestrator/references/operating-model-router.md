# Operating-Model-Router

## Regel

Wähle ein primäres Arbeitsmodell. Dokumentiere zusätzliche Koordinationsmuster als bewusste Ergänzung. Nenne einen Hybrid nie „Scrum“, „Kanban“, „LeSS“ oder „SAFe“, wenn zentrale Regeln des jeweiligen Modells abweichen.

## Auswahlmatrix

| Dominante Situation | Primäres Modell | Prüffragen |
|---|---|---|
| stabiles Produktteam, gemeinsames Product Goal, regelmäßige integrierte Inkremente | Scrum | Ist ein nutzbares Inkrement pro Sprint realistisch? Gibt es einen Product Owner und ein gemeinsames Backlog? |
| kontinuierlicher variabler Arbeitszufluss, Support/Operations, Serviceklassen | Kanban | Sind Commitment-/Delivery-Points, WIP, Flow-Metriken und explizite Policies zentral? |
| Mischung aus planbaren Produktinkrementen und substanzieller ungeplanter Arbeit | explizites Scrumban-/Dual-Flow-Modell | Welche Regeln stammen aus welchem Modell? Wie werden Kapazität und Expedite-Arbeit begrenzt? |
| mehrere Teams an einem Produkt mit einem Product Backlog und einem integrierten Inkrement | LeSS prüfen | Sind ein Product Owner, ein Backlog und gemeinsamer Sprint tatsächlich gewollt? |
| Portfolio-/ART-/PI-Struktur ist organisatorisch verbindlich | SAFe-spezifisches Modell | Welche SAFe-Konfiguration und Begriffe sind offiziell eingeführt? |
| systemische Koordination zwischen Strategie, End-to-End-Fluss und Teams | Flight-Levels-orientierte Steuerung | Welche Interaktionen und Flüsse werden verbessert, ohne Rollenmodell zu erfinden? |
| Coding-Agenten als Ausführende | Agenten-Handoff-Schicht, kein eigenständiges agiles Framework | Sind Repository, Grenzen, Tests, Verifikation und Stop-Regeln vorhanden? |

## Entscheidungsprozess

1. Beschreibe Liefercharakteristik, Unsicherheit, Arbeitsankunft, Teamstabilität und Integrationsbedarf.
2. Prüfe die einfachste passende Option.
3. Formuliere das stärkste Gegenargument gegen die bevorzugte Option.
4. Wähle primäres Modell und dokumentiere verworfene Alternativen.
5. Liste Rollen, Artefakte, Ereignisse und Metriken, die tatsächlich verwendet werden.
6. Markiere Abweichungen und Konsequenzen.
7. Prüfe nach zwei bis vier Lieferzyklen, ob das Modell Flow und Lernen verbessert.

## Scrum-Minimum

- ein Scrum Team;
- Product Owner, Scrum Master, Developers als Accountabilities;
- Product Goal, geordnetes Product Backlog, Sprint Goal, Sprint Backlog, Increment und Definition of Done;
- Sprint Planning, Daily Scrum, Sprint Review und Sprint Retrospective;
- Sprint-fähige, testbare Items.

Ein Sprint Review ist kein Release Gate und kein Projektstart-Gate.

## Kanban-Minimum

- Servicegrenzen und Work-Item-Typen;
- Commitment- und Delivery-Points;
- visualisierter Workflow;
- WIP-Limits und Pull-Regeln;
- explizite Policies und Blockerregeln;
- Serviceklassen nur bei echtem Bedarf;
- Flow-Metriken und Feedbackschleifen.

Vermeide Statusspalten, die nur Tätigkeiten statt Zustandsänderungen abbilden.

## Multi-Team-Regel

Prüfe zuerst, ob ein gemeinsames Product Goal und ein gemeinsames Product Backlog genügen. Füge Capabilities, Programmebenen oder zusätzliche Jira-Hierarchien nur hinzu, wenn sie Entscheidungen, Ownership oder End-to-End-Traceability messbar verbessern.
