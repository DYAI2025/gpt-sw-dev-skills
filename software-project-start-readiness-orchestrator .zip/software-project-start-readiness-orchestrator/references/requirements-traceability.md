# Requirements und Traceability

## Requirements-Baseline

Erzeuge eine nach Projektrisiko angemessene PRD/SRS-Baseline. Jede Anforderung enthält:

- stabile ID;
- Quelle und Faktenstatus;
- betroffene Nutzer oder Systemakteure;
- gewünschtes beobachtbares Verhalten oder Ergebnis;
- Scope und Ausschlüsse;
- Priorität und Begründung;
- Akzeptanzkriterien;
- NFR- und Datenauswirkungen;
- Abhängigkeiten, Risiken und Owner;
- Verifikationsmethode und Evidenzziel;
- Änderungs- und Reviewstatus.

Formuliere keine Lösung als Requirement, solange die Lösung nicht entschieden ist.

## NFR-Szenario

Verwende für kritische Qualitätsattribute ein messbares Szenario:

```text
Quelle/Stimulus → betroffener Teil → Umgebungsbedingung → erwartete Reaktion → messbare Schwelle → Nachweismethode
```

Beispiele für Attribute: Performance, Verfügbarkeit, Security, Privacy, Accessibility, Maintainability, Compatibility, Portability, Reliability und Recoverability. Kopiere keine generischen Qualitätslabels ohne messbare Schwelle.

## Traceability-Kette

Beweise für jedes kritische Outcome:

```text
Strategisches Ziel
→ Nutzer- oder Geschäftsergebnis
→ Product Goal
→ Requirement oder Hypothese
→ Architekturentscheidung oder Control
→ Jira-Vorgang
→ Akzeptanz- und Testnachweis
→ Release
→ Betriebsmetrik
→ realisierter Nutzen
```

Jeder Link enthält Beziehungstyp, Owner, Status und Evidenz. Ein Hyperlink allein genügt nicht.

## Pflichtprüfungen

Blockiere oder warne bei:

- verwaistem kritischem Requirement;
- Arbeit ohne Outcome oder Product Goal;
- Feature ohne Akzeptanz oder NFR-Betrachtung;
- kritischem NFR ohne Test;
- Risiko ohne Behandlung und Owner;
- Entscheidung ohne Umsetzung;
- Test ohne Requirement oder Risiko;
- Release ohne Betriebsnachweis;
- abgeschlossenem Ticket ohne Aktualisierung dauerhaften Systemwissens;
- Nutzenmetrik ohne Baseline, Owner oder Messdatum.

## Baseline und Änderung

- Versioniere Requirements und Traceability.
- Änderungen nach Freigabe benötigen Impact-Analyse auf Architektur, Tests, Betrieb, Jira, Risiken und Gate.
- Ersetze keine historischen Entscheidungen; markiere Supersession.
- Bewahre Quelle und rationale Ableitung auf.
