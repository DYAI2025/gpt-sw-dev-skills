# Produktvision und Produktstruktur

## Visionsergebnisse

Erzeuge drei konsistente Darstellungen.

### Kurzvision

Ein verständlicher Absatz mit Zielgruppe, Problem, gewünschtem Ergebnis, Lösungsprinzip, zentralem Nutzen und Abgrenzung.

### Erweiterte Vision

Beschreibe:

- Ausgangs- und Zielzustand;
- Nutzererlebnis und Nutzungskontext;
- Nutzen für Nutzer und Organisation;
- zentrale Produktfähigkeiten;
- Scope und Grenzen;
- messbare Outcomes und Metriken;
- wichtigste Unsicherheiten, Risiken und Annahmen.

### Vision Statement

```text
Für [Zielgruppe], die [Problem oder Bedarf] hat, ist [Produktname] ein [Produkttyp oder Lösungsansatz], der [beobachtbaren Nutzen] ermöglicht. Im Gegensatz zu [heutiger Alternative] bietet die Lösung [entscheidenden Unterschied].
```

Ersatzfelder bleiben `MISSING`, bis sie bestätigt sind. Erfinde keine Markt- oder Nutzerbelege.

## Visionstatus

- `VISION_DRAFT`: initialer, quellenmarkierter Entwurf;
- `VISION_REVIEWED`: Nutzer hat geprüft, aber nicht bestätigt;
- `VISION_CONFIRMED`: konkrete Version ausdrücklich bestätigt;
- `VISION_REJECTED`: Nutzer lehnt ab;
- `VISION_REVISION_REQUIRED`: materieller Klärungsbedarf.

Speichere Bestätigung mit Version, Datum, bestätigender Identität und Umfang.

Ohne `VISION_CONFIRMED`:

- darf ein vorläufiger Artefaktplan entstehen;
- darf ein Jira-Dry-Run als Hypothese entstehen;
- darf keine endgültige Jira-Provisionierung oder Delivery-Start-Freigabe erfolgen.

## Product Vision Map

Modelliere mindestens:

`Zielgruppe → Problem → Wertversprechen → Outcome → Produktfähigkeit → Metrik`

Verknüpfe Risiken und Annahmen mit dem jeweils betroffenen Knoten. Zeige Evidenzstärke und Owner.

## Produktstruktur

Leite nach Visionbestätigung schrittweise ab:

1. Produktgrenze und externe Akteure;
2. fachliche Domänen;
3. Capabilities;
4. Features oder Services;
5. Komponenten und Datenobjekte;
6. Schnittstellen und externe Systeme;
7. Ownership und Lebenszyklus.

Die Struktur beschreibt dauerhafte Produkt- und Systemgrenzen. Jira-Tickets beschreiben Veränderungen daran.

## Änderungsregel

Eine materielle Änderung an Zielgruppe, Problem, Outcome, Scope, Datenverwendung, Architekturgrenze oder Betriebsmodell setzt:

- `VISION_REVISION_REQUIRED`;
- Impact-Analyse für Artefakte, Gate und Jira-Manifest;
- neue ausdrückliche Bestätigung;
- Revalidierung einer vorhandenen Freigabe.
