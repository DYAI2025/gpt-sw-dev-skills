# Evaluationsdesign

## Schichten

### Trigger-Evals

`evals/trigger_queries.json` enthält positive und nahe negative Fälle. Bestehen bedeutet: relevante Projektstart-, Readiness-, Jira-Bootstrap- und Gate-Anfragen aktivieren den Skill; Routine-Sprintplanung, reine Codeimplementierung und allgemeine PM-Fragen ohne Startreifebezug aktivieren ihn nicht.

### Output-Evals

`evals/output_evals.json` deckt die zwanzig Auftragsszenarien ab. Jedes Szenario definiert erwartete Eigenschaften, Hard Failures und erlaubte Annahmen.

### Interview- und Pressure-Evals

- `evals/interview_scenarios.md` prüft adaptive Fragefolge, Wiederholungsvermeidung und Confirmation Gates.
- `evals/pressure_scenarios.md` prüft Widerstand gegen Nutzerdrang, Scorewashing, Frameworkfixierung, Toolerfolg ohne Read-back und erfundene Repositorydaten.

### Jira Read-only Evals

`evals/jira-read-only-evals.xml` nutzt den versionierten, synthetischen Sandbox-Snapshot `evals/fixtures/jira-sandbox-snapshot.json`. Das Fixture ist keine Behauptung über einen realen Jira-Standort. Es ermöglicht stabile, nicht-destruktive Evalantworten. Für einen realen Connector müssen nach Sandbox-Inspektion neue, standortgebundene stabile Evals erzeugt werden.

## Akzeptanz

- mindestens 10 positive und 8 negative Triggerfälle;
- alle 20 fachlichen Output-Szenarien;
- keine Evaluation verlangt destruktive Aktionen;
- Jira-/Toolfragen sind read-only, unabhängig und stabil;
- Release Gate und Validatoren bestehen;
- offene `SOURCE_NEEDED`-Punkte werden nicht als bestandene Live-Capability ausgegeben.

## Baseline-Fehler ohne Skill

Erwartete naive Fehler:

- sofortiger Feature-Backlog aus einer Lösungsidee;
- statischer Fragebogen;
- unbestätigte Vision;
- ein universeller Dokumentensatz;
- tiefe Jira-Hierarchie ohne Plan-/Permission-Preflight;
- KI-Empfehlung als Freigabe;
- Scorewashing;
- Coding-Agent-Auftrag mit erfundenen Pfaden;
- Toolerfolg ohne Read-back.

Die Evals prüfen, dass der Skill diese Muster systematisch unterbindet.
