# Start gate and audit model

## 1. Purpose

The start gate is a formal, evidence-based authorization to commit material delivery capacity. It is not a ceremonial checklist and not a substitute for empirical product discovery. It establishes that the initiative is sufficiently constituted, owned, bounded, financed, testable, secure, operable, and technically feasible to begin the next approved phase.

## 2. Separate gates

The Skill shall distinguish at least these decisions:

| Gate | Decision question | Typical authority |
|---|---|---|
| `G0_DISCOVERY` | May a bounded discovery/experiment start? | Product sponsor / budget owner |
| `G1_INVESTMENT` | Is further investment justified by the evidence and options? | Sponsor / portfolio authority |
| `G2_CONSTITUTION` | Are mandate, scope, owners, governance, funding and constraints valid? | Sponsor / steering authority |
| `G3_DELIVERY_START` | Is the initiative ready to begin implementation safely and effectively? | Named start-gate authority with assurance sign-offs |
| `G4_RELEASE` | Is this increment safe and ready for production or external use? | Product, engineering, security/privacy/quality and service authorities as applicable |
| `G5_OPERATIONAL_HANDOVER` | Has the operating organization accepted the service and residual obligations? | Service owner / operations authority |
| `G6_BENEFITS_REVIEW` | Were intended outcomes realized and what decision follows? | Benefits owner / sponsor |

A gate may authorize only the phase named in its scope. Discovery approval does not imply delivery or production approval.

## 3. Gate states

| State | Meaning |
|---|---|
| `DRAFT` | Evidence collection incomplete; no decision requested |
| `IN_REVIEW` | Complete enough for reviewers to assess |
| `BLOCKED` | One or more hard blockers prohibit approval |
| `CONDITIONAL_APPROVAL` | Phase may start under explicit, bounded, non-critical conditions with owners and deadlines |
| `APPROVED` | All mandatory criteria met; residual risks accepted by authorized roles |
| `REJECTED` | Authority declined the proposal; rationale and next options recorded |
| `EXPIRED` | Approval validity ended or revalidation trigger occurred |
| `REVOKED` | Authority withdrew approval due to changed or false conditions |

## 4. Non-negotiable hard blockers

The following conditions force `BLOCKED` for `G2/G3` unless the gate explicitly covers only a safe, bounded discovery activity:

1. No named sponsor or decision authority.
2. No accountable Product Owner/product owner for product work, or no accountable project/programme lead where temporary project coordination is required.
3. Unclear product/project boundary, target users, or material scope.
4. No measurable outcome, Product Goal, or falsifiable success/stop criteria.
5. No approved funding/capacity envelope or critical skills unavailable.
6. Critical legal, regulatory, contractual, privacy, security, safety, or data applicability unknown.
7. A required DPIA, threat model, safety assessment, or other mandatory assurance is absent or contains unresolved critical findings.
8. No architecture boundary/baseline for a material or high-criticality system.
9. Critical interfaces, data ownership, migration, or suppliers have no accountable owner or feasible path.
10. No integrated test and acceptance strategy for critical outcomes and risks.
11. Production-bound work has no service owner, support path, observability concept, incident model, or release/rollback strategy.
12. Critical risks, assumptions, issues, or dependencies are unowned, unassessed, or past due.
13. Required evidence is missing, contradictory, outdated, or below the defined confidence threshold.
14. Jira/tooling hierarchy, permissions, or configuration capability is insufficient for the claimed provisioning plan.
15. Approval would depend on a score while a hard blocker remains open.
16. The requested work violates organizational policy or lacks authorized exception/waiver.

## 5. Conditional approval constraints

`CONDITIONAL_APPROVAL` is permitted only when all of these are true:

- the gap is non-critical and does not involve unknown or unacceptable legal, privacy, security, safety, funding, or operational exposure;
- the authorized phase can proceed safely without the missing item;
- each condition has a concrete deliverable, accountable owner, due date, verification method, and escalation path;
- approval has an expiry date;
- breach of a condition automatically blocks affected work or revokes approval;
- the decision authority explicitly accepts the bounded residual risk.

Examples appropriate for conditional approval:

- a non-critical dashboard is due before the second increment;
- a secondary stakeholder workshop is scheduled and does not change the core scope;
- a low-risk ADR must be finalized before implementation of the affected component.

Examples not appropriate:

- “security review later” for an internet-facing production system;
- unresolved lawful basis or high-risk data processing;
- absent service owner for a planned production release;
- unfunded team capacity;
- unknown architecture for a critical integration.

## 6. Evidence domains and criteria

For `G3_DELIVERY_START`, assess these domains:

| Domain | Mandatory questions | Evidence examples |
|---|---|---|
| Mandate and value | Is the problem real, outcome measurable, scope bounded, sponsor authorized? | charter, business case, evidence synthesis, Product Goal |
| Governance and ownership | Are decisions, veto/assurance roles, escalation and residual-risk authorities explicit? | decision-rights matrix, responsibility model, stakeholder plan |
| Funding and capacity | Are budget/capacity and key skills available for the authorized phase? | funding approval, capacity plan, supplier lead-time evidence |
| Requirements and traceability | Are critical needs testable and traceable to outcomes and evidence? | PRD/SRS, NFR scenarios, traceability sample |
| Architecture and data | Are boundaries, critical decisions, interfaces, data ownership and migration feasible? | context/views, ADRs, contracts, data model, migration plan |
| Security/privacy/safety/compliance | Are applicable obligations known, controls planned, critical findings resolved or accepted? | screening, threat model, DPIA, control matrix, risk acceptance |
| Quality and validation | Is there a risk-based strategy to verify functionality and quality attributes? | test strategy, acceptance plan, environments/test data |
| Delivery system | Are teams, repositories, CI/CD, environments, dependencies and first increment ready? | team topology, pipeline design, dependency plan |
| Operations and release | Can the resulting service be observed, supported, recovered, released and rolled back? | service model, SLOs, observability, incident, runbooks, rollback |
| Commercial/supplier | Are procurement, contracts, licenses, data rights and exit risks controlled? | vendor assessment, contract plan, license/IP review |
| Jira/tooling readiness | Can the approved information model be provisioned and verified with available rights/tools? | capability preflight, dry-run manifest, permission evidence |
| Evidence integrity | Are sources current enough, attributable, versioned and non-contradictory? | source map, document metadata, review log |

## 7. Evidence status model

Each criterion receives one state:

- `MET` — required evidence exists, is current enough, reviewed, and satisfies the criterion.
- `PARTIALLY_MET` — evidence exists but a bounded non-critical gap remains.
- `NOT_MET` — required evidence is absent or inadequate.
- `NOT_APPLICABLE` — trigger does not apply; rationale and approver recorded.
- `UNKNOWN` — applicability or evidence cannot be determined; treat as a blocker for critical domains.

Each evidence item includes:

- ID, title, version, owner, source, date;
- classification (`primary`, `secondary`, `user_provided`, `derived`, `uncertain`);
- confidence score 1–5;
- criterion links;
- reviewer and review date;
- limitations and contradictions;
- hash or immutable reference where required.

Hard rules should normally require confidence 4–5. Confidence 3 may support a documented assumption. Confidence 1–2 cannot justify approval.

## 8. Scoring without scorewashing

A domain score may summarize completeness:

```text
MET = 1.0
PARTIALLY_MET = 0.5
NOT_MET = 0.0
UNKNOWN = 0.0
NOT_APPLICABLE = excluded from denominator
```

However:

- scores are informational, not decisive;
- no weighted average can override a hard blocker;
- security/privacy/safety/compliance and funding/authority criteria are not tradeable against documentation quantity;
- an approval decision must cite evidence and residual risks, not only a percentage.

## 9. Decision authority and separation of duties

The gate record shall identify:

- proposer;
- accountable sponsor;
- gate chair/decider;
- Product Owner/product owner;
- project/programme lead where applicable;
- architecture reviewer;
- security reviewer;
- privacy/DPO reviewer where applicable;
- data owner;
- quality/test reviewer;
- service/operations owner;
- commercial/legal reviewer where applicable;
- residual-risk acceptor;
- recorder/audit owner.

The same person should not unilaterally propose, review every assurance domain, and approve a high-risk initiative. Required independence is determined by organizational policy and criticality.

## 10. Exception and waiver model

An exception must contain:

- policy/control being waived;
- reason and alternatives considered;
- risk introduced;
- compensating controls;
- affected scope;
- authorized approver;
- start and expiry dates;
- verification and monitoring;
- remediation owner and due date;
- automatic revalidation trigger.

No exception is permanent by default. Expired exceptions become blockers.

## 11. Revalidation triggers

Approval expires or must be revalidated when any of these occurs:

- material scope, Product Goal, architecture, data use, user group, supplier, or deployment model changes;
- new regulatory or contractual obligation applies;
- critical risk increases or a new critical finding appears;
- funding/capacity falls below the approved envelope;
- critical owner leaves or refuses acceptance;
- target Jira configuration/hierarchy changes materially;
- approval conditions or review dates are missed;
- evidence used for the decision is found inaccurate or superseded;
- project remains inactive beyond the approved start window;
- transition to a new phase not covered by the current gate.

## 12. Audit workflow

1. **Normalize request:** identify gate, phase, scope, project profile, target date and authority.
2. **Inventory evidence:** collect documents, Jira/Confluence records, repository/runtime evidence and source confidence.
3. **Determine applicability:** produce mandatory/conditional/not-applicable artifact matrix.
4. **Validate structure:** document IDs, versions, owners, approvals, links, freshness and signatures.
5. **Validate substance:** testability, consistency, feasibility, security/privacy/compliance, operations, funding and ownership.
6. **Run cross-evidence checks:** identify contradictions, orphan requirements, unowned risks, missing test evidence and broken traceability.
7. **Check Jira capability:** inspect plan, permissions, hierarchy, schemes, work types, fields and dry-run manifest.
8. **Identify blockers and conditions:** classify severity and decision impact.
9. **Generate challenge review:** strongest counterargument, failure modes, missing alternatives and confirmation-bias risks.
10. **Draft decision:** `BLOCKED`, `CONDITIONAL_APPROVAL`, `APPROVED`, or `REJECTED`, with evidence and residual risks.
11. **Obtain authorized decision:** the Skill may recommend or record approval, but shall not impersonate an organizational authority.
12. **Freeze record:** version/hash decision, conditions, approvers and evidence references.
13. **Provision only after approval:** apply Jira/Confluence changes under explicit authorization.
14. **Verify and report:** read back actual state and attach validation results.

## 13. Critical truth boundary for an AI Skill

The future Skill may:

- research and synthesize evidence;
- generate and validate documents;
- calculate completeness indicators;
- detect hard blockers and contradictions;
- recommend a decision;
- prepare an approval record;
- record the decision made by an authorized human or configured governance service;
- provision tools after authorization.

It must not claim independent legal, executive, safety, privacy, security, or financial authority. “Approved by the Skill” means only that deterministic criteria passed unless an authorized human/system decision is also recorded. The output must distinguish:

- `AUTOMATED_VALIDATION_PASSED`;
- `AI_RECOMMENDATION`;
- `AUTHORIZED_DECISION`.

Only the third constitutes organizational permission to start.
