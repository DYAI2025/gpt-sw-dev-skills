# Backlog-Zerlegung und Arbeitspakete

## Kette

Nutze nur die Ebenen, die Entscheidungen tragen:

```text
Vision → Outcomes → Product Goal → Initiative → Epic/Capability → Feature → Story/Enabler → Task/Subtask → Test- und Evidenznachweis
```

Nicht jede Ebene ist erforderlich. Vermeide doppelte Epic-Begriffe.

## Qualitätsvertrag je Element

Jedes relevante Element enthält:

- stabile ID, Typ, Parent und Owner;
- Nutzer- oder Systemnutzen;
- Problem oder gewünschte Veränderung;
- Scope und Out-of-Scope;
- Akzeptanzkriterien;
- NFR-, Daten-, Security-, Privacy- und Betriebsauswirkungen;
- Dependencies, Risiken und offene Entscheidungen;
- Test- und Evidenzanforderungen;
- Definition of Done;
- Priorität und Begründung;
- Größeninformation nur, wenn sie eine Entscheidung unterstützt;
- Links zu Requirements, ADRs, Controls und Gate-Bedingungen.

## Titel

Titel benennen konkretes Ergebnis oder Verhalten.

Schwach: `Login verbessern`, `API fixen`, `Backend-Arbeit`.

Stark: `Passwortlose Anmeldung für registrierte Geschäftskunden ermöglichen`, `Idempotente Verarbeitung eingehender Zahlungsereignisse sicherstellen`.

Vermeide unbestätigte Lösungsentscheidungen im Titel.

## Priorisierung

Berücksichtige Nutzerwert, Geschäftswert, Lernwert, Risikoreduktion, Zeitkritikalität, Compliance, Dependencies, technische Enabler, Betriebsrisiko, Aufwand, Reversibilität und kleinsten testbaren End-to-End-Schnitt.

WSJF ist nur zulässig, wenn Eingangswerte transparent und relativ vergleichbar sind. Es ersetzt keine Investment-, Risiko- oder Compliance-Entscheidung.

## Scrum-Vorbereitung

Erzeuge Product Goal, geordnetes Product Backlog, Sprint-fähige Items, mögliche Sprint Goals, gemeinsame Definition of Done, Integrationskriterien, Dependency-Sicht und Startfähigkeit des ersten Sprints. Ausgewählt bedeutet nicht `In Progress`.

## Kanban-Vorbereitung

Erzeuge Services, Work-Item-Typen, Commitment-/Delivery-Points, echte Workflowzustände, WIP-Limits, Pull-Regeln, Serviceklassen nach Bedarf, Blockerregeln, Replenishment, Service-Level-Erwartungen und Flow-Metriken.

## Enabler und Spikes

- Enabler benötigen eine konkrete Fähigkeit oder Risikoreduktion und verknüpften Nutzer-/Systemwert.
- Spikes benötigen Frage, Timebox, Methode, Evidenz, Entscheidungskriterium und Folgeentscheidung.
- Technische Schuld benötigt Ursache, Auswirkung, Owner, Schwelle und Remediation-Entscheidung.
