# End-to-end traceability model

## Required semantic chain

For every critical outcome, prove:

`Strategic objective → Business outcome → Product Goal → Requirement or hypothesis → Architecture decision or control → Jira work item → Test or acceptance evidence → Release → Operational metric → Realized benefit`

## Link record

Each relationship contains:

- `source_id`
- `target_id`
- `relationship_type`
- `owner`
- `evidence_ref`
- `status`
- `last_verified`

Allowed relationship types include `contributes_to`, `defines`, `implements`, `constrained_by`, `validated_by`, `released_in`, `measured_by`, `realizes`, `mitigates`, `depends_on`, and `supersedes`.

## Integrity rules

1. A hyperlink without relationship type and owner is not sufficient.
2. Critical requirements require test or acceptance evidence.
3. Completed features require release and evidence links where a release exists.
4. Benefits claims require a baseline, target, metric owner, measurement date, and attribution limitation.
5. A broken critical trace is a gate blocker unless the relevant gate scope is explicitly narrower.
6. Do not duplicate enduring knowledge into every ticket; link tickets to controlled documents and immutable evidence references.
