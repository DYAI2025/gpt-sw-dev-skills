# Adaptives Interviewprotokoll

## Ziel

Ermittle nur Informationen, die den nächsten Entwurf materiell verändern. Vermeide einen statischen Universalfragebogen und wiederhole keine beantwortete Frage.

## Interviewzustand

Führe während des gesamten Interviews:

- Faktenregister;
- Quellenregister;
- Entscheidungsregister;
- Annahmenregister;
- Konfliktliste;
- Blockerliste;
- Bestätigungsprotokoll.

Jede Frage erhält intern einen Zweck: `scope`, `value`, `authority`, `risk`, `architecture`, `delivery`, `operations`, `jira` oder `gate`.

## Block A — Ausgangslage

Kläre nur fehlende, entscheidende Punkte:

- Arbeitstitel, Initiator, Sponsor und Ziel-Gate;
- Problem oder Chance, Zielgruppen, heutiger und gewünschter Zustand;
- erwarteter Nutzen und bestehende Alternativen;
- Systeme, Daten, Schnittstellen und Einsatzkontext;
- Zieltermin, externe Zusagen und harte Einschränkungen.

Stoppe den Block, sobald Problem, Zielgruppe, Nutzenhypothese und Zielphase ausreichend klar sind.

## Block B — Produkt und Nutzen

Klärpunkte:

- Product Vision und Product Goal;
- Nutzungssituationen oder Jobs-to-be-Done;
- primäre und sekundäre Nutzer;
- beobachtbare Outcomes, Leading und Lagging Indicators;
- MVP/Experiment, Full Scope, Out-of-Scope;
- Stop-, Pivot- und Fortführungskriterien.

Erzeuge danach einen Vision Draft und fordere keine weitere Detailklärung, bevor der Nutzer den Draft prüfen konnte.

## Block C — Projektkonstitution

Klärpunkte:

- Produkt-/Projektgrenze;
- Sponsor, Product Owner/Product Manager, Projekt-/Programmleitung;
- Architektur, Security, Privacy, Daten, Qualität und Betrieb;
- Budget-/Kapazitätsrahmen, Teams und Kompetenzen;
- Lieferanten, Dependencies, Decision Rights, Eskalation und Residualrisiko-Autorität.

Fehlende kritische Owner werden `BLOCKER`.

## Block D — Fachlichkeit und System

Klärpunkte:

- zentrale Fähigkeiten, Geschäftsregeln, Rollen und Prozesse;
- Datenobjekte, Systemgrenzen und Vertrauensgrenzen;
- APIs, Events, Dateien und Integrationen;
- Legacy, Migration, Koexistenz und Decommission;
- Technologiezwänge, NFRs, Support und Recovery.

Frage keine Implementierungsdetails, solange Architekturentscheidungen offen sind.

## Block E — Ausführungsmodell

Klärpunkte:

- ein oder mehrere Teams;
- Scrum, Kanban, Scrumban, LeSS, SAFe, Flight Levels oder expliziter Hybrid;
- menschliche Teams, Coding-Agenten oder gemischt;
- Repositories, CI/CD, Umgebungen, Release-/Deploymentmodell;
- Integrationsrhythmus und Jira-/Confluence-Zielbild.

## Frageauswahl

Vor jeder Frage prüfe:

1. Ist die Antwort bereits vorhanden? Dann nicht fragen.
2. Kann die Information aktuell extern recherchiert werden? Dann recherchieren.
3. Kann sie aus bestätigten Fakten abgeleitet werden? Dann `DERIVED` mit Begründung.
4. Verändert die Antwort Scope, Gate, Artefakte, Architektur, Risiko, Jira oder Ausführung materiell? Nur dann fragen.
5. Ist sie kritisch und unbekannt? Frage gezielt und setze bis zur Antwort `BLOCKER`.
6. Ist sie nicht kritisch? Führe sie als `ASSUMPTION` mit Test und Ablaufdatum.

Stelle pro Interaktion höchstens fünf eng zusammenhängende Fragen. Bevorzuge eine Frage, wenn deren Antwort Folgefragen obsolet machen kann.

## Nicht-suggestive Formulierung

Schwach: „Sollten wir nicht Scrum und Microservices verwenden?“

Besser: „Welche Liefercharakteristik dominiert: feste, integrierte Produktinkremente oder kontinuierlicher variabler Fluss? Welche Architekturzwänge sind bereits entschieden?“

Prüfe mindestens eine Gegenhypothese und eine einfachere Alternative.

## Zwischenzusammenfassung

Nach jedem größeren Block liefere:

```text
CONFIRMED_FACTS
DERIVED
ASSUMPTIONS
CONFLICTS
BLOCKERS
NEXT_DECISION
```

## Bestätigungspunkte

Fordere ausdrückliche Bestätigung nur für:

- Product Vision;
- Projektprofil und Tailoring;
- Decision Rights und Gate-Autorität;
- Jira-Provisionierungsmanifest;
- organisatorische Gate-Entscheidung;
- Jira-Mutation;
- wesentliche Scope-, Daten- oder Architekturänderungen nach Freigabe.

Speichere Bestätigung mit Datum, bestätigender Identität, Inhalt, Version und betroffenen Artefakten.
