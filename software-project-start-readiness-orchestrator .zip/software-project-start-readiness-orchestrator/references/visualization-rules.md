# Visualisierungsregeln

## Pflichtdiagramme

Erzeuge für jedes Projekt mindestens:

1. Product Vision Map;
2. Produktstruktur;
3. Systemkontext mit Akteuren, externen Systemen, Datenflüssen und bei Bedarf Trust Boundaries;
4. Projektvorbereitungsprozess;
5. separater G0–G6-Gate-Ablauf;
6. Dokument- und Outcome-Traceability-Struktur;
7. Entscheidungs- und Eskalationspfad;
8. Jira-Hierarchie mit Parent-Child, typisierten Links, Rollen und Traceability.

## Formate

- Primär: Graphviz/DOT oder Mermaid als editierbare Quelle.
- Zusätzlich: verständliche Textlegende.
- Optional: SVG oder PNG, wenn ein Renderer vorhanden ist.
- Die editierbare Quelle ist maßgeblich; Bilder sind abgeleitete Assets.

## Graphviz-Konventionen

| Bedeutung | Form |
|---|---|
| Entscheidung/Frage | `diamond` |
| Aktion | `box` |
| Befehl | `plaintext` |
| Zustand | `ellipse` |
| Warnung/Blocker | `octagon`, rot gefüllt, weiße Schrift |
| Start/Ende | `doublecircle` |

Kanten erhalten konkrete Bedingungen: `yes`, `no`, `blocked`, `approved`, `requires`, `validates`. Verwende `relates` nur, wenn keine stärkere Semantik möglich ist.

## Benennung

- Fragen enden mit `?`.
- Aktionen beginnen mit einem Verb.
- Zustände beschreiben eine beobachtbare Lage.
- Befehle enthalten den tatsächlichen Befehl.
- Blocker benennen Ursache und gestoppte Phase.

## Konsistenzprüfung

Prüfe vor Ausgabe:

- jeder Diagrammknoten hat eine Entsprechung im Text oder Register;
- jede Parent-Child-Beziehung stimmt mit der Jira-Taxonomie überein;
- jede Trust Boundary ist in Security-/Datenartefakten behandelt;
- jeder Gate-Zustand stimmt mit dem Gate Record überein;
- keine Visualisierung behauptet ausgeführte Toolaktionen ohne Read-back;
- Diagrammquellen lassen sich syntaktisch rendern, wenn Graphviz verfügbar ist.

## Zugänglichkeit

- Verlasse dich nicht nur auf Farbe.
- Nutze eindeutige Labels und Legenden.
- Vermeide unnötige Kreuzungen und dekorative Komplexität.
- Beschreibe Inhalt zusätzlich als Text.
