# Jira bootstrap and taxonomy

## 1. Purpose and boundary

Jira is the execution and traceability system, not the source of truth for every enduring document. The Skill shall first produce a **Jira provisioning manifest**, review it, then apply it only after project-start approval and explicit authorization to mutate the target Jira site.

The current Atlassian user interface increasingly uses the terms **space** and **work item**, while REST APIs and many administrative pages still use **project** and **issue**. The Skill shall preserve the target site's actual terminology and API field names.

## 2. Mandatory capability and permission preflight

Before proposing or applying a hierarchy, inspect and record:

1. Jira site/cloud identifier and deployment type.
2. Jira plan: Free, Standard, Premium, or Enterprise.
3. Whether the target is company-managed or team-managed.
4. User's project-creation and global administration permissions.
5. Existing project/space templates and reusable schemes.
6. Available work-item types in the target project.
7. Fields and required-field metadata for each type.
8. Existing hierarchy levels, parent-child rules, and Plans availability.
9. Existing workflows, statuses, resolutions, permission schemes, security schemes, notifications, and automation limits.
10. Apps or integrations that depend on current hierarchy or field IDs.
11. Naming, key, data-residency, archival, and retention constraints.
12. Current platform limits relevant to fields, work types, projects/spaces, plans, and automation.

If any required capability cannot be verified, produce `BLOCKED_CAPABILITY_UNKNOWN` and stop before mutation.

## 3. Current Jira constraints that must shape the Skill

- Default Jira hierarchy is normally `Epic → standard work item → Subtask`.
- Additional hierarchy levels above Epic require Jira Premium or Enterprise and administrative configuration.
- Changes to hierarchy levels can affect all company-managed projects/spaces and may break parent relationships; treat them as platform changes, not project-local edits.
- Creating company-managed projects/spaces and modifying workflows requires elevated permissions.
- Issue creation can be automated through REST; Jira's bulk issue creation endpoint accepts a bounded batch, so large imports require chunking, idempotency, and retry logic.
- Platform limits exist for fields, work types, plans, teams, and projects/spaces. The Skill must inspect current official limits instead of hardcoding an old number.

## 4. Project/space strategy

### 4.1 Prefer a new company-managed project when

- common schemes and governance are required across several teams;
- central administration must control work types, workflows, permissions, fields, and notifications;
- Advanced Roadmaps/Plans and cross-project reporting are important;
- regulated or controlled evidence requires stable configurations.

### 4.2 Prefer a team-managed project when

- one autonomous team owns a bounded, low-risk product area;
- local configuration speed matters more than centralized reuse;
- the required hierarchy fits the team's supported model;
- no enterprise-level shared scheme or controlled workflow is required.

### 4.3 Reuse an existing project when

- the work belongs to the same enduring product and governance boundary;
- the existing configuration already supports the required traceability and permissions;
- creating a new project would fragment one Product Backlog or product view.

Do not equate each temporary project with a new Jira project. A product may contain multiple temporary initiatives in one enduring execution space.

## 5. Size-dependent hierarchy profiles

The hierarchy is a proposed information model, not a universal Jira standard. The Skill shall map it to capabilities actually available in the target site.

### Profile J1 — Single team, standard hierarchy

```text
Epic
├── Story
├── Task
├── Bug
├── Spike
└── Enabler
    └── Subtask
```

Use when one team can deliver within a common product backlog. Strategic context remains in linked documents or fields, not extra hierarchy levels.

### Profile J2 — Multi-team / Premium

```text
Initiative                 # level above Epic, if available
└── Epic / Feature         # Jira Epic-level container; choose one unambiguous name
    ├── Story
    ├── Task
    ├── Bug
    ├── Spike
    └── Enabler
        └── Subtask
```

Use for several teams where initiatives need roll-up and dependency planning.

### Profile J3 — Enterprise / portfolio

```text
Strategic Initiative       # custom level above
└── Portfolio Epic         # custom level above
    └── Capability         # custom level above, only if truly needed
        └── Feature        # Jira Epic level
            ├── Story
            ├── Enabler
            ├── Task
            ├── Bug
            └── Spike
                └── Subtask
```

This depth is justified only where portfolio-to-team roll-up materially improves decisions. It increases administration and can obscure flow. Before adopting it, test whether `Strategic Initiative → Feature/Epic → Story` plus typed links provides adequate traceability with less complexity.

### Terminology rule

Never use “Epic” for two different levels. If SAFe's Portfolio Epic and Jira's Epic coexist, rename the Jira-level type to `Feature`, or use explicit labels such as `Portfolio Epic` and `Delivery Epic`.

## 6. Recommended work-item types outside the parent hierarchy

Some governance objects should not be forced into the delivery hierarchy. Use dedicated types or an external controlled register with links:

- Risk;
- Assumption;
- Issue;
- Dependency;
- Decision;
- Experiment;
- Exception/Waiver;
- Architecture Decision;
- Security Finding;
- Compliance Obligation;
- Operational Readiness Action.

Where custom types would create field/workflow overload, store these in Confluence or another controlled registry and link them to Jira work items. Preserve semantic distinctions.

## 7. Minimal field model

### 7.1 Baseline fields for delivery work

- summary;
- description;
- parent;
- accountable owner/assignee;
- status and resolution;
- priority;
- acceptance criteria;
- target release/version;
- component/service;
- labels only for low-governance tagging;
- linked requirement/document;
- linked test/evidence;
- dependencies/links;
- security/data classification where applicable.

### 7.2 Portfolio and outcome fields

- strategic objective;
- business outcome hypothesis;
- Product Goal;
- benefits owner;
- leading and lagging indicators;
- MVP scope and pivot/stop criteria;
- cost of delay components and job size when WSJF is used;
- funding/capacity envelope;
- target planning interval or milestone;
- residual risk and decision authority.

### 7.3 Risk/decision fields

- record type;
- cause/event/impact or decision statement;
- probability and impact scales with definitions;
- response/decision rationale;
- accountable owner;
- due/review/expiry date;
- evidence links;
- residual exposure;
- approval/acceptance authority.

### Field discipline

- Reuse existing fields where semantics match.
- Avoid global custom fields for one-project convenience.
- Use field contexts and screens to limit clutter.
- Maintain a field dictionary with stable IDs, names, meaning, allowed values, owner, and deprecation status.
- Never encode durable business semantics only in free-form labels.

## 8. Workflow model

Use separate workflows where lifecycle semantics differ.

### 8.1 Portfolio/investment workflow

```text
Draft → Triage → Analysis → Ready for Decision → Approved → In Execution → Measuring Benefits → Done
                       ↘ Rejected
                       ↘ Parked
```

Required guards:

- approval transition requires decision authority and evidence;
- approved items require benefit owner, MVP, scope, risk and funding fields;
- rejection/parking requires rationale and review date;
- changes after approval create a new decision or controlled amendment.

### 8.2 Delivery workflow

```text
Backlog → Ready → In Progress → In Review → Integrated → Done
                  ↘ Blocked ↗
```

Keep it simple. Use status only for actual lifecycle state, not every activity. Test state belongs in test evidence, not dozens of workflow statuses.

### 8.3 Risk/assumption/decision workflows

Risk:

```text
Identified → Assessed → Treating → Monitoring → Closed
                       ↘ Accepted
```

Assumption:

```text
Proposed → Validating → Confirmed | Disproved | Expired
```

Decision:

```text
Proposed → Under Review → Decided → Superseded
```

Exception:

```text
Requested → Assessed → Approved with Expiry | Rejected → Expired/Closed
```

## 9. Link semantics

At minimum support or map these relationships:

- `blocks / is blocked by`;
- `depends on / is prerequisite for`;
- `implements / is implemented by`;
- `validates / is validated by`;
- `mitigates / is mitigated by`;
- `realizes / is realized by`;
- `supersedes / is superseded by`;
- `relates to` only when no stronger semantic relationship applies.

Before creating custom link types, inspect site-level permissions and existing integrations.

## 10. Boards, plans, versions, and components

- **Board:** visualize a team's or value stream's flow; do not use a board as a hierarchy definition.
- **Plan:** aggregate cross-team hierarchy, releases, dependencies, scenarios, and capacity where licensed.
- **Version/release:** represent a deployable or market release, not a sprint.
- **Component/service:** represent stable ownership or architecture boundaries, not arbitrary categories.
- **Sprint:** timebox for a Scrum team; do not use Sprint to represent programme increments or releases.
- **Planning Interval/PI:** model with a dedicated field, release, or plan convention based on chosen operating model.

## 11. Automation rules

Potential automations, subject to site capabilities and governance:

1. Populate inherited strategic/outcome fields from parent where appropriate.
2. Prevent approval when required evidence or owner fields are absent.
3. Create review tasks when an exception or residual-risk acceptance approaches expiry.
4. Flag broken traceability: delivery item without parent/outcome, critical requirement without test, completed feature without evidence.
5. Notify dependency owners on date/status changes.
6. Synchronize document status links, but never overwrite controlled approvals silently.
7. Create operational-readiness actions when a production release is targeted.
8. Archive or mark stale items after a governed retention period.

All automations require an owner, purpose, trigger, permissions, failure handling, audit trail, test case, and rollback/deactivation procedure.

## 12. Provisioning manifest

Before mutation, produce a version-controlled manifest containing:

```yaml
site: https://example.atlassian.net
mode: dry-run
project:
  action: create-or-reuse
  key: EXAMPLE
  name: Example Product Delivery
  management: company-managed
  template: software-kanban
hierarchy_profile: J2
work_item_types: []
fields: []
workflows: []
workflow_schemes: []
field_schemes: []
permissions: []
security_levels: []
notifications: []
components: []
versions: []
boards: []
plans: []
automations: []
seed_items: []
links: []
validation_queries: []
rollback_actions: []
```

Each manifest operation must have:

- `desired_state`;
- `observed_state`;
- `action` (`none`, `create`, `update`, `manual`, `blocked`);
- stable idempotency key;
- required permission;
- risk level;
- rollback or compensating action;
- evidence/result.

## 13. Safe provisioning sequence

1. **Discover:** inspect site, projects, metadata, types, fields, links, permissions, and limits.
2. **Classify:** map project profile to the least complex compatible Jira model.
3. **Dry-run:** generate manifest and diff; no writes.
4. **Review:** validate terminology, ownership, schemes, migration impact, and rollback.
5. **Gate:** require project-start approval and explicit provisioning authorization.
6. **Apply platform configuration:** project/space, hierarchy, schemes, fields, workflows, permissions; use admin API/UI or approved adapter.
7. **Apply project configuration:** components, versions, boards, plans, filters, automation.
8. **Seed content:** initiatives, epics/features, stories/tasks/bugs, risks, decisions, links; chunk bulk requests and use idempotency.
9. **Verify:** query actual state, parent relationships, permissions, workflows, fields, boards/plans, automations, and representative traces.
10. **Report:** produce created/updated/skipped/failed/manual items, IDs, evidence, and rollback status.

Never claim success from HTTP acceptance alone. Read back and validate the resulting configuration.

## 14. Connector reality in this environment

The available ChatGPT Atlassian connector exposes actions for:

- discovering visible Jira projects;
- reading project work-item types and field metadata;
- reading, creating, updating, linking, commenting on, and transitioning Jira work items;
- creating and updating Confluence content.

It does **not** currently expose direct actions for creating a Jira project/space, creating workflows, changing global hierarchy, or installing schemes. Therefore:

- content seeding in an existing project can be automated through the connector;
- complete site/project bootstrap requires Jira REST API access, administrator UI actions, or an approved custom MCP/Forge/API adapter;
- the Skill must report `MANUAL_OR_EXTERNAL_ADAPTER_REQUIRED` rather than pretending full provisioning occurred.
