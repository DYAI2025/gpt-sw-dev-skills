# Coding-Agent-Handoff

## Zulässigkeit

Erzeuge einen Implementierungsauftrag nur, wenn Repository, relevante Module, Architekturgrenzen, Schnittstellen, Testpfad und Toolgrenzen durch Evidenz bekannt sind. Fehlen sie, erzeuge zuerst einen read-only Discovery-Task.

## Pflichtinhalt

Jeder Auftrag enthält:

- Ziel und fachlichen Nutzen;
- betroffene Repositories, Komponenten und nachgewiesene Dateien/Module;
- Ausgangszustand und relevante Evidenz;
- Architekturgrenzen und unveränderliche Invarianten;
- erlaubte und verbotene Änderungen;
- Schnittstellen, Daten- und Kompatibilitätsverträge;
- Akzeptanzkriterien;
- Testanforderungen und konkrete, belegte Verifikationsbefehle;
- Security-, Privacy-, Safety- und Secrets-Grenzen;
- Migration, Rollback und Rückwärtskompatibilität;
- Observability und Dokumentationspflicht;
- Branch-/Commit-/PR-Regeln, wenn projektseitig bestätigt;
- erwartete Evidenz;
- Definition of Done;
- Stop- und Eskalationsbedingungen.

## Wahrheitsgrenze

Erfinde keine Pfade, Klassen, APIs, Datenbanken, Commands, Branches oder Konfigurationen. Kennzeichne unbekannte Details als `SOURCE_NEEDED` und erstelle Discovery-Schritte.

## Discovery-Task

Ein Discovery-Task ist read-only und beantwortet konkrete Fragen:

- Welche Repositories und Module implementieren die betroffene Fähigkeit?
- Welche Verträge, Tests und Architekturregeln existieren?
- Welche Build-, Test- und Lint-Befehle sind im Repository belegt?
- Welche Secrets-, Daten- und Deploymentgrenzen gelten?
- Welche Dateien sind voraussichtlich betroffen und warum?

Ausgabe: Evidenzliste, keine Codeänderung.

## Ausführungsregeln

- Beginne mit Tests oder reproduzierbarer Fehler-/Anforderungsevidenz.
- Ändere nur notwendigen Scope.
- Keine destruktiven Git-Operationen, kein Force Push, keine Secret-Ausgabe.
- Stoppe bei Konflikt mit Architektur, Security, Datenmigration oder unklarer Autorität.
- Führe definierte Tests aus und berichte tatsächliche Ergebnisse, nicht erwartete.
- Aktualisiere dauerhaftes Systemwissen und Traceability, nicht nur Tickets.
