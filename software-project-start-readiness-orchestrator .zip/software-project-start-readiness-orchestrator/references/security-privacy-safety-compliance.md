# Security, Privacy, Compliance und Safety

## Applicability Screening

Prüfe vor Detailplanung:

- Datenarten, Sensitivität, Betroffene, Zwecke und Weitergabe;
- Internetexposition, privilegierte Aktionen und Trust Boundaries;
- Identitäten, Rollen und Missbrauchspotenzial;
- regulatorische, vertragliche und branchenspezifische Verpflichtungen;
- Safety- oder physische Auswirkungen;
- Lieferkette, externe Anbieter und Datenresidenz.

`UNKNOWN` in einem kritischen Bereich ist ein Blocker.

## Threat Model

Erfasse Assets, Akteure, Trust Boundaries, Eintrittspunkte, Abuse Cases, Bedrohungen, Kontrollen, Testnachweise, Residualrisiken und autorisierte Akzeptanz. Verwende eine passende Methode, ohne deren Vollständigkeit zu behaupten.

## Privacy

- Dokumentiere Zwecke, Datenminimierung, Rechtsgrundlagen als durch autorisierte Rollen zu bestätigende Angaben, Retention, Löschung, Betroffenenrechte und Weitergabe.
- Prüfe, ob eine DPIA erforderlich sein kann. Bei voraussichtlich hohem Risiko muss die zuständige Privacy-/DPO-Rolle die Bewertung vor der Verarbeitung durchführen oder bestätigen.
- Der Skill liefert Screening und Evidenzstruktur, keine Rechtsentscheidung.

## Secure Development

Nutze eine aktuelle offizielle Secure-Development-Referenz, etwa den finalen NIST SSDF, und tailore Kontrollen auf das Projekt. Prüfe mindestens:

- Code Review und geschützte Branches;
- Secrets und Schlüsselverwaltung;
- Abhängigkeits- und Containerinventar;
- SBOM, Provenienz, Signierung oder Attestation nach Risiko;
- SAST/DAST/SCA oder äquivalente Nachweise nach Technologie;
- Schwachstellenannahme, Priorisierung und Remediation;
- Build- und Release-Integrität;
- Incident- und Disclosure-Pfade.

Prüfe bei Anwendung die aktuell finale Referenzversion; verwende Entwürfe nicht als verbindliche Norm ohne Kennzeichnung.

## Identity und Access

Dokumentiere Identitäten, Rollen, Least Privilege, privilegierten Zugriff, Joiner/Mover/Leaver, Service Accounts, Break Glass, Audit und Rezertifizierung.

## Supply Chain und Anbieter

Erfasse Komponenten, Lizenzen, Provenienz, Patchfähigkeit, Support, Subprozessoren, Datenrechte, Exit, Konzentrationsrisiko und Incident-Pflichten.

## Residualrisiko

Eine Akzeptanz enthält Risiko, bestehende und kompensierende Kontrollen, verbleibende Exposition, Umfang, Ablaufdatum, Monitoring, Remediation Owner und nachgewiesene Autorität.

Keine AI-Empfehlung ersetzt Security-, Privacy-, Legal-, Compliance- oder Safety-Freigabe.
