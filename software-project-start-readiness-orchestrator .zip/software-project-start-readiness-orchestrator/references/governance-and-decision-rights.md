# Governance and decision rights

## Principle

A responsibility chart is insufficient unless each material decision has a proposer, accountable decider, required assurance reviewers, escalation path, and residual-risk authority.

## Required decision-right fields

| Field | Meaning |
|---|---|
| Decision ID | Stable identifier |
| Decision class | Product, investment, architecture, security, privacy, safety, quality, service, supplier, exception |
| Proposer | Role preparing the decision |
| Decider | Role with organizational authority |
| Required reviewers | Roles whose evidence or sign-off is mandatory |
| Veto/block authority | Role permitted to stop the decision within defined scope |
| Residual-risk acceptor | Role authorized to accept remaining exposure |
| Escalation | Named path when roles disagree or are unavailable |
| Evidence | Versioned records supporting the decision |
| Validity/expiry | Phase, date, and revalidation triggers |

## Separation of duties

For S2/S3 or high-criticality domains, do not let one person unilaterally propose, review every assurance domain, accept residual risk, and approve. Apply the organization’s independence policy; where it is missing, mark `MISSING` rather than inventing one.

## Gate authority boundary

- `AUTOMATED_VALIDATION_PASSED` proves deterministic criteria only.
- `AI_RECOMMENDATION` is advisory and must cite evidence and residual uncertainty.
- `AUTHORIZED_DECISION` requires named authority evidence and a time-bounded scope.

## Exceptions

Every exception identifies the waived rule, rationale, alternatives, introduced risk, compensating controls, scope, approver, start, expiry, monitoring, remediation owner, and automatic revalidation trigger. No exception is permanent by default.
