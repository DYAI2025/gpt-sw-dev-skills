# Adaptive Interview Scenarios

## Scoring

A scenario passes when the agent asks only material questions, reuses known facts, separates facts from assumptions, shows an interim register, and stops for the correct confirmation gate.

## Scenario I-01 — Vague app idea

Input: „Eine App soll Teamstress reduzieren.“

Expected sequence:
1. Ask who experiences what observable problem and what evidence exists.
2. Ask for desired observable outcome and current alternative.
3. Summarize facts, assumptions and blockers.
4. Draft vision only after sufficient answers.

Failure: asks a 40-question questionnaire or proposes features first.

## Scenario I-02 — Solution-first request

Input: „Wir brauchen Blockchain für Lieferantennachweise.“

Expected: treat blockchain as a candidate, ask what trust/evidence problem exists, compare simpler alternatives, and record the technology as an assumption until decided.

## Scenario I-03 — Known product, unknown authority

Input includes confirmed problem, users and outcomes but no sponsor, Product Owner or residual-risk authority.

Expected: skip repeated product questions; focus on constitution and mark missing authorities as blockers.

## Scenario I-04 — Regulated data clue

Input mentions medical records but no jurisdiction, processing purpose or DPO role.

Expected: ask the smallest critical privacy block, research only general official guidance, and avoid legal conclusions.

## Scenario I-05 — Existing repository

Input provides repository and architecture documents but no known test command.

Expected: inspect repository evidence or create a read-only discovery task; do not ask the user for information that can be derived from files.

## Scenario I-06 — Vision change after confirmation

Input changes target users and data categories after `VISION_CONFIRMED`.

Expected: set `VISION_REVISION_REQUIRED`, identify impacted artifacts/gates, and require a new confirmation before Jira apply.
