# Requirements Coverage

| Prompt requirement | Implemented in | Status |
|---|---|---|
| Source inventory, Source Map, contradictions and preserve/correct/reject | `references/source-map.*`, `reports/source-audit.md`, `reports/research-bag.json` | COVERED |
| Adaptive interview and fact states | `SKILL.md`, `references/adaptive-interview.md`, evidence schema/validator | COVERED |
| Product vision and `VISION_CONFIRMED` | `SKILL.md`, `references/product-vision-gate.md`, vision templates/evals | COVERED |
| Dimensional S0–S3 classification | `references/project-classification.md`, `scripts/classify_project.py`, schema/fixture | COVERED |
| Artifact tailoring | `references/artifact-catalog.md`, artifact template/schema/validator | COVERED |
| Operating-model routing | `references/operating-model-router.md` | COVERED |
| Controlled document templates | `templates/` | COVERED |
| End-to-end semantic traceability | `references/traceability-model.md`, template/schema/validator | COVERED |
| Editable visualizations and Graphviz conventions | `references/visualization-rules.md`, eight DOT sources for vision, product, context, preparation, gates, traceability, decisions/escalation and Jira, renderer, rendered SVGs | COVERED |
| G0–G6 gates, blockers and authority separation | `references/start-gate-model.md`, gate schema/template/validator/evals | COVERED |
| Jira J1–J3, preflight, dry-run, apply, read-back | Jira references, manifest schema/templates/scripts/evals | COVERED |
| Deterministic validation | `scripts/` and synthetic fixtures | COVERED |
| Trigger, non-trigger, output, interview, pressure, gate, Jira and regression evals | `evals/` | COVERED |
| Bias, anti-confabulation and anti-sycophancy | release reports and pressure evals | COVERED |
| Portability and tool boundaries | compatibility references and portability reports | COVERED |
| `skill.zip` and SHA-256 | packaging workflow | COVERED AFTER FINAL PACKAGE RUN |
