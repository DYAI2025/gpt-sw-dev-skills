# Installability Report

**Status:** `PASS`  
**Generated:** `2026-07-26T21:43:22Z`

- Primary artifact name: `skill.zip`
- Checksum artifact: `skill.zip.sha256`
- Required archive root: `software-project-start-readiness-orchestrator/`
- Required entry points: `SKILL.md`, `agents/openai.yaml`
- Preliminary package validation: PASS
- ZIP integrity test: PASS
- Single-root check: PASS
- Checksum comparison: PASS
- Frontend install suggestion: `prepared`, never guaranteed

Workspace permissions, plan availability, region, client version and UI rendering remain outside package control. The final archive is revalidated externally after the normalized reports are included.
