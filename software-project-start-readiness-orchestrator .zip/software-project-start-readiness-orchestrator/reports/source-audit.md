# Source Audit

Audit date: 2026-07-26

## Fully processed local inputs

| File | Bytes | SHA-256 |
|---|---:|---|
| markdown.md eingefügt | 27494 | `7a21102c0d2e67097239301029cd70dab13800ec473469086506906116fdeaa5` |
| 00-forschungsergebnis-de.md | 9671 | `ab20f19b925b4c10d2b1f1521f69fa4cecc630f337bc703f94a6d4549a028625` |
| 02-complete-artifact-catalog.md | 23786 | `3260db60ea756dd66ea62b6cdd5a01cfcd2aeea7485813220b990d8213beca73` |
| 03-jira-bootstrap-and-taxonomy.md | 13780 | `e4fd41252c7f7895a39362ad921b752f57546a4b285e5b50419621040a4e9227` |
| 04-start-gate-and-audit-model.md | 12953 | `3080ef939d17ea8797e4a48b02a949290deb0076f13c39e5bc934897388878a1` |
| 06-skill-design-specification.md | 12175 | `b5e3c1870620beefba71debc646b7cab7393087800483f06fcff8eb9312ac40a` |
| hier_sind_die_detaillierten_vorlagen_templates_f.md | 29884 | `cd4a9036e41788c8927cdc29b4b2c10e0386210b996e3c2ad15f41c0886f3ce5` |
| architektur_und_dokumentationsstruktur_skalierter_.md | 109528 | `77c9c247e0151cf7e29bbd85a59ab12ec87db3cdfb9bf82154ebd5f62b84b56c` |
| evaluation.md | 21663 | `8c99479f8a2d22a636c38e274537aac3610879e26f34e0709825077c4576f427` |
| self_bias_check.md | 8360 | `c892d4fb5a8f5ea675bbd181b9c93d2c0b585e976e3ecdce4e724d58b7c3fcaf` |
| graphviz-conventions.dot | 5970 | `e2890a593c91370e384b42f2f67b1a6232c9e69dddea7891a0c1c46d7b20b694` |
| persuasion-principles.md | 5908 | `c3c84f572a51dd8b6d4fc6e5cbdc2bc3b9e07ba381a45bdabfce7ad2894dd828` |
| skill-building-orchestrator.md | 5629 | `42b0a3eefd341eba4dc9dd5e34c90628b2b9b184ab9a6a463bd76e08c8322107` |
| SKILL.md | 7067 | `090e9f212fa5a61f786d737ebf821054bff42aa19699be6717c9a601fb2a6c6d` |
| skill.md | 11381 | `3204bb329c23f93d653743fc81868beb58ea40c86a2260f57bae6dcd0c90ceb5` |

## Preserve / Correct / Reject

| Source content | Decision | Implementation |
|---|---|---|
| Portfolio/Capability/Feature/Story/Task/Bug templates | PRESERVE WITH TAILORING | Retained as optional delivery taxonomy; not forced on every project. |
| Lean Business Case, outcomes, MVP, stop/pivot criteria | PRESERVE | Included in artifact catalog and templates when investment trigger applies. |
| Solution Intent as enduring knowledge | PRESERVE AND EXTEND | Combined with ADRs, architecture views, evidence, data, security and operations knowledge. |
| Multi-level Definition of Done | PRESERVE WITH SCOPE | Separated from project, release and operational authorization gates. |
| WSJF | PRESERVE AS OPTIONAL METHOD | Used only for suitable relative prioritization; never substitutes for investment, risk or compliance decisions. |
| Silent synthesis of Scrum, Kanban, LeSS, SAFe and Flight Levels | CORRECT | Select one primary model and document every hybrid addition and consequence. |
| WCAG 2.1 as static default | CORRECT | Reverify applicability and use current W3C reference; WCAG 2.2 is current at build review. |
| Universal 80 percent code coverage | REJECT | Replace with risk-, architecture-, language- and defect-history-based quality evidence. |
| Every project needs every enterprise document | REJECT | Use dimensional S0–S3 and mandatory/conditional/optional/not-applicable tailoring. |
| Feature must fit one PI as universal truth | CORRECT | Treat as SAFe-specific convention only when SAFe is the selected primary model. |
| Sprint Review or Done equals release/start approval | REJECT | Use separate G0–G6 decisions and named authority evidence. |
| API acceptance equals provisioning success | REJECT | Require read-back and manifest comparison. |
| Current connector performs full Jira administration | REJECT | Current exposed connector can seed content but complete bootstrap requires admin REST/Forge/MCP/manual path. |

## Gaps retained as runtime inputs

- Organization-specific authority, approval, assurance, retention and exception policies.
- Target Jira site, plan, management type, fields, hierarchy, schemes, permissions, apps and limits.
- Project-specific legal, privacy, security, safety and contractual applicability.
- Repository paths, commands, APIs and runtime evidence before coding-agent handoff.
- Public redistribution license for this generated package.

## Current primary-source corrections

- Atlassian documents the default three-level work hierarchy and limits custom hierarchy levels to Premium/Enterprise; hierarchy changes can break parent-child relationships.
- Atlassian REST exposes project and issue operations, but actual connector exposure and permissions must be discovered separately.
- W3C WCAG 2.2 is the current W3C Recommendation referenced by this package where accessibility applies.
- NIST SP 800-218 version 1.1 remains the current final SSDF; version 1.2 is still a draft at the review date.
- European Commission guidance requires DPIA before likely high-risk processing; authorized privacy review remains project-specific.
