# Portability Report

## Portable components

- `SKILL.md` workflow and invariants;
- Markdown references and templates;
- JSON Schemas and fixture data;
- Python 3 validators and packaging scripts;
- trigger/output/pressure/interview/gate/Jira evaluations;
- DOT diagram sources.

## Runtime-specific components

- `agents/openai.yaml` is OpenAI-facing metadata.
- Connector names, schemas, permissions, filesystem access, shell execution, browser control, memory and install UI vary by runtime.

## Claude Code, Codex, Cursor, Windsurf and similar agents

Use `SKILL.md` as the control plane, load references on demand, run validators in a local Python environment, and map connector operations explicitly. Semantic portability is prepared; identical behavior or tool parity has not been runtime-tested and is not guaranteed.
