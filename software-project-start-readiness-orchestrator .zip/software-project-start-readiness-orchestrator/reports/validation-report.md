# Validation Report

**Status:** `PASS`  
**Generated:** `2026-07-26T21:43:22Z`  
**Release readiness:** `RELEASE_APPROVED_WITH_LIMITATIONS`

## Deterministic checks

| Check | Result | Evidence |
|---|---|---|
| Exact package name, frontmatter and entry points | PASS | Folder, `SKILL.md` and `agents/openai.yaml` match the binding contract |
| Required source-tree content | PASS | 151 source files; 104 explicitly required by the strict validator |
| Source map | PASS | 28 classified sources; confidence and hard-rule policy enforced |
| JSON, YAML, XML and JSON Schemas | PASS | Syntax and schema meta-validation completed without errors |
| Python compilation | PASS | `python -m py_compile scripts/*.py` |
| Controlled artifacts | PASS | Artifact and evidence fixtures valid; invalid evidence rejected |
| Traceability | PASS | 10 nodes, 9 typed links, no required-path gaps |
| Gate logic | PASS | Approved fixture has 0 blockers; blocked fixture retains 1 blocker |
| Jira manifests | PASS | Dry-run and gated apply fixtures valid; unauthorized apply rejected |
| Release and installability gates | PASS | Release hook PASS; archive name/root policy PASS |
| Portability and core preservation | PASS | Semantic portability documented; 12 core functions preserved |
| Enterprise output evaluator | PASS | 5/5 across all five evaluation dimensions |
| Graphviz | PASS | 9 editable DOT sources; 8 rendered SVG derivatives |
| Authoring hygiene | PASS | No unfinished authoring markers or empty files |
| Preliminary archive | PASS | Exactly one root folder, 151 members, ZIP integrity and checksum match |

## Negative tests

- Invalid `VERIFIED` evidence without sufficient confidence/source references was rejected with non-zero exit.
- Jira apply without `VISION_CONFIRMED`, approved gate, explicit mutation authorization, authority evidence and target site was rejected with non-zero exit.
- Read-back mismatch was rejected by the evaluation suite.

## Boundary

No network call, live Jira/Confluence mutation, credential use, legal approval, security approval or management approval was performed. The final `skill.zip` is rebuilt after this report and receives an external SHA-256 file; this avoids the circular problem of embedding an archive checksum inside the archive it hashes.
