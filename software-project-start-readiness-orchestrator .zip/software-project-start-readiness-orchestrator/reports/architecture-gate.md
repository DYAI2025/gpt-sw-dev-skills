# Pre-Build Architecture Gate

- Status: PASS
- Selected architecture: one modular orchestrator with compact `SKILL.md`, direct progressive references, controlled templates, JSON Schemas, deterministic validators, synthetic fixtures, eval layers, and machine-readable release reports.
- Smallest robust slice: no live Jira adapter is embedded; the Skill prepares manifests and uses only runtime-exposed tools after permission gates.
- Strongest counterargument: the scope can become a document factory that delays learning and over-governs S0/S1 work.
- Failure-mode chain: unverified idea → false vision certainty → oversized artifacts → unsupported Jira hierarchy → simulated authority → premature coding → unowned operational/security risk.
- Required controls applied: S0–S3 tailoring, adaptive interview, J3 non-default, authority separation, capability preflight, dry-run, read-back, risk-based quality, and pressure evals.
- Browser-Act branch: NOT_APPLICABLE; no website functionality is being forged into this Skill.
