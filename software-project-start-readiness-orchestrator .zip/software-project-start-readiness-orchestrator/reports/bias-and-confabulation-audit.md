# Bias and Confabulation Audit

## Decision

PASS WITH MONITORED LIMITATIONS

## Reviewed risks

| Risk | Finding | Control |
|---|---|---|
| Overconfidence | Dynamic Jira, legal and standards claims can age | Runtime primary-source revalidation and `SOURCE_NEEDED` |
| Confirmation bias | User sources strongly favored enterprise governance | Preserve/correct/reject review and S0/S1 anti-over-governance evals |
| Enterprise/SAFe bias | Deep hierarchies can look inherently mature | One primary operating model; J3 non-default; typed-link alternative |
| Over-governance | Document volume may replace evidence | Minimum-sufficient artifact tailoring |
| Tool optimism | REST capability can be confused with connector capability | Separate target API, connector exposure, permission and read-back evidence |
| Automation bias | Passing validators can be confused with permission to start | `AUTOMATED_VALIDATION_PASSED` is never `AUTHORIZED_DECISION` |
| Cultural/regulatory generalization | Organization and jurisdiction vary | Applicability screening and authorized domain review |
| False precision | Scores can conceal unknowns | Hard blockers dominate; scores informational only |
| Authority confusion | AI could impersonate sponsor/reviewer | Authority-evidence fields and gate validation |

## Blocked claims

None in the package. Project-specific approvals, legal conclusions, Jira capabilities and repository details remain runtime evidence requirements.
