# Evaluation Report

**Status:** `PASS`  
**Generated:** `2026-07-26T21:43:22Z`

## Coverage

| Evaluation layer | Count |
|---|---:|
| Should-trigger queries | 12 |
| Should-not-trigger queries | 10 |
| Output evaluations | 20 |
| Interview/tailoring scenarios | 6 |
| Pressure/adversarial scenarios | 12 |
| Gate scenarios | 6 |
| Jira capability scenarios | 6 |
| Regression cases | 15 |
| Stable read-only Jira QA pairs | 10 |

## Deterministic execution

`python scripts/run_evals.py evals` passed **14 of 14** checks. The suite validated dimensional classification, evidence, artifact tailoring, full critical-outcome traceability, approved and blocked gates, Jira dry-run/apply manifests, generated capability blockers, successful read-back, and rejection of invalid evidence, unauthorized apply and mismatched read-back.

## Mandatory adversarial behaviors

The eval corpus explicitly requires the Skill to resist false approval, scorewashing, framework fixation, premature Jira apply, missing sponsor/authority, missing threat model, unconfirmed vision, unsupported Jira hierarchy, connector overclaiming, and S3 over-governance of small projects.

## Boundary

The evaluation is local and deterministic. It does not claim measured behavior from a live frontier model or a production Jira tenant. Those are runtime acceptance tests, not prerequisites for releasing this generic Skill package.
