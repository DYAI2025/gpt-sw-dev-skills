# License and third-party notice

## Package content

This Skill package was generated for the requesting user from user-provided requirements, original orchestration logic, templates, validators, and evaluation fixtures.

## External references

The package links to official standards and product documentation but does not redistribute their normative text. Trademarks and framework names remain the property of their respective owners.

## Distribution status

`ORGANIZATION_LICENSE_DECISION: MISSING`

No organization-specific redistribution license was supplied. This package therefore makes no claim about internal, public, or commercial redistribution rights. The package owner must apply the governing platform, employment, contract, and intellectual-property terms before redistribution or sublicensing. This notice is not legal advice.
