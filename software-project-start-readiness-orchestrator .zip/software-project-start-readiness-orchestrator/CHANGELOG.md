# Changelog

## 1.0.0 — 2026-07-26

### Added

- Evidence-backed intake and adaptive interview workflow.
- Explicit `VISION_CONFIRMED` gate before final delivery structure or Jira apply.
- Dimensional S0–S3 project classification and minimum-sufficient artifact tailoring.
- G0–G6 gate model with hard-blocker dominance and authority separation.
- J1–J3 Jira information models with capability preflight, dry-run, idempotency, rollback, and read-back.
- Controlled document templates, JSON Schemas, deterministic Python validators, synthetic fixtures, trigger/output/pressure/interview/gate/Jira evaluations, and editable DOT diagrams.
- Installability, portability, source-audit, bias, anti-confabulation, release, and core-preservation reports.

### Corrected from source material

- Replaced universal document mandates with conditional applicability.
- Replaced static WCAG 2.1 defaults with current-source verification and WCAG 2.2 as the current W3C reference where applicable.
- Rejected universal code-coverage thresholds in favor of risk-based quality evidence.
- Prevented silent synthesis of Scrum, Kanban, LeSS, SAFe, and Flight Levels.
- Prevented AI recommendation, Sprint Review, ticket completion, or API acceptance from being treated as formal authorization.
