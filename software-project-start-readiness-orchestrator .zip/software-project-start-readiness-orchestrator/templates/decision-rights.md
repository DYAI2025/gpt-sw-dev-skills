# Decision Rights and Authority Matrix
## Kontrollmetadaten

| Feld | Wert |
|---|---|
| Dokument-ID | MISSING |
| Projekt-/Produkt-ID | MISSING |
| Owner | MISSING |
| Accountable Approver | MISSING |
| Status | DRAFT |
| Version | 0.1 |
| Effective Date | MISSING |
| Next Review Date | MISSING |
| Quellen/Evidenz | SOURCE_NEEDED |
| Confidence | 1 |
| Annahmen/Konflikte | MISSING |
| Traceability-Links | MISSING |
| Vertraulichkeit/Datenklassifikation | MISSING |
| Freigabestatus | NOT_AUTHORIZED |

## Steuerung

| Feld | Wert |
|---|---|
| Dokument-ID | MISSING |
| Version/Status | 0.1 / DRAFT |
| Owner/Approver | MISSING |

## Rollen

| Rolle | Person/Gruppe | Nachweis der Autorität | Stellvertretung | Gültig bis |
|---|---|---|---|---|
| Sponsor | MISSING | MISSING | MISSING | MISSING |
| Product Owner | MISSING | MISSING | MISSING | MISSING |
| Gate Authority | MISSING | MISSING | MISSING | MISSING |
| Residual Risk Acceptor | MISSING | MISSING | MISSING | MISSING |

## Entscheidungsrechte

| Entscheidung | Proposer | Consulted | Assurance/Veto | Decider | Recorder | Eskalation |
|---|---|---|---|---|---|---|
| Vision bestätigen | MISSING | MISSING | MISSING | MISSING | MISSING | MISSING |
| Scope ändern | MISSING | MISSING | MISSING | MISSING | MISSING | MISSING |
| Delivery Start | MISSING | MISSING | MISSING | MISSING | MISSING | MISSING |
| Release | MISSING | MISSING | MISSING | MISSING | MISSING | MISSING |
| Residualrisiko akzeptieren | MISSING | MISSING | MISSING | MISSING | MISSING | MISSING |
| Jira-Plattformänderung | MISSING | MISSING | MISSING | MISSING | MISSING | MISSING |

## Separation of Duties

Dokumentiere erforderliche Unabhängigkeit, Interessenkonflikte und verbotene Rollenkombinationen. Status: MISSING.

## Änderungshistorie

| Version | Datum | Änderung | Autor | Approver |
|---|---|---|---|---|
| 0.1 | MISSING | Initialer kontrollierter Entwurf | MISSING | MISSING |
