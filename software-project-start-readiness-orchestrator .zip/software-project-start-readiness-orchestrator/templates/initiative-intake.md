# Initiative Intake
## Kontrollmetadaten

| Feld | Wert |
|---|---|
| Dokument-ID | MISSING |
| Projekt-/Produkt-ID | MISSING |
| Owner | MISSING |
| Accountable Approver | MISSING |
| Status | DRAFT |
| Version | 0.1 |
| Effective Date | MISSING |
| Next Review Date | MISSING |
| Quellen/Evidenz | SOURCE_NEEDED |
| Confidence | 1 |
| Annahmen/Konflikte | MISSING |
| Traceability-Links | MISSING |
| Vertraulichkeit/Datenklassifikation | MISSING |
| Freigabestatus | NOT_AUTHORIZED |

## Dokumentsteuerung

| Feld | Wert |
|---|---|
| Dokument-ID | MISSING |
| Initiative-ID | MISSING |
| Version | 0.1 |
| Status | DRAFT |
| Owner | MISSING |
| Approver | MISSING |
| Vertraulichkeit | MISSING |
| Erstellt/Review | MISSING |

## Anfrage

- Arbeitstitel: MISSING
- Initiator: MISSING
- Sponsor oder Budget Owner: MISSING
- Gewünschtes Ziel-Gate: MISSING
- Gewünschter Starttermin: MISSING
- Erwartete Ausführende: MISSING

## Problem oder Chance

- Betroffene Zielgruppe: MISSING
- Heutiger Zustand: MISSING
- Beobachtbares Problem oder Chance: MISSING
- Beleg/Evidenz: SOURCE_NEEDED
- Folgen des Nicht-Handelns: MISSING

## Erwarteter Nutzen

- Nutzerergebnis: MISSING
- Organisationsergebnis: MISSING
- Messbare Zielgröße: MISSING
- Baseline: SOURCE_NEEDED
- Zielzeitpunkt: MISSING

## Bekannter Kontext

- Systeme und Daten: MISSING
- Schnittstellen und Lieferanten: MISSING
- Regulatorische/vertragliche Hinweise: MISSING
- Zeit-, Budget- oder Technologiezwänge: MISSING

## Offene Punkte

| ID | Aussage | Status | Kritikalität | Owner | Nächster Nachweis |
|---|---|---|---|---|---|
| F-001 | Ausgangslage ist unvollständig | MISSING | medium | MISSING | adaptives Interview |

## Änderungshistorie

| Version | Datum | Änderung | Autor | Approver |
|---|---|---|---|---|
| 0.1 | MISSING | Initialer kontrollierter Entwurf | MISSING | MISSING |
