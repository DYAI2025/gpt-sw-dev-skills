# Template usage contract

All templates are controlled-document skeletons. Values such as `MISSING`, `SOURCE_NEEDED`, `ASSUMPTION`, `CONFLICT`, and `NOT_APPLICABLE` are deliberate state markers, not completed content.

Rules:

1. Never replace a marker with invented project data.
2. `NOT_APPLICABLE` requires a rationale and accountable approver.
3. Every controlled document retains ID, project/product ID, owner, approver, status, version, dates, sources, confidence, assumptions/conflicts, traceability, classification, change history, and approval status.
4. Remove unused rows only after applicability is decided and recorded.
5. A template does not grant authority; use a gate record for authorization evidence.
