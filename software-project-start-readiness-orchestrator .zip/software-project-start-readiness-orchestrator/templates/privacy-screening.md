# Privacy Screening and DPIA Decision Record
## Kontrollmetadaten

| Feld | Wert |
|---|---|
| Dokument-ID | MISSING |
| Projekt-/Produkt-ID | MISSING |
| Owner | MISSING |
| Accountable Approver | MISSING |
| Status | DRAFT |
| Version | 0.1 |
| Effective Date | MISSING |
| Next Review Date | MISSING |
| Quellen/Evidenz | SOURCE_NEEDED |
| Confidence | 1 |
| Annahmen/Konflikte | MISSING |
| Traceability-Links | MISSING |
| Vertraulichkeit/Datenklassifikation | MISSING |
| Freigabestatus | NOT_AUTHORIZED |

## Steuerung

| Feld | Wert |
|---|---|
| Screening-ID | MISSING |
| Verarbeitung/System | MISSING |
| Status | DRAFT |
| Privacy Owner/DPO Reviewer | MISSING |
| Rechtsraum | MISSING |

## Verarbeitung

- Zwecke: MISSING
- Betroffene Personengruppen: MISSING
- Datenkategorien und Sensitivität: MISSING
- Quellen/Empfänger/Subprozessoren: MISSING
- Regionen/Residenz: MISSING
- Retention/Löschung: MISSING

## Screening

| Kriterium | Status | Evidenz | Risiko | Owner |
|---|---|---|---|---|
| Profiling/systematische Bewertung | UNKNOWN | SOURCE_NEEDED | MISSING | MISSING |
| sensible Daten in relevantem Umfang | UNKNOWN | SOURCE_NEEDED | MISSING | MISSING |
| systematische Überwachung | UNKNOWN | SOURCE_NEEDED | MISSING | MISSING |
| neue Technologie/hohe Auswirkung | UNKNOWN | SOURCE_NEEDED | MISSING | MISSING |

## Entscheidung

- DPIA erforderlich: SOURCE_NEEDED
- Entscheider und Autoritätsnachweis: MISSING
- Begründung: MISSING
- Vor Verarbeitung abgeschlossen: MISSING
- Residualrisiko/Prior Consultation: MISSING

Der Skill trifft keine Rechtsentscheidung; zuständige Privacy-/DPO-/Legal-Rollen bestätigen die Anwendbarkeit.

## Änderungshistorie

| Version | Datum | Änderung | Autor | Approver |
|---|---|---|---|---|
| 0.1 | MISSING | Initialer kontrollierter Entwurf | MISSING | MISSING |
