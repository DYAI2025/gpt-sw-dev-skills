# Project Charter
## Kontrollmetadaten

| Feld | Wert |
|---|---|
| Dokument-ID | MISSING |
| Projekt-/Produkt-ID | MISSING |
| Owner | MISSING |
| Accountable Approver | MISSING |
| Status | DRAFT |
| Version | 0.1 |
| Effective Date | MISSING |
| Next Review Date | MISSING |
| Quellen/Evidenz | SOURCE_NEEDED |
| Confidence | 1 |
| Annahmen/Konflikte | MISSING |
| Traceability-Links | MISSING |
| Vertraulichkeit/Datenklassifikation | MISSING |
| Freigabestatus | NOT_AUTHORIZED |

## Dokumentsteuerung

| Feld | Wert |
|---|---|
| Dokument-ID | MISSING |
| Projekt/Product ID | MISSING |
| Version/Status | 0.1 / DRAFT |
| Sponsor | MISSING |
| Project/Programme Lead | MISSING |
| Product Owner/Product Manager | MISSING |
| Effective/Review Date | MISSING |
| Vertraulichkeit | MISSING |

## Mandat

Beschreibe die autorisierte Problemstellung, den genehmigten Untersuchungs- oder Lieferumfang und die Phase, die dieses Charter abdeckt. Status: MISSING.

## Ziele und Outcomes

| Outcome-ID | Outcome | Baseline | Ziel | Messdatum | Benefits Owner | Evidenzstatus |
|---|---|---|---|---|---|---|
| OUT-001 | MISSING | SOURCE_NEEDED | MISSING | MISSING | MISSING | MISSING |

## Scope

- In Scope: MISSING
- Out of Scope: MISSING
- Produktgrenze: MISSING
- Projektgrenze: MISSING
- Externe Zusagen: MISSING

## Governance und Decision Rights

- Gate Authority: MISSING
- Residual Risk Authority: MISSING
- Architecture Authority: MISSING
- Security/Privacy/Quality/Service Authorities: MISSING
- Eskalationspfad: MISSING

## Finanzierung und Kapazität

- Funding Source: MISSING
- Kapazitätsrahmen: MISSING
- Kritische Skills: MISSING
- Lieferanten/Procurement: NOT_APPLICABLE oder MISSING mit Begründung

## Hauptrisiken und Annahmen

| ID | Typ | Aussage | Exposure | Owner | Entscheidung/Test | Fällig |
|---|---|---|---|---|---|---|
| RA-001 | Risk/Assumption | MISSING | MISSING | MISSING | MISSING | MISSING |

## Gate und Genehmigung

- Abgedeckte Phase: MISSING
- Automated Validation: NOT_RUN
- AI Recommendation: NOT_ISSUED
- Authorized Decision: MISSING
- Bedingungen/Ablaufdatum: MISSING

## Änderungshistorie

| Version | Datum | Änderung | Autor | Approver |
|---|---|---|---|---|
| 0.1 | MISSING | Initialer kontrollierter Entwurf | MISSING | MISSING |
