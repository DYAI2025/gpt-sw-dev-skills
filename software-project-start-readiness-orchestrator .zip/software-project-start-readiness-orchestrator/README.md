# Software Project Start Readiness Orchestrator

This package is an install-ready enterprise Skill for evidence-backed software-project initiation. It converts incomplete ideas or mandates into a controlled chain of intake, adaptive interview, vision confirmation, dimensional tailoring, artifact generation, readiness audit, gate decision support, Jira dry-run, authorized provisioning, and read-back verification.

## Core boundary

The Skill may validate evidence and issue an AI recommendation. It does not invent organizational authority. Only a recorded `AUTHORIZED_DECISION` permits the named phase to start.

## Main entry point

Read `SKILL.md` first. Load detailed references, templates, schemas, scripts, and evals only when the workflow requires them.

## Local validation

```bash
python -m py_compile scripts/*.py
python scripts/validate_skill_package.py .
python scripts/run_evals.py evals
```

## Packaging

```bash
python scripts/package_skill.py . ./dist
```

The primary installable artifact is always named `skill.zip` and contains exactly one root folder: `software-project-start-readiness-orchestrator/`. Packaging also emits `skill.zip.sha256` and verifies the checksum against the archive.
