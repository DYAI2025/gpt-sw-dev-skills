---
name: gpt-project-management
description: Unterstützt beim Planen und Steuern von Projekten, in denen Custom GPTs/Agenten, Skill-Orchestrierung über LiveAgent, Systemprompts (≤ 8000 Zeichen) und automatisierbare Workflows als Deliverables entstehen; verwenden, wenn Scope, Backlog, Roadmap, Prompt-/Skill-Architektur, Qualitätsgates oder n8n-Workflow-JSON benötigt werden.
---

# GPT Project Management

## Wann verwenden

Verwenden, wenn:

- ein Vorhaben als **Projekt** geführt werden soll, bei dem ein **Custom GPT/Agent** (Systemprompt, Skills, Knowledge, Tools) gebaut/erweitert wird.
- aus vagen Ideen ein **prüfbarer Plan** werden muss (Scope, Phasen, Backlog, DoD, KPIs).
- die Arbeit in **LLM-geeignete Tasks** zerlegt und mit **Prompts für Umsetzungsagenten** versehen werden soll.
- **Automations** (z. B. n8n) als Ergebnis gefordert sind, inkl. importierbarem JSON.
- Qualität explizit gesichert werden muss: **Bias-Check + Anti-Sycophancy-Check + Format-/Längenchecks**.

Nicht verwenden, wenn:

- nur eine einzelne Kleinantwort ohne Projekt-/Planungsanteil gewünscht ist.
- der Nutzer bewusst keine Struktur/Artefakte, sondern nur Brainstorming möchte (dann nur Ideation-Teil liefern).

## Workflow / Anweisungen

Hinweis zur Orchestrierung: **LiveAgent** orchestriert die vorhandenen Skills. Dieser Skill liefert PM-Artefakte/Regeln und kann von LiveAgent bei Bedarf aktiviert werden.

### 1) Intake → Projektsnapshot erzeugen (immer zuerst)

1. Extrahiere aus der Anfrage:
   - Zielbild/Outcome, Zielgruppe/Stakeholder, Kontext/Constraints, vorhandene Artefakte.
2. Stelle maximal drei Rückfragen nur bei Blockern (in dieser Reihenfolge):
   1. Erfolg/„fertig“ (messbar)
   2. harte Constraints (Zeit/Budget/Tools/Policies)
   3. Scope in/out
3. Erzeuge **Projekt-Snapshot** nach `references/artifacts-and-contracts.md`.

### 2) Projektmodus wählen (klein vs. groß) und passende Breakdown-Methode

Entscheide anhand Scope/Unklarheit:

- **Klein** (≤ 10 Arbeitspakete, ≤ 1–2 Wochen, geringe Unsicherheit): direktes Backlog + Meilensteine.
- **Mittel/Groß** (viele Stakeholder, MVP/Releases, hohe Unsicherheit): Story Mapping / Slicing.

Wenn Story Mapping sinnvoll ist, triggert LiveAgent (sofern vorhanden) den Story-Mapping-Skill und nutzt dessen Exporte als Backlog-Quelle.

### 3) Deliverables und Architektur festlegen (GPT-spezifisch)

Lege explizit fest, welche Artefakte geliefert werden:

- **GPT-Bausteine**: Systemprompt, Skill-Liste, Knowledge-Dateien, Tool-/Connector-Konzept, Evaluationsszenarien.
- **Projektartefakte**: Backlog, Roadmap, Risiko-/Entscheidungslog, Definition of Done (DoD), Status-Reporting-Rhythmus.

Regel: **Keine Skill-/Strukturannahmen als Fakt**. Skill-Namen nur verwenden, wenn sie in der realen Skill-Liste enthalten sind; sonst optional markieren.

### 4) Backlog bauen (testbar, slice-fähig, agententauglich)

1. Erzeuge Backlog-Items mit:
   - Titel, Zweck/Outcome, DoD/AC, Abhängigkeiten, Aufwand (S/M/L), Risiko, „primär Mensch/primär LLM/Mixed“.
2. Schneide vertikal (Walking Skeleton / MVP) statt horizontal:
   - MVP = kleinster End-to-End-Wertfluss.
3. Priorisierung:
   - Wenn ein Framework verwendet wird, muss die Formel vollständig vorliegen (siehe `references/scoring-frameworks.md`).
   - Falls keine Daten: priorisiere „Top-Risks first“ + „Time-to-first-value“.

### 5) Prompt-/Skill-Design als Engineering-Arbeit behandeln

Wenn ein Systemprompt oder Prompt-Set verlangt ist:

1. Entwirf eine **Systemprompt-Struktur**, die:
   - unter 8000 Zeichen bleibt,
   - die **tatsächlich vorhandene Struktur** beschreibt (keine Phantom-Skills),
   - Guardrails enthält (Format, Wahrheit/Unsicherheit, Checks).
2. Erzeuge Prompts für Umsetzungsagenten:
   - klare Inputs/Outputs,
   - harte Formatvorgaben,
   - Review-Gate („Draft → Review → Final“).

Siehe `references/system-prompt-structure-8000.md` und `scripts/check_system_prompt_len.py`.

### 6) Automations (n8n) nur als importierbares JSON liefern

Wenn n8n-Workflows verlangt sind:

1. Verwende den Output-Contract aus `references/n8n-workflow-output-contract.md`.
2. Liefere **genau einen** JSON-Block (importierbar), ohne Zusatztext im Block.
3. Definiere Resilienz:
   - Idempotenz, Retries/Backoff, Fehlerpfad,
   - Secrets nie hardcoden (env/credentials-Referenzen),
   - Logging minimal, aber nutzbar.

### 7) Steuerung im Projektverlauf (Status, Risiken, Änderungen)

1. Status-Update im vereinbarten Rhythmus (oder auf Nachfrage).
2. Change-Control leichtgewichtig:
   - Scope-Änderung ⇒ Backlog/Roadmap/Risiken aktualisieren.
3. Decision Log führen (kurz, datumiert).

Formate: `references/artifacts-and-contracts.md`.

### 8) Qualitätsgates (Pflicht vor „final“)

Vor finaler Ausgabe:

1. **Format-/Constraint-Checks**
   - Systemprompt ≤ 8000 Zeichen.
   - JSON validierbar.
   - Deliverables vollständig vs. versprochen.
2. **Bias-Check** (falls vorhanden: entsprechender Subskill).
3. **Anti-Sycophancy-Check** nach `references/sycophancy-check.md`.
4. Erst danach final ausgeben.

## Ausgabeformat

Standardstruktur einer Projektantwort:

1. Projekt-Snapshot
2. Backlog (Tabelle, inkl. DoD/AC)
3. Roadmap (3–7 Meilensteine, mit Kriterien)
4. Risiken (Top 5, mit Gegenmaßnahmen)
5. Entscheidungen (falls vorhanden)
6. GPT-Artefakte (nur wenn angefordert)
7. n8n-Workflow JSON (nur wenn angefordert, exakt ein JSON-Block)
8. Nächste Schritte (max. 7 Bulletpoints)
