# n8n Workflow Output Contract (importierbares JSON)

Ziel: Wenn n8n-Workflows geliefert werden, müssen sie ohne Nacharbeit importierbar sein.

Muss-Kriterien
1. Ausgabe enthält genau einen JSON-Codeblock mit dem Workflow.
2. JSON ist syntaktisch valide.
3. Keine Secrets im Klartext (Credentials/Environment referenzieren).
4. Resilienz: Fehlerpfad + Retry/Backoff wo sinnvoll.
5. Idempotenz/Double-Submit berücksichtigen (Dedupe per Message-ID o. ä.).
6. Inputs/Outputs klar (welche Felder erwartet/erzeugt werden).

Minimaler Inhaltsumfang
- nodes[] mit eindeutigen id/name/type/parameters
- connections
- settings (mindestens defaults)
- Trigger-Node klar erkennbar

Begleittext außerhalb des JSON (optional, kurz)
- Annahmen (Credentials vorhanden)
- Testfälle (3 Normalfälle + 2 Fehlerfälle)

Im JSON-Block selbst: keine Kommentare, kein Markdown.
