# Artefakte & Contracts (Projektmanagement)

Ziel: Artefakte so definieren, dass sie prüfbar, versionierbar und LLM-umsetzbar sind.

## 1) Projekt-Snapshot (Markdown)

Pflichtfelder
- Zielbild/Outcome (1–2 Sätze)
- In-Scope / Out-of-Scope (je 3 Bulletpoints)
- Constraints (Zeit/Tools/Policies)
- KPIs/Erfolgskriterien (3–7)
- Stakeholder (Rolle → Erwartung)
- Deliverables (konkret)
- Definition of Done (global, kurz)

## 2) Backlog-Item (Schema)

Felder
- ID
- Titel
- Zweck/Outcome
- DoD/Acceptance Criteria (präzise)
- Abhängigkeiten
- Aufwand (S/M/L)
- Risiko (low/med/high)
- Ausführungsmodus (Mensch / LLM / Mixed)

Regel: Wenn Priorisierung via WSJF/RICE/EVM/PERT o. ä., dann nur mit vollständiger Formel aus `references/scoring-frameworks.md`.

## 3) Status-Report (Markdown)

Pflichtfelder
- Datum
- Was erledigt (seit letztem)
- Was als nächstes
- Blocker
- Risiken (Delta)
- Entscheidungen (Delta)

## 4) Risiko-Register (Top-Risks)

Felder
- Risiko
- Impact/Probability (low/med/high oder numerisch)
- Mitigation
- Owner
- Trigger/Signal

Optional: numerische Risiko-Exposure-Berechnung (siehe `references/scoring-frameworks.md`).

## 5) Decision Log (kurz)

Felder
- Datum
- Entscheidung
- Begründung
- Konsequenz (Trade-off)
