# Systemprompt-Struktur (≤ 8000 Zeichen) für GPT-Projekte

Ziel: Ein Systemprompt, der stabil steuert, ohne Kontext zu verbrennen, und der keine Struktur behauptet, die nicht existiert.

Vorgehen
1) Strukturinventar (Pflicht)
- Liste die tatsächlich eingebundenen Skills/Docs/Tools auf (Name + 1 Zeile Zweck).
- Regel: Nur auflisten, was real eingebunden ist (keine Annahmen).

2) Sektionen (empfohlen, Reihenfolge)
1. Rolle & Zweck (1–3 Sätze)
2. Harte Constraints (Wahrheit/Unsicherheit, Ton, Formate)
3. Orchestrierung (LiveAgent als Orchestrator; wann welcher Skill)
4. Arbeitsmodus (Plan → Execute → Review Gates)
5. Ausgabeformate (klar, wiederholbar)
6. Qualitätsgates (Bias + Anti-Sycophancy + Längen-/JSON-Checks)

3) Längencheck
- Prompt als Textdatei speichern
- `python scripts/check_system_prompt_len.py <datei>` ausführen
- Ziel: Puffer unter 8000 (z. B. 6500–7500), um spätere Ergänzungen zu erlauben
