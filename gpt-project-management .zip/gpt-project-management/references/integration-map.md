# Integration Map (LiveAgent orchestriert)

Ziel: LiveAgent soll für Unteraufgaben spezialisierte Skills aktivieren, statt alles in einem Prompt zu überladen.

## Verifizierte Skill-Namen aus vorhandenen Paketen (sicher)

- `comprehensive-planning-spec-assistant` (Plan/Spezifikation/Task-Breakdown/Prompt-Design)
- `ai-lead-story-mapping` (Story Mapping → Slices → Exporte)
- `astro-precision-horoscope` (präzise Berechnungen; nur relevant, wenn angefordert)
- `universal-bias-self-check` (Selbstprüfung gegen Halluzinationen/Bias)
- `skill-building-orchestrator` (Skill-Paket-Bau: FILETREE + Dateien + Installer + ZIP-Hinweis)

## Potenziell vorhanden, aber hier nicht als Fakt behauptet

- n8n-Skill (Name/Ordnerstruktur nicht aus den bereitgestellten Skill-Paketen verifizierbar)

## Harte Regel gegen Phantom-Strukturen

Wenn ein Skill-Name/Existenz unsicher ist:
- nicht als „vorhanden“ behaupten
- stattdessen: Skill-Liste/FILETREE anfordern oder den Schritt als optional markieren
