# Scoring- & PM-Formeln (vollständig)

Ziel: Keine halben Frameworks. Jede verwendete Metrik muss als vollständige Formel + Definitionen vorliegen.

## 1) WSJF (Weighted Shortest Job First)

**WSJF-Score:**
WSJF = CoD / JS

- CoD (Cost of Delay) = BV + TC + RR_OE
  - BV = Business Value (relativ, z. B. 1..20)
  - TC = Time Criticality (relativ, 1..20)
  - RR_OE = Risk Reduction / Opportunity Enablement (relativ, 1..20)
- JS = Job Size (relativ, z. B. 1..13; darf nicht 0 sein)

Interpretation:
- höherer WSJF ⇒ früher umsetzen (bei gleichen Abhängigkeiten/Constraints)

Rechenregeln:
- BV, TC, RR_OE, JS > 0
- Skalen müssen innerhalb eines Backlogs konsistent sein

CLI: `python scripts/wsjf_calculator.py --bv 20 --tc 8 --rr 13 --js 8`

## 2) RICE

**RICE-Score:**
RICE = (Reach × Impact × Confidence) / Effort

- Reach: Anzahl erreichte Nutzer/Events pro Zeitraum (z. B. /Monat)
- Impact: Nutzen pro Nutzer (typisch 0.25, 0.5, 1, 2, 3)
- Confidence: 0..1 (z. B. 0.8 = 80%)
- Effort: Aufwand (z. B. Person-Wochen oder Person-Monate; darf nicht 0 sein)

Interpretation:
- höherer RICE ⇒ höhere Priorität (unter gleichen Randbedingungen)

CLI: `python scripts/rice_calculator.py --reach 5000 --impact 2 --confidence 0.8 --effort 3`

## 3) Risiko-Exposure (numerisch)

**Risk Exposure (RE):**
RE = P × I

- P: Eintrittswahrscheinlichkeit (0..1)
- I: Impact (z. B. € oder Punkte)
- Ergebnis: erwarteter Schaden/Exposure in derselben Einheit wie I

CLI: `python scripts/risk_exposure.py --p 0.2 --i 50000`

## 4) EVM (Earned Value Management)

Eingaben:
- PV: Planned Value
- EV: Earned Value
- AC: Actual Cost
- optional BAC: Budget at Completion

Abweichungen:
- CV (Cost Variance) = EV − AC
- SV (Schedule Variance) = EV − PV

Indizes:
- CPI (Cost Performance Index) = EV / AC  (AC ≠ 0)
- SPI (Schedule Performance Index) = EV / PV (PV ≠ 0)

Prognosen (wenn BAC gegeben):
- EAC (Estimate at Completion) = BAC / CPI  (CPI ≠ 0)
- ETC (Estimate to Complete) = EAC − AC

CLI: `python scripts/evm_calculator.py --pv 100 --ev 80 --ac 90 --bac 200`

## 5) PERT (Three-Point Estimation)

Eingaben:
- O: Optimistic
- M: Most likely
- P: Pessimistic

Erwartungswert:
- E = (O + 4M + P) / 6

Standardabweichung:
- σ = (P − O) / 6

Varianz:
- Var = σ² = ((P − O) / 6)²

CLI: `python scripts/pert_estimator.py --o 2 --m 5 --p 14`
