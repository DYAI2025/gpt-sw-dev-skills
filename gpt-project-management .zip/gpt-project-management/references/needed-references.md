# Fehlende/optionale Referenzen (für späteren Agent-Bau)

Diese Referenzen sind nicht zwingend für den Kernbetrieb, erhöhen aber Robustheit und Wiederverwendbarkeit. Falls benötigt, sollen sie als zusätzliche Dateien unter `references/` und ggf. `assets/templates/` erzeugt werden.

## A) LiveAgent-spezifisches Orchestrationshandbuch
- Skill-Auswahlregeln (Trigger-Mapping)
- De-/Aktivierungslogik (z. B. Default-Skill, Fallbacks)
- Standard-Review-Gates (Bias/Sycophancy/Format/JSON)

## B) Stakeholder & Kommunikation
- Stakeholder Map Template (Rollen, Erwartungen, Einfluss, Risiken)
- Kommunikationsplan (Cadence, Kanal, Owner, DoD)

## C) Change-Control & Scope-Management
- Change-Request Template (Beschreibung, Impact, Risiko, Entscheidung)
- Scope Baseline & Re-Planning-Regeln

## D) Qualität & Abnahme
- Definition of Ready (DoR) + Definition of Done (DoD) Bibliothek
- Abnahmekriterien-Beispiele für GPT-Artefakte (Systemprompt, Skill-Paket, Workflow-JSON)

## E) Tool-/Automation-Governance
- Secrets/Compliance-Policy Template
- n8n Node Guidelines (Retries, Idempotenz, Logging, Error Paths)

## F) Projektmetriken (zusätzlich zu scoring-frameworks.md)
- Flow-Metriken (Cycle Time, Throughput) mit Definitionen & Messregeln
- Forecasting-Guide (Monte Carlo optional, falls wirklich gebraucht)
