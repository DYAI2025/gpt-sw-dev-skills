#!/usr/bin/env python3
import argparse
import json
import sys

def main() -> int:
    p = argparse.ArgumentParser(description="WSJF calculator: WSJF = (BV + TC + RR_OE) / JS")
    p.add_argument("--bv", type=float, required=True, help="Business Value (BV) > 0")
    p.add_argument("--tc", type=float, required=True, help="Time Criticality (TC) > 0")
    p.add_argument("--rr", type=float, required=True, help="Risk Reduction / Opportunity Enablement (RR_OE) > 0")
    p.add_argument("--js", type=float, required=True, help="Job Size (JS) > 0 and != 0")
    p.add_argument("--json", action="store_true", help="Output JSON")
    args = p.parse_args()

    for name, v in [("bv", args.bv), ("tc", args.tc), ("rr", args.rr), ("js", args.js)]:
        if v <= 0:
            print(f"ERROR: {name} must be > 0 (got {v})", file=sys.stderr)
            return 2

    cod = args.bv + args.tc + args.rr
    wsjf = cod / args.js

    if args.json:
        print(json.dumps({"BV": args.bv, "TC": args.tc, "RR_OE": args.rr, "JS": args.js, "CoD": cod, "WSJF": wsjf}))
    else:
        print(f"CoD={cod:.6g} WSJF={wsjf:.6g}  (WSJF = (BV+TC+RR_OE)/JS)")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
