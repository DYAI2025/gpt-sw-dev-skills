#!/usr/bin/env python3
import argparse
import json
import sys
from typing import Optional

def safe_div(n: float, d: float) -> Optional[float]:
    if d == 0:
        return None
    return n / d

def main() -> int:
    p = argparse.ArgumentParser(description="EVM calculator (CV, SV, CPI, SPI, optional EAC/ETC with BAC).")
    p.add_argument("--pv", type=float, required=True, help="Planned Value (PV) >= 0")
    p.add_argument("--ev", type=float, required=True, help="Earned Value (EV) >= 0")
    p.add_argument("--ac", type=float, required=True, help="Actual Cost (AC) >= 0")
    p.add_argument("--bac", type=float, required=False, help="Budget at Completion (BAC) >= 0 (optional)")
    p.add_argument("--json", action="store_true", help="Output JSON")
    args = p.parse_args()

    for name, v in [("pv", args.pv), ("ev", args.ev), ("ac", args.ac)]:
        if v < 0:
            print(f"ERROR: {name} must be >= 0 (got {v})", file=sys.stderr)
            return 2
    if args.bac is not None and args.bac < 0:
        print("ERROR: bac must be >= 0", file=sys.stderr)
        return 2

    cv = args.ev - args.ac
    sv = args.ev - args.pv
    cpi = safe_div(args.ev, args.ac)
    spi = safe_div(args.ev, args.pv)

    out = {
        "PV": args.pv,
        "EV": args.ev,
        "AC": args.ac,
        "CV": cv,          # EV - AC
        "SV": sv,          # EV - PV
        "CPI": cpi,        # EV / AC
        "SPI": spi,        # EV / PV
    }

    if args.bac is not None:
        out["BAC"] = args.bac
        # EAC = BAC / CPI (wenn CPI definiert)
        eac = None if cpi is None or cpi == 0 else (args.bac / cpi)
        out["EAC"] = eac
        # ETC = EAC - AC (wenn EAC definiert)
        out["ETC"] = None if eac is None else (eac - args.ac)

    if args.json:
        print(json.dumps(out))
    else:
        def fmt(x):
            return "NA" if x is None else f"{x:.6g}"
        line = (
            f"CV={fmt(out['CV'])} SV={fmt(out['SV'])} "
            f"CPI={fmt(out['CPI'])} SPI={fmt(out['SPI'])}"
        )
        if "EAC" in out:
            line += f" EAC={fmt(out['EAC'])} ETC={fmt(out['ETC'])}"
        print(line)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
