#!/usr/bin/env python3
import argparse
import json
import sys

def main() -> int:
    p = argparse.ArgumentParser(description="PERT estimator: E=(O+4M+P)/6, sigma=(P-O)/6, var=sigma^2")
    p.add_argument("--o", type=float, required=True, help="Optimistic (O) > 0")
    p.add_argument("--m", type=float, required=True, help="Most likely (M) > 0")
    p.add_argument("--p", type=float, required=True, help="Pessimistic (P) > 0")
    p.add_argument("--json", action="store_true", help="Output JSON")
    args = p.parse_args()

    for name, v in [("o", args.o), ("m", args.m), ("p", args.p)]:
        if v <= 0:
            print(f"ERROR: {name} must be > 0 (got {v})", file=sys.stderr)
            return 2
    if args.p < args.o:
        print("ERROR: p should be >= o for a valid three-point estimate", file=sys.stderr)
        return 2

    E = (args.o + 4 * args.m + args.p) / 6.0
    sigma = (args.p - args.o) / 6.0
    var = sigma * sigma

    if args.json:
        print(json.dumps({"O": args.o, "M": args.m, "P": args.p, "E": E, "sigma": sigma, "var": var}))
    else:
        print(f"E={E:.6g} sigma={sigma:.6g} var={var:.6g}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
