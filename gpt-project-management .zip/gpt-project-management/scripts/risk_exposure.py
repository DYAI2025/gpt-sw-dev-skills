#!/usr/bin/env python3
import argparse
import json
import sys

def main() -> int:
    p = argparse.ArgumentParser(description="Risk Exposure: RE = P * I")
    p.add_argument("--p", type=float, required=True, help="Probability P in [0, 1]")
    p.add_argument("--i", type=float, required=True, help="Impact I (>= 0), same unit as output")
    p.add_argument("--json", action="store_true", help="Output JSON")
    args = p.parse_args()

    if not (0.0 <= args.p <= 1.0):
        print("ERROR: p must be in [0, 1]", file=sys.stderr)
        return 2
    if args.i < 0:
        print("ERROR: i must be >= 0", file=sys.stderr)
        return 2

    rexp = args.p * args.i
    if args.json:
        print(json.dumps({"P": args.p, "I": args.i, "RE": rexp}))
    else:
        print(f"RE={rexp:.6g}  (RE = P*I)")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
