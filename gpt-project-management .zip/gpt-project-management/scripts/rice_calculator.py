#!/usr/bin/env python3
import argparse
import json
import sys

def main() -> int:
    p = argparse.ArgumentParser(description="RICE calculator: RICE = (Reach * Impact * Confidence) / Effort")
    p.add_argument("--reach", type=float, required=True, help="Reach per period (>= 0)")
    p.add_argument("--impact", type=float, required=True, help="Impact per user (> 0)")
    p.add_argument("--confidence", type=float, required=True, help="Confidence in [0, 1]")
    p.add_argument("--effort", type=float, required=True, help="Effort (> 0)")
    p.add_argument("--json", action="store_true", help="Output JSON")
    args = p.parse_args()

    if args.reach < 0:
        print("ERROR: reach must be >= 0", file=sys.stderr)
        return 2
    if args.impact <= 0:
        print("ERROR: impact must be > 0", file=sys.stderr)
        return 2
    if not (0.0 <= args.confidence <= 1.0):
        print("ERROR: confidence must be in [0, 1]", file=sys.stderr)
        return 2
    if args.effort <= 0:
        print("ERROR: effort must be > 0", file=sys.stderr)
        return 2

    score = (args.reach * args.impact * args.confidence) / args.effort

    if args.json:
        print(json.dumps({
            "Reach": args.reach,
            "Impact": args.impact,
            "Confidence": args.confidence,
            "Effort": args.effort,
            "RICE": score
        }))
    else:
        print(f"RICE={score:.6g}  (RICE = Reach*Impact*Confidence/Effort)")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
