#!/usr/bin/env python3
import argparse
import re
import sys
from pathlib import Path

NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")

def extract_frontmatter(skill_md: str) -> str:
    lines = skill_md.splitlines()
    if len(lines) < 3 or lines[0].strip() != "---":
        raise ValueError("Missing YAML frontmatter start '---' on line 1.")
    try:
        end = lines[1:].index("---") + 1
    except ValueError as e:
        raise ValueError("Missing YAML frontmatter end '---'.") from e
    return "\n".join(lines[1:end])

def parse_key(front: str, key: str) -> str:
    for line in front.splitlines():
        if line.strip().startswith(f"{key}:"):
            return line.split(":", 1)[1].strip().strip('"').strip("'")
    raise ValueError(f"Missing required frontmatter key: {key}")

def main() -> int:
    p = argparse.ArgumentParser(description="Validate SKILL.md frontmatter basics.")
    p.add_argument("skill_dir", help="Path to the skill directory (containing SKILL.md).")
    args = p.parse_args()

    skill_dir = Path(args.skill_dir)
    skill_md_path = skill_dir / "SKILL.md"
    if not skill_md_path.exists():
        print(f"ERROR: SKILL.md not found in: {skill_dir}", file=sys.stderr)
        return 2

    raw = skill_md_path.read_text(encoding="utf-8")
    try:
        front = extract_frontmatter(raw)
        name = parse_key(front, "name")
        desc = parse_key(front, "description")
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    ok = True

    if skill_dir.name != name:
        ok = False
        print(f"ERROR: directory name '{skill_dir.name}' must match frontmatter name '{name}'", file=sys.stderr)

    if not NAME_RE.match(name):
        ok = False
        print(f"ERROR: name '{name}' does not match regex {NAME_RE.pattern}", file=sys.stderr)

    if "<" in desc or ">" in desc:
        ok = False
        print("ERROR: description must not contain '<' or '>'", file=sys.stderr)

    if ok:
        print("valid: frontmatter ok")
        return 0
    return 1

if __name__ == "__main__":
    raise SystemExit(main())
