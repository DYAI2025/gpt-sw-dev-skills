#!/usr/bin/env python3
import argparse
import sys
from pathlib import Path

DEFAULT_LIMIT = 8000

def main() -> int:
    p = argparse.ArgumentParser(description="Check system prompt length (max N characters).")
    p.add_argument("path", help="Path to a text file containing the system prompt.")
    p.add_argument("--limit", type=int, default=DEFAULT_LIMIT, help="Character limit (default: 8000).")
    args = p.parse_args()

    path = Path(args.path)
    if not path.exists() or not path.is_file():
        print(f"ERROR: file not found: {path}", file=sys.stderr)
        return 2

    text = path.read_text(encoding="utf-8")
    n = len(text)

    print(f"chars={n} limit={args.limit} ok={n <= args.limit}")
    if n > args.limit:
        print(f"ERROR: prompt exceeds limit by {n - args.limit} characters", file=sys.stderr)
        return 1
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
