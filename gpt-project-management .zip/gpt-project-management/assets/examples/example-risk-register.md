# Risiko-Register (Beispiel)

| ID | Risiko | Impact | Prob | Mitigation | Owner | Trigger |
|---|---|---|---|---|---|---|
| R1 | Systemprompt > 8000 Zeichen | high | med | Kürzen, Duplikate entfernen, Längencheck-Script nutzen | PM | char>8000 |
| R2 | Phantom-Skill-Nennung | high | med | Skill-Liste verifizieren; sonst optional markieren | PM | unbestätigte Namen |
| R3 | Unklare DoD/AC → Rework | med | med | AC im Gherkin-Stil, Review-Gate | Team | „Was heißt fertig?“ |
| R4 | Secrets im Workflow hardcodiert | high | low | Env/Credentials-Referenzen, Review | Dev | Klartext-Token entdeckt |
| R5 | Unkritische Zustimmung (Sycophancy) | med | med | Anti-Sycophancy-Check, Gegenargument-Pflicht | Reviewer | Floskeln ohne Evidenz |
