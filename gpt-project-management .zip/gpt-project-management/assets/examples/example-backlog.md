# Backlog (Beispiel, MVP)

| ID  | Titel | Outcome | AC (kurz) | Deps | Aufwand | Risiko | Modus |
|---|---|---|---|---|---:|---|---|
| B-01 | Projekt-Snapshot finalisieren | Klarer Scope, KPIs, Deliverables | In/Out/Constraints/KPIs/DoD vorhanden | — | S | low | Mixed |
| B-02 | Backlog-Schema + DoD/AC Regeln | Items sind testbar & slice-fähig | Jedes Item hat DoD/AC, Aufwand, Risiko | B-01 | S | low | LLM |
| B-03 | Systemprompt-Struktur entwerfen | Prompt ist kurz & steuert zuverlässig | Sektionen; keine Phantom-Skills; ≤8000 | B-01 | M | med | Mixed |
| B-04 | Qualitätsgates festziehen | Bias/Sycophancy/Format-Checks standardisiert | Gate-Checkliste existiert, ist kurz | B-02 | S | med | LLM |
| B-05 | Beispiel-Statusreport + Risiko-Register | Reporting ist reibungslos nutzbar | Formate kopierbar, 1 Beispiel vollständig | B-01 | S | low | LLM |
