# deep_reasoning_analysis_report

## meta

- **Analyse-ID:** DR-2026-07-23-enterprise-workforce-planning-builder
- **Datum:** 23.07.2026, Zeitzone Europe/Berlin
- **Auftrag:** Drei bereitgestellte Texte kritisch analysieren, mit aktueller Primärquellenrecherche zu Enterprise-Tooling-Agenten verbinden, einen vollständigen Skill-Plan erstellen und den Skill bauen.
- **Ergebnis:** Freigabe eines installierbaren Master-Skills mit progressiven Referenzen; keine Aussage, dass dadurch bereits eine konkrete Anwendung produktionsreif ist.

## intake_scope

### In Scope

- Zeit-, Schicht-, Abwesenheits- und Zeiterfassungsprodukte
- Mitarbeiter-, Qualifikations-, Kapazitäts- und Personaleinsatzplanung
- Baustellen-, Gewerk-, Crew-, Geräte- und Auslastungsplanung
- Field Service, Dispatch und Routing
- strategische EPM-Szenarien und operative FSM-/ERP-/HCM-/Payroll-Integration
- Webapp sowie spätere iOS-/Android-App einschließlich Offline-Betrieb
- Constraint Optimization, MCP, RAG und agentische Entwicklung
- Architektur, Implementierung, Tests, Evaluation, Security, Observability und Production Gate
- vollständiger Skill-Plan, Skill-Paket, Evals, Reports und ZIP

### Out of Scope

- Bau einer konkreten Kundenanwendung ohne Repository und Fachanforderungen
- Auswahl oder Beschaffung eines konkreten Vendors ohne Proof of Concept
- rechtsverbindliche Prüfung oder Compliance-Zertifizierung
- produktive Migration, Deployment oder Zugriff auf Beschäftigtendaten

### MISSING

- Organisation, Nutzerforschung und priorisierte Geschäftsprobleme
- anwendbare Gesetze, Tarifverträge, Betriebsvereinbarungen und Sicherheitsregeln
- Identity-, Autorisierungs- und System-of-Record-Modell
- Repository, Deployment-Plattform und Betriebsmodell
- repräsentative Last-, Routing-, Schicht- und Baustellendaten
- SLOs, Budget, App-Store-, Geräte- und Offline-Anforderungen
- Vendor-Editionen, Lizenzen, Datenregionen, APIs und PoC-Ergebnisse

## source_map

Die drei Nutzertexte wurden als `user_provided` klassifiziert, nicht als automatische Wahrheit:

| ID | Quelle | Status | Kernaussage |
|---|---|---|---|
| S-U1 | Enterprise-Architekturmuster | geprüft und korrigiert | Nützliche Muster, aber mehrfach zu absolut formuliert |
| S-U2 | Anaplan vs. OneStream | Vendor-Hypothese | Für Auswahlentscheidung fehlen edition- und projektspezifische Belege |
| S-U3 | AI-Co-Architekt und Coding Agent | runtimeabhängig | Sinnvolle Fähigkeiten, aber Tool-, Rechte- und Ausführungszugang sind nicht garantiert |

Primärquellen wurden unter anderem für Agent Skills, MCP, Outbox, Event Sourcing, OR-Tools, Last Planner System, IFC, JSON Schema, Temporal, WCAG, OWASP, OpenTelemetry, NIST AI RMF, DSGVO und EU AI Act verwendet. Die vollständige Source Map befindet sich in `analysis_report.json` und im Skill unter `references/source-map.md`.

## standards_alignment

Der Skill ist in seinem jeweiligen Geltungsbereich ausgerichtet an:

- Agent Skills Specification für Paketstruktur und Progressive Disclosure
- MCP Specification 2025-11-25 für optionale Tool-Integration
- JSON Schema Draft 2020-12 für kontrollierte Metadatenmodelle
- IFC 4.3.2.0 als optionale Austauschbasis für BIM-/Bauobjekte
- WCAG 2.2 für Web-Zugänglichkeit
- OWASP ASVS und MASVS als risikobasierte Verifikationsgrundlagen
- NIST AI RMF als freiwillige AI-Risikomanagement-Orientierung

Diese Ausrichtung ist **keine Zertifizierung, keine Rechtsprüfung und kein Nachweis der Konformität einer späteren Anwendung**.

## risk_gate

**Risikostufe: hoch.**

Begründung:

- Personalzuweisung, Standortdaten, Zeit, Leistung, Abwesenheit und Payroll können Beschäftigte materiell betreffen.
- Falsche Planung kann Arbeitsschutz, Zertifikate, Ruhezeiten, SLA, Kosten und Baustellenablauf verletzen.
- Der gewünschte Agent soll Software erzeugen und Production Readiness beurteilen.

Erlaubt waren Recherche, Analyse, lokaler Skill-Bau und nicht-destruktive Validierung. Blockiert blieben produktive Änderungen, direkte Beschäftigten-/Payroll-Schreibzugriffe, Rechts- oder Compliance-Garantien und Vendor-Entscheidungen ohne PoC.

## method_selection

- **PS+:** Zerlegung in Analyse, Plan, Skill-Architektur, Build und Release
- **ToT:** Vergleich Master-Skill vs. Subskill-System sowie modularer Monolith vs. frühe Verteilung
- **CoVe:** Claim-für-Claim-Prüfung gegen Primärquellen
- **MP:** Bias-, Unsicherheits- und Failure-Mode-Prüfung
- **ER:** Zusammenführung der tragfähigen Teile der Nutzertexte mit korrigierten Alternativen

## evidence_plan

Zu prüfen waren insbesondere:

1. Welche Architekturclaims der Texte stabil, bedingt oder falsch sind.
2. Welche Planungsmethoden für Schichten, Routing und Baustellenproduktion fehlen.
3. Welche Agentenfähigkeiten tatsächlich runtime- und berechtigungsabhängig sind.
4. Welche Web-, Mobile-, Security-, Accessibility- und Production-Praktiken in den Skill gehören.
5. Ob ein Master-Skill oder mehrere Subskills die kleinste robuste erste Version bilden.

## evidence_ledger

| Evidence | Claim | Confidence | Grenze |
|---|---|---:|---|
| E-001 | Outbox, Event Sourcing und Temporal müssen bedingt eingesetzt werden | 5 | Projektarchitektur bleibt kontextabhängig |
| E-002 | CP-SAT, VRPTW und Last Planner lösen unterschiedliche Planungsprobleme | 5 | Lokale Regeln und Daten fehlen |
| E-003 | MCP und AI brauchen Domain-, Policy- und Human-Oversight-Grenzen | 5 | Rechtsanwendung ist projektspezifisch |
| E-004 | Anaplan-/OneStream-Empfehlung ist nicht ausreichend verifiziert | 2 | Vendor-PoC fehlt |
| E-005 | Coding-Agent-Autonomie benötigt Tool-, Sandbox- und Freigabeevidenz | 4 | Kein Repository oder CI vorhanden |
| E-006 | Progressive Disclosure stützt einen Master-Skill | 5 | Subskill-Split kann später sinnvoll werden |
| E-007 | Dynamische UIs, Web und Mobile benötigen überprüfbare Standards | 5 | Skill implementiert keine konkrete App |
| E-008 | Baustellenplanung braucht Produktionssteuerung plus optionale IFC-Integration | 5 | IFC ist use-case-abhängig |

## tool_plan

- Nutzerdateien und vorhandene Dateiinhalte lesen
- Primärquellen im Web prüfen
- Skill-Dateien, Evals, Reports und Plan lokal erzeugen
- JSON, XML, Graphviz, Frontmatter, Quellenstruktur, Evals, Release Gate und ZIP deterministisch validieren

Keine produktiven APIs, Repositories, Cloud-Umgebungen oder Beschäftigtendaten wurden verwendet.

## analysis

### Architektur

Die Texte liegen mit dem modularen Monolithen als Ausgangspunkt grundsätzlich richtig, machen aber aus einer sinnvollen Heuristik ein Dogma. Ein Bounded Context kann mehrere technische Module besitzen. Eine spätere Service-Extraktion ist nur dann relativ günstig, wenn Datenbesitz, Verträge, Idempotenz, Observability und Migration vorher tatsächlich erzwungen wurden.

Outbox ist sinnvoll, garantiert aber keine globale Exactly-once-Semantik. CQRS und Event Sourcing sind selektive Muster und nicht die Standardantwort auf Auditierbarkeit. Temporal ist ein Werkzeug für langlebige, fehlertolerante Workflows as Code und keine allgemeine deklarative Geschäftsprozess-Engine. API Gateway, BFF, Redis, Kafka, Kubernetes, MCP und RAG benötigen jeweils belastbare Trigger.

### Planungswissenschaft

Die größte Lücke der Texte liegt nicht in der Softwarearchitektur, sondern im eigentlichen Planungsmodell. Drei Methoden müssen getrennt und kombinierbar sein:

- Constraint Programming beziehungsweise CP-SAT für diskrete Mitarbeiter-, Skill-, Schicht-, Crew- und Ressourcenzuweisung
- Vehicle Routing with Time Windows für Außendienst- und Multi-Site-Routen
- Last Planner System für Make-ready, zuverlässige Commitments und Lernschleifen in der Baustellenproduktion

Ein Solver prüft Feasibility und Objectives. Das LLM darf Anforderungen interpretieren, Szenarien erzeugen und Ergebnisse erklären, aber nicht selbst als Feasibility Engine auftreten.

### Enterprise-Systemgrenzen

EPM eignet sich primär für strategische, finanzielle und Szenario-Planung. FSM eignet sich primär für operative Work Orders, Dispatch und Technikerabläufe. ERP, HCM, Payroll und Identity bleiben normalerweise führende Systeme für ihre Daten. Die differenzierende Eigenentwicklung liegt im übergreifenden, nachvollziehbaren, realisierbaren Planungs- und Koordinationskern.

### Web und Mobile

Die Webapp benötigt eine zugängliche, dichte Planner-UX mit expliziten Zuständen, Konflikterklärungen und Concurrency-Verhalten. Mobile ist kein automatischer zweiter Schritt, sondern braucht einen Wertbeleg: Offline-Arbeit, Zeit, Check-in, Fotos, Push, Signatur oder Gerätesensorik.

Offline-first bedeutet lokale Source of Truth, dauerhafte Command Queue, Idempotenz, Konfliktklassen, Revocation, Verschlüsselung, Upgrade- und Recovery-Verhalten. Caching allein reicht nicht.

### Agentische Entwicklung

AST, LSP, MCP, Container, CI, Telemetrie und autonome Branches sind optionale Runtime-Capabilities. Der Skill darf ihre Existenz nicht behaupten. Ein Self-Healing Loop wird auf maximal drei materiell unterschiedliche Hypothesen begrenzt. Danach erfolgt Eskalation mit Logs, Hypothesen und sicherem Rollback.

## findings

1. **High:** Die Texte machen bedingte Architekturentscheidungen zu Universalregeln.
2. **Medium:** Bounded Context und NestJS-Modul sind nicht zwingend 1:1.
3. **High:** Outbox bedeutet nicht globale Exactly-once- oder absolute Konsistenz.
4. **High:** CQRS und Event Sourcing sind nicht generell für Zeitdaten erforderlich.
5. **Critical:** CP-SAT, VRPTW und Last Planner fehlen als eigenständige Planungsmethoden.
6. **Critical:** LLM, Autorisierung, Solver und produktive Domain Commands müssen getrennt werden.
7. **High:** Mobile benötigt ein vollständiges Offline- und Konfliktmodell.
8. **High:** Die Anaplan-/OneStream-Auswahlthesen brauchen einen echten PoC.
9. **High:** Coding-Agent-Fähigkeiten sind runtime- und rechteabhängig.
10. **Medium:** Der Master-Skill ist sinnvoll, aber seine Breite muss durch Evals beobachtet werden.
11. **Critical:** Lokaler Build plus Unit Tests ist keine Production Readiness.
12. **High:** Maximale Auslastung ist kein ausreichendes oder verantwortbares Gesamtziel.

## verification

- Alle harten technischen Korrekturen wurden primärquellenbasiert oder als Ableitung markiert.
- Vendor-Entscheidungen bleiben `SOURCE_NEEDED`.
- Rechtsquellen begründen nur Review- und Oversight-Gates, keine Rechtsberatung.
- Der Skill enthält 16 Trigger-Evals und 10 Output-Evals.
- Die Analyse-JSON bestand Struktur-, Quellen-, Reihenfolge- und Artifact-Policy-Prüfung.
- Graphviz-Workflow, Skill-Frontmatter, Dateien, Release Gate, Installability und Portability werden separat validiert.

## bias_and_failure_modes

### Erkannte Bias-Risiken

- Tool Bias zugunsten TypeScript, NestJS, React und OR-Tools
- Overengineering durch das Wort Enterprise
- Automation Bias durch den Wunsch nach einem hochautonomen Agenten
- Vendor- und Authority Bias in Produktvergleichen
- Optimization Bias zugunsten von Utilization und Kosten
- kulturelle und rechtliche Generalisierung
- Confirmation Bias gegenüber der beigefügten Architektur

### Failure-Mode-Kette

`zu früher Stackentscheid -> fehlende Arbeits-, Sicherheits-, Zeit-, Tenant- oder Offline-Regel -> falsches Modell -> unzulässiger Planungsvorschlag -> unautorisierte Veröffentlichung -> schwacher Recovery-Pfad`

Gegenmaßnahmen sind Domain-first, Source Map, Constraint-Katalog, typed commands, risk-based approval, TDD, Evals, Migration, Observability und Rollback.

## synthesis

Empfohlen und gebaut wurde ein einzelner installierbarer Master-Skill `enterprise-workforce-planning-builder`. Er besitzt:

- einen knappen Kontrollfluss in `SKILL.md`
- progressive Referenzen für Domain, Architektur, Optimierung/AI, Web/Mobile, Security und Production
- einen bedingten TypeScript-first-Standardpfad statt eines Stack-Dogmas
- klare Solver-, Domain-Command- und AI-Grenzen
- Baustellen-, Field-Service- und strategische Planung
- Worker-Governance und risikobasierte Freigaben
- TDD, Evals, Production Gate, Installability und Agent-Portability

**Entscheidung: release.**

## artifact_policy

Pflichtartefakte:

- `analysis_report.md`
- `analysis_report.json`

Zusätzlich erzeugt:

- vollständiger Skill-Plan
- `skill.zip`
- Validation Report

Kein SARIF, weil kein konkretes Repository oder Code-Finding analysiert wurde.

## optional_artifacts

- `2026-07-23-enterprise-workforce-planning-builder.md`: vollständiger Ausführungsplan
- `skill.zip`: primäres Installationsartefakt
- `validation-report.txt`: deterministische Prüfnachweise

## machine_readable_json

Die kanonische maschinenlesbare Fassung liegt in:

```text
/mnt/data/enterprise-workforce-planning-builder-analysis/analysis_report.json
```

Sie enthält Source Map, Standards Alignment, Evidence Ledger, Findings, Artifact Policy, Adaptive Output Selection und Ultrathink Gate.

## adaptive_output_selection

Ausgewählt wurde der kleinste vollständige Satz: Markdown-Analyse, JSON-Analyse, Markdown-Plan, installierbares Skill-ZIP und Validierungslog. HTML, PDF und SARIF wurden nicht erzeugt, weil sie für diesen Auftrag keinen zusätzlichen Prüfwert liefern.

## human_readable_summary

Die Ausgangstexte liefern ein gutes Gerüst, übertreiben aber die Allgemeingültigkeit einzelner Patterns und lassen zentrale Planungsmethoden aus. Der korrigierte Skill denkt vom Geschäftsproblem, den Entscheidungsrechten und den Constraints her; hält Architekturentscheidungen bedingt; trennt LLM, Domain Commands und Solver; baut Web und Mobile mit Offline-, Security- und Accessibility-Gates; und erklärt Production Readiness erst nach überprüfbarer Evidenz.

## open_questions

1. Welche Länder, Tarifverträge, Betriebsvereinbarungen und Sicherheitsregeln gelten?
2. Welche Systeme führen Mitarbeiter, Qualifikationen, Zeit, Payroll, Projekte, Baustellen und Work Orders?
3. Welche Nutzergruppen und messbaren Planungsprobleme haben Priorität?
4. Welche Last, Offline-Dauer, Geräte, Routing-, BIM- und Integrationsanforderungen bestehen?
5. Welche Cloud, Identity, Datenresidenz, SLOs, Budgets und Betriebsfähigkeiten sind vorhanden?
6. In welchem konkreten Repository soll die erste Anwendung später implementiert werden?

## ultrathink_craftsmanship_gate

**Triage:** Tief — Verb: analysieren, planen und bauen — Engpass: einen breiten Enterprise-Agenten gleichzeitig fachlich tief, praktisch ausführbar, sicher und nicht überladen zu gestalten — Modus: voll

### Optionen

| Option | Nutzen | Kosten | Risiko | Reversibilität |
|---|---|---|---|---|
| Ein großer selbstenthaltener Skill | einfache Installation | Kontextüberladung | generische Antworten | mittel |
| Master-Skill plus progressive Referenzen | klare Kontrolle, tiefe Nachladung | mehr Dateien | spätere Trigger-Verfeinerung nötig | hoch |
| Sofortiges Multi-Skill-System | starke Spezialisierung | Routing- und Installationskomplexität | Fragmentierung vor Evidenz | mittel |

### Entscheidung

Master-Skill plus progressive Referenzen. Dies ist die kleinste robuste und reversible Lösung. Spezialisierte Subskills werden erst extrahiert, wenn Trigger- oder Output-Evals wiederholt zeigen, dass einzelne Domänen eigene Kontrollflüsse benötigen.

### Stärkstes Gegenargument

Die Domäne ist sehr breit; ein einzelner Skill könnte bei konkreten Coding-Aufgaben zu viel Kontext oder zu allgemeine Praktiken liefern.

### Korrektur

Der Entry Point bleibt unter 500 Zeilen, lädt Referenzen nur nach Bedarf, besitzt Mode Routing, 16 Trigger-Evals und 10 Output-Evals. Der Skill schreibt keine bestimmte App-Struktur vor, wenn ein bestehendes Repository andere belastbare Konventionen hat.

### Konfabulations-Audit

- Technik- und Standardclaims: belegt
- Architekturstandardpfad: als Hypothese markiert
- Vendor-Fit: `SOURCE_NEEDED`
- Rechtsanwendung: qualifizierter Review erforderlich
- Produktionsreife einer späteren App: nicht behauptet

**Final Decision: release.**
