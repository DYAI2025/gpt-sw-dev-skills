# Enterprise Workforce Planning Builder — Skill Implementation Plan

Plan path: `docs/plans/2026-07-23-enterprise-workforce-planning-builder.md`  
Status: **executed-and-locally-validated**  
Primary artifact: `enterprise-workforce-planning-builder-dist/skill.zip`

<!-- GOAL_START -->
Goal: Enterprise Workforce Planning Builder

Ziel. Erzeuge einen installierbaren, evidenzgebundenen Enterprise-Skill, der einen GPT oder vergleichbaren Agenten befähigt, Zeit-, Mitarbeiter-, Field-Service-, Baustellen-, Auslastungs- und Personalplanungssysteme fachlich zu entwerfen, als Webapp und später als iOS-/Android-App umzusetzen, bestehende Repositories zu verbessern, deterministisch zu testen und nur mit belastbarer Evidenz als produktionsreif freizugeben. Der Agent trennt LLM, Domain Commands, Solver, Autorisierung und menschliche Verantwortung.

Scope. Ein Master-Skill mit `SKILL.md`, OpenAI-Metadaten, progressiven Referenzen, Templates, Evals, Validatoren, Release Reports und exakt `skill.zip`. Enthalten sind Domainmodell, Build-versus-Buy, bedingte Architektur, CP-SAT/VRPTW/Last Planner, Web/Mobile/Offline, Integrationen, MCP/RAG, Security, Worker Governance, TDD, Observability, Migration, Rollback und kontinuierliche Verbesserung.

Bedingungen (hart).
- Nutzer- und Vendor-Texte bleiben `user_provided` beziehungsweise `vendor_claim`, bis Primärquellen oder Projektevidenz sie tragen.
- Keine Architekturtechnik wird allein wegen Bekanntheit oder Enterprise-Label zum Default.
- Kein LLM ersetzt Feasibility Checker, Solver, Autorisierung oder verantwortliche Freigabe.
- Keine Production-Ready-Aussage ohne Tests, Security, Accessibility, Migration, Observability, Backup, Restore und Rollback.
- Konsequenzreiche Worker-, Safety-, Performance- oder Payroll-Aktionen benötigen autorisierte menschliche Freigabe.

Akzeptanzkriterien.
- Skill-Ordner, Frontmatter, `agents/openai.yaml`, direkte Referenzen, Evals, Validatoren und Reports bestehen lokale Gates.
- Mindestens 16 Trigger-Fälle und 10 Output-Evals decken Domain, Build, Mobile, Integration, Safety und Production ab.
- Source Map enthält alle drei Nutzertexte, mindestens 20 Primärquellen und explizite Confidence-Regeln.
- Graphviz-Workflow, JSON-Reports, XML-Evaluation und ZIP-Wurzel sind syntaktisch valide.
- ZIP heißt `skill.zip` und enthält genau einen Root-Ordner mit passendem Skill-Namen.

Explizit out-of-scope.
- Keine konkrete Kunden-Webapp oder Mobile-App ohne Repository und Anforderungen.
- Keine Vendor-Beschaffung oder Rechtsberatung.
- Kein produktives Deployment, keine produktive Migration und kein Zugriff auf echte Beschäftigtendaten.
- Keine Garantie für automatische Skill-Invocation oder einen Install-Button im Zielclient.

Done-Definition. Analysebericht, vollständiger Plan, Skill-Paket, Validierungslog und installierbares `skill.zip` liegen vor; alle lokalen Struktur-, Quellen-, Eval-, Release-, Portabilitäts- und Packaging-Gates sind grün. Empirische Modell-Evals bleiben als separat auszuführender Wirksamkeitsnachweis dokumentiert.

Reference-Doc: `docs/plans/2026-07-23-enterprise-workforce-planning-builder.md`
<!-- GOAL_END -->

## Evidence and source boundary

### Gelesene Projektquellen

| ID | Quelle | Klasse | Verwendung | Grenze |
|---|---|---|---|---|
| SRC-U1 | Enterprise-Architekturmuster für Planungsplattformen | `user_provided` | Muster für DDD, Outbox, Workflows, MCP, RAG, HITL | Mehrere Muster und Leistungsclaims zu absolut |
| SRC-U2 | Anaplan-/OneStream-Vergleich | `user_provided`, teilweise `vendor_claim` | EPM/FSM-Build-versus-Buy-Kontext | Keine Edition-, Lizenz-, API- oder PoC-Evidenz |
| SRC-U3 | Agent als Co-Architekt und Entwickler | `user_provided` | Repository-Introspektion, Tests, Sandbox, Telemetrie | Runtime-Capabilities und Autonomie nicht garantiert |

### Primärquellen-Gruppen

- Agent Skills Specification
- MCP Specification 2025-11-25
- PostgreSQL und PostGIS
- OR-Tools Employee Scheduling und VRPTW
- Lean Construction Institute Last Planner System
- buildingSMART IFC 4.3.2.0
- JSON Schema Draft 2020-12
- Temporal TypeScript Dokumentation
- OpenAPI, AsyncAPI und CloudEvents
- WCAG 2.2, OWASP ASVS und MASVS
- NIST AI RMF, DSGVO, EU AI Act und Working Time Directive
- OpenTelemetry

### Korrigierte Ausgangsclaims

- Bounded Context und NestJS-Modul sind nicht zwingend 1:1.
- Outbox erzeugt keine globale Exactly-once- oder absolute Konsistenz.
- CQRS und Event Sourcing sind nicht pauschal für Zeitdaten erforderlich.
- Temporal ist eine durable Workflows-as-code-Option, keine allgemeine deklarative UI-Workflow-Lösung.
- MCP ersetzt weder Domain API noch Identity, Authorization, Audit oder Workflow State.
- PostgreSQL `ts_rank_cd` ist nicht BM25; RRF verhindert keine Halluzinationen.
- NestJS, Python und Go bilden keinen verpflichtenden Default-Stack.
- AI-Autonomie wird risikobasiert statt absolut erlaubt oder verboten.

## Assumptions, missing information, open questions, blockers

### ASSUMPTION

- Ein TypeScript-first-Modular-Monolith ist eine sinnvolle, reversible Greenfield-Referenz für kleine bis mittlere Teams.
- Ein einzelner Master-Skill mit Progressive Disclosure ist die kleinste kohärente erste Releaseform.
- Eine Python-Solver-Grenze wird erst bei OR-Tools-, Scientific-Library- oder unabhängigen Skalierungsanforderungen aktiviert.

### MISSING

- Zielunternehmen, Nutzerforschung und konkrete Planning Jobs-to-be-Done
- anwendbare Arbeits-, Tarif-, Sicherheits- und Datenschutzregeln
- Systeme of Record, Identity und Authorization
- Repository, Tests, CI/CD und Infrastruktur
- repräsentative Daten, Scale, SLOs und Kosten
- Mobile-Geräte, Offline-Dauer, Sensoren und Distribution
- Vendor-Editionen und Proof-of-Concept-Daten

### OPEN QUESTIONS

1. Welche erste Kunden- oder interne Anwendung soll mit dem Skill gebaut werden?
2. Welcher Planungszeitraum und welche Entscheidungstaktung haben Vorrang?
3. Welche Constraints sind hart, welche Präferenzen weich, wer darf überschreiben?
4. Welche Worker-Governance und Mitbestimmung gelten?
5. Welche bestehende Plattform und welches Team tragen Betrieb und Weiterentwicklung?

### BLOCKER

Kein Blocker für das Skill-Paket. Die fehlenden Angaben blockieren jedoch jede Behauptung, eine konkrete Anwendung sei rechtlich korrekt, optimal oder produktionsreif.

## Requirements

| ID | Requirement | Source | Verification | Risk if wrong |
|---|---|---|---|---|
| REQ-F-001 | Skill deckt strategische, taktische, operative und Echtzeitplanung ab. | user + derived | Domain-Referenz und Output-Evals | Vermischte Zustände und ungeeignete Modelle |
| REQ-F-002 | Skill modelliert Zeit, Workforce, Skills, Sites, Crews, Work Packages, Assets, Travel und Actuals. | user | Domain-Ontologie und Trigger-Evals | Fachliche Lücken |
| REQ-F-003 | Skill trennt Build, Buy, Integrate und Experiment. | user + analysis | Workflow und Architecture Guide | Rebuild von Commodity/SOR |
| REQ-F-004 | Skill enthält CP-SAT/Constraint Scheduling, VRPTW und Last Planner als getrennte Methoden. | primary research | Planning Reference und Evals | Unrealisierbare Planung |
| REQ-F-005 | Skill enthält Web-, Mobile-, Offline-, Sync-, Device- und Store-Release-Praxis. | user + primary research | Mobile Reference und Evals | Datenverlust und schlechte Field UX |
| REQ-F-006 | Skill unterstützt Greenfield, Repository Build, Audit und Release-Modi. | user | `SKILL.md` Modes | Unklare Ausführung |
| REQ-F-007 | Skill erzeugt Goal, Requirements, ADRs, Vertical Slices, Tests, Validation und Rollback. | writing-plans | Output Contract | Nicht ausführbare Pläne |
| REQ-F-008 | Skill integriert EPM/FSM/ERP/HCM/Payroll über klare Verträge und SOR-Regeln. | user | Architecture Guide und Integration Eval | Datenkonflikte |
| REQ-F-009 | Skill behandelt MCP/RAG/AI als optionale Adapter hinter Domain- und Policy-Grenzen. | user + MCP | AI Reference und Safety Eval | Unsafe agentic actions |
| REQ-F-010 | Skill prüft eigene Lösungen dialektisch und verbessert evidenzbasiert. | user + ultrathink | Counterargument, Bias, bounded loop | Sycophancy und Overconfidence |
| REQ-NF-001 | `SKILL.md` bleibt unter 500 Zeilen, Details liegen progressiv in Referenzen. | Agent Skills | Quick Validator | Kontextüberladung |
| REQ-NF-002 | Referenzen sind direkt erreichbar, package- und agentenagnostisch dokumentiert. | enterprise creator | Link- und compatibility gate | Nicht portable Nutzung |
| REQ-NF-003 | Keine unbelegten Zahlen, Framework-Garantien oder Compliance-Claims. | research policy | Source/Release Gate | Konfabulation |
| REQ-D-001 | Source Map klassifiziert `primary`, `user_provided`, `vendor_claim`, `derived`, `uncertain`. | research builder | `validate_source_map.py` | User-These wird als Fakt gelaundert |
| REQ-D-002 | Reale personenbezogene Daten sind nicht Teil des Pakets oder der Evals. | security | File review | Datenschutzverletzung |
| REQ-A-001 | Master-Skill plus progressive Referenzen bildet Release 1. | ultrathink decision | Filetree und quick validator | Fragmentierung oder Overload |
| REQ-A-002 | TypeScript-first ist Referenzhypothese, kein Mandat. | corrected analysis | Skill wording und eval | Tool Bias |
| REQ-A-003 | LLM, Domain Command, Solver, Approval und Persistence bleiben getrennt. | primary + governance | Skill hard rule und safety eval | Invalid/unauthorized writes |
| REQ-S-001 | Kein direkter Tabellen-, Payroll-, Safety- oder Employee-Impact-Write durch Agenten. | user + governance | Security Reference und OUT-007 | Materieller Schaden |
| REQ-S-002 | Authorization, Tenant Scope, Data Classification, Approval, Audit und Rollback sind Pflicht. | security sources | Release Gate | Cross-tenant oder unkontrollierte Aktion |
| REQ-S-003 | Web und Mobile nutzen risikobasierte ASVS-/MASVS-Prüfung und Accessibility Gate. | primary | References und release checklist | Security/Accessibility Regression |
| REQ-O-001 | Paket enthält deterministische Validatoren, Evals, Reports und Packaging. | enterprise creator | lokale Commands | Nicht reproduzierbarer Release |
| REQ-O-002 | Production Readiness verlangt SLO, Telemetrie, Backup, Restore, Incident und Rollback. | primary + user | Production Reference und Eval | Falsche Freigabe |
| REQ-O-003 | Repair Loop endet nach drei materiell verschiedenen Fehlversuchen. | ultrathink correction | Skill und Eval | Endlosschleife und Testmanipulation |

## Architecture and file boundaries

### Gewählte Skill-Architektur

```text
enterprise-workforce-planning-builder/
├── SKILL.md
├── agents/
│   └── openai.yaml
├── references/
│   ├── source-policy.md
│   ├── source-map.md
│   ├── domain-product-model.md
│   ├── architecture-stack-decision-guide.md
│   ├── planning-optimization-and-ai.md
│   ├── web-mobile-delivery.md
│   ├── security-and-tools.md
│   ├── testing-evaluation-and-production.md
│   ├── eval-design.md
│   ├── release-gate-policy.md
│   ├── enterprise-skill-output-evaluator.md
│   ├── installability-and-distribution.md
│   ├── agent-agnostic-compatibility.md
│   ├── capability-parity-policy.md
│   └── workflow.dot
├── assets/
│   ├── product-brief-template.md
│   ├── adr-template.md
│   ├── planning-problem-example.json
│   └── release-checklist.md
├── scripts/
│   ├── quick_validate.py
│   ├── validate_source_map.py
│   ├── validate_evals.py
│   ├── validate_release_gate.py
│   ├── validate_installability.py
│   ├── validate_agent_agnostic.py
│   ├── validate_core_parity.py
│   ├── validate_no_placeholders.py
│   ├── validate_workflow.py
│   ├── validate_enterprise_skill_evaluation.py
│   └── package_skill.py
├── evals/
│   ├── trigger_queries.json
│   └── output_evals.json
└── reports/
    ├── release-gate-report.json
    ├── installability-report.json
    ├── agent-compatibility-report.json
    ├── core-functionality-preservation.json
    ├── analysis-corrections.json
    └── enterprise-skill-evaluation.xml
```

### Boundary rules

- `SKILL.md` steuert Mode, Gates und End-to-End-Workflow.
- Fachwissen und ausführliche Regeln liegen nur in `references/`.
- `assets/` enthält wiederverwendbare, absichtlich auszufüllende Vorlagen.
- `scripts/` führt deterministische Paketprüfung aus; keine produktiven APIs.
- `evals/` prüft Trigger, Architektur, Domain, Mobile, Integration, Safety und Release.
- `reports/` dokumentiert Release, Installability, Portability, Korrekturen und Baseline.

### Options considered

| Option | Nutzen | Kosten | Risiko | Entscheidung |
|---|---|---|---|---|
| Ein selbstenthaltener Super-Skill | geringe Dateizahl | hoher Kontext | generische und widersprüchliche Antworten | verworfen |
| Master-Skill mit Referenzen | klare Kontrolle, progressive Tiefe | mehr Dateien | spätere Extraktion möglich | gewählt |
| Sofortiges Multi-Skill-System | starke Spezialtrigger | hohe Routing- und Installationskomplexität | Fragmentierung vor Nutzungsdaten | später bei Eval-Evidenz |
| Vendor-spezifischer Agent | schnelle Produktanpassung | Lock-in und schmaler Scope | falsche Plattformprämisse | verworfen |

## Implementation phases

### Phase 1 — Evidence and correction

- Nutzerquellen inventarisieren.
- Primärquellen zu Standards, Planning, Mobile, Security und AI Governance prüfen.
- Claim Matrix und Korrekturliste erstellen.
- Universalclaims auf bedingte Regeln reduzieren.

### Phase 2 — Skill control plane

- Name, Description, Modes, Hard Rules und Output Contract erzeugen.
- Domain-first-, Buy/Integrate/Build- und Risk-Gates einbauen.
- Progressive Reference Routing definieren.

### Phase 3 — Domain and architecture knowledge

- Ontologie, Planning Horizons, Decision Rights, Invariants und SOR-Grenzen schreiben.
- Conditional Architecture Guide und TypeScript-first-Referenz entwerfen.
- Outbox, CQRS, Event Sourcing, Temporal, BFF, MCP, RAG und Deployment korrekt gaten.

### Phase 4 — Planning, construction, web, and mobile

- CP-SAT, VRPTW, Multi-Objective, Fairness, Explanation und Solver Tests definieren.
- Last Planner, Make-ready, Weekly Commitments und Variance Learning integrieren.
- Web UX, Accessibility, Offline-first, Sync, Permissions, Security und Release modellieren.

### Phase 5 — Agent engineering and production

- Agent Risk Ladder, typed tools, MCP, RAG und Prompt-Injection-Grenzen definieren.
- TDD, Property, Contract, E2E, Accessibility, Mobile, Performance und Resilience aufnehmen.
- SLO, Observability, Migration, Backup/Restore, Rollback und Incident Gate schreiben.

### Phase 6 — Evals and deterministic validation

- Trigger- und Output-Evals schreiben.
- Validatoren test-first gegen absichtlich unvollständige Paketvarianten entwerfen.
- Release-, Installability-, Portability- und Core-Parity-Reports erzeugen.

### Phase 7 — Ultrathink release and packaging

- stärkstes Gegenargument und Failure Chain prüfen.
- Tool-, Overengineering-, Automation-, Vendor- und Legal Bias korrigieren.
- alle Validatoren ausführen.
- exakt `skill.zip` mit einem Root-Ordner erzeugen.

## Tasks

### TASK-001: Inventarisiere Quellen und Claims

Objective: Trenne belegte Fakten, Nutzerthesen, Vendor-Claims, Ableitungen und Lücken.
Requirement links: REQ-D-001, REQ-NF-003
Files/modules:
- Create: `references/source-policy.md`
- Create: `references/source-map.md`
- Create: `reports/analysis-corrections.json`

Steps:
1. Lies alle drei Nutzertexte vollständig.
2. Zerlege Aussagen in Architektur-, Produkt-, Planning-, Agent-, Security- und Vendor-Claims.
3. Markiere `user_provided`, `vendor_claim`, `primary`, `derived`, `uncertain`.
4. Prüfe dynamische und kritische Claims gegen Primärquellen.
5. Erzeuge Confidence und Korrekturstatus.

Acceptance criteria:
- Mindestens drei Nutzerquellen, 20 Primärquellen und fünf abgeleitete Entscheidungen sind vorhanden.
- Kein Confidence-1-bis-3-Claim wird als harte Regel übernommen.

Validation:
- Command: `python scripts/validate_source_map.py <skill-dir>`
- Expected result: `PASS`

Rollback note: Source Map ist additiv; fehlerhafte Claims werden entfernt oder herabgestuft.

### TASK-002: Definiere Master-Skill und Trigger

Objective: Erzeuge einen präzisen Entry Point mit Mode Routing und Hard Rules.
Requirement links: REQ-F-001, REQ-F-006, REQ-NF-001, REQ-A-001
Files/modules:
- Create: `SKILL.md`
- Create: `agents/openai.yaml`

Steps:
1. Schreibe failing Trigger-Szenarien für In-Scope und Near-Miss-Aufgaben.
2. Formuliere Name und Description mit Domain- und Delivery-Keywords.
3. Definiere Discovery, Architecture, Build, Audit, Release Modes.
4. Definiere Hard Rules, End-to-End-Workflow, Output und Stop Rules.
5. Halte den Entry Point unter 500 Zeilen.

Acceptance criteria:
- Description triggert Domain- und Build-Aufgaben, aber keine simplen Kalender- oder Copy-Aufgaben.
- Alle Kernreferenzen sind direkt verlinkt.

Validation:
- Command: `python scripts/quick_validate.py <skill-dir>`
- Expected result: `PASS`

Rollback note: Description und Mode Routing können unabhängig revidiert werden; Evals schützen gegen Regression.

### TASK-003: Baue Domain- und Product-Modell

Objective: Verankere fachliche Entscheidungen vor Technik.
Requirement links: REQ-F-001, REQ-F-002, REQ-F-003
Files/modules:
- Create: `references/domain-product-model.md`
- Create: `assets/product-brief-template.md`

Steps:
1. Definiere Planning Horizons, Actors, Decision Rights und Bounded Contexts.
2. Definiere Time, Workforce, Site, Work Package, Asset, Plan, Actual und Integration Concepts.
3. Formuliere Hard Invariants und Soft Objectives.
4. Definiere Construction Make-ready und Build-versus-Buy-Boundary.
5. Ergänze Discovery Evidence Checklist.

Acceptance criteria:
- Modell erklärt Corrections, History, Concurrency und Assignment-Rejection.
- Utilization besitzt explizite Denominatoren und ist nicht das einzige Ziel.

Validation:
- Command: `grep -q "Hard invariants" references/domain-product-model.md`
- Expected result: exit 0

Rollback note: Fachbegriffe sind versionierbar; keine Anwendungsmigration erfolgt in diesem Task.

### TASK-004: Entwirf bedingte Architekturregeln

Objective: Ersetze Stack-Dogma durch überprüfbare Entscheidungsgates.
Requirement links: REQ-A-002, REQ-F-008, REQ-NF-003
Files/modules:
- Create: `references/architecture-stack-decision-guide.md`
- Create: `assets/adr-template.md`

Steps:
1. Definiere TypeScript-first-Referenzpfad als Hypothese.
2. Definiere Extraction Gates für Services und Python Solver.
3. Gate Data, Outbox, Broker, CQRS, Event Sourcing, Workflow, BFF, Mobile und MCP.
4. Definiere EPM/FSM/ERP/HCM/Payroll-Integrationsregeln.
5. Definiere Deployment Progression ohne Kubernetes-/ArgoCD-Widerspruch.

Acceptance criteria:
- Jedes fortgeschrittene Pattern besitzt Use- und Avoid-Kriterien.
- Kein generischer Latenz-, Memory- oder Scale-to-Zero-Claim bleibt bestehen.

Validation:
- Command: `python scripts/validate_no_placeholders.py <skill-dir>`
- Expected result: `PASS`

Rollback note: Jede Architekturentscheidung bleibt ADR-basiert und rückbaubar.

### TASK-005: Modellieren Planning Optimization und AI

Objective: Verankere deterministische Feasibility und erklärbare Scenario-Optimierung.
Requirement links: REQ-F-004, REQ-A-003, REQ-O-003
Files/modules:
- Create: `references/planning-optimization-and-ai.md`
- Create: `assets/planning-problem-example.json`

Steps:
1. Definiere versionierten Planning-Problem- und Result-Contract.
2. Trenne Hard Constraints, Soft Objectives und Objective Hierarchy.
3. Definiere CP-SAT, VRPTW, MIP, Heuristics, Simulation und Rolling Horizon.
4. Integriere Construction Production Control, Fairness und Explanation.
5. Definiere Solver Tests, MCP Tools, RAG Boundary und bounded repair loop.

Acceptance criteria:
- LLM darf keine Feasibility behaupten, bevor ein deterministischer Checker akzeptiert.
- Solverresultat enthält Status, Version, Objective, Diagnose und Reproduzierbarkeit.

Validation:
- Command: `python -m json.tool assets/planning-problem-example.json`
- Expected result: exit 0

Rollback note: Solver bleibt hinter einem versionierten Contract austauschbar.

### TASK-006: Integriere Baustellen-Produktionssteuerung

Objective: Ergänze Softwareplanung um Make-ready, Commitments und Learning.
Requirement links: REQ-F-002, REQ-F-004
Files/modules:
- Modify: `references/domain-product-model.md`
- Modify: `references/planning-optimization-and-ai.md`

Steps:
1. Definiere Master/Phase/Lookahead/Weekly/Daily States.
2. Definiere Ready-Kriterien für Information, Material, Crew, Equipment, Access, Safety und Predecessor.
3. Definiere Constraint Log, Owner und Due Date.
4. Definiere Percent Plan Complete und Reasons for Variance.
5. Gate IFC/BIM als optionale Austauschschicht.

Acceptance criteria:
- Nicht ready Work Packages gelangen nicht in den optimierten Weekly Plan.
- Menschliche Commitments und Solveroptimierung bleiben komplementär.

Validation:
- Command: `grep -q "Make-ready" references/planning-optimization-and-ai.md`
- Expected result: exit 0

Rollback note: Construction-Funktionen bleiben optionaler Domainpfad.

### TASK-007: Entwirf Web- und Mobile-Lifecycle

Objective: Definiere zugängliche Planner-UX und robuste Field-Mobile-App.
Requirement links: REQ-F-005, REQ-S-003
Files/modules:
- Create: `references/web-mobile-delivery.md`

Steps:
1. Trenne Planner, Site/Dispatch, Worker Mobile, Admin und Executive Surface.
2. Definiere Dense Grid, Keyboard, Screen Reader, Conflict und Concurrency UX.
3. Führe Mobile Value Gate ein.
4. Definiere local source of truth, Command Queue, Conflict Classes und Revocation.
5. Definiere Device Permissions, Time UX, Auth, Push, Deep Links, Tests und Store Release.

Acceptance criteria:
- Offline Write Flow ist nicht mit Query Cache gleichgesetzt.
- Location und andere Sensoren sind minimiert, widerrufbar und off-duty begrenzt.

Validation:
- Command: `grep -q "Offline-first" references/web-mobile-delivery.md`
- Expected result: exit 0

Rollback note: Responsive Web bleibt valide, solange Mobile Value nicht belegt ist.

### TASK-008: Definiere Security, Privacy und Worker Governance

Objective: Mache Agent- und Planungsaktionen sicher und überprüfbar.
Requirement links: REQ-S-001, REQ-S-002, REQ-S-003
Files/modules:
- Create: `references/security-and-tools.md`

Steps:
1. Definiere Data Classification, Purpose, Access, Retention und Redaction.
2. Definiere RBAC/ABAC/Relationship Checks und Separation of Duties.
3. Definiere ASVS-/MASVS-, API-, Mobile-, Supply-Chain- und Webhook-Controls.
4. Definiere Agent Tool Risk Policy und MCP Controls.
5. Definiere Worker Impact, Oversight, Appeal und Legal Review Boundary.

Acceptance criteria:
- Kein generisches SQL, Shell, Payroll oder Admin Tool wird exponiert.
- Konsequenzreiche Aktionen benötigen validierte Domain Commands und autorisierte Approval.

Validation:
- Command: `grep -q "Agent and tool risk policy" references/security-and-tools.md`
- Expected result: exit 0

Rollback note: Rechte werden deny-by-default erweitert, nicht breit zurückgerollt.

### TASK-009: Definiere Test- und Production-Gate

Objective: Operationalisiere TDD, Evaluation, Migration, Observability und Release.
Requirement links: REQ-F-007, REQ-O-001, REQ-O-002
Files/modules:
- Create: `references/testing-evaluation-and-production.md`
- Create: `assets/release-checklist.md`

Steps:
1. Definiere Evidence Hierarchy und TDD Vertical Slice.
2. Definiere Unit, Property, Solver, DB, Contract, Integration, E2E, Accessibility, Mobile, Performance und Resilience Tests.
3. Definiere AI/Agent-Evaluation und Baseline-Vergleich.
4. Definiere OTel Signals, SLOs, Migration Safety und CI/CD Gates.
5. Definiere Production Gate, Incident, Rollback und Improvement Loop.

Acceptance criteria:
- Lokaler Build oder grüne Unit Tests reichen explizit nicht aus.
- Jeder Release besitzt Support, Ownership, Telemetry, Restore und Rollback.

Validation:
- Command: `grep -q "Production-readiness gate" references/testing-evaluation-and-production.md`
- Expected result: exit 0

Rollback note: Feature Flag oder Deployment-Rollback ersetzt keine ungetestete Datenmigration.

### TASK-010: Erzeuge Skill-Evals

Objective: Prüfe Trigger, Verhalten, Safety, Minimalität und Production Claims.
Requirement links: REQ-F-010, REQ-O-001
Files/modules:
- Create: `references/eval-design.md`
- Create: `evals/trigger_queries.json`
- Create: `evals/output_evals.json`

Steps:
1. Schreibe positive und nahe negative Trigger Queries.
2. Schreibe Greenfield-, Repository-, Solver-, Construction-, Mobile-, Integration-, Safety- und Release-Szenarien.
3. Definiere Expected Properties statt einer einzigen Musterantwort.
4. Definiere konkrete Failure Modes aus der Textanalyse.
5. Validiere Struktur und Coverage.

Acceptance criteria:
- Mindestens 16 Trigger und 10 Outputs.
- Safety-, Integration- und Minimal-Solution-Evals sind vertreten.

Validation:
- Command: `python scripts/validate_evals.py <skill-dir>`
- Expected result: `PASS`

Rollback note: Evals sind versionierte Regression Contracts; Löschung erfordert Begründung.

### TASK-011: Baue deterministische Validatoren

Objective: Ersetze Release-Bauchgefühl durch maschinenlesbare Gates.
Requirement links: REQ-NF-001, REQ-D-001, REQ-O-001
Files/modules:
- Create: `scripts/*.py`

Steps:
1. Schreibe Failure Fixtures mental oder lokal für fehlende Pfade, falsche Frontmatter, geringe Source Coverage und unvollständige Evals.
2. Implementiere Package, Source, Eval, Release, Installability, Portability, Core-Parity, Placeholder, Workflow und XML Validator.
3. Führe jeden Validator gegen das Paket aus.
4. Korrigiere gefundene Lücken, ohne Gate zu schwächen.
5. Integriere alle Gates in `package_skill.py`.

Acceptance criteria:
- Jeder Validator liefert eindeutiges `PASS` oder `FAIL` und non-zero Exit bei Fehler.
- Packaging stoppt beim ersten fehlgeschlagenen Gate.

Validation:
- Command: `for s in scripts/validate_*.py; do python "$s" <appropriate-input>; done`
- Expected result: alle `PASS`

Rollback note: Validatoren sind unabhängig; fehlerhafte Regel kann isoliert revidiert werden.

### TASK-012: Erzeuge Release- und Portability-Reports

Objective: Dokumentiere Freigabe, Grenzen und zukünftige Regression Baseline.
Requirement links: REQ-A-001, REQ-NF-002, REQ-O-001
Files/modules:
- Create: `reports/*.json`
- Create: `reports/enterprise-skill-evaluation.xml`
- Create: `references/installability-and-distribution.md`
- Create: `references/agent-agnostic-compatibility.md`
- Create: `references/capability-parity-policy.md`

Steps:
1. Dokumentiere Craftsmanship, Confabulation, Sycophancy und Bias Gate.
2. Dokumentiere `skill.zip`, kontrollierte und nicht kontrollierbare Installability-Aspekte.
3. Dokumentiere portable und runtime-spezifische Bestandteile.
4. Friere Core Functions als Release-1-Baseline ein.
5. Erzeuge und validiere XML-Evaluation.

Acceptance criteria:
- Keine UI-Install-Garantie.
- Agent-Portability bedeutet semantische Portabilität, nicht Tool-Parität.

Validation:
- Command: `python scripts/validate_release_gate.py <skill-dir>` und weitere Report-Validatoren
- Expected result: `PASS`

Rollback note: Reports werden gegen die letzte valide Baseline verglichen.

### TASK-013: Modelliere Workflow und Ultrathink-Gate

Objective: Mache Stop-, Build-, Repair- und Release-Entscheidungen sichtbar.
Requirement links: REQ-F-010, REQ-O-003
Files/modules:
- Create: `references/workflow.dot`
- Create: `references/release-gate-policy.md`

Steps:
1. Modellieren Intake, Blocker, Evidence, Domain, Buy/Build, Architecture, AI, Mobile, Plan, Build, Validate und Release.
2. Verwende Diamonds, Boxes, Plaintext, Octagons und Double Circles gemäß Konvention.
3. Baue Three-Attempt Repair Gate ein.
4. Prüfe Graphviz-Syntax.
5. Dokumentiere stärkstes Gegenargument und Failure Chain.

Acceptance criteria:
- Workflow hat explizite Block- und Exit-Pfade.
- Unbounded Repair ist ausgeschlossen.

Validation:
- Command: `python scripts/validate_workflow.py <skill-dir>`
- Expected result: `PASS`

Rollback note: Workflow ist Dokumentation; keine produktive Zustandsmaschine wird verändert.

### TASK-014: Validiere Analyse und Plan

Objective: Prüfe menschen- und maschinenlesbare Steuerartefakte.
Requirement links: REQ-F-007, REQ-F-010
Files/modules:
- Create: `enterprise-workforce-planning-builder-analysis/analysis_report.md`
- Create: `enterprise-workforce-planning-builder-analysis/analysis_report.json`
- Create: `docs/plans/2026-07-23-enterprise-workforce-planning-builder.md`

Steps:
1. Erzeuge Evidence Ledger, Findings, Verification, Bias und Synthesis.
2. Validiere JSON-Schema-Struktur, Top-Level-Order, Sources und Artifact Policy.
3. Erzeuge Goal unter 4000 Zeichen, Requirements und Tasks.
4. Validiere den Plan.
5. Dokumentiere verbleibende Projektfragen.

Acceptance criteria:
- Analyse-JSON besteht alle installierten Deep-Reasoning-Validatoren.
- Plan enthält alle Pflichtabschnitte und mindestens drei Out-of-Scope-Punkte.

Validation:
- Command: `python /home/oai/skills/deep-reasoning-analysis-enterprise/scripts/validate_analysis_report.py analysis_report.json`
- Command: `python /home/oai/skills/writing-plans/scripts/validate_plan.py <plan>`
- Expected result: `PASS`

Rollback note: Analyse und Plan sind additive Audit-Artefakte.

### TASK-015: Package und verifiziere skill.zip

Objective: Erzeuge das primäre installierbare Artefakt.
Requirement links: REQ-NF-002, REQ-O-001
Files/modules:
- Create: `enterprise-workforce-planning-builder-dist/skill.zip`
- Create: `enterprise-workforce-planning-builder-delivery/validation-report.txt`

Steps:
1. Führe alle Skill-Validatoren aus.
2. Führe den Enterprise-Skill-XML-Validator aus.
3. Erzeuge `skill.zip` nur bei grünen Gates.
4. Prüfe genau einen Root-Ordner und Pflichtdateien im ZIP.
5. Speichere Prüfausgaben und SHA-256.

Acceptance criteria:
- Artefakt heißt exakt `skill.zip`.
- ZIP enthält genau `enterprise-workforce-planning-builder/` als Root.
- `SKILL.md` und `agents/openai.yaml` sind im ZIP vorhanden.

Validation:
- Command: `python scripts/package_skill.py <skill-dir> <dist-dir>`
- Expected result: `PACKAGED: .../skill.zip`

Rollback note: ZIP ist reproduzierbar und kann ohne Veränderung der Quellen neu erzeugt werden.

## Validation strategy

### Statische Skill-Gates

```bash
python scripts/quick_validate.py <skill-dir>
python scripts/validate_source_map.py <skill-dir>
python scripts/validate_evals.py <skill-dir>
python scripts/validate_release_gate.py <skill-dir>
python scripts/validate_installability.py <skill-dir>
python scripts/validate_agent_agnostic.py <skill-dir>
python scripts/validate_core_parity.py <skill-dir>
python scripts/validate_no_placeholders.py <skill-dir>
python scripts/validate_workflow.py <skill-dir>
python scripts/validate_enterprise_skill_evaluation.py <skill-dir>/reports/enterprise-skill-evaluation.xml
```

### Analyse- und Plan-Gates

```bash
python /home/oai/skills/deep-reasoning-analysis-enterprise/scripts/validate_analysis_report.py analysis_report.json
python /home/oai/skills/deep-reasoning-analysis-enterprise/scripts/check_sources_and_evidence.py analysis_report.json
python /home/oai/skills/deep-reasoning-analysis-enterprise/scripts/validate_output_order.py analysis_report.json
python /home/oai/skills/deep-reasoning-analysis-enterprise/scripts/validate_artifact_policy.py analysis_report.json
python /home/oai/skills/writing-plans/scripts/validate_plan.py docs/plans/2026-07-23-enterprise-workforce-planning-builder.md
```

### Packaging-Gate

```bash
python scripts/package_skill.py <skill-dir> <dist-dir>
unzip -l <dist-dir>/skill.zip
sha256sum <dist-dir>/skill.zip
```

### Noch ausstehender empirischer Wirksamkeitsnachweis

- Run baseline prompts ohne Skill.
- Run dieselben Prompts mit Skill.
- Vergleiche Trigger, Domain-Completeness, Safety, Minimality und Production Claims.
- Human Review für mindestens die zehn Output-Evals.
- Extrahiere Subskills nur bei wiederholter Evidenz für Kontext- oder Triggerprobleme.

## Rollback and safety

- Keine produktiven Systeme oder Branches wurden verändert.
- Alle Dateien liegen in einem neuen isolierten Skill-Ordner.
- Packaging ist reproduzierbar und destruktionsfrei.
- Keine Credentials, Produktionsdaten oder proprietäre Vendor-Dokumente wurden eingebettet.
- Fortgeschrittene Architektur, Mobile, AI und Solver bleiben durch Gates optional.
- Bei zukünftigen Änderungen bleibt die vorherige ZIP-Baseline erhalten.
- Jeder zukünftige App-Build benötigt eigene Migration-, Backup-, Restore-, Deployment- und Rollback-Evidenz.

## Execution handoff

Der Plan wurde für Release 1 ausgeführt. Nächste praktische Anwendung:

1. Wähle ein konkretes erstes Produktproblem und Repository.
2. Liefere Nutzerinterviews, Beispieldaten, Constraint-Katalog, System-of-Record- und Decision-Right-Matrix.
3. Aktiviere den Skill im Discovery Mode.
4. Erzeuge Product Brief, Goal, Requirements, ADRs und ersten Vertical Slice.
5. Implementiere test-first in einer isolierten Branch-/Sandbox-Umgebung.
6. Führe Domain-, Security-, Mobile-, Integration- und Production-Gates aus.
7. Führe parallel empirische Skill-Evals ohne/mit Skill aus.

Empfohlener erster App-Slice:

`authorized planner -> workers/skills/sites/demand -> proposed assignment -> deterministic rejection or acceptance -> approval -> published schedule -> audit and telemetry`

## Plausibility and truth self-check

### Truth

- Die Dateien und Validatoren wurden lokal erzeugt und ausgeführt.
- Der Skill ist strukturell installierbar; eine Client-UI-Installation ist nicht garantiert.
- Die Quellen belegen Methoden und Grenzen, nicht die optimale Architektur eines unbekannten Unternehmens.
- Anaplan-/OneStream-Produktfit bleibt ungeprüft.
- Keine konkrete App, Mobile-Binary oder produktive Infrastruktur wurde gebaut.

### Strongest counterargument

Die Domäne ist zu breit für einen einzelnen Skill. Solver, Construction, Mobile und Production Audit könnten als eigene Skills präziser triggern und weniger Kontext verbrauchen.

### Antwort auf das Gegenargument

Release 1 nutzt einen knappen Control Plane und progressive Referenzen. Eine sofortige Fragmentierung erhöht Installations- und Routingkosten ohne Nutzungsdaten. Trigger- und Output-Evals bilden die Revisit-Bedingung. Wiederholte Kontext- oder Qualitätsprobleme führen zu evidence-backed Subskill-Extraktion.

### Failure-mode chain

`zu breiter Trigger -> irrelevante Referenzladung -> generische Architektur -> fehlende Domain Constraint -> falscher Slice -> unzureichender Test -> falsche Production-Freigabe`

Gegenmaßnahmen:

- konkrete Description und Negative Trigger-Evals
- Mode Routing und Progressive Disclosure
- Domain Model vor Stack
- deterministic solver boundary
- TDD, Safety und Production Gate
- bounded repair und human review

### Bias review

- **Tool Bias:** TypeScript-first ist Hypothese, kein Mandat.
- **Overengineering:** Broker, Temporal, RAG, MCP, Microservices und Kubernetes sind conditional.
- **Automation Bias:** Konsequenzreiche Aktionen bleiben human-approved.
- **Optimization Bias:** Fairness, Stabilität, Readiness und Sicherheit ergänzen Utilization und Cost.
- **Vendor Bias:** Produktclaims benötigen PoC.
- **Legal Bias:** Jurisdiktion und qualifizierter Review bleiben offen.

### Final decision

**Release des Skill-Pakets.** Empirische Model-Evals bleiben erforderlich, bevor eine höhere Wirksamkeitsbehauptung als „strukturell und evidenzseitig vorbereitet“ abgegeben wird.
