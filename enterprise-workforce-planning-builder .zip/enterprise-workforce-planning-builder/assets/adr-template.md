# ADR: Architecture decision

- Status: proposed
- Date:
- Decision owners:
- Related requirements:

## Context and forces

State verified facts, assumptions, missing evidence, scale, risk, team ownership, and reversibility.

## Options considered

### Option A

- Benefits:
- Costs:
- Risks:
- Migration:
- Rollback:
- Evidence:

### Option B

- Benefits:
- Costs:
- Risks:
- Migration:
- Rollback:
- Evidence:

## Decision

State the smallest robust option and decisive trade-off.

## Consequences

- Security and privacy:
- Data and integration:
- Testing and operations:
- Cost and team capability:
- Worker and user impact:

## Validation and revisit trigger

- Validation commands or proof:
- Metrics:
- Conditions that reopen this decision:
