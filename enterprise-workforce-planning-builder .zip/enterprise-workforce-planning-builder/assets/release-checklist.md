# Production release checklist

## Product and domain

- [ ] Acceptance criteria and non-goals are confirmed.
- [ ] Domain invariants, decision rights, and correction paths are tested.
- [ ] Planning explanations and infeasibility handling are reviewable.

## Data and integrations

- [ ] Migrations, compatibility, reconciliation, backup, restore, and rollback are tested.
- [ ] Idempotency, duplicate, retry, late data, and dead-letter paths are tested.
- [ ] System-of-record ownership and data freshness are visible.

## Security, privacy, and worker governance

- [ ] Threat model and authorization tests pass.
- [ ] Data minimization, retention, logging, and provider boundaries are reviewed.
- [ ] Consequential worker actions require the correct human approval.
- [ ] Applicable legal, safety, and worker-representation review is recorded.

## Quality

- [ ] Unit, property, solver, integration, contract, E2E, accessibility, and mobile tests pass as applicable.
- [ ] Performance and resilience evidence matches representative scale.
- [ ] Known limitations and residual risk have accountable acceptance.

## Operations

- [ ] SLOs, telemetry, alerts, runbooks, ownership, incident, and support paths exist.
- [ ] Progressive rollout, kill switch, rollback, and post-release verification are ready.
- [ ] Mobile signing, store metadata, runtime compatibility, and update rollback are ready when applicable.
