# Agent-agnostic compatibility

The core workflow is written as portable instructions. It may be used by ChatGPT, Codex, Claude, Claude Code, Cursor, Windsurf, or another capable frontier agent, but semantic portability is not runtime parity.

## Portable components

- evidence and source discipline;
- product and domain modeling;
- architecture decision gates;
- planning, optimization, and AI boundaries;
- web/mobile delivery principles;
- security, testing, release, and improvement workflow;
- file-based templates, eval cases, and validators.

## Runtime-specific components

- `agents/openai.yaml` is OpenAI-specific metadata;
- skill discovery and implicit invocation differ;
- connector, browser, repository, MCP, shell, container, and code-execution tool availability differs;
- approval prompts and UI install behavior differ;
- context limits, file mounts, network access, model names, and policy enforcement differ.

## Required adaptation

Before execution in another agent runtime:

1. inventory tool availability and permissions;
2. map file, browser, repository, CI, cloud, and MCP operations to supported tools;
3. preserve approval and destructive-action gates;
4. preserve evidence, test, validation, and rollback requirements;
5. replace unsupported automation with explicit human handoff;
6. do not claim identical behavior merely because the same `SKILL.md` is readable.

## Explicit limitations

Claude or another model is not guaranteed to invoke this skill automatically. Tool availability is not guaranteed. A UI install suggestion or button is not controlled by the package. Production access, legal review, app-store publication, and deployment remain external capabilities and permissions.
