# Release gate policy

Packaging is permitted only when the release report is `PASS` and deterministic validators pass.

## Mandatory gates

1. **Craftsmanship**
   - smallest robust architecture selected;
   - at least two viable options considered for deep decisions;
   - strongest counterargument and one failure chain addressed;
   - unnecessary default technologies removed.

2. **Anti-confabulation**
   - user and vendor claims are classified;
   - current technical claims point to primary sources or are weakened;
   - unsupported numbers, guarantees, certifications, and legal conclusions are removed;
   - `blocked_claims` is empty.

3. **Anti-sycophancy**
   - user assumptions are challenged where evidence conflicts;
   - the package does not mirror overengineering, autonomy, or product claims merely because requested;
   - score remains below the blocking threshold.

4. **Bias**
   - tool, stack, automation, optimization, legal, cultural, and worker-impact bias reviewed;
   - residual bias is disclosed and bounded.

5. **Package quality**
   - required files exist;
   - frontmatter and directory name are valid;
   - references are reachable;
   - evals include positive, negative, and safety cases;
   - no empty files or unresolved production placeholders;
   - installability and agent-compatibility reports pass.

6. **Domain coverage**
   - product/domain model;
   - architecture decision guide;
   - planning optimization and AI boundaries;
   - web/mobile and offline delivery;
   - security, governance, testing, production, and improvement.

## Blocking conditions

Set `release_gate.status` to `BLOCKED` when:

- a required source or security boundary is missing;
- a hard rule relies on Confidence 1-3 evidence;
- direct consequential AI action is permitted without approval;
- the package claims production readiness or compliance without evidence;
- tests, evals, or validators fail;
- core functionality is missing or unintentionally changed;
- installability structure is invalid.

## Release report

`reports/release-gate-report.json` must contain:

- craftsmanship gate;
- anti-confabulation gate and blocked claims;
- anti-sycophancy score and threshold;
- bias gate;
- validation summary;
- release gate status and packaging permission;
- corrections applied and residual limitations.
