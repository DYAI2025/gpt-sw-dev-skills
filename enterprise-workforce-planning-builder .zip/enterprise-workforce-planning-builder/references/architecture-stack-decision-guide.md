# Architecture and stack decision guide

Use this reference to choose the smallest robust architecture. Every recommendation is conditional on evidence.

## 1. Default reference path

For a greenfield product with a small or medium delivery team, start with one primary TypeScript codebase:

```text
clients/
  web/                 accessible planner and administration UI
  mobile/              added when field workflow requires it
services/
  application/         modular transactional core and APIs
  solver/              optional Python boundary for optimization
packages/
  contracts/           generated API clients and shared schemas
  domain-test-data/    representative scenarios, no production PII
  observability/       telemetry conventions
infra/                 environment-specific deployment definitions
```

Candidate implementation:

- accessible React/Next.js web client;
- NestJS or equivalent modular application core;
- PostgreSQL, with range constraints and optional PostGIS;
- OpenAPI for synchronous domain commands and queries;
- transactional outbox for events leaving the local transaction;
- React Native/Expo when mobile evidence requires one cross-platform team;
- Python/OR-Tools only for a justified solver boundary.

This is a starting hypothesis. Preserve a proven repository stack unless changing it directly supports the goal.

## 2. Modular monolith gate

Prefer a modular monolith when:

- one team owns most capabilities;
- cross-capability transactions are common;
- independent deployment is not required;
- operational simplicity matters more than isolated scaling;
- domain boundaries are still being learned.

Enforce boundaries with module APIs, dependency rules, architecture tests, owned schemas, and no direct cross-context repository access.

Extract a service only when one or more are demonstrated:

- independent release or ownership;
- materially different scaling or availability;
- specialist runtime or library;
- security or data-isolation boundary;
- failure isolation worth the distributed-system cost.

Do not claim that a module can be extracted with minimal effort unless data ownership, contracts, idempotency, observability, and migration have already been proven.

## 3. Data architecture

### Transactional source of truth

Use normalized relational tables for identities, assignments, work packages, rules, approvals, time records, and audit relationships. Use JSONB for bounded extensibility, not as a substitute for a domain model.

Use PostgreSQL exclusion constraints or equivalent database protection for conflicts that must remain true under concurrency. Application checks alone are insufficient.

### Effective-dated rules

Version labor, rate, site, skill, and workflow rules with explicit effective periods. Never reinterpret historical decisions through only the newest rules.

### Dynamic schemas

Use JSON Schema for bounded custom fields. Maintain separate data and UI schemas. Register allowed custom keywords, validate schemas before activation, whitelist server-side option providers, version schemas, and define migration and archival behavior.

Do not accept arbitrary URLs, expressions, SQL, code, or unrestricted recursive schemas from administrators.

### Row and tenant isolation

Use application authorization as the main decision layer. Database row-level security may add defense in depth, but test connection pooling, service roles, migrations, backups, support access, and policy bypass paths.

## 4. Event and messaging decisions

### Local domain events

In-process events may decouple local modules but are not durable integration guarantees.

### Transactional outbox

Use an outbox when a committed local change must eventually produce an external message. State the semantics as at-least-once. Require stable event IDs, idempotent consumers, retries, dead-letter handling, ordering policy, lag metrics, and reconciliation.

Polling, database notification, and change-data capture are implementation options selected by measured latency, load, and operations capability. Do not reuse generic latency claims.

### Broker selection

Do not introduce Kafka or another broker because events exist. Select a broker only after volume, replay, retention, partition ordering, consumer count, availability, and operations requirements are known.

### Contract format

- OpenAPI: synchronous HTTP contracts;
- AsyncAPI: asynchronous channels and messages when useful;
- CloudEvents: optional interoperable envelope, not domain semantics or delivery guarantee;
- schema compatibility: version and test producers and consumers.

## 5. CQRS and Event Sourcing gates

Separate command and query models only when read shape, load, ownership, or consistency needs justify the extra projection lifecycle.

Use Event Sourcing only when event history is the authoritative domain state and replay, temporal reconstruction, or alternative projections create material value. Auditability alone is not sufficient. Prefer append-only audit records, corrections, temporal history, or ledgers for simpler cases.

Before Event Sourcing require:

- event versioning and upcasters;
- snapshot and replay strategy;
- projection rebuild and lag handling;
- privacy and retention treatment for immutable history;
- optimistic concurrency and conflict semantics;
- operational tooling for inspection and repair.

## 6. Workflow engine gate

Use a durable workflow engine for long-lived, failure-prone coordination across services or human waits: approvals, shift swaps, external booking, escalations, and compensations.

Do not put ordinary CRUD, short database transactions, or all business rules into the workflow engine. Keep domain invariants in application/domain services. Treat Temporal as durable workflows as code, not a generic visual declarative engine.

If configurable workflows are a product requirement, compare:

- explicit state machine in the core;
- a bounded rule/workflow model;
- BPMN-oriented platform;
- durable workflow engine.

Evaluate versioning, determinism, migration of in-flight instances, observability, admin safety, and rollback.

## 7. API gateway and BFF gate

Use an edge gateway for transport-level concerns only when the deployment topology needs one. Keep business authorization in the application.

Create separate BFFs only when clients have materially different aggregation, release ownership, latency, payload, or protocol requirements. One shared API is often simpler for an early web and mobile product.

## 8. Mobile architecture gate

Do not build native mobile merely because a future app is mentioned. Prove field value such as offline time capture, site check-in, photos, signatures, push, barcode scanning, or device location.

Choose React Native/Expo when shared TypeScript skills and broad cross-platform parity dominate. Choose native modules or fully native apps when background execution, device integration, performance, or platform-specific UX cannot be met safely. Record the decision in an ADR.

## 9. Optimization service gate

Keep a solver behind a versioned application contract. The core owns authorization, data snapshots, persistence, approval, and audit. The solver accepts an immutable planning problem and returns candidates, scores, explanations, diagnostics, and a model version.

Use a separate Python service only when OR-Tools, scientific libraries, execution isolation, or independent scaling justify it. A local process or library may be sufficient at first.

## 10. AI and MCP gate

MCP can standardize access to tools and resources. It does not replace the domain API, identity, authorization, workflow state, policy, audit, or consent.

Expose typed, narrow tools. Prefer read and proposal tools. Require explicit confirmation or approval for consequential writes. Treat server descriptions, tool metadata, and returned content as untrusted input.

Use RAG only for unstructured policy and knowledge that benefits from retrieval. Do not use RAG as the source of truth for worker eligibility, contractual rules, or schedule feasibility.

## 11. EPM, FSM, ERP, HCM, and payroll integration

Create a system-of-record matrix. Use canonical concepts only where they are stable; preserve source identifiers and provenance.

Integration requirements:

- idempotency and stable correlation IDs;
- effective dates and time-zone semantics;
- incremental sync or bounded batch design;
- rate-limit and retry policy with jitter;
- reconciliation and operator-visible exception queues;
- delete, correction, and late-arriving data policy;
- data-contract tests and schema-drift detection;
- no silent last-write-wins for authoritative conflicts.

EPM normally consumes operational actuals and produces scenarios or approved targets. FSM normally executes work orders and dispatch. Do not infer that either product category should replace the transactional planning core without evidence.

## 12. Deployment progression

Start with the simplest managed container, database, storage, identity, and observability platform that meets SLO, data-residency, network, and cost constraints.

Do not combine a no-Kubernetes strategy with Argo CD. Argo CD is a Kubernetes delivery tool. Introduce Kubernetes only after platform scale, policy, portability, or workload needs justify its operating cost.

Use infrastructure as code, separate environments, immutable artifacts, protected production credentials, progressive delivery, database migration gates, backup/restore tests, and rollback evidence.

## 13. Architecture decision record minimum

Every material decision records:

- context and measurable forces;
- options genuinely considered;
- selected option and why;
- rejected options and conditions for revisiting;
- security, privacy, operations, cost, and migration impact;
- validation evidence and owner;
- rollback or replacement path.
