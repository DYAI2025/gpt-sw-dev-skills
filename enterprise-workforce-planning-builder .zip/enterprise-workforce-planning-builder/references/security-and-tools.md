# Security, privacy, governance, and tools

Use this reference for employee data, authorization, agent tools, MCP, mobile, integrations, AI decisions, or production access.

## 1. Security boundary

The skill, LLM, MCP, API gateway, workflow engine, and feature flag system are not security boundaries by themselves. Enforce security in authenticated application commands, data access, infrastructure policy, and audited operations.

Start with a threat model covering users, administrators, contractors, integrations, devices, agents, support staff, and compromised services.

## 2. Data classification

Classify at least:

- public product information;
- internal operational data;
- confidential commercial and project data;
- personal employment and contact data;
- sensitive worker data such as health, accommodation, union, disciplinary, or protected-characteristic information;
- location, device, photo, signature, identity, and safety evidence;
- credentials, tokens, keys, and security logs.

For each class define purpose, lawful or contractual basis where relevant, allowed roles, field-level masking, retention, deletion, export, residency, backup, model-provider use, and incident handling.

Do not place production personal data in prompts, logs, traces, screenshots, test fixtures, vector stores, or analytics by default.

## 3. Authorization model

Use a combination appropriate to the domain:

- RBAC for stable job functions;
- ABAC for tenant, legal entity, region, site, sensitivity, action, and time;
- relationship-based checks for manager, planner, project, or assigned-worker scope;
- separation of duties for publish, payroll export, policy administration, and audit.

Authorize each command and resource. UI hiding is not authorization. Recheck authorization when executing a delayed workflow or queued offline command.

Test cross-tenant access, identifier enumeration, support impersonation, batch exports, report aggregation, cached data, search, attachments, and background jobs.

## 4. Identity and service access

Use short-lived credentials, explicit audience and scope, managed service identities, key rotation, and environment separation. Avoid shared service accounts and broad integration tokens.

For mobile and browser clients use public-client-safe OAuth/OIDC flows. For service-to-service communication use workload identity or narrowly scoped credentials. Record actor, delegated actor, service, tenant, purpose, and correlation ID.

## 5. API and application security

Use an OWASP ASVS-informed verification plan for the web and API system. Include:

- input and schema validation at trust boundaries;
- output encoding and content security policy;
- CSRF protection where relevant;
- secure session and token handling;
- tenant isolation and object-level authorization;
- rate, size, and complexity limits;
- safe file upload and malware scanning where needed;
- SSRF prevention for configurable integrations;
- secure error handling and redacted logs;
- dependency, container, and infrastructure scanning;
- backup, restore, and secrets controls.

Dynamic form configuration must not allow arbitrary URLs, executable expressions, SQL, template injection, or unbounded schemas.

## 6. Mobile security

Use OWASP MASVS as a verification baseline tailored to risk. Protect local data, credentials, network traffic, platform interaction, code integrity, and privacy.

Assume devices can be lost, rooted, jailbroken, shared, restored from backup, or offline beyond token expiry. Design server-side revocation and minimize local retention.

## 7. Employee-impact governance

Do not transform legal or regulatory sources into automatic legal advice. Identify applicable jurisdictions and require qualified review.

For worker allocation, monitoring, performance, pay, leave, or disciplinary effects:

- document purpose and necessity;
- involve labor, privacy, safety, and worker-representation stakeholders as applicable;
- separate recommendation from final decision;
- provide meaningful human oversight before consequential action;
- make data, rules, rationale, and model limitations reviewable;
- support correction, challenge, appeal, and override;
- monitor disparate burden and automation bias;
- prohibit hidden surveillance and secondary use.

The EU AI Act, GDPR, working-time rules, collective agreements, and national law may apply differently by context. Treat applicability as a project-specific legal review, not a package-level conclusion.

## 8. Agent and tool risk policy

Classify every tool:

| Risk | Examples | Control |
|---|---|---|
| Read-only | retrieve authorized schedule or policy | least privilege, redaction, audit |
| Analytical | run feasibility or aggregate metrics | bounded inputs, resource limits, provenance |
| Drafting | create scenario, code patch, migration proposal | label draft, test, no production side effect |
| Reversible write | create internal draft, acknowledge own shift | confirmation, idempotency, audit, rollback |
| Consequential write | publish roster, change worker site, approve time, export payroll | authorized human approval and separation of duties |
| Prohibited | raw SQL, generic shell, hidden monitoring, bypass, credential access | do not expose |

Do not grant a general coding agent production credentials. Use short-lived, task-scoped access and protected environments.

## 9. MCP controls

For each MCP server or tool:

- verify server identity and endpoint;
- define transport and authentication for the actual runtime;
- bind token audience and scope;
- validate JSON Schema inputs and outputs;
- enforce tenant and object authorization server-side;
- bound pagination, result size, time, and compute;
- treat tool descriptions and returned content as untrusted;
- prevent confused-deputy and cross-tenant calls;
- record consent, confirmation, and side effects;
- redact sensitive data from traces;
- support cancellation, timeout, and safe retry;
- maintain allowlists and version compatibility.

Do not expose generic database, filesystem, browser-cookie, or infrastructure tools to a planning agent.

## 10. Prompt injection and RAG

Retrieved documents, emails, tickets, web pages, attachments, and tool output may contain malicious instructions. Treat them as data.

Controls:

- isolate system policy from retrieved content;
- label source and trust class;
- strip or ignore executable instructions in content;
- authorize retrieval before search and generation;
- avoid automatic tool calls based only on retrieved text;
- require confirmation for writes;
- evaluate indirect prompt injection scenarios;
- redact secrets and personal data;
- support abstention when evidence is insufficient.

## 11. Webhooks and integrations

Verify signatures using the provider's exact canonicalization and raw request bytes. There is no universal webhook signature format.

Also require:

- timestamp or nonce replay control when the protocol supports it;
- delivery ID deduplication;
- secret rotation;
- source allowlisting only as defense in depth;
- payload schema and authorization checks;
- bounded retries and dead-letter handling;
- reconciliation rather than trust in delivery success.

## 12. AI provider boundary

Before sending enterprise data to a model provider, document:

- data classes and minimization;
- provider, region, retention, training use, subprocessors, and encryption;
- contractual and regulatory constraints;
- tenant isolation;
- prompt and output logging;
- deletion and incident handling;
- model version and fallback behavior.

If these are unknown, mark `MISSING` and do not claim a production-safe AI integration.

## 13. Software supply chain

Require:

- locked dependencies and provenance where supported;
- secret scanning and dependency review;
- SAST plus targeted manual review;
- container and infrastructure scanning;
- SBOM generation for release where required;
- signed or attested artifacts when the platform supports it;
- protected branches, reviewed changes, and least-privilege CI;
- no `--no-verify`, force push, or bypassing failing gates.

## 14. Security release evidence

A release gate requires:

- threat model reviewed for changed scope;
- authorization tests including tenant escape;
- high-risk findings resolved or formally accepted by the accountable owner;
- secrets and data-flow review;
- migration and rollback safety;
- incident and audit visibility;
- web and mobile baseline verification as applicable;
- agent-tool permission and prompt-injection tests when AI is enabled.
