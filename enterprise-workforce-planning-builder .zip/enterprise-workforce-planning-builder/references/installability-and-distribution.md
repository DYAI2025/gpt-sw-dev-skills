# Installability and distribution

The primary installable artifact is named exactly `skill.zip`.

## Required ZIP shape

```text
enterprise-workforce-planning-builder/
  SKILL.md
  agents/openai.yaml
  references/
  assets/
  scripts/
  evals/
  reports/
```

The ZIP must contain exactly one top-level skill directory. The directory name must match the `name` in `SKILL.md`.

## Controlled guarantees

The package can verify:

- `SKILL.md` and frontmatter exist;
- directory and skill names match;
- `agents/openai.yaml` exists;
- required references, evals, scripts, and reports exist;
- validators pass;
- `skill.zip` has the expected root and no empty files.

The package cannot guarantee:

- a ChatGPT or other client displays an install button;
- every runtime supports the same tools, files, connectors, MCP transports, code execution, or permissions;
- the user has installation rights;
- platform policy accepts the package indefinitely.

## Packaging

Run:

```bash
python scripts/package_skill.py <skill-dir> <output-dir>
```

The script runs package validators before writing `<output-dir>/skill.zip`.

## Distribution hygiene

Do not include secrets, production data, local caches, environment files, private keys, binary dependencies, model credentials, or proprietary source documents without permission. Treat the ZIP as a portable instruction and validation package, not an execution sandbox or compliance certificate.
