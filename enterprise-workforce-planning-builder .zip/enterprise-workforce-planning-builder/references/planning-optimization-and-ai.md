# Planning optimization and AI

Use this reference for workforce scheduling, construction allocation, dispatch, routing, scenario optimization, RAG, MCP, or AI-assisted decisions.

## 1. Separate the planner from the solver

The planner owns business intent, data quality, scenario definition, approval, explanation, and change management. The solver owns deterministic feasibility and objective calculation. An LLM may translate requests, propose assumptions, compare scenarios, explain results, and call tools; it must not be the feasibility engine.

## 2. Canonical planning-problem contract

A versioned problem snapshot should include:

- horizon and time-zone policy;
- workers, crews, skills, certification windows, contracts, and calendars;
- work packages, tasks, quantities, precedence, duration distributions, sites, and time windows;
- vehicles, equipment, depots, travel-time matrix, and capacities;
- hard constraints with source and effective date;
- soft objectives with priority, normalization, and weight;
- locked assignments, change budget, and baseline schedule;
- uncertainty scenarios and data freshness;
- model version, input hash, and requesting actor.

The result should include:

- status: feasible, infeasible, optimal, bounded, timed out, or error;
- candidate assignments and unassigned demand;
- objective components, bound, gap, and solve duration when available;
- violated soft preferences and binding constraints;
- infeasibility diagnostics or conflict set when possible;
- model, data, and policy versions;
- deterministic seed and reproducibility metadata;
- explanation suitable for planner review.

## 3. Constraint hierarchy

### Hard constraints

Typical hard constraints:

- no overlapping committed assignment for person or exclusive asset;
- required skill level and unexpired certification;
- site induction, safety, and access eligibility;
- contract, availability, leave, working-time, rest, and break rules;
- task precedence and time window;
- crew composition and minimum supervision;
- vehicle, equipment, capacity, and compatibility;
- geographic reachability and travel time;
- locked or acknowledged assignments;
- tenant and authorization boundary.

A hard constraint must name its source, owner, effective period, exception authority, and test cases.

### Soft objectives

Typical soft objectives:

- service level and due-date risk;
- continuity of worker, crew, or project;
- preference satisfaction and schedule stability;
- fair distribution of undesirable shifts, travel, overtime, or idle time;
- skill development and mentoring;
- subcontractor, overtime, travel, and setup cost;
- utilization without unsafe saturation;
- carbon or distance;
- robustness to likely disruptions.

Use lexicographic priorities for non-compensable objectives. Normalize weighted terms and run sensitivity tests. Do not let a hidden cost weight override safety, law, or worker protection.

## 4. Solver selection

### Constraint programming or CP-SAT

Use for discrete assignment, shift coverage, calendars, skills, precedence, crew, and many logical constraints. OR-Tools CP-SAT is a strong reference implementation, but model quality and local rules determine correctness.

### Vehicle routing with time windows

Use for field-service or multi-site routing with depots, travel times, service durations, capacities, breaks, skills, pickups, deliveries, and appointment windows. Do not model routing as straight-line distance when realistic travel times matter.

### Mixed-integer programming

Use when linear cost, capacity, portfolio, or strategic location decisions dominate and constraints can be represented appropriately.

### Heuristics and local search

Use when exact optimization is too slow or continuous replanning matters. Benchmark solution quality, stability, and worst-case behavior against an accepted baseline.

### Simulation and forecasting

Use forecasting for demand distributions, not fabricated certainty. Use discrete-event or Monte Carlo simulation to assess queues, utilization, disruption, and policy under uncertainty. Separate prediction error from optimization quality.

## 5. Multi-horizon and rolling planning

Do not use one model for all horizons by default.

- strategic model: aggregate capacity, hiring, location, contractor and cost scenarios;
- tactical model: crews, projects, skills, site phases, weekly capacity;
- operational model: named workers, tasks, shifts, appointments, routes;
- real-time repair: smallest feasible change around locked commitments.

Use rolling horizons. Freeze or penalize changes near execution. Carry forward commitments and explain changes to affected workers.

## 6. Construction production control

Combine optimization with human commitment planning:

1. master and phase plan define sequence and milestones;
2. lookahead process identifies constraints that prevent readiness;
3. constraint log assigns owner and due date;
4. only sound, ready work enters the weekly plan;
5. crews make bounded commitments;
6. daily coordination records execution state;
7. reasons for variance drive learning and model correction.

Track percent plan complete only with a clear denominator and completion rule. Do not optimize a plan that includes work not made ready.

## 7. Fairness and worker impact

Fairness is not one scalar. Define affected groups, relevant burden, comparison period, protected or sensitive data, and legitimate operational need.

Evaluate:

- distribution of nights, weekends, overtime, long travel, cancellations, and short notice;
- preference satisfaction by group and contract type;
- exposure to unsafe or undesirable work;
- schedule predictability and change frequency;
- opportunity for development and premium work;
- error and override rates.

Use legal, labor, safety, and worker-representation review where applicable. Never infer protected characteristics or health status to improve optimization without an explicit lawful and ethical basis.

## 8. Explainability and planner control

Each assignment or rejection should answer:

- which hard constraints passed or failed;
- which objectives influenced selection;
- what alternatives were considered;
- what changed from the baseline;
- what data and rule versions were used;
- whether the result is optimal, bounded, heuristic, or timed out;
- what authorized override path exists.

Expose scenario comparison rather than a single opaque answer. Log human overrides and use them as evidence for rule or model review, not as automatic training labels.

## 9. Testing the planning engine

Use:

- unit tests for each constraint and objective term;
- property-based tests for generated calendars, intervals, and assignments;
- metamorphic tests, for example adding capacity must not reduce feasibility under unchanged rules;
- golden scenarios with reviewed expected outcomes;
- infeasible scenarios with expected diagnostics;
- concurrency and stale-snapshot tests;
- boundary tests for daylight saving, certification expiry, and effective rules;
- performance tests by problem size and density;
- differential tests against a trusted simple implementation for small instances;
- sensitivity tests for objective weights and forecasts;
- fairness and stability scorecards.

A solver returning a result is not evidence that the business model is correct.

## 10. Agent action-risk ladder

| Level | Capability | Default |
|---|---|---|
| READ | inspect authorized data and evidence | permitted with least privilege |
| ANALYZE | compute metrics or feasibility without persistence | permitted and logged |
| DRAFT | create scenario or change proposal | permitted and clearly labeled |
| CONFIRM | reversible low-impact command after user confirmation | bounded and audited |
| APPROVE | consequential worker, pay, safety, or production action | authorized human approval required |
| FORBIDDEN | bypass controls, hidden monitoring, discriminatory or destructive action | block |

The same domain authorization and invariant checks apply regardless of whether a human, UI, integration, or agent invokes the command.

## 11. MCP and tool design

Use MCP or other tool calling as an adapter. Expose narrow tools such as:

- `get_planning_snapshot`;
- `check_assignment_feasibility`;
- `create_staffing_scenario`;
- `compare_scenarios`;
- `submit_plan_for_approval`;
- `get_integration_reconciliation_status`.

Do not expose generic SQL, unrestricted file, shell, payroll write, or raw administrative endpoints.

For each tool define:

- purpose and non-purpose;
- input and output schema;
- authorization and tenant scope;
- data classification;
- side effect and risk level;
- idempotency and confirmation policy;
- timeout, retry, and cancellation behavior;
- audit fields and redaction;
- expected errors and recovery.

Current MCP standard transports are stdio and Streamable HTTP for the cited specification revision. Check the target runtime before hard-coding protocol details.

## 12. RAG boundary

RAG is suitable for policies, manuals, contract commentary, work instructions, lessons learned, and historical narrative. It is not authoritative for schedule feasibility or current worker eligibility.

Use:

- access control before retrieval;
- source provenance and effective date;
- hybrid retrieval only when evals show benefit;
- grounded answers with citations and abstention;
- document deletion and retention propagation;
- retrieval, reranking, and answer-quality evals.

PostgreSQL full-text ranking with `ts_rank_cd` is not BM25. RRF is a fusion method, not a guarantee of precision or hallucination prevention. Tune retrieval with an actual evaluation set.

## 13. Bounded repair loop

For generated code, models, or plans:

1. reproduce and classify the failure;
2. make one hypothesis-driven change;
3. rerun the smallest relevant validation;
4. record evidence;
5. after at most three materially different failed attempts, stop and escalate with hypotheses, logs, and safe rollback.

Do not create an unbounded self-healing loop or silently weaken tests to obtain green status.
