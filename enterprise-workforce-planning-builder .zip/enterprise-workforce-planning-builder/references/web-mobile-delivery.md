# Web and mobile delivery

Use this reference when designing the planner web application, employee or field mobile app, offline workflows, device integrations, or store releases.

## 1. Product surfaces

Separate surfaces by user job rather than by technology:

- planner workspace: dense schedule, capacity, conflicts, scenarios, approval, and publication;
- site or dispatch board: near-term work, crew, readiness, disruption, and handoff;
- worker mobile: personal schedule, acknowledgement, time, absence, work evidence, and permitted change requests;
- administration: rules, skills, sites, integrations, roles, and audit;
- executive analytics: aggregate capacity, cost, risk, and scenario comparison without exposing unnecessary personal detail.

Do not make a complex desktop planning grid the mobile interaction model.

## 2. Web application architecture

Prefer server-rendered shells and client-side interaction only where it creates value. Keep domain commands in the application API, not in UI components.

For planner UIs:

- use virtualized grids and timelines for large schedules;
- preserve keyboard navigation, focus, screen-reader labels, and non-color conflict indicators;
- make time zone, date range, filters, scenario, and publication status visible;
- distinguish proposal, approved plan, published commitment, and actual;
- show conflict cause and permitted resolution, not a generic red cell;
- provide undo only when the domain operation is genuinely reversible;
- protect concurrent edits with version checks and explicit merge or refresh behavior;
- avoid optimistic UI for high-impact assignments unless failure is clearly reconciled.

Target WCAG 2.2 at the agreed conformance level. Include automated and manual accessibility checks.

## 3. Mobile value gate

Build mobile only when field evidence requires capabilities such as:

- offline schedule and work-order access;
- time capture, break, travel, or standby recording;
- site check-in, permitted geofence validation, or QR/barcode scan;
- photo, signature, form, or proof-of-work capture;
- push notification and acknowledgement;
- safety brief, permit, or induction evidence;
- disruption and availability updates.

A responsive web application may be sufficient for early validation.

## 4. Offline-first model

An offline-capable app reads from a local source of truth. Network calls synchronize that local state; they are not the immediate UI dependency.

Define:

- which entities and date ranges are cached;
- maximum safe offline duration;
- local encryption and device-access policy;
- command queue and idempotency keys;
- dependency ordering between queued commands;
- retry, backoff, cancellation, and dead-letter behavior;
- conflict detection and resolution ownership;
- server rejection behavior after stale rules or revoked access;
- attachment upload, compression, resumability, and retention;
- logout, device loss, remote revocation, and local wipe behavior.

Do not represent cached server state as an offline write model without a durable command queue.

## 5. Conflict semantics

Do not use generic last-write-wins for staffing, time, certification, or safety data.

Classify conflicts:

- commutative: independent notes can merge;
- authoritative: server or system-of-record value wins and local action is rejected;
- user-resolvable: present both versions and consequences;
- planner-resolvable: create an exception task;
- forbidden: access revoked, policy changed, or assignment no longer feasible.

Return machine-readable rejection codes and human-readable recovery instructions.

## 6. Mobile stack decision

React Native with Expo is a practical default when one TypeScript team, rapid delivery, and common cross-platform behavior dominate. Confirm compatibility for background location, Bluetooth, rugged-device SDKs, large file capture, offline database, native authentication, and enterprise distribution.

Choose platform-specific native implementation when critical requirements cannot be met reliably through the shared stack. Record evidence, cost, team ownership, test strategy, and fallback.

## 7. Permissions and sensitive sensors

Request device permissions only at the moment of user value. Explain purpose, duration, retention, and alternatives.

Location controls:

- collect the minimum precision and duration;
- avoid continuous background tracking unless necessity and governance are proven;
- separate attendance evidence from performance monitoring;
- make off-duty collection impossible by design;
- expose correction and dispute paths;
- document battery, offline, spoofing, and accuracy limits.

Camera, files, contacts, notifications, biometrics, and Bluetooth require equivalent purpose limitation and graceful denial behavior.

## 8. Authentication and session

Use the enterprise identity provider where possible. Apply OAuth/OIDC patterns appropriate to public mobile clients, platform-secure storage, short-lived tokens, refresh rotation, device revocation, and phishing-resistant methods where available.

Never embed client secrets in a mobile binary. Test clock skew, revoked users, tenant change, device restore, offline expiry, and reauthentication.

## 9. Push and deep links

Treat push as an unreliable hint, not a source of truth. Opening a notification must refetch or validate authorized current state.

Protect deep links and universal links against tenant confusion, identifier guessing, replay, and unauthorized navigation. Do not put sensitive personal data in notification payloads or lock-screen text by default.

## 10. Time capture UX

Make state explicit: not started, running, paused, completed, submitted, approved, exported, corrected.

Prevent accidental duplication with a visible active timer, idempotent commands, and server constraints. Support correction reasons and approval. Display local time zone and authoritative recorded interval. Do not infer paid time solely from geolocation or device activity.

## 11. Testing

Web:

- component and interaction tests;
- API contract and authorization tests;
- browser E2E across supported engines;
- keyboard, screen-reader, zoom, contrast, and reduced-motion review;
- large-grid, slow-network, and concurrent-edit tests.

Mobile:

- unit and state-machine tests;
- offline command-queue and sync tests;
- native integration tests on real supported OS versions;
- permission denial and revocation tests;
- network transition, app termination, device time change, storage pressure, and upgrade tests;
- OWASP MASVS-informed security verification;
- release-candidate smoke tests on representative devices.

## 12. Release and updates

Use signed, immutable builds and environment-specific configuration. Separate native binary changes from runtime-delivered updates. A runtime update must remain compatible with the installed native runtime and use staged rollout plus rollback.

Before store or enterprise distribution:

- verify signing and credential custody;
- complete privacy and permission declarations;
- test data migration from supported previous versions;
- test offline queue survival or safe invalidation across upgrade;
- publish support, incident, and rollback procedures;
- verify accessibility and localized date/time behavior;
- monitor crash-free sessions, sync failures, API errors, battery, and update adoption.

Do not claim an iOS or Android app is production ready because it builds in a simulator.
