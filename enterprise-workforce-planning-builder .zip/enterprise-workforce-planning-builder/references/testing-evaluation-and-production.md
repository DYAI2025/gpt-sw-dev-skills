# Testing, evaluation, production readiness, and improvement

Use this reference for implementation plans, coding, audits, release decisions, incidents, or continuous improvement.

## 1. Evidence hierarchy

Rank claims about the product:

1. source-inspected code or schema;
2. deterministic test result;
3. runtime observation or trace;
4. deployment and production telemetry;
5. documented design intent;
6. inference or assumption.

Do not report a feature as complete because a file or UI label exists.

## 2. TDD and vertical slices

For behavior changes:

1. state the invariant or user-observable outcome;
2. reproduce the failure or write a failing test;
3. implement the smallest coherent change;
4. run focused tests;
5. run affected contracts, integrations, and E2E flows;
6. inspect diff, migration, security, telemetry, and rollback;
7. record exact commands and results.

Do not weaken tests, snapshots, types, lint, or security gates to obtain green status.

## 3. Test portfolio

### Domain and unit tests

Test commands, state transitions, value objects, authorization decisions, temporal rules, correction semantics, and objective calculations without framework coupling.

### Property-based tests

Generate intervals, calendars, rules, qualifications, and disruptions. Assert invariants such as no overlap, no impossible travel, no assignment after certification expiry, and idempotent repetition.

### Solver tests

Use golden, infeasible, boundary, metamorphic, differential, performance, sensitivity, fairness, and stability tests. Record solver version, seed, limits, objective, bound, and gap.

### Database tests

Test migrations forward and backward where supported, constraints under concurrency, isolation behavior, row security, indexes, query plans, retention, and backup restore.

### Contract tests

Validate OpenAPI and event schemas. Test provider and consumer compatibility, pagination, errors, idempotency, retries, rate limits, and late or duplicate messages.

### Integration tests

Run real database, queue, object store, identity test double or sandbox, maps sandbox, and solver boundary as appropriate. Avoid mocks that remove the failure mode under test.

### End-to-end tests

Cover critical user journeys:

- planner creates, validates, approves, and publishes a plan;
- worker receives, acknowledges, works offline, syncs, and corrects time;
- site disruption produces a bounded replanning proposal;
- integration duplicate, delay, failure, and reconciliation;
- unauthorized and cross-tenant attempts;
- migration and rollback smoke path.

Use Playwright or an equivalent real-browser tool. Prefer user-visible locators and isolated test data.

### Accessibility tests

Combine automated checks with keyboard, focus, screen-reader, zoom, responsive, contrast, error, and non-color review. Test dense planning views, not only static pages.

### Mobile tests

Test real devices, OS support range, permission denial, background/foreground, offline queue, network transitions, upgrade, secure storage, push, deep links, and device loss.

### Performance and resilience

Test representative scale and data density. Measure API latency, solver latency, query plans, grid rendering, sync throughput, queue lag, and recovery. Run load, soak, spike, failover, dependency timeout, retry storm, and restore exercises where risk warrants.

## 4. AI and agent evaluation

Separate:

- trigger evaluation: should the skill or agent be invoked;
- task success: did it satisfy the user goal;
- factual grounding: are claims supported;
- tool selection and argument validity;
- authorization and side-effect compliance;
- planning feasibility and deterministic validation;
- explanation quality and calibrated uncertainty;
- prompt-injection resistance;
- human approval and refusal behavior;
- latency, cost, and fallback behavior.

Use fixed scenario corpora and versioned evals. Compare against a baseline. Do not use model self-rating as the only quality signal.

## 5. Observability

Instrument traces, metrics, and logs with stable correlation identifiers across UI, API, solver, workflow, queue, and integrations.

Minimum signals:

- command success, rejection reason, and latency;
- authorization denial by class without exposing sensitive values;
- planning problem size, solve status, duration, bound, gap, and infeasibility;
- schedule change volume and human override;
- outbox age, duplicate, retry, dead letter, and reconciliation gap;
- offline queue age, rejection, conflict, and sync failure;
- API latency, error, saturation, and dependency health;
- database slow query, lock, pool, replication, backup, and restore status;
- mobile crash, update, and supported-version health;
- agent tool calls, approval, denial, hallucination or grounding eval, with redaction.

Do not put raw personal, health, location, token, prompt, or document content into telemetry without an explicit need and policy.

## 6. SLO and error budget

Define user-centered SLOs per critical journey, not one generic uptime value. Examples:

- publish an approved schedule;
- retrieve today's authorized assignment;
- accept a time command online or durably queue it offline;
- complete an integration export within a bounded time;
- return a feasible plan or clear failure before a decision deadline.

Set target, measurement window, exclusions, dependency policy, and response when the error budget is exhausted. Do not invent thresholds without product and operations input.

## 7. Migration safety

Every schema or data migration states:

- compatibility with old and new application versions;
- expand, backfill, verify, switch, and contract sequence;
- lock and runtime impact;
- resumability and idempotency;
- data validation and reconciliation;
- backup and restore evidence;
- rollback or forward-fix path;
- treatment of offline clients and queued commands.

Use shadow reads or dual writes only with an explicit reconciliation and removal plan.

## 8. CI/CD gates

A protected pipeline should include relevant subsets of:

- format, lint, type, unit, property, integration, contract, E2E, and accessibility tests;
- schema and migration validation;
- dependency, secret, SAST, container, IaC, and license checks;
- build and artifact provenance;
- preview or ephemeral environment smoke tests;
- release manifest and configuration validation;
- progressive deployment and automated rollback signals.

No direct production deployment from an unreviewed conversational agent.

## 9. Production-readiness gate

A feature is production ready only when all applicable evidence is present:

- user and business acceptance criteria passed;
- domain invariants and authorization tests passed;
- data and migration plan validated;
- integration failure and reconciliation handled;
- accessibility target met;
- performance and capacity evidence exists;
- security and privacy review completed;
- observability and alerts exist;
- support, runbook, ownership, and escalation defined;
- backup/restore and rollback tested;
- feature flag or staged rollout configured when risk warrants;
- mobile store, signing, privacy, and update controls completed when applicable;
- known limitations and residual risks accepted by accountable owners.

Generated code, a passing local build, or a green unit suite alone is insufficient.

## 10. Incident and rollback

Prepare:

- detection and severity rules;
- safe disable or kill switch;
- read-only or degraded mode;
- rollback for application, configuration, schema, and mobile update;
- reconciliation for duplicate or missed integrations;
- communication for affected workers and planners;
- evidence preservation and privacy-safe investigation;
- post-incident learning linked to tests and controls.

Do not roll back a destructive database migration without proven compatibility.

## 11. Continuous improvement loop

Use evidence, not autonomous feature churn:

1. observe product outcome, reliability, support, override, and user-friction signals;
2. classify signal quality and affected users;
3. identify the smallest plausible product or engineering hypothesis;
4. challenge it with an alternative and possible harm;
5. run a bounded experiment or vertical slice;
6. measure outcome and side effects;
7. retain, revise, or remove;
8. update documentation, tests, rules, and source map.

Telemetry and feedback authorize investigation, not automatic code or policy changes.

## 12. Bounded coding-agent loop

The coding agent may create branches, patches, tests, and migration proposals when the runtime permits and user permission is clear. It must:

- inspect before editing;
- maintain a public task and evidence log;
- work test-first;
- run in an isolated environment;
- cap repair attempts at three materially different hypotheses;
- stop on ambiguous destructive behavior, secrets, production access, or policy conflicts;
- request human review before merge, migration, or deployment;
- never bypass a failing gate.
