# Domain and product model

Use this reference before architecture or implementation. Model the planning problem first; frameworks come later.

## 1. Product boundary

The product coordinates people, skills, time, places, work, vehicles, equipment, cost, and commitments. It is not automatically the system of record for payroll, identity, accounting, HCM, ERP, EPM, FSM, CRM, maps, weather, or safety certification. Assign ownership explicitly.

Classify every capability:

| Class | Meaning | Typical examples |
|---|---|---|
| System of record | Authoritative lifecycle and corrections live elsewhere | payroll, identity, legal entity, accounting |
| Operational planning core | Differentiating decisions belong here | feasible staffing, crew planning, dispatch, utilization |
| Commodity service | Buy unless it creates strategic advantage | maps, email, push, identity proofing |
| Analytical projection | Derived, rebuildable view | utilization cube, cost forecast, SLA dashboard |
| Experimental capability | Validate before commitment | LLM planner, predictive absence signal, autonomous rescheduling |

## 2. Planning horizons

Do not combine all horizons in one mutable schedule.

| Horizon | Typical decisions | Granularity | Stability |
|---|---|---|---|
| Strategic | hiring, contractors, locations, fleet, skills investment | quarter to years | scenarios, not commitments |
| Tactical | capacity by region, project, site, trade, crew | weeks to months | approved plan baseline |
| Operational | shifts, work packages, appointments, routes | days to weeks | controlled commitment |
| Real-time | disruption, absence, delay, emergency reassignment | minutes to hours | minimal safe change |

Keep scenarios, proposals, approved plans, published schedules, actuals, and corrections distinct.

## 3. Core actors and decision rights

At minimum consider:

- worker or technician;
- contractor and subcontractor coordinator;
- dispatcher or planner;
- site manager and foreperson;
- project or work-package owner;
- HR, payroll, finance, safety, and worker-representation reviewers;
- system administrator and integration operator;
- auditor or data-protection role;
- automated recommender or optimization service.

For each command record who may propose, approve, publish, correct, cancel, export, and override it. An administrator role is not a substitute for a decision-right model.

## 4. Bounded contexts

Use these as candidates, not mandatory one-to-one code modules.

### Identity and organization

- tenant, legal entity, business unit, region, cost center;
- user identity, service principal, role, relationship, delegation;
- effective-dated organization membership.

### Workforce and qualifications

- worker, employment or contract relation, home base;
- skill, proficiency, certification, expiry, evidence;
- availability, absence, working-time calendar, restrictions;
- preferences and accommodations with strict access controls.

### Sites, geography, and assets

- site, geofence, access rules, working windows;
- vehicle, equipment, capacity, maintenance, compatibility;
- travel matrix, territory, route, depot, parking or access constraints.

### Work demand

- project, service order, work package, task, activity;
- quantity, duration estimate, predecessor, due window, SLA;
- required skills, crew composition, equipment, materials, location.

### Planning and commitments

- planning problem, constraint set, objective profile;
- scenario, candidate assignment, explanation, infeasibility reason;
- approved plan, published roster, dispatch instruction;
- acknowledgement, change request, override, cancellation.

### Time and actuals

- time entry, interval, break, travel, standby, allowance;
- submit, approve, lock, correction, export, reconciliation;
- immutable audit evidence without requiring full Event Sourcing.

### Construction production control

- phase plan, lookahead window, constraint log;
- ready work, weekly work plan, daily commitment;
- reason for variance, percent plan complete, learning action;
- handoff condition and production-control metric.

### Integration and automation

- inbound snapshot or change feed;
- outbound domain event, webhook delivery, batch export;
- idempotency record, reconciliation finding, dead-letter item;
- agent proposal, tool request, approval, execution result.

## 5. Core concepts

### Availability is not assignability

A worker is assignable only when all relevant constraints pass: contract, working time, absence, travel, site access, skills, certification, equipment, conflict, rest, decision right, and data freshness. Availability alone is insufficient.

### Assignment lifecycle

Use explicit states such as:

`proposed -> validated -> approved -> published -> acknowledged -> started -> completed`

Allow controlled paths to `rejected`, `cancelled`, `superseded`, `disputed`, and `corrected`. Do not silently edit a published commitment.

### Temporal semantics

Store an instant in UTC plus the business time-zone identifier and local-date meaning where needed. Distinguish:

- instant: one point on the timeline;
- local civil time: human schedule in an IANA zone;
- interval: half-open range such as `[start, end)`;
- effective time: when a rule applies in the business;
- system time: when the system learned or recorded it.

Test daylight-saving gaps, repeated local times, cross-midnight shifts, leap days, travel across zones, and rules that change on an effective date.

### Skills and certification

Represent skill requirements separately from certification validity. A skill may have level, evidence, assessor, issue date, expiry, scope, and equivalence rule. Never infer a legally or safety-relevant qualification from job title alone.

### Capacity and utilization

Define denominators. Useful measures include:

- nominal capacity;
- contracted capacity;
- feasible capacity after absence and restrictions;
- scheduled productive time;
- travel, setup, waiting, rework, standby, and leave;
- delivered quantity or completed work packages.

A single utilization percentage without denominator and horizon is misleading.

## 6. Hard invariants

Adapt and prove these per project:

1. No person, exclusive asset, or exclusive space has overlapping committed intervals.
2. Every assignment satisfies required skills, valid certifications, site access, and crew composition.
3. Working-time, break, rest, availability, and contractual rules pass for the effective jurisdiction and date.
4. Published work changes only through an authorized transition with audit and notification.
5. Repeating the same domain command with the same idempotency key does not duplicate effects.
6. Every external state transition can be reconciled to its source command and delivery record.
7. A planner cannot read or change workers outside the authorized tenant, organization, region, or relationship scope.
8. A schedule proposal cannot be described as feasible until the deterministic constraint checker accepts it.
9. A time correction preserves the original, corrected value, reason, actor, approval, and export state.
10. AI output never bypasses the same authorization and invariant checks used by human callers.

## 7. Soft objectives

Soft objectives may include SLA, due-date adherence, continuity, skill development, worker preferences, fairness, travel, overtime, subcontractor cost, carbon, setup changes, and robustness to disruption.

Do not collapse them into hidden weights. Publish the objective hierarchy, normalization, weights, tie breakers, and tolerated trade-offs. Test whether small weight changes create unreasonable schedules.

## 8. Construction planning model

Combine, but do not conflate:

- critical-path or location-based master planning for long-range sequence;
- phase planning for trade handoffs;
- lookahead planning to make work ready;
- weekly work planning for reliable commitments;
- daily coordination and reason-for-variance capture;
- constraint optimization for resources and time windows;
- BIM or IFC references for shared object identity when valuable.

A task is `ready` only when prerequisite information, design, materials, labor, equipment, access, safety, permits, and predecessor handoff conditions are satisfied.

## 9. Build-versus-buy boundary

Evaluate EPM platforms for strategic scenario, finance, and corporate planning. Evaluate FSM for work-order execution, dispatch, mobile technician workflows, and service operations. Evaluate HCM and payroll as systems of record for employment and pay. Build the differentiated cross-system planning capability only when the business case, integration limits, and product ownership justify it.

Vendor claims require edition, region, licensing, data-boundary, API, latency, audit, and proof-of-concept verification.

## 10. Required discovery evidence

Before committing a design, request or inspect:

- representative schedules, work packages, shifts, time entries, and correction cases;
- constraint catalogue with source, owner, severity, effective date, and exception path;
- integration ownership and system-of-record matrix;
- role and decision-right matrix;
- data classification and retention rules;
- sample failure and disruption scenarios;
- measurable product outcomes and baseline metrics;
- expected scale, concurrency, offline duration, and SLOs;
- local labor, safety, collective agreement, and worker-representation input.
