# Enterprise skill output evaluator

Evaluate this package or a future revision without silently rebuilding it.

## Dimensions

Score each from 1 to 5:

- `spec_compliance`: valid Skill structure, frontmatter, progressive references, installability;
- `research_quality`: source classification, primary-source use, confidence, missing evidence;
- `enterprise_readiness`: domain breadth, security, tests, operations, mobile, integration, governance;
- `architecture_quality`: conditional patterns, smallest robust solution, contracts, migration and rollback;
- `release_gate_integrity`: anti-confabulation, anti-sycophancy, bias, eval and validator results.

## Decision values

- `PASS`
- `PASS_WITH_MINOR_REVISIONS`
- `REVISE`
- `REBUILD`
- `BLOCKED`

## XML format

```xml
<enterprise_skill_evaluation>
  <scores>
    <spec_compliance>5</spec_compliance>
    <research_quality>5</research_quality>
    <enterprise_readiness>5</enterprise_readiness>
    <architecture_quality>5</architecture_quality>
    <release_gate_integrity>5</release_gate_integrity>
  </scores>
  <decision>PASS</decision>
  <reason>All mandatory gates passed with explicit project-specific limitations.</reason>
</enterprise_skill_evaluation>
```

Do not interpret a static package score as proof that every future app it designs will be correct. Runtime capabilities, project evidence, legal review, implementation, and validation remain separate.
