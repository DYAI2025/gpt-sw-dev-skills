# Source and confidence policy

## Source classes

| Class | Meaning | Permitted use |
|---|---|---|
| `primary` | Official specification, standard, regulation text, project documentation, repository evidence, schema, test, log, or measured runtime result | May support hard rules when current and applicable |
| `secondary` | Independent technical explanation or research synthesis | Context and corroboration; not the sole basis for critical operational rules |
| `user_provided` | User documents, notes, examples, screenshots, or stated business facts | Project input; verify before treating as external truth |
| `vendor_claim` | Marketing, product positioning, benchmark, or capability statement from a vendor | Capability candidate; verify in target edition, contract, and proof of concept |
| `derived` | Explicit inference from inspected evidence | Recommendation only when premises and uncertainty are visible |
| `uncertain` | Unknown provenance, stale version, conflicting evidence, or incomplete access | Do not turn into a hard rule |

## Confidence scale

| Score | Meaning | Rule |
|---:|---|---|
| 5 | Directly supported by applicable primary evidence | Hard rule or factual statement allowed |
| 4 | Strong primary evidence or convergent independent evidence | Recommendation allowed with normal qualification |
| 3 | Plausible but indirect, contextual, or vendor-specific | Mark as assumption or design hypothesis |
| 2 | Weak, conflicting, or likely stale | `SOURCE_NEEDED`; do not operationalize |
| 1 | Unsupported or speculative | Remove or block |

## Claim discipline

For each material claim record:

- claim;
- source ID and source class;
- access date or repository revision;
- applicability boundary;
- confidence;
- status: `verified`, `assumption`, `source_needed`, or `blocked`.

Numbers, current framework behavior, API versions, legal requirements, vendor capabilities, benchmarks, and security guarantees require current evidence. A better argument does not verify a fact.

## Research order

1. Inspect user-provided and repository evidence.
2. Identify claims that can change or materially affect safety and architecture.
3. Prefer official specifications, standards, repositories, product documentation, and original regulations.
4. Use secondary material to compare or challenge, not to launder an unsupported claim.
5. Preserve disagreement and scope differences.
6. Remove hard claims that remain below Confidence 4.

## Legal and employment boundary

This skill may identify likely governance and legal review needs. It does not provide legal advice. Labor law, collective agreements, works council rights, automated employment decisions, location monitoring, retention, payroll, and cross-border data processing require qualified review in each applicable jurisdiction.

## Vendor and framework boundary

Do not select a product because a capability page exists. Verify edition, license, region, data export, API limits, identity model, auditability, portability, security, support, total cost, and a representative proof of concept.

## Release rule

A source gap blocks release when it affects:

- worker safety or working-time validity;
- authorization or sensitive data exposure;
- payroll or financial correctness;
- destructive migration or historical interpretation;
- solver feasibility or auditability;
- a claimed production guarantee.

## Missing-evidence markers

Use `MISSING` when a required project input, file, permission, policy, dataset, repository fact, or runtime observation is absent. Use `SOURCE_NEEDED` when a material external claim still needs applicable evidence. Neither marker may be silently converted into a hard rule.
