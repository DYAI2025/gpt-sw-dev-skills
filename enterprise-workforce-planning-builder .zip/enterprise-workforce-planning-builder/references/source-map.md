# Source map

Access date for web sources: 2026-07-23.

## User-provided project sources

| ID | Source | Class | Purpose | Confidence | Limits | Status |
|---|---|---|---|---:|---|---|
| SRC-001 | `Eingefuegter Text.txt` - enterprise architecture patterns for planning platforms | user_provided | Candidate patterns: modularity, outbox, schemas, workflows, MCP, RAG, HITL, stack | 3 | Several conditional patterns and performance claims are stated as universal | reviewed |
| SRC-002 | `Eingefuegter Text (2).txt` - Anaplan and OneStream comparison for field service planning | user_provided | Buy/build and EPM integration context | 2 | Vendor capability and comparative conclusions require product-level verification | reviewed |
| SRC-003 | `Eingefuegter Text (3).txt` - AI coding-agent capabilities | user_provided | Repository introspection, schema evolution, testing, sandbox, telemetry loop | 3 | Tool availability and autonomy are runtime-dependent | reviewed |

## Primary technical sources

| ID | Source | Class | Purpose | Confidence | Applicability | Status |
|---|---|---|---|---:|---|---|
| SRC-010 | https://docs.nestjs.com/modules | primary | Module encapsulation and exported public surface | 5 | NestJS architecture; does not define DDD bounded-context cardinality | verified |
| SRC-011 | https://www.postgresql.org/docs/current/rangetypes.html | primary | Time ranges and exclusion constraints for overlap control | 5 | PostgreSQL current documentation | verified |
| SRC-012 | https://www.postgresql.org/docs/current/ddl-rowsecurity.html | primary | Row-level security semantics and default-deny behavior | 5 | PostgreSQL current documentation | verified |
| SRC-013 | https://www.postgresql.org/docs/current/transaction-iso.html | primary | Concurrency and transaction-isolation semantics | 5 | PostgreSQL current documentation | verified |
| SRC-014 | https://www.postgresql.org/docs/current/datatype-datetime.html | primary | Timestamp and time-zone semantics | 5 | PostgreSQL current documentation | verified |
| SRC-015 | https://postgis.net/workshops/postgis-intro/indexing.html | primary | Spatial indexing and index-aware geospatial queries | 5 | PostGIS workloads | verified |
| SRC-016 | https://developers.google.com/optimization/scheduling/employee_scheduling | primary | Constraint programming example for workforce scheduling | 5 | OR-Tools; model must be validated against local rules | verified |
| SRC-017 | https://developers.google.com/optimization/routing/vrptw | primary | Vehicle routing with time windows | 5 | Routing and field-service travel | verified |
| SRC-018 | https://modelcontextprotocol.io/specification/2025-11-25 | primary | MCP architecture, capabilities, consent, and security boundaries | 5 | MCP revision dated 2025-11-25 | verified |
| SRC-019 | https://modelcontextprotocol.io/specification/2025-11-25/basic/transports | primary | Standard MCP transports: stdio and Streamable HTTP | 5 | MCP revision dated 2025-11-25 | verified |
| SRC-020 | https://openai.github.io/openai-agents-python/ | primary | Agent, handoff, guardrail, and tracing primitives | 5 | OpenAI Agents SDK; runtime-specific | verified |
| SRC-021 | https://openai.github.io/openai-agents-python/guardrails/ | primary | Guardrail execution boundaries | 5 | Custom function tools differ from hosted and MCP tools | verified |
| SRC-022 | https://openai.github.io/openai-agents-python/tracing/ | primary | Agent tracing and sensitive-data considerations | 5 | OpenAI Agents SDK; runtime-specific | verified |
| SRC-023 | https://json-schema.org/draft/2020-12 | primary | JSON Schema vocabulary and validation model | 5 | Custom UI extensions remain application-specific | verified |
| SRC-024 | https://docs.temporal.io/develop/typescript/message-passing | primary | Signals, queries, updates, validators, and handler concurrency | 5 | Temporal TypeScript SDK | verified |
| SRC-025 | https://spec.openapis.org/oas/latest.html | primary | Language-neutral HTTP API contracts | 5 | Resolve and pin a concrete supported version in a project | verified |
| SRC-026 | https://www.asyncapi.com/docs/reference/specification/latest | primary | Machine-readable asynchronous API contracts | 5 | Use only when events cross owned boundaries | verified |
| SRC-027 | https://github.com/cloudevents/spec | primary | Portable event-envelope specification | 5 | Does not solve delivery or domain semantics | verified |
| SRC-028 | https://opentelemetry.io/docs/concepts/signals/ | primary | Traces, metrics, logs, and baggage | 5 | Instrumentation and backend choices remain project-specific | verified |
| SRC-029 | https://docs.expo.dev/router/introduction/ | primary | Universal React Native routing and platform capabilities | 5 | Does not by itself provide business-data offline sync | verified |
| SRC-030 | https://docs.expo.dev/build/introduction/ | primary | Android and iOS build and signing workflow | 5 | Store policy and native compatibility still require project evidence | verified |
| SRC-031 | https://tanstack.com/query/latest/docs/framework/react/guides/mutations | primary | Mutation persistence and offline-resume constraints | 4 | Library behavior; functions themselves are not serialized | verified |
| SRC-032 | https://owasp.org/www-project-application-security-verification-standard/ | primary | Web application security verification baseline | 5 | Tailor controls to threat model | verified |
| SRC-033 | https://mas.owasp.org/MASVS/ | primary | Mobile application security verification baseline | 5 | Tailor controls to platform and data risk | verified |
| SRC-034 | https://www.w3.org/TR/WCAG22/ | primary | Web accessibility success criteria | 5 | Target conformance level must be stated | verified |
| SRC-035 | https://www.nist.gov/itl/ai-risk-management-framework | primary | Voluntary AI risk-management and TEVV structure | 5 | Not certification or legal compliance | verified |
| SRC-036 | https://eur-lex.europa.eu/eli/reg/2024/1689/oj | primary | EU AI Act regulation text | 5 | Applicability and implementation require legal review | verified |
| SRC-037 | https://eur-lex.europa.eu/eli/reg/2016/679/oj | primary | GDPR regulation text | 5 | Applicability and lawful basis require legal review | verified |
| SRC-038 | https://learn.microsoft.com/en-us/azure/architecture/databases/guide/transactional-out-box-cosmos | primary | Transactional outbox and at-least-once/idempotency implications | 5 | Technology example; pattern is broader | verified |
| SRC-039 | https://learn.microsoft.com/en-us/azure/architecture/patterns/event-sourcing | primary | Event Sourcing trade-offs and selective use | 5 | Architecture guidance, not a mandate | verified |
| SRC-040 | https://agentskills.io/specification | primary | Skill package structure and progressive disclosure | 5 | Runtime support can vary | verified |


## Additional primary construction, labor-time, and offline sources

| ID | Source | Class | Purpose | Confidence | Applicability | Status |
|---|---|---|---|---:|---|---|
| SRC-041 | https://leanconstruction.org/lean-topics/last-planner-system/ | primary | Last Planner should/can/will/did/learn, make-ready, weekly work, daily coordination, PPC, and variance learning | 5 | Construction production control; adapt to organization | verified |
| SRC-042 | https://standards.buildingsmart.org/IFC/RELEASE/IFC4_3/index.html | primary | IFC 4.3.2.0 schema and shared construction object exchange | 5 | Optional BIM/IFC integration, not mandatory product model | verified |
| SRC-043 | https://eur-lex.europa.eu/eli/dir/2003/88/oj | primary | EU working-time baseline and review trigger | 5 | Legal applicability and national implementation require qualified review | verified |
| SRC-044 | https://developer.android.com/topic/architecture/data-layer/offline-first | primary | Offline-first data-layer principles and local data source | 5 | Android guidance; cross-platform design still project-specific | verified |

## Vendor capability sources

| ID | Source | Class | Purpose | Confidence | Limits | Status |
|---|---|---|---|---:|---|---|
| SRC-050 | https://www.anaplan.com/platform/artificial-intelligence/ | vendor_claim | Current Anaplan AI capability discovery | 3 | Edition, availability, data boundary, and fit require verification | reviewed |
| SRC-051 | https://www.anaplan.com/solutions/sales-planning/territory-and-quota-planning/ | vendor_claim | Territory-planning reference | 3 | Sales territory functionality is not proof of field-service dispatch optimization | reviewed |
| SRC-052 | https://www.onestream.com/solutions/planning-budgeting-forecasting/ | vendor_claim | Finance-centric planning and forecasting reference | 3 | Product fit, edition, and operational detail require proof of concept | reviewed |

## Derived conclusions used by this skill

| ID | Claim | Source IDs | Class | Confidence | Status |
|---|---|---|---|---:|---|
| DER-001 | Start with a modular monolith unless independent scaling, deployment, or ownership is evidenced | SRC-010, SRC-038, SRC-039 | derived | 4 | adopted as conditional default |
| DER-002 | The LLM must not replace the feasibility checker or optimization solver | SRC-016, SRC-017, SRC-018, SRC-035 | derived | 5 | adopted as hard architecture boundary |
| DER-003 | MCP is an integration adapter, not a replacement for domain APIs, identity, authorization, audit, or workflow state | SRC-018, SRC-019 | derived | 5 | adopted as hard architecture boundary |
| DER-004 | Mobile readiness requires explicit sync and conflict semantics, not only cached UI | SRC-029, SRC-030, SRC-031 | derived | 4 | adopted |
| DER-005 | EPM products should normally integrate with, not replace, operational dispatch and transactional workforce systems | SRC-050, SRC-051, SRC-052 | derived | 3 | retained as decision hypothesis, not hard rule |
| DER-006 | Employee-impacting AI requires stronger approval, explanation, audit, and legal review than low-risk drafting | SRC-035, SRC-036, SRC-037 | derived | 5 | adopted as governance rule |

## Unresolved project-specific evidence

No unresolved source is converted into a package-level hard claim. Each real project still requires evidence for local labor rules, collective agreements, safety policy, retention, payroll semantics, identity model, deployment platform, expected scale, SLOs, and app-store constraints.
