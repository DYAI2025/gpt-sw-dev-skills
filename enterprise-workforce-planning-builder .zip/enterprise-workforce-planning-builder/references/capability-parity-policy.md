# Capability parity policy

Porting this skill to another agent or updating it must preserve the following core behaviors:

- evidence-first intake and current-state reconstruction;
- domain model before framework choice;
- build, buy, and integrate decision;
- conditional architecture patterns and TypeScript-first reference path;
- deterministic feasibility and solver boundary;
- construction planning and field-service coverage;
- offline mobile conflict semantics;
- employee-impact, privacy, and approval controls;
- TDD, eval, observability, migration, rollback, and production gate;
- bounded repair and continuous-improvement loop;
- explicit uncertainty, counterargument, and bias review.

A runtime may omit an operation only when the capability is unavailable or unauthorized. It must then state the limitation and provide a safe handoff. It may not silently replace verification with prose.

Changes that narrow or remove a core behavior require:

- explicit reason;
- affected use cases;
- regression eval;
- migration or replacement guidance;
- accountable approval in the project context.
