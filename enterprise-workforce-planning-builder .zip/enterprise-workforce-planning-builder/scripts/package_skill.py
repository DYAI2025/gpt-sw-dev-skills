#!/usr/bin/env python3
"""Run all package gates and create an install-ready skill.zip."""
from __future__ import annotations

import argparse
import subprocess
import sys
import zipfile
from pathlib import Path

VALIDATORS = [
    "quick_validate.py",
    "validate_source_map.py",
    "validate_evals.py",
    "validate_release_gate.py",
    "validate_installability.py",
    "validate_agent_agnostic.py",
    "validate_core_parity.py",
    "validate_no_placeholders.py",
    "validate_workflow.py",
]


def run_validator(skill_dir: Path, script: Path) -> None:
    result = subprocess.run([sys.executable, str(script), str(skill_dir)], text=True, capture_output=True)
    if result.stdout:
        print(result.stdout.strip())
    if result.returncode != 0:
        if result.stderr:
            print(result.stderr.strip(), file=sys.stderr)
        raise SystemExit(result.returncode)


def package(skill_dir: Path, out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    zip_path = out_dir / "skill.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(skill_dir.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(skill_dir)
            if "__pycache__" in rel.parts or path.suffix in {".pyc", ".pyo"} or path.name == ".DS_Store":
                continue
            archive.write(path, Path(skill_dir.name) / rel)
    return zip_path


def validate_zip(zip_path: Path, skill_name: str) -> None:
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
    roots = {name.split("/", 1)[0] for name in names if name and not name.startswith("__MACOSX/")}
    if roots != {skill_name}:
        raise SystemExit(f"ZIP must contain exactly one root directory {skill_name!r}; got {sorted(roots)}")
    required = {f"{skill_name}/SKILL.md", f"{skill_name}/agents/openai.yaml"}
    missing = sorted(required - set(names))
    if missing:
        raise SystemExit("ZIP missing required entries: " + ", ".join(missing))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_dir")
    parser.add_argument("out_dir", nargs="?", default="./dist")
    args = parser.parse_args()

    skill_dir = Path(args.skill_dir).resolve()
    script_dir = skill_dir / "scripts"
    for name in VALIDATORS:
        run_validator(skill_dir, script_dir / name)

    evaluation = skill_dir / "reports" / "enterprise-skill-evaluation.xml"
    result = subprocess.run(
        [sys.executable, str(script_dir / "validate_enterprise_skill_evaluation.py"), str(evaluation)],
        text=True,
        capture_output=True,
    )
    if result.stdout:
        print(result.stdout.strip())
    if result.returncode != 0:
        if result.stderr:
            print(result.stderr.strip(), file=sys.stderr)
        return result.returncode

    zip_path = package(skill_dir, Path(args.out_dir).resolve())
    validate_zip(zip_path, skill_dir.name)
    print(f"PACKAGED: {zip_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
