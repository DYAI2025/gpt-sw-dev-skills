#!/usr/bin/env python3
"""Validate source classes, confidence discipline, and minimum evidence coverage."""
from __future__ import annotations

import re
import sys
from pathlib import Path

REQUIRED_CLASSES = {"primary", "user_provided", "vendor_claim", "derived"}


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_source_map.py <skill-dir>")
    root = Path(argv[1])
    map_path = root / "references" / "source-map.md"
    policy_path = root / "references" / "source-policy.md"
    if not map_path.is_file() or not policy_path.is_file():
        return fail("source-map.md and source-policy.md are required")

    source_map = map_path.read_text(encoding="utf-8")
    policy = policy_path.read_text(encoding="utf-8")
    combined = source_map + "\n" + policy

    for source_class in REQUIRED_CLASSES:
        if source_class not in combined:
            return fail(f"missing source class: {source_class}")
    for term in ["SOURCE_NEEDED", "MISSING", "Confidence", "Release rule", "access date"]:
        if term.lower() not in combined.lower():
            return fail(f"missing source discipline term: {term}")

    user_sources = len(re.findall(r"\| SRC-00[1-9] \|", source_map))
    primary_sources = sum(1 for line in source_map.splitlines() if re.search(r"\|\s*primary\s*\|", line))
    derived_claims = len(re.findall(r"\| DER-00[1-9] \|", source_map))
    if user_sources < 3:
        return fail("source map must include at least three user-provided sources")
    if primary_sources < 20:
        return fail("source map must include at least twenty primary technical sources")
    if derived_claims < 5:
        return fail("source map must include at least five derived conclusions")

    low_confidence_hard = re.findall(r"\| DER-[^\n]+\|\s*[123]\s*\|\s*adopted as hard", source_map, flags=re.IGNORECASE)
    if low_confidence_hard:
        return fail("derived hard rule has confidence below 4")

    print(f"PASS: source map ({user_sources} user, {primary_sources} primary, {derived_claims} derived)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
