#!/usr/bin/env python3
"""Validate that the new skill preserves its declared domain core."""
from __future__ import annotations

import json
import sys
from pathlib import Path

CORE = {
    "evidence_first_intake",
    "domain_model_before_stack",
    "buy_integrate_build_decision",
    "conditional_architecture",
    "deterministic_feasibility_boundary",
    "workforce_field_construction_planning",
    "web_mobile_offline_delivery",
    "security_worker_governance",
    "tdd_evaluation_production_gate",
    "bounded_improvement_loop",
    "critical_countercheck",
}


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_core_parity.py <skill-dir>")
    path = Path(argv[1]) / "reports" / "core-functionality-preservation.json"
    if not path.is_file():
        return fail("core-functionality-preservation.json missing")
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(f"invalid core preservation report: {exc}")
    preserved = set(report.get("preserved_core_functions", []))
    missing = sorted(CORE - preserved)
    if missing:
        return fail("missing core functions: " + ", ".join(missing))
    if report.get("core_behavior_change") not in [False, "false"]:
        return fail("core_behavior_change must be false for initial release baseline")
    if not report.get("minimal_additions"):
        return fail("minimal_additions must be listed")
    if report.get("unintended_changes"):
        return fail("unintended_changes must be empty")
    print("PASS: core functionality preservation")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
