#!/usr/bin/env python3
"""Validate the release-gate report."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_release_gate.py <skill-dir>")
    path = Path(argv[1]) / "reports" / "release-gate-report.json"
    if not path.is_file():
        return fail("reports/release-gate-report.json missing")
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(f"invalid release gate JSON: {exc}")

    release = report.get("release_gate", {})
    craft = report.get("craftsmanship_gate", {})
    confab = report.get("anti_confabulation_gate", {})
    syco = report.get("anti_sycophancy", {})
    bias = report.get("bias_gate", {})

    if release.get("status") != "PASS" or release.get("allowed_to_package") is not True:
        return fail("release gate must PASS and allow packaging")
    if craft.get("status") != "PASS":
        return fail("craftsmanship gate must PASS")
    if confab.get("status") != "PASS" or confab.get("blocked_claims"):
        return fail("anti-confabulation gate must PASS with no blocked claims")
    score = syco.get("score")
    threshold = syco.get("threshold", 3)
    if not isinstance(score, int) or score >= threshold:
        return fail("anti-sycophancy score must be an integer below threshold")
    if bias.get("status") == "BLOCKED":
        return fail("bias gate is BLOCKED")
    if not report.get("corrections_applied"):
        return fail("corrections_applied must be non-empty")
    if not report.get("residual_limitations"):
        return fail("residual_limitations must be non-empty")

    print("PASS: release gate")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
