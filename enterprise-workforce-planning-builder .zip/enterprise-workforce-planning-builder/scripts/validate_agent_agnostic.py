#!/usr/bin/env python3
"""Validate semantic portability and explicit runtime limitations."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_agent_agnostic.py <skill-dir>")
    root = Path(argv[1])
    ref = root / "references" / "agent-agnostic-compatibility.md"
    report_path = root / "reports" / "agent-compatibility-report.json"
    if not ref.is_file() or not report_path.is_file():
        return fail("compatibility reference and report are required")
    text = ref.read_text(encoding="utf-8")
    for term in ["ChatGPT", "Claude", "Codex", "tool availability", "UI install", "not guaranteed"]:
        if term.lower() not in text.lower():
            return fail(f"compatibility reference missing term: {term}")
    try:
        report = json.loads(report_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(f"invalid agent compatibility report: {exc}")
    if report.get("agent_agnostic_ready") is not True:
        return fail("agent_agnostic_ready must be true")
    if not report.get("not_guaranteed"):
        return fail("not_guaranteed must be non-empty")
    if "agents/openai.yaml" not in report.get("runtime_specific_components", []):
        return fail("agents/openai.yaml must be marked runtime-specific")
    print("PASS: agent-agnostic controls")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
