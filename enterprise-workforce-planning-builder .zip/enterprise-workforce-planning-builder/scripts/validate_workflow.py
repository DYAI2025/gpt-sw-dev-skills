#!/usr/bin/env python3
"""Validate Graphviz workflow syntax when dot is available."""
from __future__ import annotations

import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_workflow.py <skill-dir>")
    path = Path(argv[1]) / "references" / "workflow.dot"
    if not path.is_file():
        return fail("references/workflow.dot missing")
    text = path.read_text(encoding="utf-8")
    for token in ["digraph", "shape=diamond", "shape=octagon", "shape=doublecircle"]:
        if token not in text:
            return fail(f"workflow missing token: {token}")
    dot = shutil.which("dot")
    if dot:
        with tempfile.NamedTemporaryFile(suffix=".svg") as output:
            result = subprocess.run([dot, "-Tsvg", str(path), "-o", output.name], capture_output=True, text=True)
            if result.returncode != 0:
                return fail("Graphviz syntax error: " + result.stderr.strip())
        print("PASS: workflow Graphviz syntax")
    else:
        print("PASS: workflow structural tokens; Graphviz executable not installed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
