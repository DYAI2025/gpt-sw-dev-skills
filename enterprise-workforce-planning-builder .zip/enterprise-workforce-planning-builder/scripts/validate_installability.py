#!/usr/bin/env python3
"""Validate installability controls and expected package name."""
from __future__ import annotations

import json
import sys
from pathlib import Path

ALLOWED_STATUS = {"prepared", "blocked", "not_controlled_by_skill"}


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_installability.py <skill-dir>")
    root = Path(argv[1])
    required = [
        root / "SKILL.md",
        root / "agents" / "openai.yaml",
        root / "references" / "installability-and-distribution.md",
        root / "reports" / "installability-report.json",
    ]
    for path in required:
        if not path.is_file():
            return fail(f"missing installability path: {path.relative_to(root)}")
    try:
        report = json.loads((root / "reports" / "installability-report.json").read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(f"invalid installability report: {exc}")
    if report.get("artifact_name") != "skill.zip":
        return fail("artifact_name must be skill.zip")
    if report.get("chatgpt_install_ready") is not True:
        return fail("chatgpt_install_ready must be true after local structural validation")
    status = report.get("frontend_install_suggestion_status")
    if status not in ALLOWED_STATUS:
        return fail("invalid frontend_install_suggestion_status")
    if not report.get("not_controlled_by_skill"):
        return fail("not_controlled_by_skill must list external limitations")
    if report.get("blocking_issues"):
        return fail("blocking_issues must be empty for packaging")
    print("PASS: installability controls")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
