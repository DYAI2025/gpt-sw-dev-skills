#!/usr/bin/env python3
"""Validate trigger and output evaluations for domain, safety, and delivery coverage."""
from __future__ import annotations

import json
import sys
from pathlib import Path

REQUIRED_TAGS = {
    "greenfield",
    "repository",
    "optimization",
    "construction",
    "mobile-offline",
    "integration",
    "safety",
    "production-readiness",
}


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def load(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise ValueError(f"{path}: {exc}") from exc


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_evals.py <skill-dir>")
    root = Path(argv[1])
    trigger_path = root / "evals" / "trigger_queries.json"
    output_path = root / "evals" / "output_evals.json"
    if not trigger_path.is_file() or not output_path.is_file():
        return fail("trigger_queries.json and output_evals.json are required")
    try:
        triggers = load(trigger_path)
        outputs = load(output_path)
    except ValueError as exc:
        return fail(str(exc))

    if not isinstance(triggers, list) or len(triggers) < 12:
        return fail("trigger_queries.json must contain at least 12 cases")
    true_count = sum(1 for case in triggers if isinstance(case, dict) and case.get("should_trigger") is True)
    false_count = sum(1 for case in triggers if isinstance(case, dict) and case.get("should_trigger") is False)
    if true_count < 7 or false_count < 4:
        return fail("trigger evals require at least seven positive and four negative cases")
    for case in triggers:
        if not isinstance(case, dict) or not all(k in case for k in ["id", "query", "should_trigger", "reason"]):
            return fail("each trigger case needs id, query, should_trigger, and reason")

    if not isinstance(outputs, list) or len(outputs) < 8:
        return fail("output_evals.json must contain at least eight cases")
    tags: set[str] = set()
    for case in outputs:
        if not isinstance(case, dict) or not all(k in case for k in ["id", "prompt", "tags", "expected_properties", "failure_modes"]):
            return fail("each output eval needs id, prompt, tags, expected_properties, and failure_modes")
        if not case["expected_properties"] or not case["failure_modes"]:
            return fail(f"eval {case.get('id')} must include non-empty expected_properties and failure_modes")
        tags.update(case.get("tags", []))
    missing_tags = sorted(REQUIRED_TAGS - tags)
    if missing_tags:
        return fail("output eval coverage missing tags: " + ", ".join(missing_tags))

    print(f"PASS: evals ({len(triggers)} trigger cases, {len(outputs)} output cases)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
