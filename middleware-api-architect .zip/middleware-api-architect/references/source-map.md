# Source Map

## Purpose

Map stable reference sources to the architecture decisions this skill may make. Refresh current versions before relying on version-sensitive claims.

## When to use

Use this file when selecting standards, validating contract strategies, creating source registers, or deciding whether a claim is FACT, INFERENCE, ASSUMPTION, SOURCE_NEEDED, or MISSING.

## Primary source map

| Source | Type | Primary use | Reliability | Limits | Skill use |
|---|---|---|---|---|---|
| OpenAPI Specification latest | primary standard | HTTP API interface descriptions | high | does not guarantee REST quality or runtime behavior | REST/HTTP contracts, operation inventory, codegen boundaries |
| RFC 9110 HTTP Semantics | primary standard | HTTP methods, status codes, fields, resources, representations | high | does not prescribe domain resource modeling | method semantics, status mapping, cache/header decisions |
| RFC 9457 Problem Details | primary standard | HTTP API error response format | high | does not define domain error taxonomy | error envelope and failure contracts |
| AsyncAPI Specification latest | primary standard | message-driven API descriptions | high | broker-specific behavior needs bindings and vendor docs | events, channels, messages, operations, pub/sub contracts |
| CloudEvents Specification | primary CNCF spec | interoperable event metadata envelope | high | not a domain event modeling method by itself | source/id uniqueness, event metadata, cross-system event envelopes |
| JSON Schema Draft 2020-12 | primary spec | JSON validation and schema vocabulary | high | tooling support varies by dialect | payload schemas, examples, compatibility policy |
| GraphQL Specification | primary spec | GraphQL language, type system, execution semantics | high | operational controls depend on server/runtime | SDL, resolver ownership, validation, query safety |
| gRPC Core Concepts | official docs | service definition, RPC lifecycle, streaming | high | language-specific behavior requires language docs | RPC style, streaming choice, lifecycle vocabulary |
| Protocol Buffers docs | official docs | IDL and typed message model | high | edition/runtime specifics need current docs | proto schema design and generated-code strategy |
| OAuth 2.0 RFC 6749 | primary RFC | delegated authorization framework | high | current profiles and security BCP may supersede details | token model and grant selection basis |
| OpenID Connect Core 1.0 | primary spec | identity layer on OAuth 2.0 | high | provider claims/scopes vary | authentication and identity claims |
| RFC 9449 DPoP | primary RFC | OAuth sender-constrained token proof | high | does not replace HTTPS or general access control | proof-of-possession review when relevant |
| OWASP API Security Top 10 2023 | curated primary security project | API risk review categories | high | not a complete threat model | authz, resource consumption, SSRF, inventory, unsafe API consumption gates |
| OpenTelemetry Specification | primary project spec | traces, metrics, logs, context propagation | high | instrumentation maturity varies by language | observability model and telemetry terminology |
| Enterprise Integration Patterns | canonical pattern catalog | message routing and transformation patterns | medium-high | pattern catalog, not a runtime guarantee | splitter, aggregator, resequencer, claim check, normalizer |
| Official broker/gateway/workflow docs | vendor/project docs | product-specific semantics | high when official | changes by version and deployment mode | Kafka, NATS, RabbitMQ, Kong, Envoy, APISIX, Temporal, Camel, Spring Integration |
| Repository and runtime evidence | direct artifact evidence | actual implementation and behavior | high if current | may be incomplete or stale | audits, gap matrices, runtime reconstruction |

## Refresh policy

Refresh source details through web research or official documentation when the task depends on:

- standards version numbers
- provider-specific retry, quota, security, or broker behavior
- SDK or framework APIs
- cloud product features and limits
- gateway policy support
- security advisories
- performance benchmarks
- current managed-service behavior

## Boundaries

- Do not use secondary articles as sole authority for standards or security controls.
- Do not treat a spec as proof that the user's implementation complies with it.
- Do not cite a provider's generic product page as evidence for a specific runtime configuration.

## Validation questions

- Which source supports the selected contract strategy?
- Which source supports the security requirement?
- Which source supports provider-specific behavior?
- Which claims are still SOURCE_NEEDED because versions or product behavior may have changed?
