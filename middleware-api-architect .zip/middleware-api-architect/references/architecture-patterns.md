# Architecture Patterns

## Purpose

Provide reusable pattern definitions, fit criteria, risks, and validation checks for middleware/API architecture.

## When to use

Use this file when choosing, comparing, or auditing architecture patterns for integration systems.

## Patterns

### API Gateway

Use when multiple APIs need shared ingress policies: TLS, routing, authentication, authorization hooks, quotas, throttling, request shaping, analytics, version routing, or central policy enforcement.

Risks: hidden business logic in the gateway, policy drift across environments, over-centralized coupling, unclear service ownership.

Validate: Which policies belong at gateway vs service? How are policies versioned and tested? How are correlation and auth context propagated?

### Backend-for-Frontend

Use when one client surface needs tailored aggregation, response shaping, latency optimization, or client-specific workflow composition.

Risks: duplicated domain logic, client-specific sprawl, missing downstream authorization propagation, cache inconsistency.

Validate: Which client owns it? What is the latency budget? Which downstream calls are composed? How is object-level authorization preserved?

### Adapter / Connector

Use when integrating vendor APIs, legacy systems, SaaS tools, databases, files, or protocol mismatches.

Must define: external contract, internal contract, mapping, retry policy, rate limits, error translation, credential isolation, provider versioning.

Validate: What is provider-specific? What is reusable? How are failures and quota limits surfaced?

### Anti-Corruption Layer

Use when external domain models are unstable, legacy, vendor-controlled, or semantically incompatible.

Must define: canonical model, translation table, lossiness, ownership, versioning, rejected mappings, test fixtures.

Validate: Which external concepts are intentionally blocked from the internal domain?

### Orchestrated Workflow

Use when a process requires central state, compensation, visibility, sequential dependency, deadlines, or auditability.

Must define: state machine, timeout, compensation, idempotency, retry, audit trail, manual intervention path.

Validate: What state is durable? Which steps are compensatable? Which calls are unsafe to retry?

### Event-Driven Choreography

Use when services can react independently and eventual consistency is acceptable.

Must define: event schema, event owner, topic/channel naming, ordering, dedupe, replay, consumer compatibility, poison-message handling.

Validate: Who owns breaking changes? What happens when one consumer is down? How is replay controlled?

### Webhook Ingestion Pipeline

Canonical stages: receive, authenticate/signature verify, validate, dedupe, enqueue, process, persist, acknowledge, observe, DLQ on repeated failure.

Critical controls: raw body preservation for signature verification, provider event id plus provider id as idempotency basis, replay protection, durable acceptance before ACK unless provider retry model requires another strategy, no secret logging.

Validate: Is signature verification performed before parsing? Is ACK tied to durable acceptance? Does a DLQ exist?

### CQRS Read Model

Use when reads need composition, denormalization, query optimization, or independent scaling from the write model.

Risks: stale data, replay complexity, schema evolution, dual-write confusion, unclear rebuild process.

Validate: Can the read model be rebuilt? What lag is acceptable? Which source of truth wins?

### Agent-Ready API Wrapper

Use when APIs are exposed to LLM agents, tools, or MCP-like surfaces.

Must define: narrow tool surface, strong schemas, examples, auth boundary, safe defaults, idempotency, clear errors, no destructive default actions, operation allowlist, semantic documentation quality.

Validate: Can the agent infer intent safely? Are destructive actions guarded? Are errors actionable?

### Message Router

Routes messages to channels based on content, headers, metadata, or policy.

Validate: Are route predicates deterministic and tested? Is the default route explicit?

### Message Filter

Drops or quarantines messages that fail criteria while allowing valid flow to continue.

Validate: Are rejected messages observable? Are business rejections separated from technical failures?

### Splitter

Splits a composite message into correlated sub-messages.

Validate: How are sub-messages correlated, ordered, and retried?

### Aggregator

Combines related messages into a result when a completion condition is met.

Validate: What closes the group: count, timeout, marker event, or manual intervention?

### Resequencer

Restores order for messages that arrive out of sequence.

Validate: What sequence key exists? What is the timeout for missing items?

### Claim Check

Stores large or sensitive payload externally and passes a reference through the pipeline.

Validate: Who can dereference the claim? What retention and encryption apply?

### Content Enricher

Adds data by calling another system or lookup store.

Validate: What timeout, fallback, and stale-data behavior apply?

### Normalizer

Converts heterogeneous payloads into a canonical format.

Validate: What semantic loss occurs? How are versioned mappings tested?

### Dead Letter Channel

Captures messages that cannot be processed after the retry policy.

Validate: Who owns triage, replay, redaction, and alerting?

## Limits

Patterns are design tools. They are not proof of correctness, scalability, or security without concrete contracts, tests, and runtime evidence.

## Validation questions

- Why is this pattern necessary instead of a simpler direct integration?
- What coupling does it reduce and what coupling does it introduce?
- What operational burden does it add?
- Which contract, security, reliability, and observability gates apply?
