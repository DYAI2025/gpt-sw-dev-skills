# Framework and Tooling Map

## Purpose

Guide framework and tool selection without hallucinating product behavior or implying unsupported implementation details.

## When to use

Use when a user asks for implementation planning, stack selection, migration, gateway choice, workflow engine choice, or coding-agent handoff.

## Framework and tooling categories

| Category | Examples | Use for | Required verification |
|---|---|---|---|
| API gateways | Kong, Envoy, Apache APISIX, cloud API gateways | ingress policy, routing, auth integration, quotas, analytics | official docs for specific plugin/policy/version |
| Service mesh | Istio, Linkerd, Envoy-based meshes | service-to-service traffic policy, mTLS, telemetry | cluster topology and mesh version |
| Integration frameworks | Apache Camel, Spring Integration | Enterprise Integration Patterns, routes, adapters, transformations | framework docs and target runtime |
| Workflow engines | Temporal, Camunda, cloud workflow services | durable orchestration, state, compensation, retries | official semantics for retries, timers, idempotency, activities |
| Brokers and streaming | Kafka, NATS, RabbitMQ, cloud pub/sub | event distribution, queues, streams, backpressure | ordering, retention, delivery, retry, DLQ semantics per product |
| API contract tooling | OpenAPI tools, AsyncAPI tools, JSON Schema validators, Protobuf compilers | contract validation, docs, codegen, mocks | dialect/version compatibility |
| Testing tools | contract test frameworks, schema validators, integration test harnesses | compatibility and failure-path checks | language and CI compatibility |
| Observability | OpenTelemetry SDKs, collectors, tracing backends, metrics/log platforms | traces, metrics, logs, propagation | language SDK maturity and deployment model |
| Agent/tool surfaces | MCP servers, function/tool schemas, constrained OpenAPI wrappers | LLM-safe API consumption | operation allowlist, auth boundary, rate limits, evaluation tasks |

## Selection rules

- Select a gateway for shared ingress policy, not for hidden business logic.
- Select a BFF for client-specific composition, not as a dumping ground for domain logic.
- Select a workflow engine when durable state, compensation, visibility, and retries are central.
- Select choreography when independent services can tolerate eventual consistency and own their event contracts.
- Select Camel or Spring Integration when explicit routing and transformation patterns reduce custom integration code.
- Select agent wrappers only after narrowing the API surface and auditing documentation quality.

## Coding-agent handoff rules

- Specify stack only after constraints are known.
- Mark stack choices as ASSUMPTION when language/runtime/cloud constraints are absent.
- Provide contract files before implementation tasks.
- Include tests for mapping, authz, idempotency, retry, DLQ, and observability.
- Do not invent package names, framework features, or provider limits without current official documentation.

## Limits

This file is not a compatibility matrix. Product-specific features and versions must be verified through official documentation at task time.

## Validation questions

- Why is this tool category needed?
- Which official docs support the selected product behavior?
- What is the fallback if the selected tool lacks a needed feature?
- Does the selected stack increase operational burden beyond the team's maturity?
