# Source Policy

## Purpose

Define how the middleware-api-architect skill separates evidence from inference while designing, auditing, or implementation-planning middleware and API systems.

## When to use

Use this file whenever the output contains architecture claims, standards claims, security rules, provider behavior, runtime behavior, tool capability statements, or implementation handoff instructions.

## Source hierarchy

| Rank | Source type | Use |
|---|---|---|
| 1 | primary standards and specifications | RFC Editor, OpenAPI Initiative, AsyncAPI Initiative, JSON Schema, CloudEvents, GraphQL specification, gRPC, Protocol Buffers, OpenID Foundation, OWASP, OpenTelemetry |
| 2 | official project or vendor documentation | gateway, broker, workflow engine, cloud, SDK, framework, database, observability tooling behavior |
| 3 | repository evidence | source code, tests, CI, manifests, OpenAPI or AsyncAPI files, proto files, GraphQL SDL, deployment files |
| 4 | runtime evidence | logs, traces, metrics, gateway exports, HAR files, cURL captures, alert history |
| 5 | user-provided material | architecture notes, diagrams, requirements, examples, target conventions |
| 6 | secondary explanations | articles, tutorials, blog posts; use only as context, not as sole authority for rules |

## Claim labels

| Label | Meaning | Allowed use |
|---|---|---|
| FACT | directly supported by a cited source or provided artifact | may drive design or audit finding |
| INFERENCE | reasoned from evidence but not directly observed | may inform options; mark confidence lower |
| ASSUMPTION | necessary to proceed but unverified | may proceed only if risk is explicit |
| SOURCE_NEEDED | current external verification is required | do not use as a hard rule |
| MISSING | required input or artifact is absent | must appear in open questions or risk log |

## Confidence scale

| Score | Meaning |
|---|---|
| 5 | primary source or direct artifact evidence |
| 4 | official source or multiple consistent artifacts |
| 3 | plausible inference from partial evidence |
| 2 | weak, ambiguous, or conflicting evidence |
| 1 | unsupported; block or mark SOURCE_NEEDED |

## Rules

- Standards versions require current primary-source verification.
- Security recommendations require OWASP, RFC, vendor security docs, or concrete threat evidence.
- Cloud/provider behavior requires official provider docs or observed runtime evidence.
- API behavior requires contract, code, log, trace, gateway export, or verified example.
- Benchmarks and performance numbers require dated source, test context, workload, and environment.
- Diagrams supplied by a user are evidence of intended design, not proof of runtime behavior.
- Never convert naming similarity into ownership, auth, endpoint, event, or data-flow evidence.

## Limits

This policy does not replace a threat model, legal compliance review, penetration test, production incident review, or vendor-specific architecture assessment.

## Validation questions

- Is every consequential claim labeled FACT, INFERENCE, ASSUMPTION, SOURCE_NEEDED, or MISSING?
- Are version-sensitive claims checked against primary sources?
- Are security claims backed by OWASP, RFCs, official docs, or concrete evidence?
- Are runtime claims backed by runtime evidence rather than diagrams alone?
- Are weak or absent facts reflected in the confidence score?
