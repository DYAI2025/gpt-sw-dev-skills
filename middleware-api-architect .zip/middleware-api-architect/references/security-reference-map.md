# Security Reference Map

## Purpose

Provide security review anchors for middleware and API architecture without replacing a full threat model.

## When to use

Use for every architecture brief, audit, implementation plan, or agent-ready API wrapper that crosses a trust boundary or handles protected data/actions.

## Required review areas

| Area | Required decision | Evidence to request |
|---|---|---|
| Authentication | how caller identity is established | IdP config, gateway policy, token validation code, mTLS config, API key policy |
| Authorization | object/resource and function/action checks | policy code, middleware, tests, access-control matrix |
| Tenant boundary | how tenants are isolated | data model, claims, query filters, row-level policy, service boundary |
| Token model | OAuth/OIDC/JWT/API key/mTLS/DPoP choice | RFC/spec, provider docs, threat model, client type |
| Secrets | storage, rotation, redaction | secret manager config, CI/CD policy, log redaction tests |
| Input validation | boundary and domain validation | schema, validators, contract tests, negative test fixtures |
| SSRF | user-controlled outbound URLs | allowlist, DNS/IP checks, egress policy, metadata-IP protections |
| Resource limits | rate, quota, payload, timeout, cost controls | gateway policy, service config, load tests |
| Third-party APIs | unsafe consumption review | provider contract, validation, timeout, retry, response sanitization |
| Audit logging | security-relevant events | log schema, retention, redaction, access controls |

## OWASP API Security Top 10 2023 mapping

| OWASP area | Architecture check |
|---|---|
| Broken Object Level Authorization | every object-id access has ownership or policy check |
| Broken Authentication | token, session, API key, and credential handling are explicit and tested |
| Broken Object Property Level Authorization | response and update fields are authorized per property when sensitive |
| Unrestricted Resource Consumption | rate, quota, payload, CPU, memory, and downstream-cost limits exist |
| Broken Function Level Authorization | admin and privileged functions are separated and checked |
| Unrestricted Access to Sensitive Business Flows | abuse-prone workflows have friction, quotas, or risk controls |
| Server Side Request Forgery | user-controlled URLs are validated and egress-restricted |
| Security Misconfiguration | defaults, CORS, headers, debug endpoints, and environment drift are reviewed |
| Improper Inventory Management | hosts, versions, endpoints, owners, and deprecations are inventoried |
| Unsafe Consumption of APIs | third-party responses are validated and treated as untrusted |

## Token and identity notes

- OAuth 2.0 is an authorization framework; do not present it as authentication by itself.
- OpenID Connect adds an identity layer over OAuth 2.0.
- JWT validation must pin acceptable algorithms and validate issuer, audience, expiry, not-before where applicable, and key source.
- mTLS and DPoP are sender-constraining mechanisms in different layers; use only when threat model and client capabilities justify them.
- API keys identify applications or clients only when lifecycle and ownership are well managed; they are not user authorization by themselves.

## Agent-ready API wrapper security

- Use an allowlist of operations.
- Default to read-only unless write/destructive intent is explicit and guarded.
- Require strong schemas and examples.
- Enforce auth boundary outside the model prompt.
- Add rate limits and abuse controls.
- Return clear, typed, non-sensitive errors.
- Avoid exposing raw admin endpoints to agents.

## Limits

This map is a design review aid. It does not replace security architecture review, formal threat modeling, penetration testing, compliance assessment, or legal review.

## Validation questions

- What is the protected resource or action?
- Who can perform it and why?
- Where is the policy enforced?
- How is the policy tested?
- What happens when identity, token, or downstream provider validation fails?
