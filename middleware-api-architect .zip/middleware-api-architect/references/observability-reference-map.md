# Observability Reference Map

## Purpose

Define how to design observability for middleware/API systems across synchronous and asynchronous boundaries.

## When to use

Use whenever the task involves production architecture, reliability, incident response, audit, pipeline design, or implementation handoff.

## Observability model

| Signal | Required content | Examples |
|---|---|---|
| Traces | distributed path across gateway, service, adapter, queue, worker, datastore, external calls | trace id, span ids, parent/child spans, outbound call spans |
| Correlation | business-flow identifier across logs, events, and support workflows | correlation id, provider event id, order id with sensitivity review |
| Logs | structured event records without secrets or sensitive payloads by default | status, failure reason, contract version, provider id, retry attempt |
| Metrics | numeric measures for health and capacity | latency, throughput, error rate, retry count, DLQ depth, queue lag, saturation, quota pressure |
| Alerts | user or business-impact symptoms | elevated failed checkouts, DLQ growth, webhook backlog, provider outage |
| Runbooks | operational response guidance | replay procedure, DLQ triage, credential rotation, provider incident mode |

## Trace and correlation rules

- Generate or accept a correlation id at ingress.
- Propagate trace context through HTTP headers, message metadata, worker context, and external calls where supported.
- Preserve provider event id separately from internal correlation id.
- Do not put secrets or sensitive payload fragments into trace attributes.
- Use business identifiers only after privacy and access review.

## Pipeline-specific observability

For every pipeline stage, log or measure:

| Stage | Minimum observability |
|---|---|
| receive | request id, provider id, content length class, received timestamp |
| verify | verification result and reason without secret material |
| validate | schema version, validation result, rejected-field category |
| dedupe | idempotency key, duplicate/new decision |
| enqueue | queue/topic, message id, durable acceptance result |
| process | worker id, attempt count, elapsed time, dependency calls |
| persist | entity id class, transaction result, conflict/idempotent outcome |
| acknowledge | status, provider retry expectation |
| DLQ | failure reason, attempts, next action owner, replay eligibility |

## Metrics baseline

- request latency and downstream latency
- throughput and queue lag
- error rate by class and dependency
- retry count and retry exhaustion
- DLQ depth and age of oldest message
- idempotency duplicate rate
- signature verification failure rate for webhooks
- schema validation failure rate
- provider quota pressure
- worker saturation

## Alerting rules

- Prefer alerts tied to user/business impact.
- Alert on sustained DLQ growth, stale queue age, high retry exhaustion, signature verification anomaly, provider quota exhaustion, and elevated authz failures.
- Avoid noisy alerts for single expected validation failures unless they indicate abuse or regression.

## Limits

Observability design does not prove a system is instrumented. Runtime evidence requires actual traces, logs, metrics, dashboards, or configuration.

## Validation questions

- Can a single request/event be followed across all boundaries?
- Are failure reasons visible without leaking secrets?
- Are DLQ and replay operations observable?
- Are metrics aligned to SLO or business impact?
- Who owns the dashboard and runbook?
