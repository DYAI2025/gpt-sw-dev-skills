# Domain Ontology

## Purpose

Provide consistent terminology for middleware, API, event, and integration architecture work.

## When to use

Use this file when classifying systems, reconstructing diagrams, naming components, building contract inventories, and explaining trade-offs.

## Core entities

| Term | Definition | Validation question |
|---|---|---|
| Consumer | caller, client app, service, agent, batch job, webhook sender, or event subscriber | Who initiates or receives the interaction? |
| Producer | service or system publishing data, events, callbacks, or API responses | Who owns the emitted data or response? |
| Contract | machine-readable or provider-specified interface definition such as OpenAPI, AsyncAPI, GraphQL SDL, Protobuf, JSON Schema, webhook docs, file schema | Where is the interface behavior defined? |
| Adapter | component translating between an external or system-specific contract and the internal model | What mapping and error translation occur here? |
| Connector | reusable integration component for a vendor, SaaS, broker, database, or protocol | Which credentials, rate limits, and provider quirks does it isolate? |
| Gateway | ingress policy and routing layer for TLS, auth, quotas, routing, versioning, analytics, and request shaping | Which policies live here and which stay service-local? |
| BFF | backend-for-frontend tailored to one client experience, often composing downstream APIs | Which client surface owns this composition? |
| Anti-Corruption Layer | boundary preventing external or legacy domain models from leaking into internal domain logic | What canonical model and translation table protect the domain? |
| Orchestrator | central process coordinating multiple calls or steps and owning workflow state | Which state machine, timeout, compensation, and audit trail exist? |
| Choreography | distributed flow where participants react to events without a central controller | Which events, owners, and compatibility rules keep the flow coherent? |
| Canonical Model | normalized representation used inside an integration boundary | Who owns it and how is lossiness handled? |
| Idempotency Key | request or event key enabling safe repeat processing | Which duplicate key is stable across retries? |
| Correlation ID | identifier linking related calls and events across a business flow | Where is it generated and propagated? |
| Trace ID | distributed tracing identifier tying telemetry spans together | Which telemetry propagation format carries it? |
| Dead Letter Queue | destination for messages that cannot be processed after retry policy | Who monitors, replays, and resolves it? |
| Event | record of an occurrence and its relevant data/context | Who owns schema and compatibility? |
| Command | request for another component to perform an action | Is it idempotent and authorized? |
| Topic | named publish/subscribe channel, commonly many consumers | What partitioning and ordering semantics apply? |
| Queue | work distribution channel, commonly one consumer instance per message | What visibility timeout, retry, and poison handling apply? |
| Schema | structural definition of a payload or message | Which dialect/version is used? |
| Replay | controlled reprocessing of stored events or messages | What prevents duplication and stale side effects? |
| Retry Policy | rules for repeating a failed operation | Does it include timeout, backoff, jitter, max attempts, and idempotency? |

## API styles

| Style | Use when | Watch for |
|---|---|---|
| REST/HTTP API | resource-oriented request/response over HTTP semantics | weak resource design, inconsistent errors, missing idempotency |
| RPC/gRPC | explicit service methods and typed payloads are primary | missing deadlines, cancellation, and retry policy |
| GraphQL | clients need typed graph query and selected response shape | resolver sprawl, N+1 calls, missing authz, complexity abuse |
| Event API | producers and consumers exchange events or commands asynchronously | schema evolution, ordering, replay, consumer compatibility |
| Webhook | external provider calls back into owned HTTP endpoint | signature, raw body, idempotency, replay, ACK strategy |
| Batch/file integration | scheduled or bulk transfer with reconciliation | partial failure, checksum, retention, idempotent import |
| Agent/tool API | LLM or agent consumes bounded operations | overbroad tools, unsafe defaults, ambiguous schemas, destructive actions |

## Architecture decision axes

- synchronous vs asynchronous
- orchestration vs choreography
- canonical model vs point-to-point mapping
- public API vs internal API vs partner API vs agent/tool API
- strong consistency vs eventual consistency
- gateway policy vs service-local policy
- schema-first vs code-first
- generated code vs hand-written adapters
- centralized integration platform vs product-team-owned integration
- provider-controlled contract vs owned contract

## Required invariants

- Every cross-boundary API needs a contract.
- Every external input needs validation.
- Every protected resource needs object/resource and function/action authorization.
- Every retryable write needs idempotency semantics.
- Every asynchronous flow needs ordering, deduplication, retry, DLQ, and replay policy.
- Every production middleware flow needs traceability.

## Limits

This ontology defines vocabulary. It does not prove that a given system implements these concepts.

## Validation questions

- Are consumers, producers, contracts, and owners named?
- Is the component a gateway, BFF, adapter, connector, ACL, orchestrator, or choreography participant?
- Where is the trust boundary?
- Which IDs support idempotency, correlation, tracing, and replay?
