# Evaluation Plan

## Purpose

Define scenarios that test whether the middleware-api-architect skill produces safe, evidence-separated, implementation-ready architecture outputs.

## When to use

Use this file when reviewing the skill, creating regression checks, or testing an agent that claims to follow this skill.

## Evaluation method

For each scenario, compare the output against expected behaviors and failure criteria. A passing answer must separate FACT, INFERENCE, ASSUMPTION, SOURCE_NEEDED, and MISSING where relevant.

## Scenario 1: Partner REST API middleware

Input: design middleware between CRM and ERP using HTTP APIs with OAuth.

Expected output:

- contract-first plan with OpenAPI inventory
- adapter and anti-corruption layer
- OAuth token handling without storing secrets in code
- authn and authz separated
- idempotency for write operations
- retry, timeout, backoff, and error mapping
- Problem Details or equivalent error model
- observability and contract tests

Failure if:

- invents endpoints
- omits authz or token lifecycle
- recommends blind retries for non-idempotent writes
- skips contract inventory

## Scenario 2: Webhook ingestion pipeline

Input: webhook events from a payment provider into an internal order service.

Expected output:

- receive, verify, validate, dedupe, queue, process, persist, ACK, observe stages
- raw body signature verification note
- idempotency using provider id plus provider event id
- replay protection
- durable acceptance before ACK or provider-specific retry strategy
- DLQ and retry policy
- event schema and audit log
- no secret or sensitive payload logging

Failure if:

- processes synchronously without latency/failure justification
- omits signature verification
- lacks duplicate handling
- acknowledges before durable acceptance without explaining provider retry semantics

## Scenario 3: Event-driven architecture

Input: design order, inventory, and shipping integration over Kafka or pub/sub.

Expected output:

- AsyncAPI or equivalent event contract strategy
- event ownership and topic/channel model
- ordering, dedupe, schema versioning, replay
- producer/consumer compatibility strategy
- choreography vs orchestration trade-off
- DLQ and poison-message handling
- observability across producer, broker, and consumer

Failure if:

- treats events as REST calls over a queue
- omits schema evolution
- omits failure and replay behavior

## Scenario 4: Agent-ready API wrapping

Input: expose existing OpenAPI to an LLM agent or MCP-like tool layer.

Expected output:

- endpoint narrowing and operation allowlist
- contract smell and security audit
- safe schemas and examples
- non-destructive defaults
- guarded destructive actions
- clear error models
- auth boundary and rate limits
- evaluation cases for tool selection and payload construction

Failure if:

- exposes full API surface without scoping
- omits destructive-action guardrails
- ignores semantic documentation quality

## Scenario 5: Existing architecture audit

Input: repository or diagrams plus API specs.

Expected output:

- evidence table
- reconstructed architecture
- contract coverage
- gap matrix with severity and confidence
- remediation backlog
- explicit MISSING and SOURCE_NEEDED markers

Failure if:

- claims runtime behavior without logs, tests, configs, or trace evidence
- fails to separate evidence from inference
- treats diagrams as proof of runtime behavior

## Scenario 6: GraphQL gateway/BFF review

Input: mobile BFF uses GraphQL to aggregate account, billing, and support data.

Expected output:

- SDL and resolver ownership questions
- object, field, and action authorization review
- query complexity/depth controls
- downstream auth propagation
- N+1 mitigation and latency budget
- observability per resolver and downstream call

Failure if:

- treats GraphQL schema as sufficient security
- ignores field-level data exposure
- omits complexity and depth controls

## Scenario 7: gRPC service-to-service design

Input: internal pricing service accessed by checkout over gRPC.

Expected output:

- proto contract strategy
- deadline and cancellation policy
- metadata and auth propagation
- retry and hedging constraints
- typed error mapping
- compatibility and generated-code strategy

Failure if:

- omits deadlines
- recommends retries without idempotency or service-config consideration
- treats proto generation as architecture design by itself

## Scoring rubric

| Score | Meaning |
|---|---|
| 5 | complete, evidence-separated, all gates addressed, implementation-ready |
| 4 | strong, minor missing details labeled clearly |
| 3 | usable draft, several assumptions or missing gates |
| 2 | unsafe or under-specified in important areas |
| 1 | hallucinated, security-blind, or not contract-aware |

## Validation questions

- Does the answer choose the smallest useful output mode?
- Does the answer block unsafe implementation claims?
- Does the answer include contract, security, reliability, data, observability, and tests?
- Does the answer avoid inventing endpoints, payloads, provider behavior, and runtime evidence?
