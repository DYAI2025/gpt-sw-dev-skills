# Output Templates

## Purpose

Provide stable output shapes for the middleware-api-architect skill.

## When to use

Use the smallest template that satisfies the user's intent. Do not emit a full package when a table, decision, or brief is enough.

## Architecture brief

```markdown
# Middleware/API Architecture Brief

## Objective
## Evidence received
## Assumptions and missing facts
## Context boundary
## Recommended architecture
## Component map
## Runtime flow
## Contracts and schemas
## Security model
## Pipeline and failure behavior
## Observability
## Tests and acceptance criteria
## Risks, trade-offs, and decisions
## Confidence
```

## Implementation plan

```markdown
# Implementation Plan

## Goal
## Non-goals
## Target file tree
## Contracts to add/change
## Implementation tasks
## Security tasks
## Observability tasks
## Tests
## Migration/rollout
## Definition of Done
## Open questions
```

## Audit report

```markdown
# Middleware/API Audit Report

## Evidence received
## Architecture reconstruction
## Contract coverage
## Security and authz gaps
## Data/pipeline gaps
## Observability gaps
## Reliability and failure-mode gaps
## Gap matrix
## Remediation backlog
## Confidence score
```

## Contract inventory

```markdown
| Interface | Style | Contract | Owner | Version | Auth | Consumers | Risk |
|---|---|---|---|---|---|---|---|
```

## Pipeline stage table

```markdown
| Stage | Responsibility | Input | Output | Failure mode | Control/Test |
|---|---|---|---|---|---|
```

## Gap matrix

```markdown
| Area | Expected | Evidence | Gap | Severity | Confidence | Remediation |
|---|---|---|---|---|---|---|
```

## Decision matrix

```markdown
| Option | Fit | Benefits | Costs/Risks | Required evidence | Decision |
|---|---|---|---|---|---|
```

## Evidence ledger

```markdown
| Claim | Evidence | Label | Confidence | Impact |
|---|---|---|---|---|
```

## Mermaid component diagram

```mermaid
flowchart LR
  Consumer[Consumer] --> Gateway[API Gateway]
  Gateway --> Service[Service or BFF]
  Service --> Adapter[Adapter or Connector]
  Adapter --> External[External System]
```

## Mermaid sequence diagram

```mermaid
sequenceDiagram
  participant C as Consumer
  participant G as Gateway
  participant S as Service
  participant Q as Queue
  C->>G: Request
  G->>S: Authenticated request with correlation id
  S->>Q: Durable message
  S-->>G: Accepted
  G-->>C: Response
```

## Limits

Templates are output structures, not proof that an implementation exists.

## Validation questions

- Does the selected template match the task?
- Are evidence labels present where claims matter?
- Are risks and open questions visible?
- Are tables filled with concrete values rather than generic filler?
