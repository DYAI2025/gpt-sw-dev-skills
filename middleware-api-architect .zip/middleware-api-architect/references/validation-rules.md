# Validation Rules

## Purpose

Define mandatory quality gates for middleware/API architecture outputs.

## When to use

Use before finalizing every architecture brief, implementation plan, audit report, and coding-agent handoff.

## Contract gates

- Public or cross-team HTTP APIs have OpenAPI or an equivalent explicit contract.
- Message-driven APIs have AsyncAPI or an equivalent event contract.
- JSON payload validation identifies the JSON Schema dialect when relevant.
- gRPC services have proto files plus explicit deadlines, cancellation, and retry policy.
- GraphQL APIs have schema, resolver ownership, authz strategy, and complexity/depth controls.
- Webhooks have provider contract, payload schema, signature model, idempotency model, and retry expectations.
- Batch/file integrations have schema, manifest, checksum or integrity check, reconciliation, and retention rules.
- Error response model is documented and consistent.
- Versioning and deprecation policy exists.

## Security gates

- Authentication mechanism is explicit.
- Authorization is checked at object/resource and function/action level.
- Tenant boundary is defined when multi-tenant.
- Secrets are never embedded in code, contracts, examples, prompts, or logs.
- Input validation exists at boundary and domain level.
- Rate, quota, payload, and resource limits are defined for public, partner, agent, and expensive APIs.
- SSRF risk is handled for any user-controlled outbound URL.
- Third-party API consumption is treated as untrusted input.
- Sensitive data classification is marked when applicable.
- Audit events cover security-relevant decisions without logging sensitive payloads by default.

## Reliability gates

- Timeouts are explicit for all outbound calls.
- Retry policy distinguishes safe from unsafe operations.
- Idempotency exists for retried writes, webhook ingestion, event consumers, and replay.
- Backoff and jitter are defined for retry storms.
- Circuit breaker and bulkhead strategy are considered for unstable dependencies.
- Async flows define ordering, dedupe, replay, DLQ, poison-message handling, and manual recovery.
- Synchronous composition has latency budget and fallback behavior.
- Long-running workflows define durable state, compensation, and timeout policy.

## Data gates

- Data owner is known for each canonical entity.
- Transformation is documented, testable, and versioned.
- Lossy mappings are explicit.
- PII and sensitive data are marked when applicable.
- Pagination, filtering, sorting, and bulk semantics are stable for collections.
- Schema compatibility is considered for producer/consumer evolution.
- Reconciliation exists for batch/file or eventually consistent flows.

## Observability gates

- Trace or correlation propagation is defined across API, gateway, queue, worker, datastore, and external calls.
- Logs exclude secrets and sensitive payloads by default.
- Metrics include latency, throughput, error rate, retry count, DLQ depth, saturation, and provider quota pressure where relevant.
- Alerts map to user or business impact where possible.
- Operational owner, dashboard, and runbook expectations are stated for production systems.

## Failure gates

Block final implementation claims when:

- endpoint behavior is inferred without contract, code, log, trace, or verified example evidence
- authz is missing or delegated vaguely to a future layer
- retries exist without idempotency for write operations
- events lack schema and compatibility policy
- webhook signature verification omits raw body preservation
- async flows lack DLQ or poison-message strategy
- security, observability, or test strategy is absent
- standards or version claims are not sourced when current correctness matters

## Limits

These gates do not prove production readiness. They identify whether the architecture output is coherent enough for implementation planning or further review.

## Validation questions

- Which gates pass, fail, or remain MISSING?
- Which failed gates block implementation?
- Which failed gates merely reduce confidence?
- Which gates require primary-source or runtime verification?
