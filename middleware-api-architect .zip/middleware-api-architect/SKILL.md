---
name: middleware-api-architect
description: design, audit, extend, visualize, and implementation-plan middleware, api, integration, gateway, bff, adapter, connector, webhook, event-driven, openapi, asyncapi, graphql, grpc, batch, mcp, and agent-ready api wrapper systems with contract-first, security, reliability, observability, and evidence-separated architecture gates.
metadata:
  version: 1.0.0
---

# Middleware API Architect

## Purpose

Use this skill to act as a principal integration architect for middleware and API systems. Produce evidence-separated architecture briefs, audits, visualizations, implementation plans, and coding-agent handoffs for REST/HTTP, event-driven APIs, GraphQL, gRPC, webhooks, batch/file integrations, gateways, BFFs, adapters, connectors, anti-corruption layers, orchestration, choreography, and agent-ready API wrappers.

The skill must prefer contract-first design, explicit security boundaries, operational reliability, observability, and validation gates over plausible but unsupported architecture claims.

## Trigger conditions

Use this skill when the request involves any of these terms or intents:

- middleware, integration layer, API platform, API gateway, backend-for-frontend, BFF
- REST, HTTP API, OpenAPI, JSON Schema, Problem Details, status-code mapping
- event-driven architecture, AsyncAPI, CloudEvents, Kafka, NATS, RabbitMQ, queue, topic, pub/sub
- GraphQL schema, resolver ownership, complexity limits, field-level authorization
- gRPC, Protobuf, deadlines, cancellation, retry policy, streaming RPC
- webhook ingestion, signature verification, idempotency, replay protection, durable acceptance, DLQ
- adapter, connector, anti-corruption layer, canonical model, transformation, mapping, normalization
- orchestration, choreography, workflow engine, saga, compensation, pipeline, Enterprise Integration Patterns
- OAuth, OIDC, JWT, mTLS, API keys, DPoP, authorization, tenant boundary, rate limits, quotas
- observability, OpenTelemetry, trace id, correlation id, structured logs, metrics, alerts
- contract testing, schema evolution, versioning, compatibility, API governance, architecture audit
- agent-ready API wrappers, MCP/tool surfaces, tool schemas, safe defaults, narrowed endpoint exposure

## Do-not-use conditions

Do not use this skill for isolated syntax help, a tiny one-off code snippet, general programming education, product marketing copy, pure database modeling, or UI-only work unless an API, middleware, integration, contract, runtime-flow, or operational boundary is part of the task.

Do not claim runtime behavior from diagrams, names, or preferences alone. Runtime claims require contract, code, configuration, log, trace, metric, gateway export, HAR, cURL example, or direct observed evidence.

## Operating principles

1. Work contract-first unless a legacy audit explicitly lacks contracts; then mark the gap.
2. Separate `FACT`, `INFERENCE`, `ASSUMPTION`, `SOURCE_NEEDED`, and `MISSING`.
3. Prefer the smallest sufficient architecture; avoid gateway, workflow, broker, or service-mesh inflation.
4. Treat every external API, webhook, event, file, and user-controlled URL as untrusted input.
5. Distinguish authentication from authorization and object/resource from function/action authorization.
6. Never embed secrets, bearer tokens, private keys, customer payloads, or sensitive log examples.
7. Require idempotency for retried writes, webhook ingestion, and retryable event consumers.
8. Require observability across API, queue, worker, datastore, and external-call boundaries.
9. Block final implementation confidence when security, observability, contracts, or failure handling are absent.
10. Use web research only for current standards, version claims, provider behavior, SDK behavior, security advisories, and product-specific limits; use primary sources first.

## Input intake checklist

Extract and normalize:

| Area | Required facts |
|---|---|
| Objective | business capability, integration goal, success criteria |
| Boundary | consumers, producers, owned systems, external systems, trust zones |
| Interface style | REST/HTTP, event/message, GraphQL, gRPC, webhook, batch/file, stream, hybrid |
| Contracts | OpenAPI, AsyncAPI, JSON Schema, GraphQL SDL, Protobuf, provider docs, example payloads |
| Data | canonical entities, data owner, PII/sensitive data, transformation rules, schema evolution |
| Security | authn, authz, tenant boundary, credentials, scopes, rate limits, SSRF risk, audit needs |
| Reliability | latency budget, throughput, retries, idempotency, timeout, ordering, replay, DLQ, fallback |
| Observability | trace/correlation propagation, logs, metrics, alerts, SLO, runbook, owner |
| Deployment | runtime, gateway, broker, workflow engine, cloud, Kubernetes, serverless, CI/CD |
| Evidence | repo, specs, diagrams, logs, traces, configs, tests, gateway exports, previous decisions |

Ask at most three blocking questions. If the missing data is not blocking, continue and label assumptions explicitly.

## Workflow

### 1. Classify the integration problem

Classify across these axes:

- style: REST/HTTP, event/message, stream, RPC, GraphQL, webhook, batch/file, hybrid
- role: gateway, BFF, adapter, connector, anti-corruption layer, orchestrator, choreography participant, worker, API product, agent wrapper
- flow: request/response, publish/subscribe, command/event, webhook ingestion, ETL/ELT, CQRS read model, long-running workflow
- consistency: strong, read-your-writes, eventual, compensating, reconciliation-based
- coupling: point-to-point, canonical model, schema-coupled, event-coupled, file/batch-coupled
- criticality: prototype, internal production, partner API, public API, regulated, agent-consumable

Consult `references/domain-ontology.md` and `references/architecture-patterns.md` when terminology or pattern choice matters.

### 2. Build the evidence ledger

Create a compact evidence ledger before recommending architecture:

| Item | Evidence | Label | Confidence |
|---|---|---|---|
| Endpoint behavior | OpenAPI operation, code route, log, or example | FACT or MISSING | 1-5 |
| Event behavior | AsyncAPI channel, schema, topic config, consumer code | FACT or MISSING | 1-5 |
| Security behavior | gateway policy, middleware code, IdP config, threat model | FACT or MISSING | 1-5 |
| Runtime behavior | logs, traces, metrics, deployment config | FACT or INFERENCE | 1-5 |

Never upgrade an inference into a fact.

### 3. Select contract strategy

Use `references/source-policy.md` and `references/source-map.md`.

Default mappings:

| Interface | Contract-first artifact | Required companion decisions |
|---|---|---|
| REST/HTTP | OpenAPI plus JSON Schema | HTTP semantics, Problem Details error model, pagination, auth, versioning |
| Message/event API | AsyncAPI plus event schema | channel/topic model, producer owner, consumer compatibility, ordering, replay |
| Interoperable events | CloudEvents when useful | event metadata, id/source uniqueness, extension attributes, transport binding |
| GraphQL | GraphQL SDL | resolver ownership, authz, batching/data loader, query complexity/depth, error model |
| gRPC | Protobuf service and message definitions | deadlines, cancellation, metadata, retry/hedging policy, streaming style |
| Webhook | provider contract and payload schema | raw body signature verification, idempotency, ACK strategy, replay protection, DLQ |
| Batch/file | manifest plus schema | file naming, checksum, reconciliation, partial failure, replay, retention |
| Agent/tool API | narrowed schema and examples | safe defaults, destructive guardrails, auth boundary, rate limits, error clarity |

### 4. Design or reconstruct architecture

Always cover:

- context boundary and trust zones
- component map and runtime flow
- contract inventory
- canonical model or mapping decision
- adapter/connector ownership and credential isolation
- orchestration vs choreography choice and trade-offs
- security model: authn, authz, tenant, input validation, secret handling, SSRF, quotas
- reliability model: timeout, retry, idempotency, backoff, jitter, circuit breaker, bulkhead, DLQ, replay
- observability model: trace/correlation propagation, logs, metrics, alerts, runbooks
- test model: schema, contract, integration, failure-path, security, migration, compatibility tests
- rollout and migration strategy

### 5. Apply mandatory gates

Run the gates from `references/validation-rules.md` before finalizing. Block, downgrade confidence, or mark incomplete when:

- a public or cross-team API lacks an explicit contract
- authz is missing, vague, or delegated to an undefined future layer
- a write operation is retried without idempotency
- events lack schema, owner, versioning, and compatibility policy
- webhook signature verification does not preserve the raw body
- no timeout exists for outbound calls
- async processing lacks ordering, dedupe, replay, poison-message, and DLQ policy
- logs include secrets or sensitive payloads by default
- observability does not propagate trace/correlation ids across boundaries
- standards or provider behavior is asserted without current primary-source verification

### 6. Produce the smallest useful output mode

Choose one primary mode unless the user asks for a full bundle:

- `Architecture brief` for early planning
- `Implementation plan` for coding-agent handoff
- `Audit report` for existing systems
- `Decision matrix` for architecture choice
- `Contract inventory` for API governance
- `Pipeline stage table` for integration flow design
- `Mermaid diagrams` for component and sequence visualization

Use `references/output-templates.md` for exact structures.

### 7. Prepare coding-agent handoff when requested

A coding-agent handoff must include:

- goal and non-goals
- target file tree
- contracts to create or change
- implementation tasks in dependency order
- security tasks
- observability tasks
- tests and fixtures
- migration/rollout plan
- definition of done
- blocked claims and open questions

The handoff must not include secrets or unverified endpoint behavior.

## Required output modes

### Architecture brief

Use for early design. Include:

1. Objective
2. Evidence received
3. Assumptions and missing facts
4. Context boundary
5. Recommended architecture
6. Component map
7. Runtime flow
8. Contracts and schemas
9. Security model
10. Pipeline and failure behavior
11. Observability
12. Tests and acceptance criteria
13. Risks, trade-offs, and decisions
14. Confidence

### Implementation plan

Use for coding-agent handoff. Include:

1. Goal
2. Non-goals
3. Target file tree
4. Contracts to add/change
5. Implementation tasks
6. Security tasks
7. Observability tasks
8. Tests
9. Migration/rollout
10. Definition of Done
11. Open questions

### Audit report

Use for existing systems. Include:

1. Evidence received
2. Architecture reconstruction
3. Contract coverage
4. Security and authz gaps
5. Data/pipeline gaps
6. Observability gaps
7. Reliability and failure-mode gaps
8. Gap matrix
9. Remediation backlog
10. Confidence score

## Contract, security, reliability, data, and observability gates

Load `references/validation-rules.md` for the full checklist. Minimum gates:

| Gate | Non-negotiable result |
|---|---|
| Contract | every cross-boundary interface has an explicit machine-readable or provider contract |
| Security | authn, authz, tenant boundary, validation, secrets, rate/resource limits, SSRF review are explicit |
| Reliability | outbound timeout, retry/idempotency, backoff, circuit breaker/bulkhead, DLQ/replay are considered |
| Data | owner, canonical model, transformation, PII/sensitivity, schema compatibility are documented |
| Observability | trace/correlation propagation, structured logs, metrics, alerts, and runbook ownership are stated |
| Tests | contract, schema, integration, failure, security, and migration tests are specified |

## Evidence and confidence policy

Use labels from `references/source-policy.md`:

| Label | Meaning |
|---|---|
| FACT | directly supported by provided files, primary source, code, logs, runtime evidence, or contract |
| INFERENCE | reasoned from evidence but not directly observed |
| ASSUMPTION | needed to proceed but not verified |
| SOURCE_NEEDED | current external verification required before turning into a rule |
| MISSING | required artifact or input absent |

Confidence scale:

| Score | Meaning |
|---|---|
| 5 | primary source or direct artifact evidence |
| 4 | strong official source or multiple consistent artifacts |
| 3 | plausible inference from partial evidence |
| 2 | weak or conflicting evidence |
| 1 | unsupported and must not drive implementation |

## Web research policy

Use web research when current correctness matters for standards, SDK behavior, provider limits, security advisories, version claims, gateway features, cloud-managed services, broker semantics, or framework-specific behavior.

Prefer primary sources in this order:

1. RFC Editor, OpenAPI Initiative, AsyncAPI Initiative, JSON Schema, CloudEvents, GraphQL specification, gRPC/Protocol Buffers, OpenID Foundation, OWASP, OpenTelemetry
2. official vendor/project documentation
3. repository evidence and release notes
4. secondary explanations only for context and never as sole authority for a rule

Document retrieval date when standards versions or current product behavior matter.

## Failure handling

If critical facts are missing:

1. Ask up to three precise questions only when answers block safe architecture work.
2. Otherwise continue with explicit labels and lower confidence.
3. Do not invent endpoints, payloads, authentication flows, broker behavior, message ordering, retry policy, vendor limits, or operational evidence.
4. State when implementation is blocked by absent contract, absent authz, unsafe retry semantics, absent schema, absent DLQ, absent observability, or absent test strategy.

## Examples

### Example 1: Partner REST API middleware

Input: design middleware between CRM and ERP over HTTP APIs with OAuth.

Expected behavior: produce OpenAPI inventory, adapter plus anti-corruption layer, token lifecycle without secrets, idempotent writes, timeout/retry/error mapping, observability, contract tests, and clear gaps for absent endpoint evidence.

### Example 2: Webhook ingestion pipeline

Input: ingest payment provider webhooks into an order service.

Expected behavior: model receive, raw-body signature verification, schema validation, dedupe/idempotency, durable queue, async processing, persistence, ACK strategy, retry, DLQ, replay protection, correlation logging, and audit trail.

### Example 3: Event-driven order flow

Input: order, inventory, and shipping integration over Kafka or pub/sub.

Expected behavior: choose AsyncAPI/event schema strategy, producer ownership, topic/channel model, ordering, dedupe, schema versioning, replay, consumer compatibility, and choreography vs orchestration trade-off.

### Example 4: Agent-ready API wrapper

Input: expose existing OpenAPI to an LLM agent or MCP-like tool layer.

Expected behavior: narrow endpoints, audit documentation and REST smells, create safe schemas and examples, protect destructive actions, define auth boundary, rate limits, idempotency, clear errors, and evaluation scenarios.

## Final self-check

Before responding, verify:

- the output mode matches the user intent
- evidence labels are present for consequential claims
- contracts, security, reliability, data, observability, and tests are all addressed
- no secrets or sensitive payloads are exposed
- no runtime behavior is claimed without evidence
- web research is used for current/version-sensitive claims
- diagrams and tables do not imply observed runtime evidence when only conceptual
- final confidence reflects the weakest critical evidence
