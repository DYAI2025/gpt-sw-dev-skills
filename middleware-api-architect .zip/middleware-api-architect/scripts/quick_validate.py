#!/usr/bin/env python3
from pathlib import Path
import re
import sys

REQUIRED = [
    'SKILL.md',
    'agents/openai.yaml',
    'references/source-policy.md',
    'references/source-map.md',
    'references/domain-ontology.md',
    'references/architecture-patterns.md',
    'references/validation-rules.md',
    'references/evaluation-plan.md',
    'references/output-templates.md',
    'references/framework-tooling-map.md',
    'references/security-reference-map.md',
    'references/observability-reference-map.md',
    'examples/partner-rest-api-middleware.md',
    'examples/webhook-ingestion-pipeline.md',
    'examples/event-driven-order-flow.md',
    'examples/agent-ready-api-wrapper.md',
    'examples/existing-architecture-audit.md',
    'README.md',
]

BLOCKED_MARKERS = [
    'TO' + 'DO',
    'TB' + 'D',
    '<' + 'placeholder' + '>',
    '[' + 'cite:',
    'SOURCE_NEEDED_' + 'SOURCE_NEEDED',
    'your_' + 'api_key_here',
    'Bearer ' + 'token123',
    'ghp_' + 'xxx',
]

CORE_TERMS = [
    'contract-first',
    'idempotency',
    'observability',
    'authorization',
    'AsyncAPI',
    'OpenAPI',
    'DLQ',
    'correlation id',
]

FRONTMATTER_RE = re.compile(r'^---\n(.*?)\n---\n', re.DOTALL)
NAME_RE = re.compile(r'^name:\s*middleware-api-architect\s*$', re.MULTILINE)
DESCRIPTION_RE = re.compile(r'^description:\s*(.+)$', re.MULTILINE)
METADATA_VERSION_RE = re.compile(r'^metadata:\n(?:  .+\n)*  version:\s*1\.0\.0\s*$', re.MULTILINE)


def fail(message: str) -> None:
    print(f'FAIL: {message}')
    raise SystemExit(1)


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding='utf-8')
    except UnicodeDecodeError as exc:
        fail(f'file is not utf-8: {path}: {exc}')


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('.')
    if not root.exists() or not root.is_dir():
        fail(f'path does not exist or is not a directory: {root}')

    for rel in REQUIRED:
        path = root / rel
        if not path.exists():
            fail(f'missing required file: {rel}')
        if path.stat().st_size == 0:
            fail(f'empty required file: {rel}')

    skill = read_text(root / 'SKILL.md')
    match = FRONTMATTER_RE.match(skill)
    if not match:
        fail('SKILL.md frontmatter missing or invalid')
    frontmatter = match.group(1)
    if not NAME_RE.search(frontmatter):
        fail('SKILL.md frontmatter name missing or invalid')
    desc_match = DESCRIPTION_RE.search(frontmatter)
    if not desc_match:
        fail('SKILL.md description missing')
    description = desc_match.group(1).strip()
    if '<' in description or '>' in description:
        fail('SKILL.md description contains angle brackets')
    if not METADATA_VERSION_RE.search(frontmatter):
        fail('SKILL.md metadata.version 1.0.0 missing')

    all_text = []
    for path in root.rglob('*'):
        if path.is_file() and path.suffix in {'.md', '.yaml', '.yml', '.py', '.txt'}:
            text = read_text(path)
            rel = path.relative_to(root).as_posix()
            all_text.append(text)
            for marker in BLOCKED_MARKERS:
                if marker in text:
                    fail(f'blocked marker {marker!r} found in {rel}')

    joined = '\n'.join(all_text)
    for term in CORE_TERMS:
        if term not in joined:
            fail(f'core term missing: {term}')

    print('OK: middleware-api-architect skill package structure and content checks passed')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
