# middleware-api-architect

## Purpose

`middleware-api-architect` is a ChatGPT skill for designing, auditing, extending, visualizing, and implementation-planning middleware, API, and integration systems.

It supports REST/HTTP APIs, OpenAPI, JSON Schema, Problem Details, AsyncAPI, CloudEvents, Kafka/pub-sub/queue flows, GraphQL, gRPC/Protobuf, webhooks, batch/file integrations, gateways, BFFs, adapters, connectors, anti-corruption layers, workflow orchestration, event choreography, observability, reliability, API security, and agent-ready API wrappers.

## Package structure

```text
middleware-api-architect/
  SKILL.md
  agents/openai.yaml
  references/
    source-policy.md
    source-map.md
    domain-ontology.md
    architecture-patterns.md
    validation-rules.md
    evaluation-plan.md
    output-templates.md
    framework-tooling-map.md
    security-reference-map.md
    observability-reference-map.md
  scripts/quick_validate.py
  examples/
    partner-rest-api-middleware.md
    webhook-ingestion-pipeline.md
    event-driven-order-flow.md
    agent-ready-api-wrapper.md
    existing-architecture-audit.md
```

## Validation

Run the bundled validator from the parent directory or repository root:

```bash
python middleware-api-architect/scripts/quick_validate.py middleware-api-architect
```

For ChatGPT skill packaging, use the environment's official packaging script:

```bash
python /home/oai/skills/skill-creator/scripts/package_skill.py middleware-api-architect ./dist
```

## Design notes

- Version is stored as `metadata.version` in `SKILL.md` and as `version` in `agents/openai.yaml` because the current ChatGPT skill validator allows only selected top-level frontmatter keys.
- The skill is evidence-first. It must not infer runtime behavior from diagrams alone.
- Security, reliability, observability, and tests are mandatory gates, not optional sections.
- Current version-sensitive claims should be checked against primary sources at task time.
