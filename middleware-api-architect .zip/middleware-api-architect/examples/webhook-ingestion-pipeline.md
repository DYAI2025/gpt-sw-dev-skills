# Example: Webhook Ingestion Pipeline

## User intent

Design a payment-provider webhook ingestion pipeline into an internal order service.

## Expected skill response shape

```markdown
# Middleware/API Architecture Brief

## Objective
Receive payment provider webhooks safely, verify authenticity, deduplicate events, accept them durably, process asynchronously, and expose replayable operational evidence.

## Evidence received
| Claim | Evidence | Label | Confidence |
|---|---|---|---|
| events come from payment provider | user statement | FACT | 3 |
| order service is target | user statement | FACT | 3 |
| signature scheme | not provided | MISSING | 1 |

## Recommended architecture
Use a webhook ingress endpoint that preserves the raw request body for signature verification, validates the provider payload schema, computes idempotency from provider id plus provider event id, writes a durable inbox record, enqueues processing, and returns ACK according to provider retry expectations.

## Pipeline stage table
| Stage | Responsibility | Input | Output | Failure mode | Control/Test |
|---|---|---|---|---|---|
| receive | accept HTTP callback | raw HTTP request | raw body plus headers | malformed request | request size and content-type limit |
| verify | validate signature using raw body | raw body and signature header | verified provider event | invalid signature | negative signature test |
| validate | check schema and required fields | verified event | normalized event | schema mismatch | JSON Schema test fixtures |
| dedupe | enforce idempotency | provider id plus event id | new or duplicate decision | duplicate replay | unique constraint test |
| enqueue | durable async handoff | inbox record | queue message | broker unavailable | transactional outbox or retry |
| process | apply domain behavior | queue message | order update | dependency failure | retry with backoff |
| persist | store outcome | domain command | state and audit | conflict | idempotent update test |
| acknowledge | response to provider | durable acceptance | HTTP status | premature ACK | provider retry contract test |
| observe | emit telemetry | all stages | logs, metrics, traces | blind failure | dashboard and alert checks |
| DLQ | capture exhausted failures | failed message | triage item | poison message loop | DLQ replay test |

## Security model
Never log secrets, signature material, or full sensitive payloads. Reject unsigned or invalid events. Treat provider payload as untrusted until verified and validated.

## Reliability model
Use explicit timeouts. Retry processing with backoff and jitter. Send unrecoverable or exhausted failures to DLQ with failure reason and replay eligibility.

## Confidence
3 until provider signature, retry, and event schema contracts are supplied.
```

## Evaluation notes

A poor response parses JSON before signature verification, omits idempotency, or acknowledges before durable acceptance without analyzing provider retry behavior.
