# Example: Partner REST API Middleware

## User intent

Design middleware between a CRM and ERP using partner HTTP APIs and OAuth-based access.

## Expected skill response shape

```markdown
# Middleware/API Architecture Brief

## Objective
Create a contract-first partner API middleware layer that maps CRM account/order updates into ERP operations without leaking external data models into the internal domain.

## Evidence received
| Claim | Evidence | Label | Confidence |
|---|---|---|---|
| CRM and ERP communicate through HTTP APIs | user statement | FACT | 3 |
| OAuth is required | user statement | FACT | 3 |
| endpoint list exists | not provided | MISSING | 1 |

## Assumptions and missing facts
- ASSUMPTION: partner APIs support sandbox testing.
- MISSING: OpenAPI documents or provider API docs for CRM and ERP.
- MISSING: object-level authorization rules for account and order resources.

## Recommended architecture
Use an adapter plus anti-corruption layer behind an internal API. Keep partner credentials isolated in the connector. Use OpenAPI contracts for internal endpoints and provider-contract snapshots for external calls.

## Runtime flow
Consumer -> Internal API -> Authz middleware -> CRM/ERP adapter -> Provider connector -> Partner API.

## Contracts and schemas
| Interface | Style | Contract | Owner | Version | Auth | Consumers | Risk |
|---|---|---|---|---|---|---|---|
| Internal account sync API | REST/HTTP | OpenAPI required | integration team | MISSING | OAuth/OIDC or service token | internal services | medium |
| ERP provider API | REST/HTTP | provider docs or OpenAPI required | ERP vendor | MISSING | OAuth token | adapter | high |

## Security model
Separate authentication from authorization. Validate object ownership before write operations. Store OAuth client credentials in a secret manager. Do not log access tokens or provider payloads.

## Pipeline and failure behavior
Set outbound timeouts. Retry reads only when safe. Retry writes only with idempotency keys. Use backoff and jitter. Map provider errors into a consistent internal error model.

## Observability
Propagate trace id and correlation id across internal API, adapter, and provider calls. Log provider request id when available without sensitive payloads.

## Tests and acceptance criteria
- OpenAPI lint and schema validation pass.
- Contract tests cover success, 4xx, 5xx, timeout, token expiry, and idempotent duplicate write.
- Authorization tests prove object-level checks.

## Confidence
3 until provider contracts, token lifecycle, and endpoint behavior are supplied.
```

## Evaluation notes

A poor response invents CRM/ERP endpoints, retries all writes blindly, or treats OAuth as sufficient authorization.
