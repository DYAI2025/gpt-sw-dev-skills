# Example: Agent-Ready API Wrapper

## User intent

Expose selected existing API capabilities to an LLM agent or MCP-like tool layer.

## Expected skill response shape

```markdown
# Implementation Plan

## Goal
Create a narrowed, safe, agent-ready wrapper around selected API operations with explicit schemas, examples, auth boundary, rate limits, idempotency, and destructive-action guardrails.

## Non-goals
- Do not expose the full API surface.
- Do not allow destructive actions by default.
- Do not rely on prompt-only security.

## Evidence received
| Claim | Evidence | Label | Confidence |
|---|---|---|---|
| source API has OpenAPI | user statement or file | FACT if provided | 3-5 |
| intended agent tasks | user statement | FACT | 3 |
| auth policy | not provided | MISSING | 1 |

## Contracts to add/change
- Create an operation allowlist.
- Normalize request schemas to strict tool inputs.
- Add examples for common and edge cases.
- Define typed, non-sensitive error responses.
- Add idempotency key for write tools.

## Security tasks
- Enforce authentication and authorization outside the model.
- Add rate limits and quotas per agent/client.
- Require confirmation or explicit mode for destructive actions.
- Redact secrets and sensitive payloads in logs and tool errors.

## Tests
- Tool selection tests for realistic user tasks.
- Payload construction tests from natural-language prompts.
- Negative tests for destructive action without confirmation.
- Authz denial tests.
- Idempotent retry tests for writes.

## Definition of Done
Wrapper exposes only approved operations, passes schema validation, handles clear errors, rejects unsafe calls, and includes evaluation scenarios with single verifiable expected outcomes.
```

## Evaluation notes

A poor response wraps every endpoint, ignores authorization, or assumes OpenAPI structural validity means agent readiness.
