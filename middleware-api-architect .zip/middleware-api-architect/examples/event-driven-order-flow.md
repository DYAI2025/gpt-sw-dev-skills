# Example: Event-Driven Order Flow

## User intent

Design order, inventory, and shipping integration over Kafka or pub/sub.

## Expected skill response shape

```markdown
# Middleware/API Architecture Brief

## Objective
Coordinate order lifecycle events across order, inventory, and shipping services while preserving producer ownership, schema compatibility, replay safety, and operational traceability.

## Architecture decision
| Option | Fit | Benefits | Costs/Risks | Required evidence | Decision |
|---|---|---|---|---|---|
| choreography | high if eventual consistency is acceptable | service autonomy, loose runtime coupling | harder global visibility, replay coordination | event ownership and SLO | likely default |
| orchestration | high if central state or compensation dominates | explicit workflow state and audit | central dependency and workflow complexity | compensation rules | use for payment/shipping saga if required |

## Event contract strategy
Use AsyncAPI or equivalent event contracts for each producer-owned event. Define event name, producer, schema version, channel/topic, ordering key, compatibility rules, and replay policy.

## Contract inventory
| Interface | Style | Contract | Owner | Version | Auth | Consumers | Risk |
|---|---|---|---|---|---|---|---|
| OrderCreated | Event | AsyncAPI plus event schema required | order service | MISSING | broker auth | inventory, shipping | high |
| InventoryReserved | Event | AsyncAPI plus schema required | inventory service | MISSING | broker auth | order, shipping | high |

## Failure behavior
Define retry with backoff, DLQ, poison-message handling, replay windows, dedupe by event id, and ordering key. Consumers must be idempotent.

## Observability
Propagate trace context through message metadata when supported. Log correlation id, event id, schema version, consumer name, attempt count, and failure reason.

## Confidence
3 until broker semantics, ordering guarantees, event schemas, and consumer compatibility policy are provided.
```

## Evaluation notes

A poor response treats events as hidden synchronous calls or omits schema evolution and replay behavior.
