# Example: Existing Architecture Audit

## User intent

Audit an existing middleware/API system from repository files, diagrams, API specs, and partial runtime evidence.

## Expected skill response shape

```markdown
# Middleware/API Audit Report

## Evidence received
| Artifact | What it proves | What it does not prove | Confidence |
|---|---|---|---|
| architecture diagram | intended components and flows | actual runtime behavior | 3 |
| OpenAPI file | declared HTTP operations | implementation correctness | 4 |
| service code | route and middleware behavior | production traffic behavior | 4 |
| logs/traces | observed runtime behavior | complete coverage | 4 |

## Architecture reconstruction
Reconstruct only what evidence supports. Mark inferred flows separately from observed flows.

## Contract coverage
| Interface | Expected | Evidence | Gap | Severity | Confidence | Remediation |
|---|---|---|---|---|---|---|
| public HTTP API | OpenAPI | openapi.yaml | incomplete error model | medium | 4 | add Problem Details responses |
| event consumer | AsyncAPI or event schema | not found | no event contract | high | 1 | define event schema and compatibility policy |

## Security and authz gaps
Separate authentication evidence from authorization evidence. Mark missing object-level and function-level checks as high severity when protected resources exist.

## Observability gaps
Check whether trace/correlation ids cross gateway, service, queue, worker, database, and external calls.

## Remediation backlog
1. Add missing event contracts.
2. Add authz tests for protected operations.
3. Add idempotency and retry tests for writes and consumers.
4. Add DLQ monitoring and replay runbook.

## Confidence score
Score is limited by absent runtime evidence and missing event contracts.
```

## Evaluation notes

A poor response treats a diagram as production truth or reports runtime behavior without logs, traces, configs, or tests.
