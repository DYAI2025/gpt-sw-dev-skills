#!/usr/bin/env python3
"""Validate agent-agnostic compatibility controls."""
from __future__ import annotations
import json
import sys
from pathlib import Path


def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_agent_agnostic.py <skill-dir>")
    root = Path(argv[1])
    ref = root / "references" / "agent-agnostic-compatibility.md"
    report_path = root / "reports" / "agent-compatibility-report.json"
    if not ref.exists():
        return fail("references/agent-agnostic-compatibility.md missing")
    if not report_path.exists():
        return fail("reports/agent-compatibility-report.json missing")
    text = ref.read_text(encoding="utf-8")
    for term in ["Claude", "not", "tool availability", "UI install"]:
        if term not in text:
            return fail(f"agent compatibility reference missing term: {term}")
    try:
        report = json.loads(report_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(f"invalid agent compatibility report JSON: {exc}")
    if report.get("agent_agnostic_ready") is not True:
        return fail("agent_agnostic_ready must be true")
    if not report.get("not_guaranteed"):
        return fail("not_guaranteed list is required")
    if "agents/openai.yaml" not in report.get("runtime_specific_components", []):
        return fail("agents/openai.yaml must be marked runtime-specific")
    print("PASS: agent-agnostic compatibility controls")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
