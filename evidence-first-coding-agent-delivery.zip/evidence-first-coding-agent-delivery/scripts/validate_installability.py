#!/usr/bin/env python3
"""Validate install-ready skill packaging controls."""
from __future__ import annotations
import json
import sys
from pathlib import Path

ALLOWED_STATUS = {"prepared", "blocked", "not_controlled_by_skill"}


def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_installability.py <skill-dir>")
    root = Path(argv[1])
    required = [
        root / "SKILL.md",
        root / "agents" / "openai.yaml",
        root / "references" / "installability-and-distribution.md",
        root / "reports" / "installability-report.json",
    ]
    for path in required:
        if not path.exists():
            return fail(f"missing required installability path: {path.relative_to(root)}")
    try:
        report = json.loads((root / "reports" / "installability-report.json").read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(f"invalid installability report JSON: {exc}")
    if report.get("artifact_name") != "skill.zip":
        return fail("installability report artifact_name must be skill.zip")
    status = report.get("frontend_install_suggestion_status")
    if status not in ALLOWED_STATUS:
        return fail("frontend_install_suggestion_status must be prepared, blocked, or not_controlled_by_skill")
    if status == "guaranteed":
        return fail("frontend install suggestion must not be claimed as guaranteed")
    if "not_controlled_by_skill" not in report:
        return fail("installability report must name what the skill cannot control")
    print("PASS: installability controls")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
