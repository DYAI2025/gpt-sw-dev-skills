#!/usr/bin/env python3
"""Validate enterprise skill eval files."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr)
    return 1


def load_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise ValueError(f"{path}: {exc}") from exc


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_evals.py <skill-dir>")
    root = Path(argv[1])
    trigger_path = root / "evals" / "trigger_queries.json"
    output_path = root / "evals" / "output_evals.json"
    if not trigger_path.exists() or not output_path.exists():
        return fail("evals/trigger_queries.json and evals/output_evals.json are required")
    try:
        trigger = load_json(trigger_path)
        output = load_json(output_path)
    except ValueError as exc:
        return fail(str(exc))
    if not isinstance(trigger, list) or len(trigger) < 4:
        return fail("trigger_queries.json must contain at least 4 cases")
    has_true = any(item.get("should_trigger") is True for item in trigger if isinstance(item, dict))
    has_false = any(item.get("should_trigger") is False for item in trigger if isinstance(item, dict))
    if not has_true or not has_false:
        return fail("trigger queries need both should_trigger true and false cases")
    if not isinstance(output, list) or len(output) < 3:
        return fail("output_evals.json must contain at least 3 evals")
    for item in output:
        if not all(key in item for key in ("id", "prompt", "expected_properties", "failure_modes")):
            return fail("each output eval requires id, prompt, expected_properties and failure_modes")
    print("PASS: eval files")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
