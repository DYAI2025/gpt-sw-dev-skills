#!/usr/bin/env python3
"""Validate that source-map and source-policy contain required enterprise source controls."""
from __future__ import annotations

import sys
from pathlib import Path

REQUIRED_TERMS = [
    "type:",
    "purpose:",
    "reliability:",
    "limitations:",
    "confidence_default:",
    "user_provided",
    "primary",
    "SOURCE_NEEDED",
    "MISSING",
]


def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_source_map.py <skill-dir>")
    root = Path(argv[1])
    source_map = root / "references" / "source-map.md"
    source_policy = root / "references" / "source-policy.md"
    if not source_map.exists():
        return fail("references/source-map.md missing")
    if not source_policy.exists():
        return fail("references/source-policy.md missing")
    text = source_map.read_text(encoding="utf-8") + "\n" + source_policy.read_text(encoding="utf-8")
    missing = [term for term in REQUIRED_TERMS if term not in text]
    if missing:
        return fail("missing source discipline terms: " + ", ".join(missing))
    print("PASS: source map and source policy")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
