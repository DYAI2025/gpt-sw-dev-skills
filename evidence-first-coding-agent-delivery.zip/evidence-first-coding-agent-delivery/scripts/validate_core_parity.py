#!/usr/bin/env python3
"""Validate that core functionality preservation is explicitly documented."""
from __future__ import annotations
import json
import sys
from pathlib import Path

CORE = {
    "intake_scope",
    "research_bag",
    "capability_discovery",
    "browser_act_branch",
    "architecture_gate",
    "draft_build",
    "release_hook",
    "enterprise_output_evaluator",
    "validation_evals_packaging",
    "source_discipline",
}


def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_core_parity.py <skill-dir>")
    root = Path(argv[1])
    path = root / "reports" / "core-functionality-preservation.json"
    if not path.exists():
        return fail("reports/core-functionality-preservation.json missing")
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(f"invalid core preservation JSON: {exc}")
    preserved = set(report.get("preserved_core_functions", []))
    missing = sorted(CORE - preserved)
    if missing:
        return fail("missing preserved core functions: " + ", ".join(missing))
    additions = report.get("minimal_additions", [])
    if not additions:
        return fail("minimal_additions must be listed")
    if report.get("core_behavior_change") not in [False, "false"]:
        return fail("core_behavior_change must be false")
    print("PASS: core functionality parity")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
