# Evidence classification

Use these labels consistently in chat, PR audits, Jira comments, and handoffs.

| Label | Meaning | Allowed claim |
|---|---|---|
| `VERIFIED_LIVE` | Orchestrator read the current canonical system directly. | Current state fact for that observation epoch. |
| `VERIFIED_EXECUTABLE` | A deterministic command/gate was executed and its result observed in the current verification environment. | Command/gate result, bound to exact revision/environment. |
| `CORROBORATED_AGENT_EVIDENCE` | Agent reported a local command and independent CI/live state supports the same conclusion, but orchestrator did not execute that local command. | Strong supporting evidence; do not call it independently executed. |
| `AGENT_REPORTED` | Coding agent claimed it or showed terminal output not independently observed by the orchestrator. | Candidate evidence only. |
| `HISTORICAL` | Previously valid evidence tied to an earlier head, version, timestamp, or state. | Context only until revalidated. |
| `ASSUMPTION` | Plausible interpretation not yet verified. | Never use as merge/Done proof. |
| `OPEN` | Required evidence or action is not yet complete. | Blocks dependent claims. |
| `BLOCKED` | A hard gate cannot proceed safely or truthfully. | Stop the dependent mutation. |

## Evidence epoch

A verification is valid only for the state it observed. Invalidate an evidence epoch when any relevant event occurs:

- PR head changes;
- base/main changes;
- issue AC/status/dependencies change;
- a documentation decision is edited;
- runtime/deployment changes;
- a required human authorization is edited or superseded;
- the coding-agent session crosses into a new issue or PR.

Do not say `exact-head CI` when the run actually tested a synthetic merge ref. Name the tested revision precisely.
