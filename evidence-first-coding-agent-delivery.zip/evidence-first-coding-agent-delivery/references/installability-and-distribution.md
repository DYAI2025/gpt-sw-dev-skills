# Installability and distribution

The package controls `SKILL.md`, `agents/openai.yaml`, references, scripts, evals, reports, valid ZIP structure, and the final file name `skill.zip`.

It does **not** control whether a ChatGPT UI install button appears, whether a workspace allows installation, or whether another agent runtime provides equivalent tools.

Primary install artifact: `skill.zip`.
