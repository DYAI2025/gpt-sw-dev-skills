# Skill routing order

Use the smallest sufficient stack. Do not activate every reasoning/repository skill on every cycle.

## Default controller

1. **Scrum/Product Owner orchestration** — first for sprint, backlog, issue, PR, status, or merge decisions. Establishes project contract and workflow truth.

## Conditional analysis before implementation

2. **Repository impact analysis** — only when blast radius, affected symbols/contracts/data/infra, or regression-test selection is genuinely uncertain. Skip for a tiny known test-only repair.
3. **Craftsmanship / architecture reasoning** — when comparing materially different architectures, deciding whether a new abstraction is necessary, or making a high-cost/irreversible design choice.
4. **Deep reasoning / dialectic verification** — when sources conflict, a claim is contested, or the decision needs explicit competing hypotheses. Do not pay this overhead for routine exact-head checks.

## Agent execution

5. **Coding agent planning skill** — inside the bounded slice only. Use Plan Fidelity Gate. New feature: internal plan allowed; critical architecture: plan then stop; repair/gate/closeout: direct execution.
6. **Coding agent TDD / implementation** — execute one slice.
7. **Independent code-quality/spec reviewers** — after implementation; parallel only if read-only and separable.

## Controller returns

8. **Product Owner orchestration** — independently verify GitHub/Jira/Confluence/runtime evidence; issue verdict.
9. **Repair cycle** — one precise finding prompt; do not reopen broad planning.
10. **Merge/closeout gate** — exact head, authorization, merge, main CI, Jira/docs reconciliation.

## Retrospective / skill evolution

11. **Deep reasoning analysis** — after a meaningful delivery sequence to extract durable patterns and failure modes.
12. **Enterprise skill creator** — only when packaging or updating this reusable method.

This order optimizes for decision quality without making expensive reasoning skills part of every trivial turn.
