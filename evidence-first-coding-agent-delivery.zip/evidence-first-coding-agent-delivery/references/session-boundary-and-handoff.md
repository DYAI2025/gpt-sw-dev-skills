# Session boundary and handoff policy

## Purpose

Keep coding-agent and orchestrator context fresh enough that old plans, repaired assumptions, terminal narratives, and historical state do not silently become authority.

## 1. Mandatory Claude session label

Every coding-agent handoff must start with exactly one visible line above the actual prompt:

```text
FRISCHE CLAUDE SESSION — /clear vor dem Einfügen
```

or:

```text
GLEICHE CLAUDE SESSION — KEIN /clear
```

Never omit the line. Never use ambiguous wording such as "fresh context recommended" without saying whether `/clear` is required.

## 2. Default: fresh after major prompts

Treat the following as major prompt boundaries and default the **next** Claude prompt to `FRISCHE CLAUDE SESSION`:

- a bounded implementation prompt completed and evidence returned;
- a writing-plan or architecture-plan phase completed;
- a material code-review finding was repaired and is ready for re-review;
- a PR/head was accepted and the next phase is merge authorization;
- a merge completed and the next phase is post-merge closeout;
- an issue closes or a new Jira/work item begins;
- governance/documentation work switches to product implementation or vice versa;
- current context contains superseded plans, stale SHAs, repaired assumptions, or multiple abandoned approaches;
- the next action should be reconstructable entirely from repository/live-system truth.

A fresh Claude session must reread the current repo/work item/contracts relevant to the next action. Filesystem state may persist across `/clear`, but conversational memory does not count as evidence.

## 3. Same-session exception

Use `GLEICHE CLAUDE SESSION — KEIN /clear` only for one immediate bounded continuation where context continuity has real value, for example:

- still-uncommitted diagnostics or scratch state are being inspected;
- the agent must compare a just-produced transient output that is not persisted anywhere else;
- a tiny repair is directly coupled to the immediately preceding failure and no product/phase boundary changed;
- an interactive command/session state would be expensive or risky to reconstruct.

Do not keep the same session merely because it is already open. After the bounded continuation, reassess and normally return to a fresh session.

## 4. Prompt independence requirement

Even when `GLEICHE CLAUDE SESSION` is selected, write the prompt so it remains understandable without hidden history whenever practical. For `FRISCHE CLAUDE SESSION`, self-containment is mandatory.

Every fresh-session prompt should carry only the minimum live contract:

- repository/project;
- issue and current slice;
- exact current base/head/PR identifiers when relevant;
- live AC/outcome and relevant canonical decision references;
- in-scope/out-of-scope;
- mutation rights;
- required tests/error paths;
- evidence to return;
- stop conditions.

Do not paste old transcripts or full historical plans unless the next action genuinely depends on them.

## 5. Orchestrator context budget

Target a fresh ChatGPT handoff around **65% context consumption**.

If the runtime exposes an exact context meter, use it. Otherwise use an **estimated 60-70% high-water mark** and say that it is estimated. Never invent a precise context percentage.

Use these pressure signals to trigger earlier handoff:

- multiple large Claude terminal transcripts have accumulated;
- several full PR diffs/reviews or long connector payloads are in the same chat;
- more than one substantial plan has been superseded;
- exact current SHAs, issue states, page versions, or gate status are becoming difficult to distinguish from historical values;
- the orchestrator is relying increasingly on summaries instead of fresh source reads;
- a new major implementation phase is about to begin and no active atomic transaction requires continuity.

Do not hand off in the middle of a write/merge/status mutation. Finish the mutation, perform required read-after-write verification, then hand off before opening new work.

## 6. Mandatory ChatGPT handoff announcement

At the threshold, emit:

```text
FRISCHE CHATGPT SESSION ERFORDERLICH
```

Then provide a minimal handoff packet. The user should start a new ChatGPT session and paste the packet there.

### Minimal handoff packet

```text
PROJECT / ROLE
- <project and orchestrator role>

WORKING METHOD
- <only the non-obvious active delivery rules needed to continue>

CANONICAL SYSTEMS
- <repo / Jira / docs / runtime identifiers and truth ownership>

ACTIVE ITEM / SLICE
- <issue, one current slice, goal>

LAST VERIFIED STATE
- <current main/base/head/PR/merge SHA, Jira status, relevant page version, CI run as applicable>

OPEN GATE / FINDINGS
- <only unresolved blockers/findings>

NEXT EXACT ACTION
- <one next action and required verification>

CRITICAL DO-NOTs
- <human-only action, no scope widening, no next issue, etc.>
```

Keep it as small as possible. Preserve details that are operationally discriminating: exact IDs, SHAs, issue keys, statuses, version numbers, unresolved findings, and authorization boundaries. Drop narrative history, already-closed findings, superseded plans, duplicate test logs, and old hypotheses.

## 7. Fresh ChatGPT intake

The new ChatGPT session must:

1. treat the handoff as `user_provided continuity context`, not canonical truth;
2. reload the most specific delivery/PO skill;
3. reread the current live systems needed for the decision;
4. reconcile any mismatch between the handoff and live state;
5. continue only from the reconciled state.

The handoff exists to prevent detail loss while reducing context carryover. It must never transport stale state as unquestioned authority.
