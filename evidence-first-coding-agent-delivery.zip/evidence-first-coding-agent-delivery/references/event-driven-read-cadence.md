# Event-driven read cadence

Fixed minute intervals are usually weaker than state invalidation. Read when a decision depends on state that may have changed.

## GitHub — highest cadence

Read at:

1. session/slice intake: current main, open PRs, active branch if known;
2. after any agent claim of commit/push/PR/head change;
3. after review-fix push;
4. before accepting a code review;
5. immediately before merge: PR state, exact head, base/main, changed files, review threads, checks/CI;
6. immediately after merge: PR readback, merge SHA, main readback;
7. again for main/push CI on the merge SHA.

Do not reuse CI from an earlier head.

## Jira/work tracker — contract cadence

Read at:

1. new issue/slice intake: description, AC, status, sprint, dependencies;
2. whenever conflicting historical comments or docs make scope ambiguous;
3. before any prompt whose legality depends on current status/AC;
4. immediately before status mutation: fetch available transitions;
5. after comment/edit/transition: read back.

Do not reread Jira after every test-only repair when the issue contract has not changed and no Jira mutation is planned. Revalidate at the final issue gate.

## Confluence/docs — decision cadence

Read at:

1. slice intake when the page carries requirement, architecture, or decision authority;
2. before a mutation to verify current version/content and idempotency;
3. after every mutation;
4. before an acceptance decision if the relevant canonical content could have drifted during the implementation;
5. sprint/accepted-increment reconciliation.

A test-only code repair does not automatically require rereading every project page. Re-read only pages that support the claim being decided.

## Runtime — demand-driven

Read for deployment, behavior, health, data, operational acceptance, or incident claims. Do not infer runtime state from repository state.

## Capability-gap fallback

If a required observation cannot be made through the orchestrator's connector:

1. mark `CAPABILITY_MISSING` for that observation path;
2. choose another already-authorized capability, usually a read-only coding-agent verifier;
3. bind the verifier prompt to the exact SHA/issue/page/version;
4. return the result as `AGENT_REPORTED` unless independently observable, or `VERIFIED_EXECUTABLE` when the orchestrator directly sees the execution result through the available tool channel;
5. do not silently waive the gate.
