# Coding-agent prompt contract

Use these four prompt modes. Replace placeholders with live values; do not send unresolved placeholders to the agent.

## Mandatory session wrapper

Before every prompt, emit exactly one line **outside and above** the prompt body:

```text
FRISCHE CLAUDE SESSION — /clear vor dem Einfügen
```

or:

```text
GLEICHE CLAUDE SESSION — KEIN /clear
```

Major prompts default to `FRISCHE CLAUDE SESSION`. Use the same-session form only under the bounded continuity exceptions in `session-boundary-and-handoff.md`.

## A. Slice execution

```text
ROLE
You are the implementing developer for one bounded slice. Do not decide product completion.

VERIFIED INPUTS
- Repository: ...
- Current main/base: ...
- Jira/work item: ...
- Live AC/outcome: ...
- Relevant canonical docs: ...
- Current blockers/PRs: ...

PLANNING MODE
INTERNAL_PLAN_ALLOWED | PLAN_REQUIRED_STOP
If you invoke a writing-plans/superpowers skill, the plan is derived/non-canonical and cannot widen this contract.

GOAL
One observable outcome.

IN SCOPE
- ...

OUT OF SCOPE
- ...

MUTATION RIGHTS
- Allowed writes: ...
- Forbidden writes: ...
- Human-only actions: ...

REQUIRED TESTS / ERROR PATHS
- command -> expected result
- negative case -> expected rejection

EVIDENCE TO RETURN
- start state
- changed files + reason
- exact commit/head/PR if created
- commands + exits + counts without hiding warnings
- CI identity and tested revision
- fresh-checkout/reproduction when required
- unresolved risks and newly discovered work

STOP CONDITIONS
- requirement contradiction
- unexpected main/head drift
- need to widen scope
- human authorization required
- destructive/production operation not explicitly authorized

Do not begin another issue. STOP after reporting this slice.
```

## B. Repair prompt

```text
This is a repair of the current slice, not a new implementation plan.
Do not run a broad planning workflow unless the finding proves the architecture itself must change.

EXACT HEAD / BASE: ...
FINDING: ...
WHY IT MATTERS: ...
REQUIRED CHANGE: ...
MUST REMAIN UNCHANGED: ...
PROOF THAT THE FIX BITES: ...
FULL REGRESSION: ...

Do not touch unrelated files, refactor adjacent code, change requirements, merge, or mutate Jira/Confluence unless explicitly stated.
Return the new head and a concise evidence packet, then STOP.
```

## C. Verification-only prompt

```text
READ-ONLY VERIFICATION. Make no code, Jira, Confluence, workflow, PR-body, or merge mutations.
Verify exactly: ...
Bind checks to revision/state: ...
Run executable gate if available: ...
Return raw identifiers, command exits, timestamps, and any mismatch.
If evidence is unavailable, say MISSING; do not infer success.
STOP.
```

## D. Post-merge closeout prompt

```text
POST-MERGE CLOSEOUT ONLY. No new feature work.
Expected PR: ...
Expected pre-merge head: ...
Expected merge/main SHA: ...

Verify:
1. PR merged/readback.
2. main equals expected integration result.
3. main/push CI on exact merge SHA.
4. required local/fresh reproduction if project policy requires it.
5. final AC/DoD evidence.

Do not transition Jira or edit docs unless this prompt explicitly grants those writes. Report blockers and STOP.
```

## Prompt design rules

- State one current slice.
- Put out-of-scope near in-scope, not at the end as an afterthought.
- Name human-only actions explicitly.
- Ask for identifiers, not prose claims: SHA, PR number, run ID, page version, issue transition.
- Ask the agent to preserve warnings and partial failures.
- Require stop on contradictions instead of asking it to resolve product policy itself.
- Make fresh-session prompts independently executable from live state.
- Never rely on "as discussed above" or an old plan as the only carrier of a requirement.
