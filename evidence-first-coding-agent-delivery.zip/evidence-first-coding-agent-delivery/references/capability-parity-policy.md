# Capability parity and preservation

This is a new skill, not a modification of the Enterprise Skill Creator. The creation pipeline preserves its required intake, research bag, capability discovery, architecture gate, draft build, release hook, evaluator, validation/evals/packaging, and source discipline.

The generated skill adds only delivery-domain behavior: coding-agent prompt contracts, plan fidelity, evidence epochs, event-driven source rereads, repair loops, exact-head merge gating, and atomic post-merge closeout.

Do not claim identical tools or behavior across agents.
