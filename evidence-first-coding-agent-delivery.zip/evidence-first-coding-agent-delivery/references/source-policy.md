# Source policy

Classify sources before turning them into skill rules.

- `primary`: live canonical system, official repository state, installed skill instruction, project policy, deterministic executable result.
- `secondary`: expert explanation or non-authoritative reference.
- `user_provided`: user-uploaded project methods, transcripts, handoffs, notes, screenshots.
- `derived`: model synthesis, retrospective, generated plan, extracted handoff.
- `uncertain`: contradictory or unattributed claim.

Use `MISSING` when required information is absent. Use `SOURCE_NEEDED` when a hard claim lacks adequate support.

Confidence 4-5 may support durable workflow rules. Confidence 3 supports design hypotheses only. Confidence 1-2 must not become hard rules.

A coding-agent transcript is not primary evidence for current GitHub/Jira/Confluence state even when it contains plausible command output. Verify live when the decision matters.
