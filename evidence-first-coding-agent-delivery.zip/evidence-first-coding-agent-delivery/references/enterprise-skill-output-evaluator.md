# Enterprise skill output evaluator contract

Evaluate the generated package on five 1-5 dimensions:

- spec_compliance
- research_quality
- enterprise_readiness
- architecture_quality
- release_gate_integrity

Return XML rooted at `enterprise_skill_evaluation` with `scores`, `decision`, and `reason`. Decisions: PASS, PASS_WITH_MINOR_REVISIONS, REVISE, REBUILD, BLOCKED.
