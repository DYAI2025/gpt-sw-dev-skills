# Agent-agnostic compatibility

The core workflow is portable natural language: live intake, bounded slice, plan fidelity, evidence classification, verification, review, explicit session boundaries, exact-head merge, and closeout.

Claude / Claude Code can receive the prompt contracts directly and may use its own planning, TDD, review, or subagent mechanisms below the fixed product boundary. For Claude Code, this skill uses explicit operator-facing labels: `FRISCHE CLAUDE SESSION — /clear vor dem Einfügen` or `GLEICHE CLAUDE SESSION — KEIN /clear`. `/clear` behavior is Claude-Code-specific; other agents should map the intent to their closest safe context-reset mechanism and state any capability gap.

ChatGPT-specific `agents/openai.yaml` is runtime metadata. Tool availability, filesystem behavior, connector permissions, memory, exact context-usage telemetry, and UI install behavior are **not** guaranteed to match Claude, Codex, Cursor, Windsurf, or other agents.

The orchestrator targets a context handoff near 65% utilization. If the runtime does not expose exact usage, the skill must estimate conservatively, label the estimate, and never fabricate a precise percentage.

A Claude-compatible handoff means the instructions are semantically portable; it does not mean identical execution behavior. If a runtime lacks GitHub/Jira/Confluence tools, mark that tool availability as missing and use an authorized alternative rather than pretending parity.

UI install behavior is not controlled by this skill.
