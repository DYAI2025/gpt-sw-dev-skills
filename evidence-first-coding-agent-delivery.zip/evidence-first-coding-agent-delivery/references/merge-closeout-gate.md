# Merge and closeout gate

## Pre-merge gate

Bind every check to current `PR_NUMBER`, `HEAD_SHA`, and current base/main.

Required unless explicitly inapplicable:

- current PR is open and mergeable under project policy;
- head/base are the expected revisions;
- changed-file set matches slice scope;
- AC mapping is complete enough for merge;
- no unresolved blocker review thread/finding;
- relevant unit/integration/contract/negative tests pass;
- local or fresh-checkout reproduction exists when the project requires it;
- CI checks are green on the exact head or exact synthetic merge candidate, named accurately;
- project-specific human approval artifact is valid and predates the gate when required;
- executable repository gates are run when an executor exists;
- no unexplained main drift.

## Merge

Use expected-head protection when the platform supports it. Do not merge a moved head using stale authorization.

## Atomic post-merge closeout

Treat these as one transaction:

```text
merge
 -> PR merged readback
 -> merge SHA
 -> main == integration result
 -> main/push CI on merge SHA
 -> optional runtime smoke
 -> final AC/DoD
 -> Jira evidence comment
 -> fresh Jira transitions
 -> Jira Done/Fertig only if whole issue is complete
 -> Jira readback
 -> Confluence/current-state reconciliation if required
 -> Confluence readback
 -> next issue
```

If a step cannot be observed:

- do not fake completion;
- immediately route a read-only verifier if another capability can observe it;
- otherwise state `MERGED — CLOSEOUT BLOCKED` with the exact missing evidence.

## Common anti-pattern

`merge succeeded -> tell user merged+verified -> leave Jira open because main CI connector could not see push runs`

Safer and more efficient:

`merge succeeded -> main CI observation unavailable -> launch read-only verifier immediately -> close Jira/docs if green -> then return one coherent closeout verdict`.
