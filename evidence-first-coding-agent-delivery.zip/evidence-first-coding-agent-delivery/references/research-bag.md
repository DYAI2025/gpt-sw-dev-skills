# Research bag

## Source inventory

S001-S004 and S008 are user-provided project method/transcripts/requirements. S005-S007 are installed primary skill instructions. See `source-map.md`.

## Knowledge model

Core terms:

- `slice`: one bounded implementation outcome tied to a work item and acceptance criterion.
- `evidence epoch`: the interval in which verified state remains valid until an invalidating event changes it.
- `agent report`: evidence candidate, not canonical truth.
- `plan fidelity`: a generated technical plan remains subordinate to the live product contract.
- `atomic closeout`: merge verification, main CI, issue status, documentation, and readbacks complete before next work begins.
- `session epoch`: one bounded coding-agent or orchestrator context period whose assumptions are invalidated at an explicit fresh-session boundary.
- `minimal handoff`: compact continuity packet containing only current method, identifiers, active slice, open gate, and next exact action.

Operational rules supported at confidence 4-5:

- WIP=1 for implementation themes.
- Live current-state reads before material decisions.
- Read-after-write.
- No Done from activity.
- Exact-head merge evidence.
- Plan files are non-canonical unless explicitly promoted.
- Use coding-agent read-only verification as capability fallback when the controller cannot observe a required gate.
- Label every Claude follow-up prompt as fresh (`/clear`) or same-session; major prompts default fresh.
- Target orchestrator self-handoff near 65% context use, or conservatively estimated 60-70% if telemetry is unavailable; never claim false precision.

## Build recommendation

`proceed`

Reason: the observed workflow contains repeated, transferable failure-prevention patterns and one concrete closeout failure that can be encoded as a deterministic interaction rule. Exact performance percentages remain SOURCE_NEEDED and are intentionally excluded.
