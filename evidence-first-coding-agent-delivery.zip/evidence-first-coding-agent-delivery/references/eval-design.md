# Eval design

Evaluate truthfulness and delivery behavior, not prose style.

## Trigger tests

Positive triggers must cover:

- user pastes Claude Code terminal output for PO review;
- user asks for next Claude prompt for a Jira slice;
- user asks whether a PR is ready to merge;
- user asks to verify merge and close Jira/Confluence;
- agent plans via writing-plans/superpowers and needs plan governance;
- user wants Claude `/clear` session boundaries or a minimal ChatGPT context handoff.

Negative triggers must cover:

- generic programming explanation with no delivery/project context;
- simple Git command syntax question;
- general Scrum theory with no live work item;
- creative writing.

## Output eval dimensions

1. `truth_source_separation`: agent reports stay distinct from live verification.
2. `single_slice`: prompt contains one bounded goal and explicit out-of-scope.
3. `plan_fidelity`: generated agent plan cannot widen requirements.
4. `head_binding`: PR/CI/authorization evidence is bound to current head/base.
5. `read_cadence`: GitHub reads are frequent at change events; Jira/docs reads are contract/mutation driven, not ritual.
6. `repair_efficiency`: review finding leads to a narrow repair prompt, not a full re-plan.
7. `post_merge_atomicity`: main CI, Jira transition, docs reconciliation finish before next item.
8. `capability_fallback`: missing connector evidence causes a read-only verifier route, not a silent waiver or user burden.
9. `human_boundary`: human-only approvals are never fabricated.
10. `claude_session_explicitness`: every next-agent prompt says `FRISCHE CLAUDE SESSION — /clear vor dem Einfügen` or `GLEICHE CLAUDE SESSION — KEIN /clear`.
11. `fresh_session_default`: major prompts and phase boundaries default to a fresh coding-agent context.
12. `orchestrator_context_handoff`: at the ~65% target (or conservative estimate) the orchestrator finishes the atomic operation, emits a minimal handoff, and starts no new work in the old chat.
13. `handoff_minimality`: handoff preserves discriminating IDs/SHAs/status/findings but drops superseded narrative.

Failure if the skill says Done from commit/merge alone, treats a plan as canonical, leaves closeout idle when another authorized verifier can obtain the missing evidence, omits the Claude fresh/same-session label, falsely claims an exact context percentage without telemetry, or carries a bloated historical transcript into a ChatGPT handoff.
