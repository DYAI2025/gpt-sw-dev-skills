# Source map

## S001
- title: Arbeitsweise im Projekt
- type: user_provided
- location: File Library / `Arbeitsweise im Projekt.md`, 2026-08-07
- purpose: Original PO/Claude role split, item-by-item loop, anti-drift, PR/merge and Jira/Confluence rules.
- reliability: Strong statement of intended project method; not independent proof of effectiveness.
- limitations: GBrain-specific and normative.
- confidence_default: 4
- use_in_skill: workflow baseline, generalized beyond ATLAS.

## S002
- title: GBrain Product Owner and Claude-Code handoff
- type: user_provided
- location: File Library / `markdown.md eingefügt`, 2026-08-09
- purpose: Refined fresh-intake, WIP=1, output contract, session boundaries, exact-head merge gates, post-merge sequence.
- reliability: Strong project method with concrete revision identifiers.
- limitations: Some dynamic state is historical by the time the skill runs.
- confidence_default: 4
- use_in_skill: live-state and session-boundary rules; dynamic values removed.

## S003
- title: ATLAS-12 Claude Code closeout transcript
- type: user_provided
- location: File Library / `Eingefügter Text.txt`, 2026-08-09
- purpose: Observed implementation/review loop: TDD, code-quality review, fresh checkout, CI, G2 stop, limited changed-file set.
- reliability: Detailed agent transcript corroborated in-session by GitHub/Jira/Confluence reads for key claims.
- limitations: Agent-reported local commands are not automatically independent evidence.
- confidence_default: 4
- use_in_skill: evidence classification, review/repair loop, stop-gate patterns.

## S004
- title: PR #10 Claude subagent execution transcript
- type: user_provided
- location: File Library / `Eingefügter Text.txt`, 2026-08-09
- purpose: Shows safe parallel read/review agents, serial doc/repo mutations, read-after-write, stale-CI rejection, plan quarantine, and final PO stop.
- reliability: Detailed transcript; key GitHub facts were independently re-read during the session.
- limitations: Not a controlled benchmark.
- confidence_default: 4
- use_in_skill: subagent concurrency and plan hygiene rules.

## S005
- title: Scrum Product Owner Orchestrator
- type: primary
- location: `skills://scrum-product-owner-orchestrator/skill.md`
- purpose: Capability discovery, project-context first, no Done from activity, transition read-before-write, read-after-write.
- reliability: Installed controlling skill instruction.
- limitations: Generic; project policies can add stricter gates.
- confidence_default: 5
- use_in_skill: controller and Jira/GitHub workflow invariants.

## S006
- title: Skill Creator
- type: primary
- location: `skills://skill-creator/skill.md`
- purpose: Skill packaging, progressive disclosure, trigger design, required SKILL.md and agents/openai.yaml.
- reliability: Installed skill-creation instruction.
- limitations: Packaging guidance, not delivery effectiveness evidence.
- confidence_default: 5
- use_in_skill: package structure and auto-trigger description.

## S007
- title: Deep Reasoning Analysis Enterprise
- type: primary
- location: `skills://deep-reasoning-analysis-enterprise/skill.md`
- purpose: Evidence ledger, verification, bias/failure-mode analysis, auditable retrospective.
- reliability: Installed analysis instruction.
- limitations: High-overhead method; not needed on every delivery turn.
- confidence_default: 5
- use_in_skill: retrospective and evidence-discipline design.

## SOURCE_NEEDED
- Exact percentage speedup or defect-reduction improvement versus other workflows requires controlled multi-project measurement; do not claim one.
- Universal superiority of any specific Claude superpower skill is not established; use task-fit gates instead.

## MISSING
- No complete machine telemetry for exact Jira/Confluence/GitHub call counts across the entire historical sprint dialogue. Cadence recommendations are therefore event-based and grounded in observed failure/success points rather than exact frequency statistics.

## S008
- title: Explicit session-reset and context-handoff requirement
- type: user_provided
- location: Current project conversation, 2026-08-09
- purpose: Requires every Claude follow-up prompt to state fresh-vs-same session explicitly; major prompts should normally start after `/clear`; requires the orchestrator to hand off to a fresh ChatGPT session around 65% context use with a minimal continuity packet.
- reliability: Direct user requirement for this workflow; authoritative as a requested behavior, not as a factual claim about runtime telemetry.
- limitations: Exact ChatGPT context utilization may not be exposed by every runtime; threshold must be estimated when telemetry is unavailable.
- confidence_default: 5
- use_in_skill: mandatory Claude session labels, fresh-session default, same-session exceptions, orchestrator context-budget and minimal handoff policy.

## Runtime limitation note for S008
- Exact context-percentage telemetry is runtime-dependent. When unavailable, the skill uses an estimated high-water mark and must disclose that it is estimated.
