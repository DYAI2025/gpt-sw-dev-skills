# Plan Fidelity Gate for writing-plans / superpowers

A coding-agent planning skill can improve implementation quality by forcing repository inspection and explicit sequencing. It can also create a second authority layer and inflate scope. Use this gate whenever the agent emits or persists an implementation plan.

## Classification

Default plan status: `derived_noncanonical`.

A plan becomes project documentation only through an explicit project mutation decision. A plan never overrides live Jira AC, canonical architecture/decision docs, or current repository state.

## Gate

Before execution, verify:

1. **Contract fidelity** — every plan task maps to the one approved slice, AC, required evidence, or necessary enabling step.
2. **No requirement invention** — no new product behavior, architecture, infrastructure, dependency, or governance rule appears without authorization.
3. **Write target discipline** — planned writes are named or bounded and fit mutation rights.
4. **Out-of-scope preservation** — prohibited systems/files/actions remain prohibited.
5. **Testability** — each meaningful behavior includes observable success and at least one relevant error/negative path.
6. **State freshness** — plan inputs were reconstructed from current systems rather than old agent memory or stale plan files.
7. **Stop points** — merge, Jira Done, production deploy, human approval, and other gated actions remain explicit stops.
8. **Plan storage hygiene** — temporary plans stay scratchpad/untracked unless committing the plan is itself in scope.
9. **Right-sized depth** — do not fully specify interfaces that do not yet exist merely to make a plan look complete. Mark later detail as a discovery gate.
10. **Execution mode** — for repair, verification, and closeout work, reject an unnecessary full re-plan.

## Recommended modes

| Work type | Plan mode | Reason |
|---|---|---|
| New bounded feature with several dependent edits | `INTERNAL_PLAN_ALLOWED` | Internal decomposition helps without adding an approval round. |
| Architecture-sensitive or high blast radius | `PLAN_REQUIRED_STOP` | Review plan before writes. |
| Single review finding | `DIRECT_EXECUTION` | Replanning adds latency and scope risk. |
| G2/approval/exact-head verification | `DIRECT_EXECUTION` read-only | Deterministic gate, not design work. |
| Post-merge closeout | `DIRECT_EXECUTION` | Transactional checklist, not implementation design. |

## Failure signatures

Reject or revise a plan that:

- turns historical notes into current requirements;
- adds a canonical config because evidence is missing;
- commits a plan file without permission;
- bundles adjacent backlog work because it is convenient;
- plans implementation beyond a human authorization boundary;
- replaces exact acceptance tests with generic "run tests" steps;
- treats its own earlier assumptions as discovered facts.
