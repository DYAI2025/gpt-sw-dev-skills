# Skill release gate policy

Package only if:

- architecture is coherent and the trigger is bounded;
- no hard rule rests on confidence below 4;
- no unresolved `SOURCE_NEEDED` becomes a workflow requirement;
- anti-confabulation gate is PASS;
- anti-sycophancy score is below 3;
- bias gate is not BLOCKED;
- trigger and output evals exist;
- installability and agent-agnostic reports validate;
- examples and validators contain no placeholders.

The generated delivery skill must not claim controlled benchmark superiority. Its effectiveness conclusions are observational and must remain labeled as such.
