# Installability and Distribution

The package can prepare an installable `skill.zip`, but cannot guarantee any frontend will display a specific installation button or UI.

## Controlled by package

- one top-level skill folder
- `SKILL.md` at the top of that folder
- valid YAML frontmatter
- `agents/openai.yaml`
- zip artifact named `skill.zip`
- deterministic validators

## Not controlled by package

- ChatGPT frontend UI behavior
- account permissions
- workspace policy
- availability of Skills feature in every client
- target-client support for scripts or MCP
