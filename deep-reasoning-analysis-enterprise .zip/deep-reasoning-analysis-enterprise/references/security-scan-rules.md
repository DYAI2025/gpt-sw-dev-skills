# Security Scan Rules

Source basis: S019, S020, S021 and package-local security policy.

## Blocking patterns

Block release when any production file contains:

- private keys or credential-shaped secrets;
- hardcoded API tokens intended for real use;
- malicious code, credential harvesting, or unauthorized access logic;
- hidden data exfiltration, undisclosed telemetry, or unauthorized redirects;
- exploit-chain instructions for real targets;
- code intended to disable platform review, abuse ratings, or scrape Platform Operational Data.

## Warning patterns

Warn and manually review:

- `subprocess`, shell invocation, dynamic imports, `eval`, `exec`, network libraries, file deletion commands;
- broad claims such as `guaranteed`, `certified`, `official`, `accurate predictions`, `legal advice`, `medical diagnosis`, `investment advice`;
- missing support contact, privacy notice, data declaration, or test cases;
- external service names without data-flow disclosure.

## Deterministic scan scope

The scan is static and conservative. It does not prove absence of vulnerabilities. It should read files, not execute packaged code. False positives must be recorded with rationale.
