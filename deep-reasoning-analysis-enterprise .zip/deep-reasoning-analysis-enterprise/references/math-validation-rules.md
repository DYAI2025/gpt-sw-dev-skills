# Math Validation Rules

Preserved from the user-provided skill and strengthened for enterprise reporting.

## Deterministic checks

- Dimensional consistency for physical equations.
- Symbolic cross-verification when algebra, calculus or proof transformation is central.
- Boundary case testing for edge conditions.
- Invariant checks for conservation or monotonic properties.
- Counterexample search for universal claims.

## Numerical checks

- Convergence monitoring for iterative methods.
- Sensitivity analysis for parameter-dependent claims.
- Error propagation for measured or uncertain data.
- Monte Carlo validation only when randomness is appropriate and seed/control details are documented.

## Reporting rule

Every mathematical conclusion must be categorized as formal proof, deterministic computation, numerical evidence, simulation evidence, or unresolved hypothesis.
