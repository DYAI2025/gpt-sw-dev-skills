# path: references/interactive-html-report-spec.md

# Interactive HTML Report Specification

## Product intent

`analysis_report.html` is the visual, inspectable version of the analysis. It should feel like an evidence control room, not a decorative export.

## Required sections

1. Header
   - report title
   - analysis date
   - source count
   - artifact count
   - output selection mode

2. Decision dashboard
   - release decision: PASS / REVISE / BLOCK / INCONCLUSIVE
   - evidence coverage
   - critical findings
   - unsupported claims
   - open blockers

3. Risk gate
   - domain risk
   - policy risk
   - evidence risk
   - runtime/tool risk
   - decision impact

4. Findings board
   - sortable finding table
   - severity
   - confidence
   - affected area
   - evidence status

5. Claim matrix
   - claim id
   - claim text
   - source map
   - evidence strength
   - counterevidence
   - status

6. Evidence ledger
   - expandable source cards
   - cited excerpts or source summaries within allowed quotation limits
   - source class
   - confidence
   - retrieval/creation metadata when available

7. Assumptions and missing evidence
   - assumptions register
   - SOURCE_NEEDED register
   - MISSING inputs

8. Interactive controls
   - client-side full-text search
   - filters by status, severity, confidence, source type
   - source jump links
   - expandable details
   - optional numeric what-if calculators

9. Audit Pack section
   - artifact list
   - download/attachment references where available
   - manifest preview
   - validation status

10. Appendix
   - method selection
   - validation notes
   - limitations
   - open questions

## Interaction modes

### static_interactive

Allowed without external services:

- section navigation
- sortable tables
- filters
- search over embedded text
- expandable cards
- deterministic calculators
- precomputed Q&A cards

### llm_interactive

Requires explicit tool/API permission boundary:

- live natural language Q&A over the report
- semantic retrieval
- model-generated follow-up analysis
- external API calls

Never present `static_interactive` as live AI chat.

## Visual design guidance

Use a premium, restrained audit aesthetic:

- dark navy or charcoal header
- white or near-white document surface
- large decision metrics
- thin rules
- evidence cards
- compact tables
- color only for status/severity
- no decorative visuals that obscure evidence

## Marketplace demo recommendation

Best demo theme:

"AI-generated market report verification audit"

Rationale:

- It competes directly against polished research-report generators.
- It shows that the skill can inspect, challenge, and structure evidence.
- It supports numeric what-if controls.
- It makes the HTML output commercially visible.

Alternative demo theme:

"Repository and AI-system readiness audit"

Rationale:

- It showcases SARIF, technical findings, and enterprise review workflows.
