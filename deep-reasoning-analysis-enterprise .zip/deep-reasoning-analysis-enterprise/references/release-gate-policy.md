# Release-Gate Policy

A draft may be packaged only if all hard gates pass.

## Required gates

- Craftsmanship Gate: coherent scope, progressive disclosure, failure modes, smallest robust slice.
- Anti-Confabulation Gate: external claims labeled supported, inferable, unverified or do_not_claim. Unverified hard claims block release.
- Anti-Sycophancy Gate: score must be below 3.
- Bias Gate: confirmation bias, overconfidence, tool bias, authority bias, cultural bias and user-thesis laundering reviewed.
- Installability Gate: package artifact is `skill.zip`, contains exactly one top-level skill folder, has `SKILL.md` and `agents/openai.yaml`.
- Core Functionality Preservation Gate: prior Deep Reasoning functions are preserved unless explicitly changed.

## Stop rule

Stop if release status is not PASS, packaging is not allowed, blocked claims exist, bias gate is BLOCKED, anti-sycophancy score is 3 or higher, or installability has blocking issues.
