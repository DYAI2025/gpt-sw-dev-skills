# Category and Regulated-Domain Rules

Source basis: S019 Schedule A.

## Primary category

Recommended Capafy categories for this skill:

- Analysis
- Research
- Engineering
- Science
- Productivity

Use no more than five tags in Capafy metadata. Recommended tags: `research`, `analysis`, `verification`, `audit`, `reasoning`.

## Regulated-domain boundary

The skill may analyze evidence in legal, medical, financial, tax, cybersecurity, or other regulated contexts, but must not present outputs as professional advice, diagnosis, treatment, investment instruction, legal strategy, tax filing position, or guaranteed outcome.

## Cybersecurity boundary

Allow defensive analysis, detection, forensics, hardening, authorized review, and safe reporting. Block malware, credential theft, unauthorized access, stealth, persistence, exploit chains, and real-target abuse.

## Advisories

Use these listing advisories:

- AI-generated analysis may be incomplete or wrong; verify before operational use.
- Not professional legal, medical, financial, tax, or mental-health advice.
- Defensive cybersecurity only; authorization required.
- User-provided files may contain sensitive data; minimize inputs.
