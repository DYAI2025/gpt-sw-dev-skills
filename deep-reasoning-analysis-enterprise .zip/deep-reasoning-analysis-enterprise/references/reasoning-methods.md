# Reasoning Methods

This reference preserves the method portfolio from the user-provided Deep Reasoning skill and adds enterprise constraints.

## Method matrix

| Method | Use | Enterprise constraint |
|---|---|---|
| PS+ | Decompose complex tasks into work packages and success criteria | Output plan publicly, not private chain-of-thought |
| ToT | Explore alternative hypotheses or solution paths | Summarize alternatives and scores without hidden reasoning traces |
| PoT | Delegate deterministic computation to code or symbolic tools | Record inputs, outputs and reproducibility status |
| SC | Compare independent paths | Report consensus and disagreement, not just final answer |
| ER | Refine and synthesize partial answers | Preserve minority objections and uncertainty |
| MP | Review assumptions, bias and confidence | Mark overconfidence, confirmation bias and scope drift |
| CoVe | Verify claims and conclusions | Link each key claim to source ids or mark SOURCE_NEEDED |

## Rule

No method is sufficient by itself for enterprise use. Combine at least planning, evidence mapping, verification and bias review. Mathematical or numerical claims require PoT or equivalent deterministic validation when tools are available.
