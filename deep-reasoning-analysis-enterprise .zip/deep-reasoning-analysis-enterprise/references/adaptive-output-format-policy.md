# path: references/adaptive-output-format-policy.md

# Adaptive Output Format Policy

## Purpose

This policy extends the Deep Reasoning Analysis Enterprise artifact system from a static report pair into an adaptive audit pack. The goal is to choose the best output format for the task while preserving evidence discipline, reproducibility, and user control.

## Canonical outputs

Always produce or include:

- `analysis_report.md`
- `analysis_report.json`

These remain the source of truth for human and machine-readable reporting.

## Additional selectable outputs

### 1. Interactive HTML: `analysis_report.html`

Use when the analysis benefits from visual navigation, evidence inspection, charts, filtering, decision dashboards, or lightweight what-if interaction.

Recommended for:

- market reports with many numbers
- technical architecture reviews
- AI-system audits
- repository audits
- claim verification
- compliance/readiness checks
- stakeholder demos
- marketplace samples

HTML should include:

- executive decision card
- risk gate card
- findings dashboard
- claim-to-source table
- source map
- evidence ledger viewer
- counterevidence register
- assumptions register
- open questions
- artifact pack section
- client-side filters and search
- optional deterministic calculators for numeric scenarios

### 2. Executive PDF: `executive_summary.pdf`

Use when the output needs to be portable, printable, board-ready, or suitable for non-technical stakeholders.

Do not make PDF mandatory when no renderer is available. Mark as `MISSING_RUNTIME_CAPABILITY` if requested but unsupported.

### 3. Evidence data exports: `evidence_ledger.jsonl` and `claim_matrix.csv`

Use when source traceability, audit review, regression testing, or downstream agent reuse matters.

Each material claim should include:

- claim id
- claim text
- source id(s)
- evidence type
- evidence strength
- confidence
- status
- assumptions
- missing evidence
- verifier notes

### 4. Audit Pack: `audit_pack.zip`

Use when three or more artifacts exist or when the user needs a bundled handoff.

The pack should include a manifest, report files, evidence data, validation logs, and domain-specific companions such as SARIF.

## User control

Accepted user output selections:

- `auto`
- `markdown`
- `json`
- `html`
- `pdf`
- `evidence-data`
- `sarif`
- `audit-pack`
- `all`

If the user's requested output conflicts with runtime limitations, mark the blocked output explicitly and propose the nearest available alternative.

## Auto-selection rule

Use `auto` unless the user explicitly selects formats.

Auto-select:

- HTML for complex, visual, technical, numeric, comparative, or stakeholder-facing analysis.
- Evidence data exports for verification-heavy or claim-heavy work.
- PDF for leadership-facing summaries when supported.
- Audit Pack for review handoff or when multiple artifacts are generated.
- SARIF only when code/repository findings exist.

## Prohibited claims

Do not claim:

- guaranteed truth
- certified audit validity
- legal compliance
- live chat with the document unless real runtime support exists
- external API independence if external dependencies exist
