# Evaluation Design

## Layers

1. Trigger evaluations in `evals/trigger_queries.json`.
2. Output evaluations in `evals/output_evals.json`.
3. Domain JSONL cases for deep reasoning, tool routing, hallucination resistance, source verification, cyber boundaries, math validation and cross-agent portability.
4. Deterministic validators in `scripts/`.

## Acceptance rules

- Positive and negative trigger cases exist.
- Output evals include expected properties and failure modes.
- No eval requires live secrets, real-target offensive actions, or irreversible side effects.
- Dynamic facts must use fixed time windows or be marked source-dependent.
