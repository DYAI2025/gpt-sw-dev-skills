# Source Map

This source map records sources used to build the skill. User files define requested behavior but do not prove external platform facts.

## S001 - User-provided system instruction
- type: user_provided
- title: Eingefügter Text.txt
- location: /mnt/data/Eingefügter Text.txt, inspected 2026-06-26
- purpose: target skill name, mission, mandatory pipeline, output contract, security boundaries, source policy, architecture expectations
- reliability: strong as user requirement
- limitations: external claims inside it remain unverified unless separately checked
- use_in_skill: SKILL.md pipeline, output order, source discipline, safety boundaries, package structure
- confidence_default: 4
- verification_status: verified as inspected user input

## S002 - Existing Deep Reasoning skill
- type: user_provided
- title: deepReasoning.zip / SKILL (8).md and references
- location: /mnt/data/deepReasoning.zip, inspected 2026-06-26
- purpose: preserve core reasoning triggers, PS+, ToT, PoT, SC, ER, MP, CoVe, tool suggestions, self-evaluation, math checks and prompt templates
- reliability: strong as prior project artifact
- limitations: lacks enterprise source map, fixed output-order validator, release gate, installability report, and explicit defensive-cyber boundary
- use_in_skill: core functionality preservation and reasoning-method references
- confidence_default: 4
- verification_status: verified as inspected user input

## S003 - User-provided roadmap
- type: user_provided
- title: enterprise_forschungs_und_build_roadmap_f_r_deep_.md
- location: /mnt/data/enterprise_forschungs_und_build_roadmap_f_r_deep_.md, inspected 2026-06-26
- purpose: enterprise architecture ideas, standards alignment candidates, MCP/tool safety concerns, schema and eval suggestions
- reliability: useful as roadmap, not external proof
- limitations: contains dynamic platform claims and quantitative claims that require primary-source verification
- use_in_skill: context for standards alignment, eval strategy, source gating and safety controls
- confidence_default: 3
- verification_status: partially_verified

## S004 - OpenAI Skills documentation
- type: primary
- title: OpenAI API Skills documentation
- location: https://developers.openai.com/api/docs/guides/tools-skills, accessed 2026-06-26
- purpose: current OpenAI skill bundle behavior, SKILL.md manifest, upload limits, safety warnings
- reliability: primary product documentation
- limitations: platform behavior can change; users must re-check before deployment
- use_in_skill: installability, package shape, safety warnings
- confidence_default: 5
- verification_status: verified

## S005 - Agent Skills specification
- type: primary
- title: Agent Skills specification
- location: https://agentskills.io/specification, accessed 2026-06-26
- purpose: SKILL.md frontmatter, name and description constraints, progressive disclosure, optional directories
- reliability: primary open-format specification
- limitations: client implementations may vary
- use_in_skill: frontmatter constraints, progressive disclosure, validation rules
- confidence_default: 5
- verification_status: verified

## S006 - OpenAI MCP and Connectors documentation
- type: primary
- title: OpenAI API MCP and Connectors documentation
- location: https://developers.openai.com/api/docs/guides/tools-connectors-mcp, accessed 2026-06-26
- purpose: MCP risk and approval guidance for external tool servers
- reliability: primary product documentation
- limitations: third-party MCP servers remain outside package control
- use_in_skill: MCP adapter safety and tool approval policy
- confidence_default: 5
- verification_status: verified

## S007 - OpenAI Codex AGENTS.md documentation
- type: primary
- title: Custom instructions with AGENTS.md – Codex
- location: https://developers.openai.com/codex/guides/agents-md, accessed 2026-06-26
- purpose: project instruction discovery and AGENTS.md handoff behavior for Codex
- reliability: primary product documentation
- limitations: specific to Codex; not universal to all IDE agents
- use_in_skill: AGENTS.md and IDE handoff notes
- confidence_default: 5
- verification_status: verified

## S008 - Research on agent skill risks
- type: secondary
- title: Recent arXiv skill security/evaluation papers
- location: arXiv search results inspected 2026-06-26
- purpose: inform risk awareness around malicious skills and eval methodology
- reliability: preprint research, useful but not an operational standard
- limitations: not peer-reviewed final standards; do not claim definitive rates as package facts
- use_in_skill: risk framing and eval emphasis only
- confidence_default: 3
- verification_status: partially_verified

## Open issues

- SOURCE_NEEDED: Exact ChatGPT frontend installation UI behavior is not controlled by this package.
- MISSING: Organization-specific legal, compliance, data classification and MCP server inventory.

## S009 - OASIS SARIF 2.1.0 JSON Schema
- type: primary
- title: Static Analysis Results Format (SARIF) Version 2.1.0 JSON Schema
- location: https://docs.oasis-open.org/sarif/sarif/v2.1.0/os/schemas/sarif-schema-2.1.0.json, accessed 2026-06-27
- purpose: code finding companion artifact and SARIF-compatible export rule
- reliability: primary standard schema
- limitations: covers static-analysis result interchange, not complete human audit reports
- use_in_skill: `code_findings.sarif.json` requirement when code findings exist
- confidence_default: 5
- verification_status: verified

## S010 - RFC 8259 JSON
- type: primary
- title: The JavaScript Object Notation (JSON) Data Interchange Format
- location: https://www.rfc-editor.org/rfc/rfc8259, accessed 2026-06-27
- purpose: machine-readable JSON artifact baseline
- reliability: Internet Standards Track document
- limitations: JSON defines data format, not domain-specific report semantics
- use_in_skill: `analysis_report.json` format baseline
- confidence_default: 5
- verification_status: verified

## S011 - JSON Schema Draft 2020-12
- type: primary
- title: JSON Schema Draft 2020-12
- location: https://json-schema.org/draft/2020-12, accessed 2026-06-27
- purpose: schema-validation orientation for machine-readable reports
- reliability: primary JSON Schema specification page
- limitations: local validators in this package implement deterministic structural checks, not full Draft 2020-12 semantics
- use_in_skill: schema design and validation guidance
- confidence_default: 5
- verification_status: verified

## S012 - CommonMark 0.31.2
- type: primary
- title: CommonMark Spec 0.31.2
- location: https://spec.commonmark.org/0.31.2/, accessed 2026-06-27
- purpose: unambiguous Markdown alignment for human-readable reports
- reliability: primary CommonMark specification
- limitations: rendering differences can still occur with extensions outside CommonMark
- use_in_skill: `analysis_report.md` format baseline
- confidence_default: 5
- verification_status: verified

## S013 - ISO 19011:2026
- type: primary
- title: Guidelines for auditing management systems
- location: https://www.iso.org/standard/19011, accessed 2026-06-27
- purpose: audit logic alignment and no-certification boundary
- reliability: primary ISO public standard page
- limitations: paid standard text not included; public page supports high-level claims only
- use_in_skill: audit process framing and `standard_aligned_not_certified` rule
- confidence_default: 5
- verification_status: verified

## S014 - ISO/IEC 25010:2023
- type: primary
- title: Systems and software engineering — SQuaRE — Product quality model
- location: https://www.iso.org/standard/78176.html, accessed 2026-06-27
- purpose: optional software-quality mapping for code, repository, and architecture audits
- reliability: primary ISO public standard page
- limitations: paid standard text not included; public page supports high-level model claim only
- use_in_skill: software quality finding taxonomy and optional `quality_model_mapping.json`
- confidence_default: 5
- verification_status: verified

## S015 - NIST OSCAL
- type: primary
- title: Open Security Controls Assessment Language
- location: https://pages.nist.gov/OSCAL/, accessed 2026-06-27
- purpose: optional control-based security assessment artifact format
- reliability: primary NIST project documentation
- limitations: optional security-control data format, not a universal analysis report template
- use_in_skill: optional `oscal-assessment-results.json`
- confidence_default: 5
- verification_status: verified

## S016 - W3C Web Annotation Data Model
- type: primary
- title: Web Annotation Data Model
- location: https://www.w3.org/TR/annotation-model/, accessed 2026-06-27
- purpose: optional text-span and marker annotation artifacts
- reliability: W3C recommendation-track specification
- limitations: optional annotation exchange model, not a full audit report schema
- use_in_skill: optional `annotations.w3c.jsonld`
- confidence_default: 5
- verification_status: verified

## S017 - Journal Article Tag Suite
- type: primary
- title: Journal Article Tag Suite
- location: https://jats.nlm.nih.gov/, accessed 2026-06-27
- purpose: optional scientific article interchange artifact
- reliability: primary JATS documentation site
- limitations: article markup format, not required for general reasoning reports
- use_in_skill: optional `article.jats.xml`
- confidence_default: 5
- verification_status: verified

## S018 - Capafy Publisher page
- type: primary
- title: Capafy For Publishers
- location: https://capafy.ai/earn, accessed 2026-06-27
- purpose: publishing modes, upload package expectations, agent card expectation, source visibility distinction between cloud and download modes
- reliability: primary platform page
- limitations: public page may omit private Publisher Console fields and current review implementation details
- use_in_skill: Capafy listing pack, pricing/execution-model notes, source-exposure warning
- confidence_default: 5
- verification_status: verified

## S019 - Capafy Publisher Agreement
- type: primary
- title: Capafy Publisher Agreement v1.0
- location: https://capafy.ai/publisher-agreement, accessed 2026-06-27
- purpose: required submission fields, data sharing declaration, support email, privacy notice, test cases, naming rules, content standards, prohibited content, regulated-domain requirements, IP/source visibility and credential handling
- reliability: primary legal/publisher source
- limitations: legal terms can change and final interpretation requires publisher review
- use_in_skill: Capafy compliance gates, listing truthfulness, privacy/data-flow files, support obligations, regulated-domain disclaimers, security gates
- confidence_default: 5
- verification_status: verified

## S020 - Capafy Privacy Policy
- type: primary
- title: Capafy Privacy Policy v1.0
- location: https://capafy.ai/privacy-policy, accessed 2026-06-27
- purpose: platform privacy context, publisher data-practice disclosure responsibility, AI interaction data handling, retention, user rights, external service disclosure expectations
- reliability: primary platform privacy source
- limitations: does not replace publisher's own privacy notice or legal counsel
- use_in_skill: privacy notice, data-flow declaration, external service disclosure, retention caveats
- confidence_default: 5
- verification_status: verified

## S021 - Capafy Review & Rating Guidelines
- type: primary
- title: Capafy Review & Rating Guidelines v1.0
- location: https://capafy.ai/review-guidelines, accessed 2026-06-27
- purpose: review authenticity, accuracy, self-promotion and off-platform solicitation boundaries
- reliability: primary platform policy source
- limitations: addresses user reviews, not full skill submission review
- use_in_skill: support and buyer-communication policy; no review manipulation rule
- confidence_default: 5
- verification_status: verified

