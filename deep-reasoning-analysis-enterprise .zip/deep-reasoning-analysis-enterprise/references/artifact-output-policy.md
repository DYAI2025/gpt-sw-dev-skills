# Artifact Output Policy

## Mandatory artifacts

Every completed analysis must produce or include both standard artifacts:

1. `analysis_report.md`
   - Human-readable Markdown.
   - CommonMark-aligned.
   - Must preserve the required section order in `references/output-order-contract.md`.

2. `analysis_report.json`
   - Machine-readable JSON.
   - RFC 8259 JSON.
   - Must validate against `schemas/analysis-report.schema.json`.

If the runtime cannot create files, the assistant must include both artifacts inline as separate sections and mark file creation as `NOT_AVAILABLE_IN_RUNTIME` in `artifact_policy.runtime_file_status`.

## Required code-analysis companion artifact

When the task is classified as code analysis, repository analysis with code findings, static analysis, security code review, or software quality audit with code findings, the report must also produce:

3. `code_findings.sarif.json`
   - SARIF 2.1.0-compatible JSON.
   - Required for code findings.
   - Companion artifact only; it never replaces `analysis_report.json`.

If code is discussed but no code findings are produced, state this in `artifact_policy.sarif_required` and explain why SARIF was not emitted.

## Optional domain artifacts

Optional artifacts may be proposed when they improve transparency, validation, or downstream reuse. They must be listed in `optional_artifacts` with `artifact_name`, `format`, `required_when`, `status`, `validator`, and `reason`.

Recommended optional artifacts:

- `source_map.json` for large source inventories.
- `evidence_ledger.jsonl` for large claim-evidence tables.
- `verification_report.json` for CI validation summaries.
- `annotations.w3c.jsonld` for span-based text annotations.
- `oscal-assessment-results.json` for control-based security assessment data.
- `article.jats.xml` only for scientific article interchange contexts.
- `quality_model_mapping.json` for ISO/IEC 25010-aligned software-quality mappings.

## Claim language

The skill must use these labels:

- `standard_aligned`: output follows selected standard logic or structure where applicable.
- `schema_validated`: output passed a local schema or deterministic validator.
- `format_compatible`: artifact is shaped for a format such as SARIF but has not been certified by an external authority.
- `not_certified`: no external certification or formal conformity assessment is claimed.

Forbidden labels unless separately proven:

- `certified`
- `legally_audited`
- `officially_compliant`
- `guaranteed_compliant`

## Blocking conditions

Block or revise the report when:

- `analysis_report.md` is missing.
- `analysis_report.json` is missing or invalid.
- Code findings exist but `code_findings.sarif.json` is absent.
- `standards_alignment`, `evidence_ledger`, `findings`, `artifact_policy`, or `optional_artifacts` is missing from JSON.
- Any standard claim overstates certification, compliance, or external validation.

## Adaptive Output System

The canonical report pair remains mandatory: `analysis_report.md` and `analysis_report.json`. Additional outputs are selected either by explicit user request or by `auto` mode.

Supported user-facing formats:

- `markdown`: canonical CommonMark report.
- `json`: canonical RFC 8259 machine-readable report.
- `html`: self-contained interactive report for inspection and presentation.
- `pdf`: compact executive or stakeholder summary when rendering support exists.
- `evidence-data`: `evidence_ledger.jsonl` and `claim_matrix.csv`.
- `sarif`: SARIF-compatible code findings when code findings exist.
- `audit-pack`: bundled review package with manifests and validation files.
- `all`: all applicable formats that the runtime can produce safely.
- `auto`: the skill selects the smallest sufficient output set.

Auto-selection rules:

- Always include `analysis_report.md` and `analysis_report.json`.
- Add `analysis_report.html` for complex evidence, many claims, multiple sources, technical architecture, repository review, market or financial figures, stakeholder presentation, or marketplace demo value.
- Add `evidence_ledger.jsonl` and `claim_matrix.csv` when there are more than eight material claims, more than five sources, quantitative claims, disputed evidence, compliance/readiness findings, or explicit verification needs.
- Add `executive_summary.pdf` for leadership, board, buyer-facing, or compact handoff contexts when PDF rendering exists.
- Add `code_findings.sarif.json` whenever code findings exist.
- Add `audit_pack.zip` whenever three or more artifacts are generated, or when the user requests review, audit, verification, packaging, marketplace evidence, compliance readiness, or stakeholder handoff.

Static interactive HTML may include local search, filters, sortable tables, expandable evidence cards, source jumps, precomputed Q&A cards, and deterministic calculators. Live document chat requires disclosed runtime integration, model/API permission, data classification, and consent.

