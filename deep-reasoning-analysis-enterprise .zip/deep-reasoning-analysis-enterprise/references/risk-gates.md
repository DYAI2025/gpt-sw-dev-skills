# Risk Gates

## Levels

| Level | Meaning | Behavior |
|---|---|---|
| low | ordinary technical or analytical task | proceed with standard source and output validation |
| medium | substantial uncertainty, external tools, or sensitive business impact | require explicit evidence plan and caveats |
| high | safety, legal, medical, financial, security, or operational impact | require expert review and strict source discipline |
| blocked | unsafe, unauthorized, or unsupported task | refuse or redirect to safe analysis |

## Blocking triggers

- Offensive cyber request.
- Request to bypass access controls or authentication.
- Missing authorization for real-world target analysis.
- Legal, medical, financial or safety conclusion without adequate professional review.
- Claims that require current facts when current verification is unavailable.
