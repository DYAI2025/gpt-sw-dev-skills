# path: references/audit-pack-manifest.md

# Audit Pack Manifest Policy

## Purpose

The Audit Pack is the bundled evidence and verification handoff for serious review workflows. It should make the analysis reusable, inspectable, and portable.

## Required manifest fields

- `pack_name`
- `created_at`
- `analysis_type`
- `source_count`
- `artifact_count`
- `canonical_report`
- `machine_report`
- `visual_report`
- `evidence_exports`
- `verification_files`
- `conditional_artifacts`
- `blocked_artifacts`
- `runtime_notes`
- `limitations`

## Recommended files

- `README.md`
- `analysis_report.md`
- `analysis_report.json`
- `analysis_report.html`
- `executive_summary.pdf`
- `evidence_ledger.jsonl`
- `claim_matrix.csv`
- `artifact_manifest.json`
- `verification_manifest.json`
- `validation_log.txt`
- `code_findings.sarif.json` when applicable

## Review rule

Every artifact in the ZIP must be listed in `artifact_manifest.json`. Every omitted but selected artifact must be listed in `blocked_artifacts` with a reason.
