# Capability Parity Policy

Do not claim runtime parity across agents unless it is tested in the target runtime.

## Claim labels

- `semantic_portability`: instructions can be transferred conceptually.
- `file_portability`: folder and files can be copied.
- `script_portability`: scripts run in the target environment.
- `tool_parity`: external tool behavior is equivalent.
- `ui_parity`: frontend behavior is equivalent.

Only the first two are design goals by default. The rest require target-client verification.
