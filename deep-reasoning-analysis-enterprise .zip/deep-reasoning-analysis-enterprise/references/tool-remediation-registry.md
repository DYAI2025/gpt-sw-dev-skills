# Tool Remediation Registry

## Package-local validators

- `scripts/validate_capafy_readiness.py`: checks Capafy listing files, data-flow docs, privacy/support/test files, overclaim language and source-map Capafy entries.
- `scripts/audit_skill_zip.py`: static ZIP/directory inventory and conservative scan without executing packaged code.
- `scripts/validate_audit_report.py`: validates audit-report structure.
- `scripts/generate_capafy_remediation_plan.py`: turns audit findings into file-level remediation items.
- `scripts/validate_capafy_remediation.py`: validates a remediated package using the Capafy readiness rules.
- `scripts/package_skill.py`: packages after existing core validators pass.

## External research hooks

Re-check official platform pages before each submission because publisher requirements and policies can change.

## Human review hooks

- publisher support email and legal entity information;
- selected pricing model and tax status;
- declared LLM provider and data-retention policy;
- professional licensing status if marketed in a regulated domain;
- download-vs-cloud IP strategy.
