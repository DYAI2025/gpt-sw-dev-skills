# Standards Alignment

This skill uses standards as alignment references, not as certification claims.

## Required baseline

- CommonMark-aligned Markdown for `analysis_report.md`.
- RFC 8259 JSON for `analysis_report.json`.
- JSON Schema Draft 2020-12 orientation for report schema validation where compatible with the runtime validator.
- ISO 19011:2026-aligned audit logic for audit-style work.

## Code and software analysis

- SARIF 2.1.0-compatible JSON is required for code findings in `code_findings.sarif.json`.
- ISO/IEC 25010:2023 may be used as a software-quality reference model for product/system/code-quality mappings.

## Optional domain alignments

- W3C Web Annotation Data Model may be used for text-span or marker annotation artifacts.
- NIST OSCAL may be used for control-based security assessment data.
- JATS may be used for scientific article interchange contexts.
- PRISMA/EQUATOR-style checklist logic may be used for scientific-reporting transparency, but do not claim PRISMA compliance unless the exact checklist has been completed.

## Source map additions

- S009: OASIS SARIF 2.1.0 JSON Schema, primary, supports SARIF-compatible code finding export.
- S010: RFC 8259, primary, supports JSON artifact baseline.
- S011: JSON Schema Draft 2020-12, primary, supports schema-validation orientation.
- S012: CommonMark 0.31.2, primary, supports Markdown parsing alignment.
- S013: ISO 19011:2026, primary, supports audit logic alignment and no-certification warning.
- S014: ISO/IEC 25010:2023, primary, supports software-quality mapping.
- S015: NIST OSCAL, primary, supports optional control-based security artifacts.
- S016: W3C Web Annotation Data Model, primary, supports optional text annotation artifacts.
- S017: JATS, primary, supports optional scientific article interchange artifacts.

## Prohibited claims

Do not claim:

- ISO certification.
- formal PRISMA compliance without completed checklist evidence.
- legal audit validity.
- third-party approval.
- identical behavior across agent clients.
