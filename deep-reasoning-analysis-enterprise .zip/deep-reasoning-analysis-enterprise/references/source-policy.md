# Source Policy

## Purpose

Prevent source laundering. User-provided files, derived summaries, and model inferences must not be silently upgraded into external truth.

## Source classes

| Class | Definition | Allowed use |
|---|---|---|
| `primary` | Official specification, standard, product documentation, source repository, law or original dataset | May support hard operational rules when current and directly relevant |
| `secondary` | Reputable explanation, textbook, expert article or survey | Context and interpretation; does not override primary sources |
| `user_provided` | Files, notes, screenshots, prompts, roadmaps, internal rules supplied by the user | Project requirements and context; external factual claims still need verification |
| `derived` | Extraction, summary, OCR, transformed data, or model-generated synthesis | Navigation only unless checked against originals |
| `uncertain` | Contradictory, incomplete, unattributed, outdated or unverifiable material | Do not use as hard rule; mark SOURCE_NEEDED |

## Required fields

Every source map entry must include: source_id, title, type:, location, purpose:, reliability:, limitations:, use_in_skill, confidence_default:, and verification_status.

## MISSING and SOURCE_NEEDED

Use `MISSING` when required information is absent. Use `SOURCE_NEEDED` when a claim exists but is not adequately supported. Never invent standards, versions, API parameters, tool behavior, legal advice, medical advice, security guarantees, market metrics or comparative claims.

## Confidence scale

- 5: directly supported by current primary source.
- 4: strong source or convergent evidence.
- 3: plausible but indirect; assumption only.
- 2: weak, conflicting or context-specific; do not operationalize.
- 1: unsupported or contradicted; block or mark SOURCE_NEEDED.
