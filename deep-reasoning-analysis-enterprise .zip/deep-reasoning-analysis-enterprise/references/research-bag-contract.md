# Research-Bag Contract

Before building or revising the skill, prepare:

- Source Inventory
- Knowledge Model
- Capability Candidates
- Browser-Act Candidates when relevant
- Eval Requirements
- Build Recommendation

## Blocking rules

- `blocked` recommendation stops build.
- SOURCE_NEEDED items may not become hard instructions.
- Confidence below 4 may not support non-negotiable rules.
- Browser capability generation requires permission boundary and verification path.
