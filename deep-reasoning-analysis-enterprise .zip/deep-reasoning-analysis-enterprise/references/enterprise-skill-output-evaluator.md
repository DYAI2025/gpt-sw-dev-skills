# Enterprise Skill Output Evaluator

Use this reference to evaluate generated skill packages. The evaluator does not build a new skill unless explicitly instructed to revise.

## Dimensions

- Spec compliance: SKILL.md, frontmatter, name, description, progressive disclosure.
- Research quality: source map, source classes, confidence, MISSING and SOURCE_NEEDED handling.
- Enterprise readiness: security/tool gate, no secrets, no destructive defaults, permission boundaries.
- Architecture quality: coherent scope, references, validators, evals and reproducible packaging.
- Release-gate integrity: craftsmanship PASS, anti-confabulation PASS, anti-sycophancy below threshold, bias not BLOCKED.

## Decisions

PASS, PASS_WITH_MINOR_REVISIONS, REVISE, REBUILD or BLOCKED.
