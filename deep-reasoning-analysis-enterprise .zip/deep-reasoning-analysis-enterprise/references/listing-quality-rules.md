# Listing Quality Rules

Source basis: S018 and S019.

## Buyer clarity requirements

The listing must answer:

1. What task does the agent perform?
2. Who is it for?
3. What inputs are required?
4. What outputs are produced?
5. What evidence and validation discipline is used?
6. What are the limits and prohibited uses?
7. What data leaves the runtime?
8. How can users get support?
9. Which execution model is being sold?
10. What test case demonstrates expected behavior?

## Promise discipline

Allowed language:

- evidence-grounded analysis
- source mapping
- hallucination controls
- machine-readable reports
- validation scripts
- defensive cybersecurity boundaries
- SARIF-compatible findings where code findings exist

Avoid language:

- certification claims, guarantee claims, official-status claims, legal-compliance claims, medical-safety claims, investment-advice claims, full-security claims, infallibility claims

## Agent card structure

Use: title, one-line value proposition, target users, inputs, outputs, guardrails, example prompts, limitations, data-flow summary, support policy, pricing/execution notes.
