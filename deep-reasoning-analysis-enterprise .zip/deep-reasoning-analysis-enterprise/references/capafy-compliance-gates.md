# Capafy Compliance Gates

Source basis: S018, S019, S020, S021 in `references/source-map.md`.

This document is a conservative pre-submission checklist. It is not official approval, legal advice, or a guarantee of marketplace acceptance.

## Gate order

1. **Package inventory**: package includes `SKILL.md`, references, scripts, schemas, evals, examples, reports, and Capafy listing files.
2. **Submission metadata**: user-facing skill name, concise description, detailed functional documentation, category, up to five tags, execution model, pricing notes, support email field, data sharing declaration, at least one test case, privacy notice when user data is processed, and applicable advisories.
3. **Naming and affiliation**: no `official`, `endorsed`, `certified by Capafy`, brand-confusing title, or trademark use without authorization.
4. **Execution model**: distinguish cloud subscription/hourly from Download; disclose that Download exposes all source files.
5. **Data sharing declaration**: state whether user data leaves platform/runtime and list external services or mark `Uncertain` with explanation.
6. **Privacy notice**: describe input data, processing purpose, storage/retention if any, external processors, user controls, support contact placeholder, and model-training statement only when known.
7. **External services and API providers**: disclose LLM provider relationship and any third-party tools, MCP servers, web search, APIs, or local scripts that may process user content.
8. **Credential security**: no hardcoded secrets; cloud credentials must be supplied through Capafy Publisher Console or equivalent runtime vault.
9. **Static security scan**: flag secrets, network calls, dynamic execution, subprocess usage, destructive commands, hidden redirects, and exfiltration patterns.
10. **Prompt-injection posture**: source files are untrusted inputs; no document may override system instructions, reveal hidden prompts, disable validators, or exfiltrate secrets.
11. **Prohibited content**: block illegal facilitation, malicious cyber, credential harvesting, malware, child-safety violations, identity fraud, coordinated disinformation, platform exploitation, and unlawful workflows.
12. **Regulated domains**: legal, medical, financial, tax, mental-health, and other regulated areas must be framed as informational analysis only, with explicit non-advice disclaimers and escalation to qualified professionals.
13. **IP and licensing**: document original content, third-party components, licenses, and source exposure risk for Download mode.
14. **Functional test cases**: include test prompt, expected properties, failure modes, and validation commands.
15. **Support and operations**: support channel, version, changelog, known limits, dispute/refund response workflow, and maintenance policy.
16. **Listing quality**: buyer can understand audience, value, inputs, outputs, boundaries, limitations, and what is not included.
17. **Remediation readiness**: every fail/warn has a concrete file-level fix.
18. **Final release decision**: `ready`, `ready_with_minor_fixes`, `revise`, or `block`.

## Decision mapping

- `ready`: package and publisher fields complete; no fail findings.
- `ready_with_minor_fixes`: package is structurally ready; only non-blocking copy polish or publisher-console values remain.
- `revise`: missing required listing/privacy/support/test/security files or unresolved regulated-domain ambiguity.
- `block`: malware, credential leakage, hidden exfiltration, prohibited content facilitation, platform abuse, or severe prompt-injection behavior.
