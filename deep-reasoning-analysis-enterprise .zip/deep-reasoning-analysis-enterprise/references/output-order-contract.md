# Output Order Contract

The human-readable report must preserve this order exactly:

1. deep_reasoning_analysis_report
2. meta
3. intake_scope
4. source_map
5. standards_alignment
6. risk_gate
7. method_selection
8. evidence_plan
9. evidence_ledger
10. tool_plan
11. analysis
12. findings
13. verification
14. bias_and_failure_modes
15. synthesis
16. artifact_policy
17. optional_artifacts
18. machine_readable_json
19. human_readable_summary
20. open_questions
21. ultrathink_craftsmanship_gate

## Required JSON object fields

The JSON report uses these top-level keys in the same order:

- meta
- intake_scope
- source_map
- standards_alignment
- risk_gate
- method_selection
- evidence_plan
- evidence_ledger
- tool_plan
- analysis
- findings
- verification
- bias_and_failure_modes
- synthesis
- artifact_policy
- optional_artifacts
- human_readable_summary
- open_questions
- ultrathink_craftsmanship_gate

The `machine_readable_json` XML-like section is the JSON itself when a JSON artifact is delivered separately.

## Artifact order

When files can be created, the default artifact set is:

1. `analysis_report.md`
2. `analysis_report.json`
3. `code_findings.sarif.json` when code findings exist
4. optional domain artifacts listed in `optional_artifacts`


## Adaptive Output Selection Extension

After `machine_readable_json`, include `adaptive_output_selection` when adaptive outputs are selected or discussed. This section should state:

- `output_selection_mode`
- `user_requested_outputs`
- `auto_selected_outputs`
- `blocked_outputs`
- `interactive_html_mode`
- `audit_pack_manifest`
- `runtime_capability_notes`

The extension does not remove or reorder the canonical analysis sections. If file generation is not available, describe the selected artifact plan inline and mark unavailable files as `MISSING_RUNTIME_CAPABILITY`.
