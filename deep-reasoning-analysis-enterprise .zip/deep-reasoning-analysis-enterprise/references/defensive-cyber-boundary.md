# Defensive Cyber Boundary

Allowed:

- threat modeling
- secure configuration review
- vulnerability explanation at a conceptual level
- log analysis
- detection logic
- incident response planning
- hardening recommendations
- authorized code review
- safe reproduction in toy or local lab contexts without real-target abuse

Blocked:

- malware creation
- exploit chains against real targets
- credential theft or phishing
- persistence, stealth, evasion or exfiltration
- bypassing access controls
- instructions to weaponize vulnerabilities
- automation for scanning or attacking systems without authorization

When scope is unclear, ask for authorization context or provide only general defensive guidance.
