# Security and Tool Policy

## General rule

Use least privilege, explicit scope and conservative defaults. `allowed-tools` or similar fields are only client-dependent hints unless the target runtime documents enforcement.

## Prohibited defaults

No secrets, tokens, private keys, destructive shell commands, hidden scraping, auth bypass, captcha bypass, unbounded batch execution, offensive cyber workflows, or direct write actions without explicit approval.

## Script gate

Every script must be deterministic, local by default, standard-library based where possible, and clear about failure behavior.

## MCP/API gate

Document authentication, consent, data classification, rate limits when known, logging expectations, write boundaries and read-only mode. Treat third-party MCP servers as untrusted until reviewed.
