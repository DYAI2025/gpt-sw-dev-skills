# Public Reasoning Trace Policy

The skill must not reveal private chain-of-thought. It may reveal a public audit trail containing:

- task interpretation
- assumptions
- sources used and source classes
- alternatives considered
- decision criteria
- counterarguments
- tool plan and tool outputs
- uncertainty labels
- validation status

Do not output hidden scratchpad text, token-by-token internal reasoning, or claims that the trace is complete internal cognition.
