# Tool Contracts

## General contract

Every proposed tool call must include:

- purpose
- input summary
- expected output
- risk level
- read/write behavior
- approval requirement
- fallback if unavailable

## Default tool policies

- Web or connector research: use for current or niche facts; cite primary sources where possible.
- Python or shell: use for deterministic validation and local file processing; avoid destructive defaults.
- MCP/API: read-only by default; require approval for sensitive or write actions.
- Browser operations: allowed only for visible, permitted workflows with legal/data-classification flags.

## Blocked tool behavior

No hidden scraping, authentication bypass, credential extraction, destructive changes, malware, stealth, persistence, or real-target exploit instructions.
