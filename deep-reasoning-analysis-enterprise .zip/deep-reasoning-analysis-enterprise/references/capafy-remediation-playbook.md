# Capafy Remediation Playbook

Use this matrix when audit findings fail.

| Finding | Fix |
|---|---|
| Missing Agent Card | Add `capafy/agent-card.md` with buyer-facing value, inputs, outputs, boundaries and example prompts. |
| Missing Data Sharing Declaration | Add `capafy/data-flow-declaration.md` and `capafy/data-flow-declaration.json`. |
| Missing Privacy Notice | Add `capafy/privacy-notice.md` with input classes, processing, retention limits, external providers and user controls. |
| Missing Support Policy | Add `capafy/support-policy.md`; publisher must enter real `support_email` in Publisher Console. |
| Missing functional test | Add `capafy/test-cases.md` and eval files with expected properties/failure modes. |
| Regulated-domain ambiguity | Add non-advice disclaimers and risk gates in `references/category-risk-rules.md` and listing copy. |
| Cyber ambiguity | Ensure `references/defensive-cyber-boundary.md` and listing prohibit offensive use. |
| Overclaiming | Replace guaranteed/certified/official language with `format-compatible`, `schema-validated`, or `standard-aligned-not-certified`. |
| Secrets or suspicious code | Remove credentials, rewrite scripts to local deterministic standard-library behavior, document false positives. |
| Download IP exposure | Add Download-mode source visibility warning and pricing note. |
