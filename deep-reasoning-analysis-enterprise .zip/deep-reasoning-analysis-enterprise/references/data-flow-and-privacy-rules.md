# Data Flow and Privacy Rules

Source basis: S019 and S020.

## Default package behavior

The skill package contains instructions, schemas, references, evals, examples, and deterministic local validators. It does not include hardcoded API credentials. It does not intentionally store user inputs outside the active runtime.

## Data processed

Potential user inputs include documents, repositories, code snippets, research claims, mathematical proofs, security logs, architecture descriptions, and analysis instructions. These may include personal data if the user supplies it.

## External data flow classes

- `platform_llm_runtime`: user input is processed by the active LLM provider/runtime selected by the host platform or Publisher Console.
- `local_validation_only`: deterministic scripts read local report/package files and emit validation results.
- `user_approved_tools`: optional external search, MCP, repository tools, or APIs may be used only after tool planning and disclosure.
- `download_mode_user_environment`: buyer receives the package and controls local execution and any connected client tools.

## Declaration rule

Use `Uncertain` if the runtime may dynamically access external services. Explain which tool categories can be used and under what user request or approval condition. Do not claim `No external data flow` unless all execution is confined to platform LLM proxy and local validators.

## Retention rule

The package itself does not define Capafy or LLM-provider retention. Publisher listing must point users to Capafy platform privacy terms and the declared LLM provider policies. If the publisher runs external services, retention and deletion contacts must be stated.

## Sensitive data rule

The skill must not request sensitive personal data unless necessary for the analysis. If sensitive data is provided, minimize use, avoid reproduction in final reports, and mark privacy risk in `risk_gate`.
