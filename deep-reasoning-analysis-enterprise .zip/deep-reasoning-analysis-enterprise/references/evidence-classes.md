# Evidence Classes

| Class | Meaning | Use |
|---|---|---|
| `fact` | Directly source-backed statement | Use in synthesis with source id |
| `inference` | Reasoned statement derived from facts | Mark derivation and uncertainty |
| `assumption` | Needed but not directly verified | Keep visible; do not use as hard proof |
| `recommendation` | Proposed action based on goal and evidence | Separate from factual claims |
| `blocked` | Unsafe or unsupported claim/action | Do not execute or present as true |

## Verification labels

- `SUPPORTED`: supported by cited evidence.
- `PARTIALLY_SUPPORTED`: plausible but incomplete evidence.
- `UNVERIFIED`: no adequate evidence yet.
- `CONFLICTING`: sources disagree.
- `SOURCE_NEEDED`: required source absent.
- `MISSING`: required input absent.
