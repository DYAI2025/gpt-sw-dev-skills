# Agent-Agnostic Compatibility

Compatibility means semantic portability of instructions, files, schemas and validation intent. It does not mean identical tool, shell, MCP, UI, security or file-system behavior across OpenAI, Claude, Gemini, Cursor, Windsurf, Codex or other agents.

## Portability rules

- Keep `SKILL.md` concise and trigger-specific.
- Keep detailed policies in `references/`.
- Keep scripts deterministic and standard-library based.
- Mark external tool behavior as SOURCE_NEEDED until verified per client.
- Provide read-only fallbacks for environments without shell or MCP.
