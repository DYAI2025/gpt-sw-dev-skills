# Claude-Compatible Handoff

This skill is semantically portable to Claude-compatible agents when the host supports reading a folder with `SKILL.md`, references, scripts, and examples. Compatibility is a design target, not a guarantee of identical runtime behavior.

## Handoff instructions

- Load `SKILL.md` first.
- Keep the 16-phase pipeline and output order unchanged.
- Use `references/` only as needed.
- Run local validators if a code-capable environment is available.
- Do not reveal private chain-of-thought; output only public reasoning traces.

## Known differences

Tool availability, security enforcement, file mounting, shell access, and MCP behavior can differ by host. Treat tool declarations as capability hints until verified in the target client.
