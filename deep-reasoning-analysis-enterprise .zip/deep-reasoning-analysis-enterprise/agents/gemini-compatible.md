# Gemini-Compatible Handoff

The skill can be translated into a Gemini or other frontier-model system instruction by preserving its activation criteria, source discipline, risk gates, fixed pipeline, output order, schemas, and validators.

## Portability limits

- File-system skill loading may not be native in all clients.
- JSON schema enforcement and tool execution semantics can vary.
- MCP or connector support must be independently verified.

Use `references/capability-parity-policy.md` before claiming runtime parity.
