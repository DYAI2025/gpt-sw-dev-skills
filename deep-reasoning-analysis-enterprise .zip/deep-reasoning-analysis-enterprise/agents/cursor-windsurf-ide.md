# Cursor / Windsurf / IDE Handoff

Use this skill in coding IDEs for architecture audits, proof-style reviews, technical RFC evaluation, AI-system risk analysis, and complex debugging hypotheses.

## IDE procedure

1. Read `SKILL.md`.
2. Scope the repository or files explicitly.
3. Use read-only inspection before any modification.
4. Create an evidence plan before running code.
5. Run deterministic validators for any produced JSON report.
6. Keep destructive operations out of default workflows.
