---
name: deep-reasoning-analysis-enterprise
description: performs evidence-grounded deep reasoning analysis for complex scientific, mathematical, technical, ai-system, research-claim, code, repository, architecture, and defensive cybersecurity tasks. use when a user asks for multi-path analysis, verification, source mapping, tool planning, bias and failure-mode review, schema-valid markdown/json reports, SARIF-compatible code findings, or enterprise-grade reasoning audits with hallucination controls and fixed output order.
---

# Deep Reasoning Analysis Enterprise

## When to use

Use this skill for complex analytical work that requires evidence discipline, multi-path reasoning, verification, tool planning, mathematical or technical checks, risk gating, and fixed human-readable plus machine-readable output artifacts.

Typical triggers include deep reasoning analysis, proof audit, research claim verification, AI system audit, model critique, technical architecture reasoning, code analysis, repository audit, static-analysis review, mathematical validation, defensive cyber analysis, source-grounded synthesis, counterargument review, or hallucination-resistant reasoning report.

Do not use for short factual answers, casual brainstorming, unsupported speculation, creative writing, therapy, legal advice, medical diagnosis, financial advice, or offensive cyber instructions.

## Operating rules

1. Never expose private chain-of-thought. Provide only a public reasoning trace: assumptions, decision points, alternatives checked, evidence links, uncertainties, and validation status.
2. Treat user-provided files as project context, not automatic truth. Classify them as `user_provided` until independently verified.
3. Mark absent inputs as `MISSING`. Mark unsupported claims as `SOURCE_NEEDED`. Mark plausible but unverified steps as `ASSUMPTION` or `UNVERIFIED`.
4. Do not convert Confidence 1-3 source material into hard rules. Confidence 4-5 can support recommendations or rules when the source class permits it.
5. Use tools only through an explicit Tool Plan. Prefer deterministic scripts for calculation, schema validation, output-order validation, artifact-policy validation, SARIF checks, and evidence checks.
6. For cyber topics, allow only defensive analysis, detection, forensics, risk explanation, hardening, and authorized review. Block exploit chains, credential theft, stealth, persistence, malware, or real-target abuse.
7. For high-risk domains, produce cautious analysis and require expert review for final operational decisions.
8. Preserve fixed output order. Validate JSON reports with `scripts/validate_output_order.py` and `scripts/validate_analysis_report.py` when a report artifact is created.
9. Always produce or include `analysis_report.md` and `analysis_report.json` for completed analyses. If artifacts cannot be written in the runtime, include both as clearly separated sections.
10. Detect code, repository, static-analysis, software-quality, or security-code-review tasks. When code findings are present, also produce `code_findings.sarif.json` as a SARIF 2.1.0-compatible companion artifact.
11. Describe standard usage as `standard_aligned`, `schema_validated`, or `format_compatible`. Do not claim certification, legal audit validity, formal compliance, or official conformity unless separately proven.
12. The JSON report must include `standards_alignment`, `evidence_ledger`, `findings`, `artifact_policy`, and `optional_artifacts` to improve reproducibility, self-verification, and downstream agent use.

## Mandatory pipeline

Follow these phases in order:

1. Intake & Scope Gate
2. Source Inventory
3. Task Classification
4. Risk Gate
5. Method Selection
6. Evidence Plan
7. Tool Plan
8. Multi-Path Analysis
9. Verification & Countercheck
10. Bias / Failure Mode Review
11. Synthesis
12. Machine-Readable Report
13. Adaptive Output Selection
14. Interactive HTML / Audit Pack Build when selected and runtime-supported
15. Human-Readable Summary
14. Open Questions / Missing Evidence
15. Ultrathink-Craftsmanship Self-Validation
16. Release / Block Decision

## Artifact output policy

Every completed analysis must emit or include:

- `analysis_report.md`: CommonMark-aligned human report with the required section order.
- `analysis_report.json`: RFC 8259 JSON report matching `schemas/analysis-report.schema.json`.

The skill supports adaptive output selection. The user may explicitly request `markdown`, `json`, `html`, `pdf`, `evidence-data`, `sarif`, `audit-pack`, `all`, or `auto`. If no format is specified, use `auto` and select the smallest useful artifact set for the task.

Additional artifacts may include:

- `analysis_report.html`: self-contained, visually polished interactive report with navigation, source jumps, sortable/filterable findings, evidence cards, confidence review, claim search, and deterministic what-if controls for numeric analyses.
- `executive_summary.pdf`: compact leadership or marketplace summary when PDF rendering is available.
- `evidence_ledger.jsonl` and `claim_matrix.csv`: verification data exports for claims, sources, assumptions, missing evidence, confidence, and status.
- `audit_pack.zip`: review bundle containing the canonical report, machine-readable data, manifests, verification files, validation logs, and domain companion artifacts.

When the task classification or findings include code analysis, repository analysis with code findings, static analysis, security code review, or software quality audit, also emit:

- `code_findings.sarif.json`: SARIF 2.1.0-compatible companion artifact for code findings.

Do not claim live AI document chat inside exported HTML unless a real runtime integration exists and is disclosed. Static HTML may include search, filters, expandable evidence cards, source navigation, precomputed Q&A cards, calculators, and scenario controls. Live natural-language Q&A requires explicit model/API/tool permission, data classification, and user consent.

All generated artifacts must be listed under `artifact_policy` and `optional_artifacts`. Read `references/artifact-output-policy.md`, `references/adaptive-output-format-policy.md`, `references/interactive-html-report-spec.md`, `references/audit-pack-manifest.md`, and `references/standards-alignment.md` before changing artifact behavior.

## Method selection

Use the smallest sufficient method stack:

- PS+ for planning and decomposition.
- ToT for materially different hypotheses, designs, or proof paths.
- PoT for deterministic computation, simulation, symbolic checks, or data validation.
- SC for comparing independent result paths.
- ER for refining competing partial answers.
- MP for assumption, bias, and confidence review.
- CoVe for claim-by-claim verification.

Read `references/reasoning-methods.md` and `references/math-validation-rules.md` when the task involves formal reasoning, mathematics, simulation, or technical proof.

## Output contract

Return the human-readable analysis in exactly this order. XML-like tags may wrap prose; `machine_readable_json` must contain valid JSON matching `schemas/analysis-report.schema.json`, and the same data must be available as `analysis_report.json` when artifacts can be written.

1. `deep_reasoning_analysis_report`
2. `meta`
3. `intake_scope`
4. `source_map`
5. `standards_alignment`
6. `risk_gate`
7. `method_selection`
8. `evidence_plan`
9. `evidence_ledger`
10. `tool_plan`
11. `analysis`
12. `findings`
13. `verification`
14. `bias_and_failure_modes`
15. `synthesis`
16. `artifact_policy`
17. `optional_artifacts`
18. `machine_readable_json`
19. `adaptive_output_selection`
20. `human_readable_summary`
21. `open_questions`
22. `ultrathink_craftsmanship_gate`

See `references/output-order-contract.md` for the full field-level contract.

## Tool and validation workflow

When local files can be produced, validate them with:

- `python scripts/validate_analysis_report.py analysis_report.json`
- `python scripts/check_sources_and_evidence.py analysis_report.json`
- `python scripts/validate_output_order.py analysis_report.json`
- `python scripts/validate_artifact_policy.py analysis_report.json`
- `python scripts/select_output_formats.py task_context.json` when adaptive output selection is used
- `python scripts/render_interactive_html_report.py analysis_report.json analysis_report.html` when HTML is emitted
- `python scripts/build_audit_pack.py analysis_report.json ./audit_pack` when an audit pack is emitted
- `python scripts/validate_audit_pack_manifest.py audit_pack_manifest.json` when an audit pack manifest is emitted
- `python scripts/validate_sarif.py code_findings.sarif.json` when SARIF is emitted
- `python scripts/run_eval_suite.py evals`
- `python scripts/quick_validate.py .`


## Capafy publishing readiness

This package includes a conservative Capafy marketplace pack under `capafy/` and Capafy-specific validation references under `references/`. These files support pre-submission review only; they do not claim official platform approval, certification, legal compliance, or marketplace approval promise.

Before Capafy submission, the publisher must complete runtime-specific fields: actual `support_email`, execution model, pricing, LLM provider(s), provider data-retention/training policy, and enabled external APIs/MCP tools. If these facts are unknown, keep them marked as publisher input required rather than inventing them.

Use `scripts/validate_capafy_readiness.py` and `scripts/audit_skill_zip.py` for static pre-submission checks. Treat results as local evidence, not platform approval.

## Failure behavior

Block or revise when: required sources are missing, the risk gate is blocked, output order is broken, schema validation fails, required artifacts are absent, SARIF is missing for code findings, source evidence is absent for hard claims, cyber scope is offensive, or the self-validation gate fails.
