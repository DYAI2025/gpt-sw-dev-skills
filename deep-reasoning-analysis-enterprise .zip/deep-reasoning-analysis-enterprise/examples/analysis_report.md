<deep_reasoning_analysis_report>
## meta
Example markdown artifact.
## intake_scope
Example scope.
## source_map
Example sources.
## standards_alignment
Example standard alignment.
## risk_gate
Example risk gate.
## method_selection
Example method selection.
## evidence_plan
Example evidence plan.
## evidence_ledger
Example evidence ledger.
## tool_plan
Example tool plan.
## analysis
Example public reasoning trace.
## findings
Example findings.
## verification
Example verification.
## bias_and_failure_modes
Example bias and failure modes.
## synthesis
Example synthesis.
## artifact_policy
Example artifact policy.
## optional_artifacts
Example optional artifacts.
## machine_readable_json
See analysis_report.json.
## human_readable_summary
Example summary.
## open_questions
None.
## ultrathink_craftsmanship_gate
Release.
</deep_reasoning_analysis_report>
