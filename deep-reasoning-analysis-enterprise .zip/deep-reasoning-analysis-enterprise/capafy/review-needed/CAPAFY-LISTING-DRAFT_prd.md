# Capafy Listing Draft

Status: draft for publisher review
Skill: ai-native-prd-architect
Version: 1.1.0
Recommended category: Productivity
Secondary categories: Engineering, Research, Analysis
Platform-specific requirements: SOURCE_NEEDED from Capafy publisher interface

---

## Suggested title

AI-Native PRD Architect Enterprise

## Short description

Produces agent-executable Product Requirements Documents — with machine-readable JSON, strict traceability, security controls, and pasteable coding-agent handoff instructions. Built for teams shipping software with Cursor, Claude Code, Windsurf, or any autonomous coding agent.

## Buyer-facing description

Coding agents don't fail because they can't write code. They fail because the specification they received was vague, inconsistent, or missing critical decisions. This skill exists to close that gap.

Submit a product idea, existing PRD, repository summary, feature request, or interview notes — and receive a structured, bounded, traceable specification that an autonomous coding agent can follow without guessing.

Every output goes through eleven quality gates before it ships: missing information is labeled, not invented. Unclear authorization, undefined data ownership, missing rollback paths, and unresolved security decisions are surfaced explicitly — not buried in polished prose.

The result is a document that tells an agent exactly what to build, what to avoid, what to test, and when to stop and ask a human.

## What the buyer gets

For every completed enterprise PRD, the skill produces:

1. `prd_report.md` — human-readable PRD with 26 canonical sections: goals, non-goals, stories, functional and non-functional requirements, data model, API/interface spec, architecture constraints, security controls, sustainability requirements, implementation phases, atomic tasks, acceptance criteria, test matrix, observability, risks, rollback checkpoints, and Definition of Done.
2. `prd_report.json` — machine-readable artifact validated against `schemas/prd-output.schema.json`, including source ledger, evidence classification, standards alignment, findings, security controls, and artifact policy.
3. `code_findings.sarif.json` — SARIF 2.1.0-compatible companion artifact when code or repository findings are present.
4. Pasteable agent handoff instructions for Cursor, Claude Code, Windsurf, GitHub Copilot, or any coding agent runtime.

Compact mode, audit mode, PRD transformation, and context-artifact generation (AGENTS.md, llms.txt, ADRs, coding standards) are also supported.

## Good use cases

- Turning a product idea or set of meeting notes into a full agent-executable PRD.
- Auditing an existing PRD for agent-readiness: finding vague requirements, missing security decisions, undefined data ownership, and untestable acceptance criteria before implementation starts.
- Transforming a legacy Word-doc PRD into structured, machine-readable format for use with a coding agent.
- Generating precise implementation plans and atomic task breakdowns from a validated PRD.
- Producing AGENTS.md, llms.txt, ADR, or coding-standards context files alongside a PRD.
- Repository-aware PRD improvement when existing codebase context is supplied.

## Not for

- writing implementation code as the primary output;
- casual idea brainstorming without a planning deliverable;
- legal, medical, or financial advice;
- claiming compliance certification, platform compatibility guarantees, or regulatory conformance;
- offensive cybersecurity instructions;
- teams that want confident-sounding output regardless of whether the underlying facts are present — this skill labels unknowns instead of inventing them.

## Input disclosure

The skill processes user-submitted text and documents: product ideas, notes, requirements, interview summaries, existing PRDs, architecture descriptions, repository summaries, and code context. All input is user-initiated and user-controlled.

Users should not submit confidential business information, trade secrets, or customer PII unless appropriate for their environment and compliance posture.

## Data-flow disclosure

Static package review found no hardcoded network calls and no packaged credentials. The skill operates as prompt instructions within the buyer's AI runtime session. Processing, retention, and provider data-handling behavior are governed by the host AI platform and LLM provider, not by this package.

## Safety disclaimer

This skill does not claim certified compliance with any legal, regulatory, or formal standards framework. Standards references (ISO/IEC/IEEE 29148, NIST SSDF, SARIF 2.1.0) are used as structural alignment and format references only. Outputs require human review before use in production decisions.

## Safe marketing claims

Use:
- agent-executable PRD with bounded tasks, acceptance criteria, and stop conditions;
- machine-readable JSON validated against published schema;
- explicit labeling of missing information, assumptions, and blockers;
- pasteable agent handoff instructions for major coding-agent runtimes;
- 11 quality gates enforced before output delivery;
- SARIF-compatible code findings for repository-aware work.

Avoid:
- guaranteed agent success or zero-defect implementation;
- certified compliance with any regulatory or formal standard;
- replaces a human product manager or engineering architect;
- works identically across all LLM runtimes without adaptation;
- perfect accuracy or complete specifications from incomplete input.

## Suggested onboarding prompt

Describe what you want to build — or paste your existing PRD, notes, feature request, or repository summary. Tell the skill whether you want a full PRD, a compact PRD, an audit of an existing document, or an agent handoff from a PRD you already have. Include any known constraints, tech stack details, target coding agent, or non-goals you care about. Missing information will be labeled explicitly and surfaced for your review.

## Pricing and support notes

Pricing is not specified in this package. Recommended execution model: subscription (the skill contains reusable methodology, schemas, validators, and reference files that should not be exposed as a download unless source disclosure is intentional).

Suggested starting point: monthly subscription USD 39–79/month depending on expected usage volume, model/runtime cost, and target buyer profile.

Support is limited to package use, validator failures, schema issues, documentation corrections, and output-format problems. The listing must not imply professional legal, compliance, or engineering consulting unless the publisher separately provides and discloses those credentials.
