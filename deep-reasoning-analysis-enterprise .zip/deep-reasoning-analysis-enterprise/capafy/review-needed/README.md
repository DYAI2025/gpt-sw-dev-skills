# Review-needed Capafy listing draft

This folder contains a user-supplied listing draft that was requested to be embedded into the Deep Reasoning Analysis Enterprise package.

Important finding: `CAPAFY-LISTING-DRAFT_prd.md` identifies the skill as `ai-native-prd-architect` and describes PRD-specific outputs such as `prd_report.md`. It was therefore **not** used to overwrite `capafy/listing.md` for Deep Reasoning Analysis Enterprise.

Clean integration decision: keep the uploaded file inside the package for traceability/review, but preserve the existing Deep Reasoning active listing files.

Before Capafy submission, either:

1. replace this draft with a Deep-Reasoning-specific listing draft, or
2. move this file into the `ai-native-prd-architect` skill package instead.
