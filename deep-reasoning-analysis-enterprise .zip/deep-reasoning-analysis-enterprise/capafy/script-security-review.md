# Script Security Review Notes

## Scope

This note addresses static-audit warnings for scripts that use dynamic or system-facing Python features.

## Reviewed scripts

- `scripts/package_skill.py`
- `scripts/audit_skill_zip.py`
- `scripts/validate_capafy_remediation.py`

## Review conclusion

No hardcoded network exfiltration, credential transmission, destructive filesystem deletion, or remote command download behavior is intentionally present in these scripts.

The detected patterns are expected for local validation and packaging:

- `subprocess` is used to invoke local validator scripts with the local Skill directory as input.
- `zipfile` is used to package or inspect Skill files.
- file reads are local and bounded to the supplied Skill directory or ZIP extraction root.

## Operational rule

Run these scripts only in a trusted local workspace or isolated build environment. Do not run them on untrusted ZIP files without first checking ZIP path safety. The included audit script checks for absolute paths and `..` path traversal before extraction.

## Not claimed

This is not a formal security audit, penetration test, malware analysis, or Capafy approval guarantee.
