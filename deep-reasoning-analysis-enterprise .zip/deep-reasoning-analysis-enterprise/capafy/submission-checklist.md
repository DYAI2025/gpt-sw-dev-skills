# Capafy Submission Checklist

## Package files

- [x] `SKILL.md`
- [x] `README.md`
- [x] `CHANGELOG.md`
- [x] `AGENTS.md`
- [x] `references/`
- [x] `schemas/`
- [x] `scripts/`
- [x] `evals/`
- [x] `examples/`
- [x] `reports/`
- [x] `capafy/agent-card.md`
- [x] `capafy/listing.md`
- [x] `capafy/data-flow-declaration.md`
- [x] `capafy/privacy-notice.md`
- [x] `capafy/support-policy.md`
- [x] `capafy/refund-and-limitations.md`
- [x] `capafy/test-cases.md`
- [x] `capafy/subscription-submission-notes.md`
- [x] `capafy/script-security-review.md`
- [x] `capafy/publisher-console-copy.md`

## Publisher Console fields

- [ ] actual support email;
- [x] selected execution model: Subscription;
- [ ] final monthly subscription price;
- [ ] exact LLM provider(s), data-retention and model-training policy;
- [ ] external APIs/MCP tools enabled in production, if any;
- [ ] legal entity, tax, payout and KYC data;
- [ ] professional licensing statement if marketed in any regulated category.

## Suggested current field values

- Execution model: `Subscription`
- Pricing: start at `USD 49/month`; test range `USD 29-99/month`; final price requires cost check.
- Data sharing: `External data flow to: Capafy Cloud Runtime and the configured LLM provider.`
- If optional dynamic tools stay enabled: use `Uncertain` and explain the trigger conditions.

## Pre-submit commands

- `python scripts/quick_validate.py .`
- `python scripts/validate_capafy_readiness.py .`
- `python scripts/audit_skill_zip.py . --out reports/capafy-audit-report.json --md reports/capafy-audit-report.md`
- `python scripts/validate_audit_report.py reports/capafy-audit-report.json`
- `python scripts/run_eval_suite.py evals`

## Manual pre-submit checks

- [ ] Replace `connect@dyai.cloud` with a real support email.
- [ ] Confirm exact provider policy language before declaring retention/training behavior.
- [ ] Confirm whether optional external tools are enabled or disabled in production.
- [ ] Re-run static audit after every change.
