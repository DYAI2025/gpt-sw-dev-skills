# Subscription Submission Notes

## Decision

Use `Subscription` as the execution model.

## Why Subscription fits this Skill

- The Skill is long-running, analysis-heavy, and may consume significant LLM/runtime resources.
- The package contains reusable methodology, validators, schemas, evals, and prompt architecture that should not be exposed by default.
- Subscription keeps users in the cloud runtime and avoids default source-file delivery.
- Updates, support expectations, and cost control are easier to manage than a one-time Download package.

## Suggested pricing

Start with a monthly subscription.

Recommended starting point: USD 49/month.

Reasonable test range: USD 29-99/month.

Use a lower price if outputs are capped and tool use is light. Use a higher price if the Agent supports long reports, repository audits, source verification, SARIF output, or support-intensive enterprise use.

## Publisher Console text

Execution model:

> Subscription

Pricing:

> Monthly subscription. Initial suggested price: USD 49/month. Final price should reflect expected LLM/runtime cost, report length, and support effort.

Data sharing declaration:

> External data flow to: Capafy Cloud Runtime and the configured LLM provider. Optional external tools are used only when enabled and approved for the task.

If optional dynamic tools remain enabled and the exact service list varies by task, use:

> Uncertain. The Skill may access user-approved search, repository, MCP, API, or validation tools when the task requires them and the runtime/tool approval flow permits it.

Support note:

> We aim to respond within 2 business days. Security and privacy reports are prioritized.

Use the support note only if the publisher can meet it.
