# Privacy Notice Draft

This notice describes the intended behavior of the Skill package under the selected Subscription model. The publisher must adapt it to the actual Capafy execution setup, LLM provider, external services, and support contact before submission.

## Selected execution model

Subscription via Capafy Cloud Runtime.

The package is not configured as a Download-first product. Under the Subscription model, users access the Agent through the cloud runtime rather than receiving the full Skill source package.

## What user data is processed

The Skill processes the material users choose to submit for analysis, such as documents, code, repositories, research claims, mathematical proofs, logs, architecture notes, and instructions. Users should avoid submitting secrets or unnecessary personal data.

## Why the data is processed

Data is processed to produce evidence-grounded analysis reports, source maps, evidence ledgers, validation outputs, risk gates, and optional code-finding artifacts.

## Where the data may go

- Capafy Cloud Runtime for cloud execution.
- The configured LLM provider, such as OpenAI API or another provider selected in the Publisher Console.
- Optional user-approved tools, such as source search, repository inspection, MCP/API connectors, or local validators, only when enabled and needed for the task.

## Storage and retention

The package does not intentionally persist user inputs outside the active runtime. Retention by Capafy, LLM providers, or external tools is governed by their policies and the publisher's declared configuration.

## Sensitive information

The Skill does not require secrets, credentials, private keys, passwords, or sensitive personal data. If such data appears in user-provided files, the Skill should minimize reproduction and mark privacy risk.

## User controls

Users can reduce data exposure by redacting secrets and personal data, limiting external tool approval, and using local validation only where possible.

## Support contact

Publisher must provide the actual Capafy `support_email` before submission.
