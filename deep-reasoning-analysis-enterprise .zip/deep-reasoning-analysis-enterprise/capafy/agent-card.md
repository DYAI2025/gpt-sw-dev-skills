# Deep Reasoning Analysis Enterprise

Evidence-grounded analysis agent for complex research, technical, mathematical, AI-system, repository/code, and defensive-cybersecurity questions.

## Who it is for

- Researchers and analysts who need source-grounded claim verification.
- Product, architecture, and engineering teams that need structured risk and failure-mode reviews.
- Security and compliance-aware teams that need defensive-only analysis with explicit boundaries.
- AI builders who need machine-readable reports, source maps, validation checks, and agent handoff artifacts.

## What it does

The Skill enforces a fixed analysis pipeline: scope gate, source inventory, risk gate, method selection, evidence plan, tool plan, multi-path analysis, verification, bias/failure-mode review, synthesis, machine-readable report, human summary, open questions, and final self-validation.

## Inputs

- Text, documents, notes, research claims, architecture descriptions, mathematical proofs, code snippets, repositories, logs, or security observations supplied by the user.
- Optional user-approved tool outputs or sources.

## Outputs

- `analysis_report.md` human-readable report.
- `analysis_report.json` schema-validated machine-readable report.
- `code_findings.sarif.json` when code findings are present.
- Source map, evidence ledger, verification report, risk gate, bias/failure-mode review, and open questions.

## Guardrails

- Does not expose private chain-of-thought.
- Marks unsupported claims as `SOURCE_NEEDED`, `UNVERIFIED`, `ASSUMPTION`, or `MISSING`.
- Defensive cybersecurity only; no exploit chains, malware, credential theft, stealth, persistence, or unauthorized targeting.
- Not legal, medical, financial, tax, mental-health, or investment advice.
- No guarantee of correctness, regulatory compliance, certification, or marketplace acceptance.

## Example prompts

1. Analyze this research claim against the provided papers and produce a source-mapped report.
2. Audit this repository architecture for risks, missing tests, and agent handoff issues.
3. Review this mathematical proof for hidden assumptions and counterexamples.
4. Analyze these logs for defensive incident response and hardening recommendations only.

## Data-flow summary

By default, the package contains local instructions, schemas, references, evals, examples, and deterministic validators. User inputs are processed by the active runtime/LLM provider selected by the host platform or publisher configuration. Optional external tools are used only when the task requires them and the tool plan discloses the purpose.

## Support and operations

Publisher must enter the actual `support_email` in the Capafy Publisher Console before submission. This package includes `capafy/support-policy.md` with the support standard and escalation boundaries.
