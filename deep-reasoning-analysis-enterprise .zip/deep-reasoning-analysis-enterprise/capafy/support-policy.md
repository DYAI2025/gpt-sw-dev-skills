# Support Policy

## Required publisher field

Capafy requires a customer support email on the Skill listing. The publisher must enter the real `support_email` in the Publisher Console before submission. This package does not invent that address.

## Selected execution model

Subscription.

Support should assume users access the Agent through Capafy Cloud Runtime. Support does not include sending the full source package to users unless the publisher separately offers Download.

## Support scope

Support covers:

- subscription access problems that appear specific to this Agent;
- validation-script failures;
- report-output schema/order failures;
- incorrect trigger behavior;
- documentation clarification;
- suspected privacy/security issue in the Skill package.

Support does not cover:

- professional legal, medical, financial, tax, mental-health, or investment advice;
- executing offensive cybersecurity tasks;
- guaranteeing external model/tool availability;
- interpreting a user's private organizational compliance obligations as legal advice;
- custom consulting beyond the Agent's documented report workflow.

## Response target

Publisher should respond to support requests within a reasonable time and prioritize security/privacy reports. For commercial positioning, use a target such as: "We aim to respond within 2 business days; security/privacy reports are prioritized." Only use that wording if the publisher can operationally meet it.

## Security report handling

If a user reports credential leakage, unsafe behavior, or prohibited output, the publisher should pause promotion if necessary, reproduce safely, patch, update validation reports, and resubmit if the change materially affects functionality.
