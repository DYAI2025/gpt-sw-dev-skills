# Data Flow Declaration Draft

## Selected execution model

`subscription`

Users access the Agent through Capafy Cloud Runtime. The package is not offered as Download by default, so buyers should not receive the full Skill source package unless the publisher separately enables Download.

## Recommended declaration

Use this if OpenAI or another external LLM provider is configured:

> External data flow to: Capafy Cloud Runtime and the configured LLM provider.

If optional search, repository, MCP, API, or external validation tools are enabled dynamically, use:

> Uncertain. The Skill may access user-approved external search, repository, MCP, API, or validation tools only when the task requires them and the runtime/tool approval flow permits it.

If the actual production setup uses only Capafy's Platform LLM proxy and no third-party tools, the publisher may instead select:

> No external data flow.

Do not choose this unless the runtime setup actually matches it.

## What is processed

The Skill processes user-submitted text, documents, code, repository material, research claims, mathematical proofs, logs, architecture notes, and instructions to generate structured analysis reports.

## What is not hardcoded in the package

- no hardcoded API keys;
- no hardcoded external account credentials;
- no package-level persistent storage of user inputs;
- no default source-file delivery to buyers under the selected Subscription model.

## Publisher must still confirm

- real support email;
- final monthly price;
- exact LLM provider;
- provider retention policy;
- provider model-training-use policy;
- whether optional external tools are enabled in production.
