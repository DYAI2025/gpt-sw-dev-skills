# path: capafy/marketplace-positioning-html.md

# Marketplace Positioning: Interactive HTML and Audit Pack

## Core positioning

Deep Reasoning Analyst is not just a research-report generator. It creates inspectable evidence artifacts: a polished report for humans, structured JSON for machines, interactive HTML for exploration, and an Audit Pack for verification and stakeholder handoff.

## 500-character marketplace text

Deep Reasoning Analyst turns complex documents, repositories and research claims into evidence-grade audit reports. It maps claims to sources, assumptions, confidence and missing proof, then exports polished Markdown, machine-readable JSON, interactive HTML and a bundled Audit Pack with verification files. For technical reviews, AI-system audits and strategic decisions that must be inspectable, challengeable and reusable.

## Suggested demo theme

"AI Market Report Verification Audit"

Use a polished market report as input, then show how the skill transforms it into:

- decision dashboard
- claim-to-source matrix
- evidence ledger
- counterevidence register
- what-if scenario controls
- audit pack manifest

This differentiates the skill from competitors that only generate polished research reports.
