# Capafy Listing Draft

## Skill name

Deep Reasoning Analysis Enterprise

## Short description

Evidence-grounded deep analysis for complex research, technical, mathematical, AI-system, repository/code, and defensive cybersecurity tasks, with source maps, risk gates, validation scripts, and schema-valid reports.

## Long description

Deep Reasoning Analysis Enterprise is a structured analysis agent for situations where a normal answer is not enough. It forces a fixed pipeline: scope gate, source inventory, risk gate, method selection, evidence plan, tool plan, multi-path analysis, verification, bias/failure-mode review, synthesis, machine-readable JSON, adaptive output selection, human-readable summary, open questions, and final self-validation.

Its strongest buyer-facing output is an interactive evidence report: a polished HTML document with navigation, source jumps, filterable findings, claim-to-evidence tables, confidence review, and deterministic scenario controls for numeric or technical analyses. For review handoff it can bundle the Markdown report, JSON, HTML, evidence exports, manifests, validation logs, and SARIF-compatible code findings into an Audit Pack.

It is designed for research claim verification, proof audits, AI-system reviews, architecture and repository analysis, technical decision audits, and defensive security analysis. It separates user-provided material from verified sources, marks missing evidence, and uses deterministic validators for report structure, output order, artifact policy, source/evidence references, SARIF-compatible code findings, and eval readiness.

This Skill is for evidence discipline, not certainty theater. It does not guarantee truth, compliance, safety, or professional outcomes. It makes uncertainty visible and blocks unsafe requests.

## Recommended category

Analysis

## Secondary categories

Research; Engineering; Science; Productivity

## Tags

research, analysis, verification, audit, reasoning

## Selected execution model

Subscription.

Rationale: this Skill is analysis-heavy, may require long-context model calls and optional validation workflows, and contains reusable methodology and validator assets that should not be exposed through a Download package unless source disclosure is intentional.

## Suggested pricing note

Suggested starting point: monthly subscription, USD 49/month.

Suggested test range: USD 29-99/month depending on expected report length, model/tool cost, customer segment, and support burden.

This is not market validation. Final pricing must be set by the publisher after checking Capafy fees, LLM/runtime cost, target buyer profile, and refund/dispute risk.

## Inputs users can provide

Documents, text, research claims, code snippets, repositories, architecture descriptions, mathematical proofs, logs, and source material.

## Outputs users receive

- `analysis_report.md`
- `analysis_report.json`
- optional `analysis_report.html` for interactive visual inspection
- optional `executive_summary.pdf` when PDF rendering is available
- optional `evidence_ledger.jsonl` and `claim_matrix.csv`
- optional `code_findings.sarif.json` when code findings exist
- optional `audit_pack.zip` with manifests and verification files
- source map
- evidence ledger
- risk gate
- verification report
- human summary
- open questions and missing evidence

## Data flow summary

User inputs may be processed by Capafy Cloud Runtime and the configured LLM provider. Optional source search, repository inspection, MCP/API connectors, or validation tools are used only if enabled by the publisher/runtime and approved for the task. Users should not submit secrets, private keys, passwords, confidential credentials, or unnecessary personal data.

## Limitations and disclaimers

- AI-generated analysis can be incomplete or wrong; users must verify outputs before operational use.
- Not legal, medical, financial, tax, mental-health, or investment advice.
- Defensive cybersecurity only and authorization required.
- External source access depends on the host runtime and user-approved tools.
- Subscription mode does not deliver the full source package to buyers by default.
- Download mode is not the recommended model for this Skill because it exposes package files.
- No official platform endorsement, certification, formal compliance audit, or marketplace approval promise is claimed.
