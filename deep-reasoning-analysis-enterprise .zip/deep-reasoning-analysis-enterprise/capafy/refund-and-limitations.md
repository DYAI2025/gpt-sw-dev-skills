# Refund, Access, and Limitations Draft

The publisher must align final refund/access language with the selected Capafy execution model and current Capafy terms.

## Selected access model

Subscription.

Users receive recurring cloud-based access through Capafy Cloud Runtime. The full Skill source package is not delivered to users under the selected Subscription model unless the publisher separately enables Download.

## Limitations

- AI output may be incomplete, wrong, stale, or affected by source quality.
- The Skill does not replace expert review for regulated or safety-critical decisions.
- External source access and tool behavior depend on the host runtime and permissions.
- The package cannot guarantee Capafy marketplace acceptance or future platform behavior.
- Download is not the recommended model for this Skill because it exposes all source files to the buyer.

## Refund / dispute note

Use Capafy's current dispute/refund framework in the Publisher Console. Do not promise refund rules that conflict with Capafy terms.

Suggested user-facing wording:

> Subscription access and refund handling follow the current Capafy platform rules. If something appears broken or materially different from the listing, contact the publisher support email with the input, expected behavior, actual behavior, and approximate timestamp.
