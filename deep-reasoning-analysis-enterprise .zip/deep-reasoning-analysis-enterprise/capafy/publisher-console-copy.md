# Publisher Console Copy Blocks

## Short description

Evidence-grounded deep analysis for research, technical, mathematical, AI-system, repository/code, and defensive cybersecurity tasks, with source maps, risk gates, validation scripts, and schema-valid reports.

## Execution model

Subscription

## Pricing

Suggested starting price: USD 49/month.

Publisher note: adjust after checking expected LLM/runtime cost, report length, support burden, and target buyer profile.

## Data Sharing Declaration

External data flow to: Capafy Cloud Runtime and the configured LLM provider.

Add this sentence if optional tools remain enabled:

Optional user-approved search, repository, MCP, API, or validation tools may be used only when enabled by the publisher/runtime and required for the task.

## Content advisories

- AI-generated analysis may be incomplete or wrong.
- Not professional legal, medical, financial, tax, mental-health, or investment advice.
- Defensive cybersecurity only and authorization required.
- External source access depends on approved tools and runtime configuration.

## Support response note

We aim to respond within 2 business days. Security and privacy reports are prioritized.

Only use this if the publisher can meet it.
