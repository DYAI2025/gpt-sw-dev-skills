# Changelog

## 0.2.0 - 2026-06-27

- Added mandatory artifact policy: `analysis_report.md` and `analysis_report.json` for every completed analysis.
- Added mandatory SARIF 2.1.0-compatible `code_findings.sarif.json` when code findings exist.
- Extended report schema with `standards_alignment`, `evidence_ledger`, `findings`, `artifact_policy`, and `optional_artifacts`.
- Added `validate_artifact_policy.py` and `validate_sarif.py`.
- Updated output order, source map, standards alignment, examples, and evals.
- Preserved core deep-reasoning methods and safety boundaries.

## 0.1.0

- Initial enterprise package structure with source mapping, risk gates, validators, evals, installability report, and agent-agnostic notes.

## 0.3.0-capafy-readiness - 2026-06-27

- Added Capafy marketplace pack under `capafy/`.
- Added Capafy compliance gates, privacy/data-flow, security-scan, category-risk, listing-quality and remediation references.
- Added Capafy audit, readiness, remediation-plan and audit-report validation scripts.
- Added Capafy source-map entries from current official platform public pages.
- Preserved core Deep Reasoning pipeline and report-output behavior.
## 0.2.1 - 2026-06-27

### Added
- Capafy Subscription submission notes.
- Publisher Console copy blocks for subscription listing, data-sharing, pricing and advisories.
- Script security review note for local validator/package scripts.

### Changed
- Selected Capafy execution model set to `subscription`.
- Listing, privacy notice, data-flow declaration, refund/access note and submission checklist updated for subscription-first publication.

### Still required
- Publisher must provide real support email, final monthly price, exact LLM provider policy and enabled external-service configuration before submission.

## 0.3.0 - Adaptive Output Formats and Interactive Audit Pack

- Added adaptive output selection for markdown, JSON, HTML, PDF, evidence-data, SARIF, audit-pack, all, and auto modes.
- Added static interactive HTML report policy and renderer for source navigation, finding filters, evidence cards, and decision dashboards.
- Added evidence-data exports: `evidence_ledger.jsonl` and `claim_matrix.csv`.
- Added audit pack manifest policy and `build_audit_pack.py` packaging script.
- Added Capafy marketplace positioning for Interactive Evidence HTML plus Audit Pack.
- Preserved mandatory `analysis_report.md`, `analysis_report.json`, and conditional SARIF behavior.

