# Data Flow Declaration — Deep Reasoning Analysis Enterprise

**Publisher:** DYAI  
**Skill version:** 0.2.0  
**Last updated:** 2026-06-27

---

## What data this skill processes

This skill processes analytical input submitted directly by the user:

- Technical documents, architecture descriptions, and system designs
- Research papers, claims, and scientific material
- Code, repository summaries, and static analysis output
- Mathematical proofs and formal reasoning material
- AI system outputs submitted for audit or verification

All input is user-initiated and user-controlled.

---

## How data flows

```
User input (documents, code, claims, research material)
    │
    ▼
AI model session (your LLM provider: Anthropic, OpenAI, etc.)
    │
    ▼
Skill instructions in SKILL.md (prompt behavior only — no external calls)
    │
    ▼
Analysis artifacts (analysis_report.md, analysis_report.json, optional SARIF)
    │
    ▼
Returned to user within the same session
```

**The skill itself makes no external network calls, stores no data, and 
transmits no data to DYAI or any third party.**

---

## Data storage

| Component | Stores data? | Notes |
|---|:---:|---|
| SKILL.md instructions | ❌ | Prompt behavior only |
| Schemas / validators | ❌ | Structural definitions only |
| Generated outputs | ❌ | Returned to user; not persisted by skill |
| DYAI systems | ❌ | Publisher has no visibility into sessions |

Session retention behavior is governed exclusively by your LLM provider 
(Anthropic, OpenAI, etc.) and their privacy policy.

---

## External services

This skill does not require external services by default.

Optional: The skill may instruct the AI model to use web research tools 
when verifying volatile facts (software versions, research citations, 
API behavior, security advisories). This only occurs when the user's AI 
environment has web access enabled and the task explicitly requires 
current external information.

Defensive cybersecurity tasks: analysis is read-only and forensic. 
The skill does not instruct any external system interaction.

---

## Personal data

This skill does not process personal data as part of its intended function.
If code or documents submitted for analysis incidentally contain PII, 
users should apply appropriate redaction before submission.

---

## Contact

Data handling questions: connect@dyai.cloud
