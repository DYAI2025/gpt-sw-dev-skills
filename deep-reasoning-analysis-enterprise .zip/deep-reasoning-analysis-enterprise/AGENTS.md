# AGENTS.md

Use `SKILL.md` as the controlling entry point. Keep large details in `references/`, schemas in `schemas/`, and deterministic checks in `scripts/`.

## Required report artifacts

- Always create or include `analysis_report.md`.
- Always create or include `analysis_report.json`.
- Create `code_findings.sarif.json` whenever code findings exist.

Do not claim certification or formal compliance unless externally proven. Use `standard_aligned`, `schema_validated`, or `format_compatible` labels.

## Validation commands

```bash
python scripts/quick_validate.py .
python scripts/validate_analysis_report.py examples/research-claim-verification.report.json
python scripts/validate_artifact_policy.py examples/research-claim-verification.report.json
python scripts/run_eval_suite.py evals
```
