#!/usr/bin/env python3
"""Validate a Capafy static audit report."""
from __future__ import annotations
import json, sys
from pathlib import Path
REQUIRED = ['meta','input_inventory','gate_summary','findings','blocking_issues','warnings','final_decision']
DECISIONS = {'ready','ready_with_minor_fixes','revise','block'}
def fail(msg: str) -> int:
    print('FAIL: ' + msg, file=sys.stderr); return 1
def main(argv: list[str]) -> int:
    if len(argv) != 2: return fail('usage: validate_audit_report.py <audit-report.json>')
    data=json.loads(Path(argv[1]).read_text(encoding='utf-8'))
    missing=[k for k in REQUIRED if k not in data]
    if missing: return fail('missing keys: ' + ', '.join(missing))
    if data['final_decision'] not in DECISIONS: return fail('invalid final_decision')
    if not isinstance(data['gate_summary'], list) or not data['gate_summary']: return fail('gate_summary empty')
    print('PASS: Capafy audit report')
    return 0
if __name__ == '__main__': raise SystemExit(main(sys.argv))
