#!/usr/bin/env python3
"""Validate that the core functionality preservation report exists and passes."""
from __future__ import annotations
import json, sys
from pathlib import Path
def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr); return 1
def main(argv: list[str]) -> int:
    if len(argv) != 2: return fail("usage: validate_core_parity.py <skill-dir>")
    root = Path(argv[1]); path = root/"reports"/"core-functionality-preservation.json"
    if not path.exists(): return fail("core-functionality-preservation.json missing")
    report = json.loads(path.read_text(encoding="utf-8"))
    if report.get("status") != "PASS": return fail("core functionality preservation must PASS")
    if report.get("unintended_core_changes"): return fail("unintended_core_changes must be empty")
    preserved = report.get("preserved_core_functions", [])
    for item in ["PS+ planning", "Tree-of-Thoughts exploration", "Program-of-Thoughts validation", "Chain-of-Verification", "bias and uncertainty review"]:
        if item not in preserved: return fail(f"missing preserved function: {item}")
    print("PASS: core functionality preservation")
    return 0
if __name__ == "__main__": raise SystemExit(main(sys.argv))
