#!/usr/bin/env python3
"""Validate that a remediated skill has Capafy readiness scaffolding."""
from __future__ import annotations
import subprocess, sys
from pathlib import Path
def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print('usage: validate_capafy_remediation.py <skill-dir>', file=sys.stderr); return 1
    root=Path(argv[1]); script=root/'scripts'/'validate_capafy_readiness.py'
    result=subprocess.run([sys.executable, str(script), str(root)], text=True, capture_output=True)
    if result.stdout: print(result.stdout.strip())
    if result.stderr: print(result.stderr.strip(), file=sys.stderr)
    return result.returncode
if __name__ == '__main__': raise SystemExit(main(sys.argv))
