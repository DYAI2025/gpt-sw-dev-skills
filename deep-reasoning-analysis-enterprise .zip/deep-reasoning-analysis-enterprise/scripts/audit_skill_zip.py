#!/usr/bin/env python3
"""Static Capafy readiness audit for a skill ZIP or directory. Does not execute packaged code."""
from __future__ import annotations
import argparse, json, re, zipfile, tempfile, shutil
from pathlib import Path
from datetime import datetime, timezone

REQUIRED_CAPAFY = [
    'capafy/agent-card.md','capafy/listing.md','capafy/data-flow-declaration.md','capafy/data-flow-declaration.json','capafy/privacy-notice.md','capafy/support-policy.md','capafy/test-cases.md','capafy/publisher-fields.json',
    'references/capafy-compliance-gates.md','references/security-scan-rules.md','references/data-flow-and-privacy-rules.md','references/category-risk-rules.md','references/listing-quality-rules.md','references/capafy-remediation-playbook.md','references/tool-remediation-registry.md',
    'scripts/validate_capafy_readiness.py'
]
SECRET_RE = re.compile(r'(BEGIN (RSA|OPENSSH|PRIVATE) KEY|sk-[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|AIza[0-9A-Za-z_\-]{20,}|xox[baprs]-[0-9A-Za-z-]{10,}|api[_-]?key\s*[=:]\s*["\'][^"\']{16,})')
RISK_RE = re.compile(r'\b(eval\(|exec\(|os\.system|subprocess|requests\.|urllib|socket\.|rm\s+-rf|curl\s+|wget\s+)')
OVERCLAIM_RE = re.compile(r'\b(official capafy|capafy certified|acceptance guarantee|compliance guarantee|claims of no hallucinations|claims of perfect accuracy|risk-free|sure profit|beat the market)\b', re.I)

def extract_if_zip(path: Path) -> tuple[Path, tempfile.TemporaryDirectory | None, list[str]]:
    if path.is_dir(): return path, None, []
    tmp = tempfile.TemporaryDirectory()
    root = Path(tmp.name)
    unsafe = []
    with zipfile.ZipFile(path) as z:
        for info in z.infolist():
            p = Path(info.filename)
            if info.filename.startswith('/') or '..' in p.parts:
                unsafe.append(info.filename)
        if not unsafe: z.extractall(root)
    tops = [p for p in root.iterdir() if p.is_dir()]
    if len(tops) == 1: return tops[0], tmp, unsafe
    return root, tmp, unsafe

def audit(root: Path, original: str) -> dict:
    files = [p for p in root.rglob('*') if p.is_file()]
    rels = [str(p.relative_to(root)) for p in files]
    findings=[]; warnings=[]; blocking=[]; gates=[]
    def gate(name, status, detail): gates.append({'gate': name, 'status': status, 'detail': detail})
    missing = [p for p in REQUIRED_CAPAFY if p not in rels]
    if missing:
        findings.append({'severity':'fail','gate':'capafy_files','message':'missing Capafy files','paths':missing}); blocking.extend(missing)
        gate('Capafy marketplace pack', 'FAIL', 'missing ' + ', '.join(missing))
    else:
        gate('Capafy marketplace pack', 'PASS', 'all required Capafy scaffold files present')
    secret_hits=[]; risk_hits=[]; overclaim_hits=[]
    for p in files:
        rel = str(p.relative_to(root))
        text = p.read_text(encoding='utf-8', errors='ignore')[:500000]
        if SECRET_RE.search(text): secret_hits.append(rel)
        if p.suffix in {'.py','.sh'} and RISK_RE.search(text): risk_hits.append(rel)
        overclaim_scope = rel in {'SKILL.md','README.md'} or rel.startswith('capafy/')
        if overclaim_scope and OVERCLAIM_RE.search(text): overclaim_hits.append(rel)
    if secret_hits:
        findings.append({'severity':'block','gate':'secret_scan','message':'credential-shaped secret patterns found','paths':secret_hits}); blocking.extend(secret_hits); gate('Credential scan','FAIL','secret-like patterns')
    else: gate('Credential scan','PASS','no credential-shaped secret patterns detected')
    if risk_hits:
        warnings.append({'severity':'warn','gate':'static_security','message':'manual review required for dynamic/system/network patterns','paths':risk_hits})
        gate('Security static scan','WARN','manual review required for ' + ', '.join(risk_hits[:8]))
    else: gate('Security static scan','PASS','no risky script patterns detected')
    if overclaim_hits:
        findings.append({'severity':'fail','gate':'listing_truthfulness','message':'forbidden overclaim phrases found','paths':overclaim_hits}); blocking.extend(overclaim_hits); gate('Listing truthfulness','FAIL','overclaim language')
    else: gate('Listing truthfulness','PASS','no forbidden overclaim phrases detected')
    if 'capafy/publisher-fields.json' in rels:
        try:
            fields = json.loads((root/'capafy/publisher-fields.json').read_text(encoding='utf-8'))
            pending = [k for k,v in fields.items() if isinstance(v,str) and 'PUBLISHER_INPUT_REQUIRED' in v]
            if pending:
                warnings.append({'severity':'warn','gate':'publisher_inputs','message':'publisher console fields still require human completion','fields':pending})
                gate('Publisher inputs','WARN','human completion required: ' + ', '.join(pending))
            else: gate('Publisher inputs','PASS','publisher fields populated')
        except Exception as exc:
            findings.append({'severity':'fail','gate':'publisher_fields','message':str(exc)}); blocking.append('capafy/publisher-fields.json')
    decision = 'block' if secret_hits else ('revise' if missing or overclaim_hits else ('ready_with_minor_fixes' if warnings else 'ready'))
    return {
        'meta': {'tool':'audit_skill_zip.py','original':original,'audited_at':datetime.now(timezone.utc).isoformat(),'claim':'static audit only; no official platform approval'},
        'input_inventory': {'file_count':len(files),'paths':rels[:500]},
        'gate_summary': gates,
        'findings': findings,
        'blocking_issues': blocking,
        'warnings': warnings,
        'final_decision': decision
    }

def to_md(report: dict) -> str:
    lines=['# Capafy Audit Report','',f"Final decision: `{report['final_decision']}`",'', '## Gate summary']
    for g in report['gate_summary']:
        lines.append(f"- **{g['gate']}**: {g['status']} — {g['detail']}")
    lines += ['', '## Findings']
    if report['findings']:
        for f in report['findings']: lines.append(f"- {f.get('severity')}: {f.get('gate')} — {f.get('message')}")
    else: lines.append('- none')
    lines += ['', '## Warnings']
    if report['warnings']:
        for w in report['warnings']: lines.append(f"- {w.get('severity')}: {w.get('gate')} — {w.get('message')}")
    else: lines.append('- none')
    lines += ['', '## Limitations', '- Static audit only; no code execution; no official platform approval or legal compliance claim.']
    return '\n'.join(lines)+'\n'

def main() -> int:
    ap=argparse.ArgumentParser(); ap.add_argument('path'); ap.add_argument('--out'); ap.add_argument('--md'); args=ap.parse_args()
    path=Path(args.path).resolve(); root,tmp,unsafe=extract_if_zip(path)
    if unsafe:
        report={'meta':{'tool':'audit_skill_zip.py','original':str(path),'claim':'unsafe zip paths blocked'},'input_inventory':{'file_count':0,'paths':[]},'gate_summary':[{'gate':'zip_safety','status':'BLOCK','detail':'unsafe paths'}],'findings':[{'severity':'block','gate':'zip_safety','message':'unsafe paths','paths':unsafe}],'blocking_issues':unsafe,'warnings':[],'final_decision':'block'}
    else:
        report=audit(root, str(path))
    if args.out: Path(args.out).write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    if args.md: Path(args.md).write_text(to_md(report), encoding='utf-8')
    if not args.out and not args.md: print(json.dumps(report, indent=2, ensure_ascii=False))
    if tmp: tmp.cleanup()
    return 0 if report['final_decision'] in {'ready','ready_with_minor_fixes'} else 1
if __name__ == '__main__':
    raise SystemExit(main())
