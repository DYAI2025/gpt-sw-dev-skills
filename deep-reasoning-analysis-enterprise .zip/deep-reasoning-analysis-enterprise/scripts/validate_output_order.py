#!/usr/bin/env python3
"""Validate required output order for JSON reports or text/XML-like reports."""
from __future__ import annotations
import json, sys
from pathlib import Path
BASE_ORDER = ["meta","intake_scope","source_map","standards_alignment","risk_gate","method_selection","evidence_plan","evidence_ledger","tool_plan","analysis","findings","verification","bias_and_failure_modes","synthesis","artifact_policy","optional_artifacts"]
TAIL_ORDER = ["human_readable_summary","open_questions","ultrathink_craftsmanship_gate"]
ORDER = BASE_ORDER + TAIL_ORDER
ORDER_WITH_ADAPTIVE = BASE_ORDER + ["adaptive_output_selection"] + TAIL_ORDER
TEXT_ORDER = ["deep_reasoning_analysis_report"] + BASE_ORDER[:17] + ["machine_readable_json"] + ["adaptive_output_selection"] + TAIL_ORDER


def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr); return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2: return fail("usage: validate_output_order.py <report.json|report.txt|report.md>")
    text = Path(argv[1]).read_text(encoding="utf-8")
    try:
        data = json.loads(text)
        keys = list(data.keys())
        if "adaptive_output_selection" in keys:
            if keys[:len(ORDER_WITH_ADAPTIVE)] != ORDER_WITH_ADAPTIVE: return fail("JSON top-level key order mismatch")
        elif keys[:len(ORDER)] != ORDER: return fail("JSON top-level key order mismatch")
        print("PASS: JSON output order"); return 0
    except Exception:
        pass
    positions = []
    for tag in TEXT_ORDER:
        pos = text.find(tag)
        if pos == -1: return fail(f"missing tag or section: {tag}")
        positions.append(pos)
    if positions != sorted(positions): return fail("text section order mismatch")
    print("PASS: text output order"); return 0
if __name__ == "__main__": raise SystemExit(main(sys.argv))
