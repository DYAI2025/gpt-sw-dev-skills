#!/usr/bin/env python3
"""Validate installability report and package-controlled install readiness."""
from __future__ import annotations
import json, sys
from pathlib import Path
def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr); return 1
def main(argv: list[str]) -> int:
    if len(argv) != 2: return fail("usage: validate_installability.py <skill-dir>")
    root = Path(argv[1])
    report_path = root/"reports"/"installability-report.json"
    if not report_path.exists(): return fail("reports/installability-report.json missing")
    report = json.loads(report_path.read_text(encoding="utf-8"))
    if report.get("artifact_name") != "skill.zip": return fail("artifact_name must be skill.zip")
    if report.get("chatgpt_install_ready") is not True: return fail("chatgpt_install_ready must be true")
    if report.get("frontend_install_suggestion_status") == "guaranteed": return fail("frontend status must not be guaranteed")
    if report.get("blocking_issues"): return fail("blocking_issues must be empty")
    if not (root/"SKILL.md").exists() or not (root/"agents"/"openai.yaml").exists(): return fail("SKILL.md and agents/openai.yaml required")
    print("PASS: installability report"); return 0
if __name__ == "__main__": raise SystemExit(main(sys.argv))
