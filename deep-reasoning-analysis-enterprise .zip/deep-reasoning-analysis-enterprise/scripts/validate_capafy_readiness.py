#!/usr/bin/env python3
"""Validate Capafy pre-submission scaffolding without claiming platform approval."""
from __future__ import annotations
import json, re, sys
from pathlib import Path

REQUIRED = [
    'SKILL.md','README.md','CHANGELOG.md','AGENTS.md',
    'capafy/agent-card.md','capafy/listing.md','capafy/data-flow-declaration.md','capafy/data-flow-declaration.json','capafy/privacy-notice.md','capafy/support-policy.md','capafy/refund-and-limitations.md','capafy/test-cases.md','capafy/submission-checklist.md','capafy/publisher-fields.json',
    'references/capafy-compliance-gates.md','references/data-flow-and-privacy-rules.md','references/security-scan-rules.md','references/category-risk-rules.md','references/listing-quality-rules.md','references/capafy-remediation-playbook.md','references/tool-remediation-registry.md',
    'schemas/capafy-audit-report.schema.json','schemas/capafy-remediation-plan.schema.json','schemas/data-flow-declaration.schema.json','schemas/marketplace-listing.schema.json'
]
FORBIDDEN = re.compile(r'\b(official capafy|capafy certified|certified by capafy|acceptance guarantee|compliance guarantee|claims of no hallucinations|claims of perfect accuracy|risk-free|sure profit|beat the market)\b', re.I)
SOURCE_IDS = ['S018','S019','S020','S021']

def fail(msg: str) -> int:
    print('FAIL: ' + msg, file=sys.stderr); return 1

def main(argv: list[str]) -> int:
    if len(argv) != 2: return fail('usage: validate_capafy_readiness.py <skill-dir>')
    root = Path(argv[1])
    missing = [p for p in REQUIRED if not (root/p).exists()]
    if missing: return fail('missing required Capafy files: ' + ', '.join(missing))
    source_map = (root/'references/source-map.md').read_text(encoding='utf-8')
    for sid in SOURCE_IDS:
        if sid not in source_map: return fail('missing Capafy source-map entry ' + sid)
    listing_text = '\n'.join((root/p).read_text(encoding='utf-8', errors='ignore') for p in ['capafy/agent-card.md','capafy/listing.md','capafy/privacy-notice.md','capafy/support-policy.md','capafy/data-flow-declaration.md'])
    hit = FORBIDDEN.search(listing_text)
    if hit: return fail('forbidden/overclaim listing phrase: ' + hit.group(0))
    fields = json.loads((root/'capafy/publisher-fields.json').read_text(encoding='utf-8'))
    if len(fields.get('tags', [])) > 5: return fail('Capafy tags exceed 5')
    if not fields.get('support_email'): return fail('support_email field missing')
    dfd = json.loads((root/'capafy/data-flow-declaration.json').read_text(encoding='utf-8'))
    if dfd.get('package_hardcoded_credentials') is not False: return fail('package_hardcoded_credentials must be false')
    if not dfd.get('publisher_inputs_required'): return fail('publisher_inputs_required must identify remaining console facts')
    print('PASS: Capafy readiness scaffolding present; publisher console fields still require human completion')
    return 0

if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
