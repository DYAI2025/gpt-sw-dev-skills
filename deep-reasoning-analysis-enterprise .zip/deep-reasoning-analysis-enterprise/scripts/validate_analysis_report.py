#!/usr/bin/env python3
"""Validate a Deep Reasoning Analysis Enterprise JSON report using standard-library structural checks."""
from __future__ import annotations
import json, sys
from pathlib import Path

BASE_TOP = ["meta","intake_scope","source_map","standards_alignment","risk_gate","method_selection","evidence_plan","evidence_ledger","tool_plan","analysis","findings","verification","bias_and_failure_modes","synthesis","artifact_policy","optional_artifacts"]
TAIL_TOP = ["human_readable_summary","open_questions","ultrathink_craftsmanship_gate"]
ALLOWED_RISK = {"low","medium","high","blocked"}
FINAL_DECISIONS = {"release","revise","block"}
MANDATORY_ARTIFACTS = {"analysis_report.md", "analysis_report.json"}


def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_analysis_report.py <report.json>")
    path = Path(argv[1])
    if not path.exists():
        return fail(f"file not found: {path}")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(f"invalid JSON: {exc}")
    if not isinstance(data, dict):
        return fail("report root must be object")
    required_top = BASE_TOP + TAIL_TOP
    missing = [k for k in required_top if k not in data]
    if missing:
        return fail("missing top-level keys: " + ", ".join(missing))
    keys = list(data.keys())
    expected_without_adaptive = BASE_TOP + TAIL_TOP
    expected_with_adaptive = BASE_TOP + ["adaptive_output_selection"] + TAIL_TOP
    prefix = keys[:len(expected_with_adaptive)] if "adaptive_output_selection" in keys else keys[:len(expected_without_adaptive)]
    if prefix not in (expected_without_adaptive, expected_with_adaptive):
        return fail("top-level key order does not match required report order")
    risk = data.get("risk_gate", {}).get("risk_level")
    if risk not in ALLOWED_RISK:
        return fail("risk_gate.risk_level must be low, medium, high or blocked")
    final = data.get("ultrathink_craftsmanship_gate", {}).get("final_decision")
    if final not in FINAL_DECISIONS:
        return fail("ultrathink final_decision must be release, revise or block")
    artifacts = set(data.get("artifact_policy", {}).get("always_emit", []))
    if not MANDATORY_ARTIFACTS.issubset(artifacts):
        return fail("artifact_policy.always_emit must include analysis_report.md and analysis_report.json")
    code_detected = data.get("artifact_policy", {}).get("code_analysis_detected")
    sarif_required = data.get("artifact_policy", {}).get("sarif_required")
    if code_detected and sarif_required is not True:
        return fail("code_analysis_detected true requires sarif_required true")
    if code_detected and not any(a.get("artifact_name") == "code_findings.sarif.json" for a in data.get("optional_artifacts", [])):
        return fail("code analysis requires optional_artifacts entry for code_findings.sarif.json")
    for src in data.get("source_map", []):
        for key in ("source_id","source_type","title","location","claim_supported","evidence_quote_or_pointer","confidence","verification_status"):
            if key not in src:
                return fail(f"source entry missing {key}")
        if not isinstance(src.get("confidence"), int) or not (1 <= src["confidence"] <= 5):
            return fail("source confidence must be integer 1-5")
    source_ids = {s.get("source_id") for s in data.get("source_map", []) if isinstance(s, dict)}
    evidence_ids = {e.get("evidence_id") for e in data.get("evidence_ledger", []) if isinstance(e, dict)}
    for ev in data.get("evidence_ledger", []):
        for sid in ev.get("source_ids", []):
            if sid not in source_ids and sid not in {"SOURCE_NEEDED", "UNVERIFIED", "MISSING"}:
                return fail(f"evidence references unknown source id: {sid}")
    for finding in data.get("findings", []):
        for eid in finding.get("evidence_ids", []):
            if eid not in evidence_ids and eid not in {"SOURCE_NEEDED", "UNVERIFIED", "MISSING"}:
                return fail(f"finding references unknown evidence id: {eid}")
    print("PASS: analysis report")
    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
