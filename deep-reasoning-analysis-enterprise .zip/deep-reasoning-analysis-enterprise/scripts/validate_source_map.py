#!/usr/bin/env python3
"""Validate source-map and source-policy contain required enterprise source controls."""
from __future__ import annotations
import sys
from pathlib import Path
REQUIRED_TERMS = ["type:","purpose:","reliability:","limitations:","confidence_default:","user_provided","primary","SOURCE_NEEDED","MISSING"]
def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr); return 1
def main(argv: list[str]) -> int:
    if len(argv) != 2: return fail("usage: validate_source_map.py <skill-dir>")
    root = Path(argv[1]); sm = root/"references"/"source-map.md"; sp = root/"references"/"source-policy.md"
    if not sm.exists(): return fail("references/source-map.md missing")
    if not sp.exists(): return fail("references/source-policy.md missing")
    text = sm.read_text(encoding="utf-8") + "\n" + sp.read_text(encoding="utf-8")
    missing = [t for t in REQUIRED_TERMS if t not in text]
    if missing: return fail("missing source discipline terms: " + ", ".join(missing))
    print("PASS: source map and source policy"); return 0
if __name__ == "__main__": raise SystemExit(main(sys.argv))
