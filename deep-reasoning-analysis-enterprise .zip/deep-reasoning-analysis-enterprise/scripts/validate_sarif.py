#!/usr/bin/env python3
"""Validate minimal SARIF 2.1.0 structural compatibility with standard library only."""
from __future__ import annotations
import json, sys
from pathlib import Path


def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr); return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2: return fail("usage: validate_sarif.py <code_findings.sarif.json>")
    path = Path(argv[1])
    if not path.exists(): return fail(f"file not found: {path}")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(f"invalid JSON: {exc}")
    if data.get("version") != "2.1.0": return fail("SARIF version must be 2.1.0")
    if "runs" not in data or not isinstance(data["runs"], list): return fail("SARIF runs array required")
    for i, run in enumerate(data["runs"]):
        if not isinstance(run, dict): return fail(f"run {i} must be object")
        tool = run.get("tool", {})
        if not isinstance(tool, dict) or not isinstance(tool.get("driver"), dict): return fail(f"run {i} requires tool.driver")
        if not tool["driver"].get("name"): return fail(f"run {i} tool.driver.name required")
        if "results" in run and not isinstance(run["results"], list): return fail(f"run {i} results must be array")
    print("PASS: SARIF minimal structure")
    return 0
if __name__ == "__main__": raise SystemExit(main(sys.argv))
