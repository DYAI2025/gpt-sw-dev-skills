#!/usr/bin/env python3
"""Run deterministic checks over eval files. This is not an LLM grader."""
from __future__ import annotations
import json, sys
from pathlib import Path
REQUIRED_JSON = ["trigger_queries.json","output_evals.json"]
REQUIRED_JSONL = ["deep_reasoning_cases.jsonl","tool_routing_cases.jsonl","hallucination_resistance_cases.jsonl","source_verification_cases.jsonl","cyber_boundary_cases.jsonl","math_validation_cases.jsonl","cross_agent_portability_cases.jsonl"]

def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr); return 1

def read_jsonl(path: Path) -> list[dict]:
    rows = []
    for i, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if line.strip():
            try: rows.append(json.loads(line))
            except Exception as exc: raise ValueError(f"{path}:{i}: {exc}")
    return rows

def main(argv: list[str]) -> int:
    if len(argv) != 2: return fail("usage: run_eval_suite.py <eval-dir>")
    root = Path(argv[1])
    for name in REQUIRED_JSON:
        if not (root/name).exists(): return fail(f"missing {name}")
        json.loads((root/name).read_text(encoding="utf-8"))
    for name in REQUIRED_JSONL:
        path = root/name
        if not path.exists(): return fail(f"missing {name}")
        rows = read_jsonl(path)
        if not rows: return fail(f"empty {name}")
    print("PASS: eval suite files")
    return 0
if __name__ == "__main__": raise SystemExit(main(sys.argv))
