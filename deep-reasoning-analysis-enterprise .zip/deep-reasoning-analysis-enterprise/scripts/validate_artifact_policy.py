#!/usr/bin/env python3
"""Validate report artifact-policy invariants."""
from __future__ import annotations
import json, sys
from pathlib import Path
FORBIDDEN = {"certified", "legally_audited", "officially_compliant", "guaranteed_compliant"}


def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr); return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2: return fail("usage: validate_artifact_policy.py <report.json>")
    data = json.loads(Path(argv[1]).read_text(encoding="utf-8"))
    policy = data.get("artifact_policy", {})
    always = set(policy.get("always_emit", []))
    if {"analysis_report.md", "analysis_report.json"} - always:
        return fail("analysis_report.md and analysis_report.json must always emit")
    claim_language = policy.get("claim_language", "")
    if not claim_language or any(term in claim_language for term in FORBIDDEN):
        return fail("claim_language must avoid certification/compliance overclaiming")
    if policy.get("code_analysis_detected") and policy.get("sarif_required") is not True:
        return fail("code analysis detected but sarif_required is not true")
    if policy.get("sarif_required"):
        artifacts = [a.get("artifact_name") for a in data.get("optional_artifacts", [])]
        if "code_findings.sarif.json" not in artifacts:
            return fail("sarif_required true but code_findings.sarif.json is not listed")
    for std in data.get("standards_alignment", []):
        if any(term in (std.get("claim_level", "") + std.get("alignment_status", "")) for term in FORBIDDEN):
            return fail("standards_alignment contains forbidden overclaiming")
    print("PASS: artifact policy")
    return 0
if __name__ == "__main__": raise SystemExit(main(sys.argv))
