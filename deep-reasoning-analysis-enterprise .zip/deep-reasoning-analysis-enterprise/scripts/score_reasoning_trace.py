#!/usr/bin/env python3
"""Score public reasoning trace completeness without reading private chain-of-thought."""
from __future__ import annotations
import json, sys
from pathlib import Path
FIELDS = ["public_reasoning_trace","hypotheses","counterarguments","edge_cases"]

def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("usage: score_reasoning_trace.py <report.json>", file=sys.stderr); return 1
    data = json.loads(Path(argv[1]).read_text(encoding="utf-8"))
    analysis = data.get("analysis", {})
    score = sum(1 for f in FIELDS if analysis.get(f)) / len(FIELDS)
    print(json.dumps({"public_trace_completeness": score, "fields_checked": FIELDS}, indent=2))
    return 0 if score >= 0.75 else 1
if __name__ == "__main__": raise SystemExit(main(sys.argv))
