#!/usr/bin/env python3
"""Detect unresolved generation placeholders in production skill files."""
from __future__ import annotations
import re, sys
from pathlib import Path
PLACEHOLDER_RE = re.compile(r"\{[A-Z_][A-Z0-9_]*\}|\{\{[A-Z_][A-Z0-9_]*\}\}")
IGNORE_PARTS = {"assets","evals","reports"}
def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr); return 1
def main(argv: list[str]) -> int:
    if len(argv) != 2: return fail("usage: validate_no_placeholders.py <skill-dir>")
    root = Path(argv[1]); hits=[]
    for path in root.rglob("*"):
        if not path.is_file(): continue
        if set(path.relative_to(root).parts) & IGNORE_PARTS: continue
        if path.suffix not in {".md",".py",".yaml",".json"} and path.name != "SKILL.md": continue
        for match in PLACEHOLDER_RE.finditer(path.read_text(encoding="utf-8", errors="ignore")):
            hits.append(f"{path.relative_to(root)}:{match.group(0)}")
    if hits: return fail("unresolved placeholders: " + ", ".join(hits))
    print("PASS: no unresolved production placeholders"); return 0
if __name__ == "__main__": raise SystemExit(main(sys.argv))
