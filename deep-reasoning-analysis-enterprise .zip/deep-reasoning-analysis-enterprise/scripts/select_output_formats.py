# path: scripts/select_output_formats.py
#!/usr/bin/env python3
"""Select recommended output formats for Deep Reasoning Analysis Enterprise.

Input: JSON task context.
Output: JSON selection result.

This script is intentionally deterministic and dependency-free.
"""
import json
import sys
from pathlib import Path

CANONICAL = ["analysis_report.md", "analysis_report.json"]

REQUEST_MAP = {
    "markdown": "analysis_report.md",
    "json": "analysis_report.json",
    "html": "analysis_report.html",
    "pdf": "executive_summary.pdf",
    "evidence-data": ["evidence_ledger.jsonl", "claim_matrix.csv"],
    "sarif": "code_findings.sarif.json",
    "audit-pack": "audit_pack.zip",
}


def add(out, value):
    if isinstance(value, list):
        for item in value:
            add(out, item)
        return
    if value not in out:
        out.append(value)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: select_output_formats.py task_context.json", file=sys.stderr)
        return 2

    path = Path(sys.argv[1])
    data = json.loads(path.read_text(encoding="utf-8"))

    requested = data.get("user_requested_outputs", []) or []
    requested_norm = [str(x).strip().lower() for x in requested]
    explicit = bool(requested_norm and "auto" not in requested_norm)

    out = []
    for item in CANONICAL:
        add(out, item)

    if explicit:
        for req in requested_norm:
            if req == "all":
                for value in REQUEST_MAP.values():
                    add(out, value)
            elif req in REQUEST_MAP:
                add(out, REQUEST_MAP[req])
    else:
        task_type = str(data.get("task_type", "")).lower()
        source_count = int(data.get("source_count", 0) or 0)
        claim_count = int(data.get("material_claim_count", 0) or 0)
        has_code = bool(data.get("has_code_findings", False))
        visual = bool(data.get("needs_visual_presentation", False))
        interactive = bool(data.get("needs_interactivity", False))
        board = bool(data.get("needs_board_summary", False))
        audit = bool(data.get("needs_audit_handoff", False))
        numeric = bool(data.get("has_quantitative_claims", False))

        html_triggers = [
            visual,
            interactive,
            numeric,
            source_count > 5,
            claim_count > 8,
            any(t in task_type for t in ["market", "technical", "repository", "audit", "compliance", "readiness", "architecture"]),
        ]
        if any(html_triggers):
            add(out, "analysis_report.html")

        evidence_triggers = [
            source_count > 5,
            claim_count > 8,
            audit,
            any(t in task_type for t in ["verification", "audit", "compliance", "research", "readiness"]),
        ]
        if any(evidence_triggers):
            add(out, ["evidence_ledger.jsonl", "claim_matrix.csv"])

        if board:
            add(out, "executive_summary.pdf")

        if has_code:
            add(out, "code_findings.sarif.json")

        if audit or len(out) >= 4:
            add(out, "audit_pack.zip")

    blocked = []
    if "executive_summary.pdf" in out and not data.get("runtime_can_render_pdf", False):
        out.remove("executive_summary.pdf")
        blocked.append({"artifact": "executive_summary.pdf", "reason": "MISSING_RUNTIME_CAPABILITY: PDF renderer unavailable"})

    if "code_findings.sarif.json" in out and not data.get("has_code_findings", False):
        out.remove("code_findings.sarif.json")
        blocked.append({"artifact": "code_findings.sarif.json", "reason": "No code findings present"})

    html_mode = "none"
    if "analysis_report.html" in out:
        html_mode = "static_interactive"
    if data.get("needs_live_document_chat", False):
        if data.get("runtime_has_llm_interactive_permission", False):
            html_mode = "llm_interactive"
        else:
            blocked.append({"artifact": "llm_interactive_html", "reason": "Requires explicit API/tool permission boundary"})

    result = {
        "output_selection_mode": "explicit" if explicit else "auto",
        "user_requested_outputs": requested_norm,
        "auto_selected_outputs": out,
        "blocked_outputs": blocked,
        "interactive_html_mode": html_mode,
        "runtime_capability_notes": data.get("runtime_capability_notes", []),
    }
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
