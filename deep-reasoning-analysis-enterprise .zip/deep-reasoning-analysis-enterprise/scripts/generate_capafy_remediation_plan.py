#!/usr/bin/env python3
"""Generate a file-level remediation plan from a Capafy audit report."""
from __future__ import annotations
import argparse, json
from pathlib import Path
FIXES = {
    'capafy_files': 'Add missing capafy marketplace/privacy/support/test/reference files.',
    'secret_scan': 'Remove secrets, rotate exposed credentials, and replace with runtime vault references.',
    'static_security': 'Manually review risky script patterns and document false positives.',
    'listing_truthfulness': 'Replace overclaims with precise limitation-aware language.',
    'publisher_inputs': 'Complete Publisher Console fields: support_email, execution model, pricing, LLM providers and external services.'
}
def main() -> int:
    ap=argparse.ArgumentParser(); ap.add_argument('audit_report'); ap.add_argument('--out', required=True); args=ap.parse_args()
    report=json.loads(Path(args.audit_report).read_text(encoding='utf-8'))
    items=[]
    for group in ('findings','warnings'):
        for f in report.get(group, []):
            gate=f.get('gate','unknown')
            items.append({'gate':gate,'severity':f.get('severity','warn'),'fix':FIXES.get(gate,'Review and remediate manually.'),'affected':f.get('paths') or f.get('fields') or []})
    plan={'meta':{'source_audit':args.audit_report,'claim':'remediation plan, not official approval'},'items':items,'final_decision_after_fix':'ready_with_minor_fixes' if items else 'ready'}
    Path(args.out).write_text(json.dumps(plan, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    print('WROTE: ' + args.out)
    return 0
if __name__ == '__main__': raise SystemExit(main())
