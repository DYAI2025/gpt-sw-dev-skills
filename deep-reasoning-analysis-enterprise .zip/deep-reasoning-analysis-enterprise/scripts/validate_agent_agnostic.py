#!/usr/bin/env python3
"""Validate agent-agnostic compatibility notes exist and avoid parity overclaiming."""
from __future__ import annotations
import sys
from pathlib import Path
def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr); return 1
def main(argv: list[str]) -> int:
    if len(argv) != 2: return fail("usage: validate_agent_agnostic.py <skill-dir>")
    root = Path(argv[1])
    required = ["references/agent-agnostic-compatibility.md","references/capability-parity-policy.md","agents/claude-compatible.md","agents/gemini-compatible.md","agents/cursor-windsurf-ide.md"]
    for rel in required:
        if not (root/rel).exists(): return fail(f"missing {rel}")
    text = "\n".join((root/rel).read_text(encoding="utf-8") for rel in required)
    if "not a guarantee" not in text and "does not mean identical" not in text: return fail("compatibility notes must avoid parity guarantee")
    print("PASS: agent agnostic compatibility")
    return 0
if __name__ == "__main__": raise SystemExit(main(sys.argv))
