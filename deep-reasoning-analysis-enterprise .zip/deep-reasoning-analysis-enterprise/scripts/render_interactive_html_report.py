#!/usr/bin/env python3
"""Render a self-contained static interactive HTML report from analysis_report.json."""
from __future__ import annotations
import argparse, html, json
from pathlib import Path


def esc(value) -> str:
    return html.escape(str(value if value is not None else ""))


def as_list(value):
    return value if isinstance(value, list) else ([] if value is None else [value])


def render_table(rows, headers):
    if not rows:
        return '<p class="muted">No rows available.</p>'
    head = ''.join(f'<th>{esc(h)}</th>' for h in headers)
    body = []
    for row in rows:
        cells = ''.join(f'<td>{esc(row.get(h, ""))}</td>' for h in headers)
        body.append(f'<tr data-search="{esc(json.dumps(row, ensure_ascii=False))}">{cells}</tr>')
    return f'<table><thead><tr>{head}</tr></thead><tbody>{"".join(body)}</tbody></table>'


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('report_json')
    parser.add_argument('out_html')
    args = parser.parse_args()
    data = json.loads(Path(args.report_json).read_text(encoding='utf-8'))
    findings = as_list(data.get('findings'))
    evidence = as_list(data.get('evidence_ledger'))
    sources = as_list(data.get('source_map'))
    meta = data.get('meta', {})
    synth = data.get('synthesis', {})
    severity_counts = {}
    for f in findings:
        sev = f.get('severity', 'unknown')
        severity_counts[sev] = severity_counts.get(sev, 0) + 1
    metrics = [('Findings', len(findings)), ('Evidence Items', len(evidence)), ('Sources', len(sources)), ('Decision', synth.get('decision', 'review'))]
    finding_rows = [{'id': f.get('finding_id', ''), 'severity': f.get('severity', ''), 'domain': f.get('domain', ''), 'claim': f.get('claim', ''), 'status': f.get('verification_status', '')} for f in findings]
    evidence_cards = []
    for e in evidence:
        evidence_cards.append(f"""
        <details class="card evidence-card" data-search="{esc(json.dumps(e, ensure_ascii=False))}">
          <summary><strong>{esc(e.get('evidence_id','evidence'))}</strong> - Claim {esc(e.get('claim_id',''))} - Confidence {esc(e.get('confidence',''))}</summary>
          <p><strong>Class:</strong> {esc(e.get('evidence_class',''))}</p>
          <p><strong>Source IDs:</strong> {esc(', '.join(as_list(e.get('source_ids'))))}</p>
          <p><strong>Pointer:</strong> {esc(e.get('quote_or_pointer',''))}</p>
          <p><strong>Limitations:</strong> {esc('; '.join(as_list(e.get('limitations'))))}</p>
        </details>""")
    css = r'''
:root { --navy:#052f46; --ink:#17202a; --muted:#64748b; --line:#d9e2ec; --soft:#f5f8fb; }
* { box-sizing:border-box; } body { margin:0; font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; color:var(--ink); background:#fff; }
header { background:linear-gradient(135deg,var(--navy),#071827); color:#fff; padding:34px 44px; }
header h1 { margin:0 0 8px; font-size:30px; letter-spacing:-.02em; } header p { margin:0; color:#cbd5e1; }
main { max-width:1240px; margin:0 auto; padding:28px 36px 60px; }
.metrics { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:14px; margin-top:-26px; }
.metric { background:#fff; border:1px solid var(--line); border-radius:16px; padding:20px; box-shadow:0 14px 28px rgba(5,47,70,.08); }
.metric strong { display:block; font-size:28px; color:var(--navy); } .metric span { color:var(--muted); font-size:12px; text-transform:uppercase; letter-spacing:.08em; }
.toolbar { position:sticky; top:0; background:rgba(255,255,255,.96); backdrop-filter: blur(8px); z-index:10; display:flex; gap:10px; padding:16px 0; border-bottom:1px solid var(--line); margin-bottom:20px; }
input, select { border:1px solid var(--line); border-radius:10px; padding:10px 12px; font:inherit; } input { flex:1; }
section { margin:28px 0; } h2 { color:var(--navy); border-bottom:2px solid var(--navy); padding-bottom:8px; }
.card { border:1px solid var(--line); border-left:4px solid var(--navy); background:var(--soft); border-radius:12px; padding:16px; margin:12px 0; }
table { width:100%; border-collapse:collapse; font-size:14px; } th { background:var(--navy); color:#fff; text-align:left; padding:10px; } td { border-bottom:1px solid var(--line); padding:10px; vertical-align:top; }
.badge { display:inline-block; border-radius:999px; padding:4px 8px; background:#e0f2fe; color:#075985; font-size:12px; } .muted { color:var(--muted); }
.hidden { display:none !important; } details summary { cursor:pointer; }
@media (max-width:820px) { .metrics { grid-template-columns:repeat(2,minmax(0,1fr)); } main { padding:20px; } header { padding:28px 24px; } }
'''
    js = r'''
const q = document.getElementById('q');
const severity = document.getElementById('severity');
function normalize(s){ return (s || '').toString().toLowerCase(); }
function applyFilters(){
  const term = normalize(q.value);
  const sev = severity.value;
  document.querySelectorAll('[data-search]').forEach(el => {
    const hay = normalize(el.getAttribute('data-search'));
    const sevOk = !sev || hay.includes('"severity": "' + sev + '"') || hay.includes(sev);
    const termOk = !term || hay.includes(term);
    el.classList.toggle('hidden', !(sevOk && termOk));
  });
}
q.addEventListener('input', applyFilters); severity.addEventListener('change', applyFilters);
'''
    metric_html = ''.join(f'<div class="metric"><strong>{esc(v)}</strong><span>{esc(k)}</span></div>' for k, v in metrics)
    severity_options = ''.join(f'<option value="{esc(k)}">{esc(k)} ({v})</option>' for k, v in sorted(severity_counts.items()))
    html_doc = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{esc(meta.get('skill_name','Analysis Report'))}</title><style>{css}</style></head>
<body><header><h1>{esc(meta.get('skill_name','Deep Reasoning Analysis Report'))}</h1><p>Run {esc(meta.get('run_id',''))} - Artifact {esc(meta.get('artifact_set_id',''))} - static_interactive</p></header>
<main><div class="metrics">{metric_html}</div>
<div class="toolbar"><input id="q" placeholder="Search claims, sources, evidence, findings"><select id="severity"><option value="">All severities</option>{severity_options}</select></div>
<section class="card"><h2>Executive Decision</h2><p><span class="badge">{esc(synth.get('decision','review'))}</span></p><p>{esc(synth.get('final_answer',''))}</p><p class="muted">Confidence: {esc(synth.get('confidence',''))} - {esc(synth.get('confidence_reason_public',''))}</p></section>
<section><h2>Findings Matrix</h2><div data-search="findings matrix">{render_table(finding_rows, ['id','severity','domain','claim','status'])}</div></section>
<section><h2>Evidence Ledger</h2>{''.join(evidence_cards) or '<p class="muted">No evidence ledger entries available.</p>'}</section>
<section><h2>Review Notes</h2><p>This file is static_interactive. It supports local filtering and evidence navigation only. It does not send data to external services and does not provide live AI chat.</p></section>
</main><script>{js}</script></body></html>"""
    Path(args.out_html).write_text(html_doc, encoding='utf-8')
    print(f'WROTE: {args.out_html}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
