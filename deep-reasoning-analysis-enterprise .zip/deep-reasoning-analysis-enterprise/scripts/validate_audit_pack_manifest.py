# path: scripts/validate_audit_pack_manifest.py
#!/usr/bin/env python3
"""Minimal dependency-free validator for audit_pack_manifest.json."""
import json
import sys
from pathlib import Path

REQUIRED = [
    "pack_name",
    "created_at",
    "analysis_type",
    "source_count",
    "artifact_count",
    "artifacts",
    "blocked_artifacts",
    "runtime_notes",
    "limitations",
]


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: validate_audit_pack_manifest.py audit_pack_manifest.json", file=sys.stderr)
        return 2
    data = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    missing = [k for k in REQUIRED if k not in data]
    if missing:
        print(json.dumps({"status": "FAIL", "missing": missing}, indent=2))
        return 1
    artifacts = data.get("artifacts", [])
    if not isinstance(artifacts, list):
        print(json.dumps({"status": "FAIL", "error": "artifacts must be a list"}, indent=2))
        return 1
    if data.get("artifact_count") != len(artifacts):
        print(json.dumps({"status": "FAIL", "error": "artifact_count does not match artifacts length"}, indent=2))
        return 1
    required_paths = {"analysis_report.md", "analysis_report.json"}
    present = {item.get("path") for item in artifacts if isinstance(item, dict)}
    missing_required_paths = sorted(required_paths - present)
    if missing_required_paths:
        print(json.dumps({"status": "FAIL", "missing_required_artifacts": missing_required_paths}, indent=2))
        return 1
    print(json.dumps({"status": "PASS", "artifact_count": len(artifacts)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
