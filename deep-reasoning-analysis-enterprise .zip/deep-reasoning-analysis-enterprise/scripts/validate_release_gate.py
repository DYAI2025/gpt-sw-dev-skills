#!/usr/bin/env python3
"""Validate release-gate report preconditions."""
from __future__ import annotations
import json, sys
from pathlib import Path
def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr); return 1
def main(argv: list[str]) -> int:
    if len(argv) != 2: return fail("usage: validate_release_gate.py <skill-dir>")
    root = Path(argv[1]); path = root/"reports"/"release-gate-report.json"
    if not path.exists(): return fail("reports/release-gate-report.json missing")
    report = json.loads(path.read_text(encoding="utf-8"))
    release, craft, confab, syco, bias = report.get("release_gate",{}), report.get("craftsmanship_gate",{}), report.get("anti_confabulation_gate",{}), report.get("anti_sycophancy",{}), report.get("bias_gate",{})
    if release.get("status") != "PASS": return fail("release_gate.status must be PASS")
    if release.get("allowed_to_package") is not True: return fail("release_gate.allowed_to_package must be true")
    if craft.get("status") != "PASS": return fail("craftsmanship_gate.status must be PASS")
    if confab.get("status") != "PASS": return fail("anti_confabulation_gate.status must be PASS")
    if confab.get("blocked_claims", []): return fail("blocked_claims must be empty")
    score, threshold = syco.get("score"), syco.get("threshold", 3)
    if not isinstance(score, int): return fail("anti_sycophancy.score must be integer")
    if score >= threshold: return fail("anti_sycophancy score exceeds threshold")
    if bias.get("status") == "BLOCKED": return fail("bias_gate.status BLOCKED")
    print("PASS: release gate"); return 0
if __name__ == "__main__": raise SystemExit(main(sys.argv))
