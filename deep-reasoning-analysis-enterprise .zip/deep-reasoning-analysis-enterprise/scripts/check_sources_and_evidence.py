#!/usr/bin/env python3
"""Check that hard claims in a report are backed by source ids or explicitly marked."""
from __future__ import annotations
import json, sys
from pathlib import Path

def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr)
    return 1

def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: check_sources_and_evidence.py <report.json>")
    path = Path(argv[1])
    data = json.loads(path.read_text(encoding="utf-8"))
    source_ids = {s.get("source_id") for s in data.get("source_map", []) if isinstance(s, dict)}
    if not source_ids:
        return fail("source_map has no source ids")
    checks = data.get("verification", {}).get("claim_check", [])
    if not checks:
        return fail("verification.claim_check is empty")
    bad = [c for c in checks if not any(sid and sid in c for sid in source_ids) and "SOURCE_NEEDED" not in c and "UNVERIFIED" not in c]
    if bad:
        return fail("claim checks lack source ids or uncertainty labels: " + "; ".join(bad[:3]))
    print("PASS: source and evidence checks")
    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
