#!/usr/bin/env python3
"""Suggest safe tool calls for a deep reasoning task from keywords. Outputs JSON."""
from __future__ import annotations
import json, sys

KEYWORD_MAP = {
    "run_python_calculation": ["integral","matrix","statistics","simulation","ode","pde","monte carlo","calculation","berechnung","gleichung"],
    "run_symbolic_solver": ["proof","symbolic","derive","algebra","eigenvalue","beweis","ableitung"],
    "run_external_search": ["current","latest","source","citation","paper","quelle","studie"],
    "construct_counterexample": ["counterexample","disprove","widerlege","gegenbeispiel","universal"],
    "run_bias_analysis": ["bias","fairness","overconfidence","confirmation"],
    "escalate_to_human_review": ["medical","legal","financial advice","safety critical","regulated"]
}

def suggest(text: str, risk: str) -> list[dict[str, object]]:
    lower = text.lower()
    out = []
    for action, keys in KEYWORD_MAP.items():
        if any(k in lower for k in keys):
            out.append({"tool_name": action, "purpose": f"Keyword-triggered support for {action}", "risk_level": risk, "approval_required": action in {"run_external_search","escalate_to_human_review"}})
    if risk == "high" and not any(o["tool_name"] == "escalate_to_human_review" for o in out):
        out.append({"tool_name":"escalate_to_human_review","purpose":"High-risk task requires expert review for final operational decisions","risk_level":"high","approval_required":True})
    seen, dedup = set(), []
    for item in out:
        if item["tool_name"] not in seen:
            dedup.append(item); seen.add(item["tool_name"])
    return dedup

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: suggest_tool_calls.py <task text> [risk_level]", file=sys.stderr); raise SystemExit(1)
    print(json.dumps(suggest(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "medium"), indent=2, ensure_ascii=False))
