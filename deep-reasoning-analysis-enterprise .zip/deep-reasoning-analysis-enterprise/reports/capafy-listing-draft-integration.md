# Capafy Listing Draft Integration Report

## Decision

Embedded the supplied `CAPAFY-LISTING-DRAFT_prd.md` in `capafy/review-needed/` for traceability.

## Important mismatch

The supplied file identifies the skill as `ai-native-prd-architect` and describes PRD-specific outputs. It does not describe `deep-reasoning-analysis-enterprise`.

## Clean merge behavior

- Preserved existing active listing: `capafy/listing.md`
- Added review-only draft: `capafy/review-needed/CAPAFY-LISTING-DRAFT_prd.md`
- Added note: `capafy/review-needed/README.md`
- Added machine-readable report: `reports/capafy-listing-draft-integration.json`

## Required next decision

Before Capafy submission, replace this review-only draft with a Deep-Reasoning-specific listing draft or move it to the PRD skill package.
