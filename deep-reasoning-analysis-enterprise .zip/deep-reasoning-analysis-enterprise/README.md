# Deep Reasoning Analysis Enterprise

Enterprise-ready analysis skill for evidence-grounded scientific, mathematical, technical, AI-system, repository/code, and defensive-cyber reasoning.

## Default outputs

Every completed analysis must emit or include:

- `analysis_report.md`
- `analysis_report.json`

When code findings exist, the skill must also emit:

- `code_findings.sarif.json`

All standards are used as standard-alignment references. This package does not claim certification or formal compliance.

## Validation

Run:

```bash
python scripts/quick_validate.py .
python scripts/validate_analysis_report.py examples/research-claim-verification.report.json
python scripts/validate_artifact_policy.py examples/research-claim-verification.report.json
python scripts/run_eval_suite.py evals
```


## Capafy marketplace pack

This package includes a Capafy-oriented pre-submission pack:

- `capafy/agent-card.md`
- `capafy/listing.md`
- `capafy/data-flow-declaration.md`
- `capafy/privacy-notice.md`
- `capafy/support-policy.md`
- `capafy/test-cases.md`
- `capafy/submission-checklist.md`

Run:

```bash
python scripts/validate_capafy_readiness.py .
python scripts/audit_skill_zip.py . --out reports/capafy-audit-report.json --md reports/capafy-audit-report.md
python scripts/validate_audit_report.py reports/capafy-audit-report.json
```

Remaining publisher-console facts must not be invented: support email, pricing, execution model, LLM provider policy, and enabled external services.


## Interactive HTML and Audit Pack outputs

The skill supports adaptive output selection. In addition to the mandatory `analysis_report.md` and `analysis_report.json`, it can produce an interactive self-contained `analysis_report.html`, `evidence_ledger.jsonl`, `claim_matrix.csv`, optional `executive_summary.pdf`, SARIF-compatible code findings, and a bundled `audit_pack.zip` when the task calls for review-ready handoff.

Use cases include research claim verification, AI-generated report audits, repository reviews, AI-system audits, Capafy readiness checks, and stakeholder-ready decision reports. Static HTML supports local navigation, filtering, evidence cards, source jumps, and deterministic calculators. Live document Q&A requires an explicit runtime model/API integration and user consent.
