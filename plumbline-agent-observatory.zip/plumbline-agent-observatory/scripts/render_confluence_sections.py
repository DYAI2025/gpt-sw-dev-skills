#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path

def block(start,end,content): return f"{start}\n{content.rstrip()}\n{end}"
def replace_or_append(body,start,end,content):
    b=block(start,end,content)
    if start in body and end in body:
        a=body.index(start); z=body.index(end,a)+len(end)
        return body[:a]+b+body[z:]
    return body.rstrip()+"\n\n---\n\n"+b+"\n"
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--page',choices=['living','observatory','audit'],required=True)
    ap.add_argument('--body',required=True)
    ap.add_argument('--event',required=True)
    args=ap.parse_args()
    body=Path(args.body).read_text(encoding='utf-8')
    ev=json.loads(Path(args.event).read_text(encoding='utf-8'))
    run=ev['observation_id']
    if run in body: raise SystemExit('DUPLICATE_RUN_ID')
    if args.page=='living':
        content=f"## Plumbline Agent Observatory – Current Verified Baseline\n\n- Last run: `{run}`\n- Repository: `{ev['repository']}`\n- Experiment arm: `{ev['experiment_arm']}`\n- Event: `{ev['canonical_prefix']}` — {ev['claim']}\n"
        out=replace_or_append(body,'<!-- PLUMBLINE_AGENT_OBSERVATORY_BASELINE_START -->','<!-- PLUMBLINE_AGENT_OBSERVATORY_BASELINE_END -->',content)
    elif args.page=='audit':
        content=f"## Plumbline Agent Observatory – Architecture Delta\n\n### {run}\n\n- Event: `{ev['canonical_prefix']}`\n- Claim: {ev['claim']}\n- Evidence ceiling: `{ev.get('plumbline_context',{}).get('evidence_ceiling','MISSING')}`\n"
        out=replace_or_append(body,'<!-- PLUMBLINE_AGENT_OBSERVATORY_AUDIT_START -->','<!-- PLUMBLINE_AGENT_OBSERVATORY_AUDIT_END -->',content)
    else:
        entry=f"### {run}\n\n- Arm: `{ev['experiment_arm']}`\n- Prefix: `{ev['canonical_prefix']}`\n- Actor: {ev['actor']}\n- Claim: {ev['claim']}\n- Status: `{ev['status']}`\n- Sources: "+", ".join(ev['source_links'])+"\n"
        start='<!-- PLUMBLINE_AGENT_OBSERVATORY_LOG_START -->'; end='<!-- PLUMBLINE_AGENT_OBSERVATORY_LOG_END -->'
        if start in body and end in body:
            a=body.index(start)+len(start); z=body.index(end,a)
            out=body[:a]+"\n\n"+entry+body[a:z]+body[z:]
        else:
            out=body.rstrip()+"\n\n---\n\n"+start+"\n\n## Plumbline Agent Observatory Event Log\n\n"+entry+end+"\n"
    print(out)
if __name__=='__main__': main()
