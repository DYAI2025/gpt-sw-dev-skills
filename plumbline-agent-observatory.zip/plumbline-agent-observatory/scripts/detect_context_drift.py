#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re, sys
from pathlib import Path

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('path')
    ap.add_argument('--comparison',action='store_true')
    args=ap.parse_args()
    text=Path(args.path).read_text(encoding='utf-8',errors='ignore')
    foreign=[]
    for pattern,label in [(r'\bEYT-\d+\b','EasyTree Jira key'),(r'DYAI2025/EasyTree','EasyTree repository'),(r'/projects/EYT/','EasyTree board'),(r'EasyTree Sprint','EasyTree sprint')]:
        if re.search(pattern,text,re.I): foreign.append(label)
    plumb=bool(re.search(r'\bPLUM-\d+\b|DYAI2025/Plumbline|Plumbline Core|PRIL|/agileteam|/concilium',text,re.I))
    result={'foreign_signals':foreign,'plumbline_signal':plumb,'comparison':args.comparison}
    if len(set(foreign))>=2 and not args.comparison:
        result['decision']='CTX_DRIFT_BLOCK'
        print(json.dumps(result,ensure_ascii=False,indent=2)); return 3
    result['decision']='PASS_OR_REVIEW'
    print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
if __name__=='__main__': raise SystemExit(main())
