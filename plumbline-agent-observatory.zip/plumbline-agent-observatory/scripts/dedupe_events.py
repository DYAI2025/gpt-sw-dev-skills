#!/usr/bin/env python3
from __future__ import annotations
import json, sys, hashlib
from pathlib import Path

def fingerprint(ev):
    keys=sorted(str(x) for x in ev.get('dedupe_keys',[]))
    return hashlib.sha256(('\n'.join(keys)).encode()).hexdigest()

def main():
    if len(sys.argv)!=3:
        print('usage: dedupe_events.py <events.jsonl> <new-event.json>',file=sys.stderr); return 2
    old=Path(sys.argv[1]); new=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
    fps=set()
    if old.exists():
        for line in old.read_text(encoding='utf-8').splitlines():
            if line.strip(): fps.add(fingerprint(json.loads(line)))
    fp=fingerprint(new)
    if fp in fps:
        print('DUPLICATE'); return 3
    print('NEW '+fp); return 0
if __name__=='__main__': raise SystemExit(main())
