#!/usr/bin/env python3
from __future__ import annotations
import json, re, sys
from pathlib import Path

ARMS={"ARM-A_AGENT_ONLY","ARM-B_AGENT_PLUS_REPO_INSTRUCTIONS","ARM-C_AGENT_PLUS_PLUMBLINE_INTAKE","ARM-D_AGENT_PLUS_PLUMBLINE_RUNTIME","ARM-E_AGENT_PLUS_PLUMBLINE_COUNCIL","ARM-MIXED_CHANGED_MID_RUN"}
PREFIXES={"AGENT-FIND","AGENT-PROCESS","PLUMB-FIND","PLB-DEFECT","PLB-GAP","AUTOMATION-FIND","REVIEW-FIND","ATTR-OPEN","MEASURE-ISSUE","CTX-DRIFT","FIX-VERIFY","DECISION"}
REQUIRED=["observation_id","timestamp","project_context","repository","experiment_arm","observer_agent","executing_agent","plumbline_context","event_type","canonical_prefix","actor","claim","facts","assumptions","missing","evidence","counterevidence","severity","status","attribution","source_links","dedupe_keys"]

def main():
    if len(sys.argv)!=2:
        print("usage: validate_event.py <event.json>",file=sys.stderr); return 2
    data=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    missing=[k for k in REQUIRED if k not in data]
    if missing: print("FAIL missing: "+", ".join(missing),file=sys.stderr); return 1
    if not re.match(r'^OBS-',str(data['observation_id'])): print('FAIL observation_id',file=sys.stderr); return 1
    if data['experiment_arm'] not in ARMS: print('FAIL experiment_arm',file=sys.stderr); return 1
    if data['canonical_prefix'] not in PREFIXES: print('FAIL canonical_prefix',file=sys.stderr); return 1
    if not isinstance(data['dedupe_keys'],list) or not data['dedupe_keys']: print('FAIL dedupe_keys',file=sys.stderr); return 1
    print('PASS: observation event')
    return 0
if __name__=='__main__': raise SystemExit(main())
