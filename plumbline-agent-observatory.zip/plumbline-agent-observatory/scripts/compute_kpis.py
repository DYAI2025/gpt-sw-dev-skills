#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path

def ratio(n,d):
    return None if d in (None,0) else n/d

def main():
    if len(sys.argv)!=2:
        print('usage: compute_kpis.py <events.jsonl>',file=sys.stderr); return 2
    events=[]
    for line in Path(sys.argv[1]).read_text(encoding='utf-8').splitlines():
        if line.strip(): events.append(json.loads(line))
    sums={}
    for ev in events:
        for k,v in ev.get('kpi_contribution',{}).items():
            if isinstance(v,(int,float)): sums[k]=sums.get(k,0)+v
    out={
      'event_count':len(events),
      'raw':sums,
      'false_green_catch_rate':ratio(sums.get('false_green_caught'),sums.get('known_false_green')),
      'false_green_escape_rate':ratio(sums.get('false_green_escaped'),sums.get('done_claims')),
      'cry_wolf_rate':ratio(sums.get('invalid_blocks'),sums.get('all_blocks')),
      'fix_survival_rate':ratio(sums.get('runtime_validated_fixes'),sums.get('fixes_revalidated')),
      'trend_status':'NO_TREND_CLAIM' if len(events)<3 else 'COMPARE_ONLY_IF_COMPATIBLE_ARMS'
    }
    print(json.dumps(out,ensure_ascii=False,indent=2)); return 0
if __name__=='__main__': raise SystemExit(main())
