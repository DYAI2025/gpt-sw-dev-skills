# Context Drift Policy

## Canonical context

This skill observes Plumbline Core. Product-project logs may be accepted only when explicitly framed as Plumbline pilot evidence or a controlled comparison arm.

## High-confidence mismatch signals

- foreign GitHub repository URL;
- foreign Jira key family, especially `EYT-*`;
- foreign board/sprint URL;
- implementation decisions whose object is the foreign product rather than Plumbline behavior;
- sudden agent answer requiring a Product Owner decision for another product.

## Decision

- one weak signal: annotate `POSSIBLE_CONTEXT_DRIFT` and continue only if Plumbline comparison is explicit;
- two independent strong signals: `CTX-DRIFT`, stop ingestion and Confluence writes;
- explicit user statement that content is comparison evidence: continue with both contexts named.

## No contamination rule

Foreign context does not increment Plumbline Core counts, change bug status, or update architecture pages until its relevance is explicitly classified.
