# Enterprise Skill Output Evaluator

Score 1–5 for specification compliance, research quality, enterprise readiness, architecture quality, and release-gate integrity. PASS requires no unresolved security or truthfulness blocker, all mandatory validators passing, and no claim that frontend installation or connector permissions are guaranteed.
