# Agent-Agnostic Compatibility

The observation model is not tied to Claude. Claude Code, Codex, Gemini, Qwen, Fable, and other agents use the same `executing_agent` fields, evidence rules, prefixes, and experiment arms.

tool availability varies by host. GitHub and Atlassian connectors may be missing; in that case the skill reports MISSING, caps the evidence, and renders patches instead of claiming updates.

`agents/openai.yaml` is runtime-specific metadata. It is not a portable behavior contract. A UI install suggestion is not guaranteed and remains outside the skill's control.
