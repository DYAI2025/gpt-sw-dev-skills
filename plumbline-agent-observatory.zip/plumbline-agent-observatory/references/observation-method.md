# Observation Method

## Purpose

The observatory measures whether Plumbline makes agentic delivery more truth-preserving, not whether an agent sounds careful or produces many artifacts.

## Unit of observation

An event is the smallest independently referenceable change in claim, evidence, status, decision, configuration, or observed behavior. One pasted transcript may contain many events; the same event pasted twice remains one event.

## Event sequence

1. baseline;
2. context and experiment arm;
3. trigger/input;
4. agent response or action;
5. Plumbline gate or intervention;
6. automation/review evidence;
7. correction or decision;
8. outcome and evidence ceiling.

## Attribution test

Ask in order:

1. Would the issue have been found without Plumbline? If directly found and reasoned by the executing agent before a Plumbline trigger, classify `AGENT-FIND`.
2. Did a Plumbline gate, intake contract, watcher, scope check, or evidence rule create the observation? Classify `PLUMB-FIND`.
3. Did a deterministic test, CI, static analyzer, or connector produce the decisive signal? Classify `AUTOMATION-FIND`.
4. Did a reviewer produce it? Classify `REVIEW-FIND`.
5. Was the outcome only reachable through interaction? Use `ATTR-OPEN` and list all contributing actors.

Do not award discovery credit to the actor that merely repeated an earlier source.

## Status lifecycle

`observed -> verified -> accepted | rejected | superseded`

A false-positive finding becomes `rejected` and may generate an `AGENT-PROCESS` or `MEASURE-ISSUE` event. It is removed from valid finding counts but remains in history.

## Evidence ceilings

- `user_statement`
- `document_supported`
- `file_verified`
- `integration_fake`
- `integration_real`
- `ci_executed`
- `real_boundary_smoke`
- `production_observed`

A higher label is never inferred from a lower one.

## Comparison discipline

Compare only events with compatible:

- project/repository and task complexity;
- model and reasoning setting;
- agent topology;
- Plumbline version and mode;
- permissions and tools;
- measurement definitions.

Otherwise report descriptive differences and `CAUSAL_INFERENCE_BLOCKED`.
