# Eval Design

The skill must pass:

1. current-baseline-first output;
2. agent/model setting captured with provenance;
3. correct canonical prefix attribution;
4. false-positive findings excluded from valid counts;
5. duplicate transcript deduplication;
6. context-drift hard warning and no writes;
7. bugfix ladder distinguishes merged from runtime validated;
8. Council/multi-agent activation opens a new experiment arm;
9. Confluence transaction preserves unmanaged content and is idempotent;
10. missing connector data caps evidence rather than becoming a guessed value.

Negative evals ensure the skill does not trigger for generic product implementation, generic Jira planning, or unrelated retrospective work without Plumbline observation.
