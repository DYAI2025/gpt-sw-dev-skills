# Prefix and Event Schema

## Canonical prefixes

| Prefix | Meaning | Counts as valid project finding? |
|---|---|---|
| `AGENT-FIND-*` | Valid finding independently identified by executing agent | yes |
| `AGENT-PROCESS-*` | Positive/negative agent behavior, correction, shortcut, drift | no |
| `PLUMB-FIND-*` | Valid project finding triggered by Plumbline | yes |
| `PLB-DEFECT-*` | Defect inside Plumbline implementation/runtime | yes, Plumbline defect |
| `PLB-GAP-*` | Missing Plumbline capability or governance contract | yes, product gap |
| `AUTOMATION-FIND-*` | Finding generated decisively by test/CI/static automation | yes |
| `REVIEW-FIND-*` | Finding from human or independent review | yes |
| `ATTR-OPEN-*` | Shared or unresolved attribution | separate bucket |
| `MEASURE-ISSUE-*` | Threat to measurement validity | no |
| `CTX-DRIFT-*` | Foreign-project or phase contamination | no |
| `FIX-VERIFY-*` | Bugfix verification or regression status | verification bucket |
| `DECISION-*` | Explicit human/product/architecture decision | no |

## Historical alias mapping

| Historical | Canonical conversion |
|---|---|
| `CLAUDE-FIND-*` | `AGENT-FIND-*`, `actor=Claude` |
| `CLAUDE-PROCESS-*` | `AGENT-PROCESS-*`, `actor=Claude` |
| `CTRL-CLAUDE-FIND-*` | `AGENT-FIND-*`, `actor=Claude`, control arm |
| `CTRL-CLAUDE-PROCESS-*` | `AGENT-PROCESS-*`, control arm |
| `CTRL-REVIEW-FIND-*` | `REVIEW-FIND-*`, control arm |
| `CTRL-AUTOMATION-FIND-*` | `AUTOMATION-FIND-*`, control arm |
| `CTRL-ATTR-OPEN-*` | `ATTR-OPEN-*`, control arm |
| `CTRL-MEASURE-ISSUE-*` | `MEASURE-ISSUE-*`, control arm |

Do not renumber historical entries. Store canonical ID and legacy alias together.

## Required event fields

- `observation_id`
- `timestamp`
- `project_context`
- `repository`
- `experiment_arm`
- `observer_agent`
- `executing_agent`
- `plumbline_context`
- `event_type`
- `canonical_prefix`
- `actor`
- `claim`
- `facts`
- `assumptions`
- `missing`
- `evidence`
- `counterevidence`
- `severity`
- `status`
- `attribution`
- `source_links`
- `dedupe_keys`

## ID construction

Use `OBS-YYYYMMDD-HHMMSS-<short-main-sha>-<sequence>` for the observation and `<PREFIX>-NNN` for the event. Time is Europe/Berlin unless explicitly reported otherwise.
