# Capability Parity Policy

Core behavior must remain: intake and scope control, source research, capability discovery, architecture gate, draft-build-validation, release hook, enterprise output evaluation, eval/packaging, and source discipline. Agent-neutral observation, context drift, bugfix survival, KPI computation, and Confluence transaction controls are minimal domain additions, not replacements.
