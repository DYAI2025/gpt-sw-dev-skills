# Release Gate Policy

Package only after structural, source, eval, release, installability, agent-agnostic, core-parity, placeholder, event-schema, and Enterprise Skill Evaluator checks pass. A release report must say PASS and allow packaging. Missing connector availability is a runtime limitation, not a package failure, if fallback behavior is explicit.
