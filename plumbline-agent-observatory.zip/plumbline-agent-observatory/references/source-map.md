# Source Map

## S001 — GitHub Plumbline repository
- type: primary
- purpose: current code, main SHA, release, PR and review state
- reliability: high
- limitations: no proof of production behavior without runtime evidence
- confidence_default: 5
- location: `DYAI2025/Plumbline`

## S002 — Jira PLUM
- type: connector
- purpose: operative issue scope, priority, status and decisions
- reliability: high for workflow state
- limitations: status does not prove implementation or runtime
- confidence_default: 5
- location: project `PLUM`

## S003 — Confluence Living Document
- type: connector
- purpose: human-readable current product and architecture snapshot
- reliability: medium-high
- limitations: derived documentation, can drift
- confidence_default: 4
- location: page `7503873`

## S004 — Confluence Sprint Observatory
- type: connector
- purpose: append-only behavior, decision and KPI history
- reliability: medium-high with source links
- limitations: event interpretation requires source verification
- confidence_default: 4
- location: page `9633793`

## S005 — Confluence Architecture Audit
- type: connector
- purpose: architecture and capability baseline/deltas
- reliability: medium-high
- limitations: not runtime proof
- confidence_default: 4
- location: page `9601026`

## S006 — User-provided transcripts/logs
- type: user_provided
- purpose: observed agent and Plumbline behavior
- reliability: medium
- limitations: may be truncated, duplicated, cross-project, or agent-reported
- confidence_default: 3

## S007 — CI, test and runtime logs
- type: runtime
- purpose: prove specific execution and results
- reliability: high when bound to SHA/job/step
- limitations: only the executed target and boundary
- confidence_default: 5

Unknown external claims use `SOURCE_NEEDED`. Required unavailable evidence is `MISSING`.
