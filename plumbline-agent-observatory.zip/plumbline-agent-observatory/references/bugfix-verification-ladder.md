# Bugfix Verification Ladder

## Principle

`Jira Done`, a merged PR, and green tests are different states. A fix is not proven to survive real use until the runtime actually used by the observed project contains the fix and its negative counterexample remains blocked.

## Status ladder

1. `FIX_CLAIMED` — ticket/PR says fixed.
2. `CODE_VERIFIED` — claimed change exists at identified commit.
3. `TEST_VERIFIED` — focused positive and negative tests execute.
4. `CI_VERIFIED` — relevant jobs execute on required platforms.
5. `INSTALLED_VERIFIED` — active hook/CLI/library resolves to fixed code.
6. `RUNTIME_VALIDATED` — real governed foreign repository exhibits correct behavior.
7. `SURVIVED_NEXT_RELEASE` — behavior remains after a later update/release.
8. `REGRESSION_CONFIRMED` — original or equivalent failure reappears.
9. `NOT_REPRODUCIBLE` — claim cannot be reproduced with recorded conditions.
10. `BLOCKED` — prerequisites unavailable.

## Mandatory evidence per verification

- issue key and invariant;
- PR/commit SHA;
- active installation path and version;
- positive path result;
- falsifying negative path result;
- platform/environment;
- source/run IDs;
- remaining ceiling.

## Mutation validity

Before interpreting a mutation:

1. capture target before;
2. apply mutation;
3. prove target changed;
4. run focused test;
5. restore;
6. prove restoration;
7. rerun focused test.

A blocked, missed, comment-only, or reverted mutation is not evidence.

## Fix Survival Rate

Report numerator and denominator:

`runtime_validated fixes / fixes selected for real-use revalidation`

Do not include untested fixes as failures or successes; report them as missing.
