# Confluence Update Contract

## Exact targets

- Living Document: `7503873`
- Sprint Observatory: `9633793`
- Repository and Architecture Audit: `9601026`

## Managed markers

Use these comments in page bodies:

- `<!-- PLUMBLINE_AGENT_OBSERVATORY_BASELINE_START -->`
- `<!-- PLUMBLINE_AGENT_OBSERVATORY_BASELINE_END -->`
- `<!-- PLUMBLINE_AGENT_OBSERVATORY_LOG_START -->`
- `<!-- PLUMBLINE_AGENT_OBSERVATORY_LOG_END -->`
- `<!-- PLUMBLINE_AGENT_OBSERVATORY_AUDIT_START -->`
- `<!-- PLUMBLINE_AGENT_OBSERVATORY_AUDIT_END -->`

If markers are absent, append a new managed section without altering existing content. Never replace text outside a managed block.

## Page roles

### Living Document

Current verified baseline only: main SHA, release, agent configuration of latest observation, latest material capability/fix state, current blockers, last observatory run ID.

### Sprint Observatory

Append-only events, decisions, experiment arms, raw KPI row, source links, corrections, and watcher verdict. Do not silently edit old rows; append revisions.

### Architecture Audit

Material architecture/capability delta, fix survival changes, and evidence ceiling. If none, leave the body unchanged and record `NO_MATERIAL_ARCHITECTURE_DELTA` in the Observatory event.

## Transaction safety

- Fetch all page bodies first.
- Verify exact titles and IDs.
- Render locally.
- Reject a candidate body shorter than the original outside an intentional managed-block replacement.
- Check run ID uniqueness.
- Write Observatory, Audit, then Living Document.
- Read after write.
- Verify run ID and markers.
- Report partial success as a blocker.

The skill cannot guarantee frontend UI refresh behavior or third-party audit availability.
