# KPI Catalog

## Core outcome KPIs

| KPI | Formula or fields | Interpretation |
|---|---|---|
| False-Green Catch Rate | caught_before_done / all_known_false_green | prevention power |
| False-Green Escape Rate | escaped_after_done / done_claims | residual risk |
| Cry-Wolf Rate | invalid_blocks / all_blocks | usability cost |
| Evidence Binding Completeness | fully_bound_critical_claims / critical_claims | claim-to-run completeness |
| Review Closure Completeness | findings_with_full_chain / findings_marked_closed | closure truth |
| Fix Survival Rate | runtime_validated_fixes / fixes_revalidated | bugfix durability |
| Gate Diagnostic Accuracy | correctly_classified_gate_errors / evaluated_gate_errors | tool/policy/evidence separation |
| Scope Drift Detection Latency | steps or minutes from drift to detection | responsiveness |
| Time to Verified Value | intake start to human accepted evidence-bound outcome | throughput without evidence loss |
| Human Intervention Count | explicit corrective interventions | autonomy cost |
| Agent Self-Correction Rate | self_corrected_valid_errors / agent_errors | agent quality |
| Plumbline Leverage Share | valid Plumbline-triggered findings / all pre-Done valid findings | observed contribution, not causality |
| Shared Attribution Share | shared valid findings / all valid findings | interaction dependence |
| Context Drift Incidents | confirmed foreign-context events | documentation integrity |

## Required segmentation

Every KPI row includes experiment arm, repository, task/sprint, agent model, reasoning mode, topology, Plumbline version/mode, start/end timestamps, and evidence ceiling.

## Trend rules

- fewer than three comparable points: `NO_TREND_CLAIM`;
- changed definition or denominator: start a new series;
- missing is not zero;
- raw counts accompany percentages;
- do not compare task volume or time without a complexity note;
- do not attribute causality when multiple variables changed.

## Preferred visualizations

- event timeline;
- stacked attribution bars;
- bugfix survival matrix;
- evidence funnel;
- claim-to-evidence graph;
- review closure graph;
- context-drift matrix;
- KPI control charts;
- agent-setting comparison matrix.
