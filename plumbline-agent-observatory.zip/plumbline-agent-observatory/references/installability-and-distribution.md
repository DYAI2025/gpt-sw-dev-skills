# Installability and Distribution

The install-ready artifact is exactly `skill.zip` with one top-level directory named `plumbline-agent-observatory`. The package can be offered for installation where the host supports Skills. The skill cannot guarantee that a frontend install suggestion appears, that connectors are connected, or that the user has Confluence write permission.
