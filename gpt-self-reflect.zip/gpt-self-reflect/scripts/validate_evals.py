#!/usr/bin/env python3
from pathlib import Path
import sys,json
def fail(m): print('FAIL: '+m,file=sys.stderr); return 1
def main(argv):
    if len(argv)!=2: return fail('usage: validate_evals.py <skill-dir>')
    root=Path(argv[1])
    try:
        t=json.loads((root/'evals/trigger_queries.json').read_text(encoding='utf-8'))
        o=json.loads((root/'evals/output_evals.json').read_text(encoding='utf-8'))
    except Exception as e: return fail(str(e))
    if not isinstance(t,list) or len(t)<8: return fail('need at least 8 trigger cases')
    if not any(x.get('should_trigger') is True for x in t): return fail('positive trigger missing')
    if not any(x.get('should_trigger') is False for x in t): return fail('negative trigger missing')
    if not isinstance(o,list) or len(o)<8: return fail('need at least 8 output evals')
    for x in o:
        if not all(k in x for k in ['id','prompt','expected_properties','failure_modes']): return fail('invalid output eval')
    print('PASS: eval files'); return 0
if __name__=='__main__': raise SystemExit(main(sys.argv))
