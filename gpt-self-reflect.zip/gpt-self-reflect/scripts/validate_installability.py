#!/usr/bin/env python3
from pathlib import Path
import sys,json
def fail(m): print('FAIL: '+m,file=sys.stderr); return 1
def main(argv):
    if len(argv)!=2: return fail('usage: validate_installability.py <skill-dir>')
    root=Path(argv[1]); rp=root/'reports/installability-report.json'; ap=root/'agents/openai.yaml'
    if not rp.exists() or not ap.exists(): return fail('installability files missing')
    r=json.loads(rp.read_text(encoding='utf-8'))
    if r.get('artifact_name')!='skill.zip': return fail('artifact_name must be skill.zip')
    if r.get('chatgpt_install_ready') is not True: return fail('chatgpt_install_ready must be true')
    if r.get('frontend_install_suggestion_status') not in {'prepared','blocked','not_controlled_by_skill'}: return fail('invalid frontend status')
    if r.get('frontend_install_suggestion_status')=='guaranteed': return fail('frontend guarantee prohibited')
    y=ap.read_text(encoding='utf-8')
    if 'display_name:' not in y or 'short_description:' not in y: return fail('openai.yaml metadata incomplete')
    print('PASS: installability'); return 0
if __name__=='__main__': raise SystemExit(main(sys.argv))
