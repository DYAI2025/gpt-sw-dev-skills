#!/usr/bin/env python3
from __future__ import annotations
import re, sys
from pathlib import Path
NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
REQUIRED = [
"SKILL.md","agents/openai.yaml","references/source-policy.md","references/source-map.md","references/research-bag.md",
"references/reflection-method.md","references/evidence-attribution.md","references/persistence-routing.md","references/skill-creation-handoff.md",
"references/attachment-fit-analysis.md","references/security-and-tools.md","references/eval-design.md","references/agent-agnostic-compatibility.md",
"references/child-artifact-validation.md",
"schemas/reflection-candidate.schema.json","schemas/reflection-report.schema.json","schemas/validation-routing-record.schema.json","evals/trigger_queries.json","evals/output_evals.json",
"evals/sample-validation-routing-record.json","scripts/validate_validation_routing.py",
"reports/validation-routing-regression-report.json",
"reports/release-gate-report.json","reports/installability-report.json","reports/core-functionality-preservation.json","reports/agent-compatibility-report.json",
"reports/enterprise-skill-evaluation.xml"
]
def fail(m): print(f"FAIL: {m}", file=sys.stderr); return 1
def fm(text):
    if not text.startswith('---\n'): raise ValueError('frontmatter missing')
    end=text.find('\n---\n',4)
    if end<0: raise ValueError('frontmatter closing marker missing')
    out={}
    for line in text[4:end].splitlines():
        if not line.strip(): continue
        if ':' not in line: raise ValueError(f'invalid frontmatter line: {line}')
        k,v=line.split(':',1); out[k.strip()]=v.strip().strip('"').strip("'")
    return out

def main(argv):
    if len(argv)!=2: return fail('usage: quick_validate.py <skill-dir>')
    root=Path(argv[1])
    if not root.is_dir(): return fail('skill directory missing')
    for rel in REQUIRED:
        if not (root/rel).exists(): return fail(f'missing required path: {rel}')
    text=(root/'SKILL.md').read_text(encoding='utf-8')
    try: data=fm(text)
    except ValueError as e: return fail(str(e))
    name=data.get('name',''); desc=data.get('description','')
    if not NAME_RE.match(name): return fail('invalid skill name')
    if root.name != name: return fail('folder name must match frontmatter name')
    if not desc or len(desc)>1024 or '<' in desc or '>' in desc: return fail('invalid description')
    body=text.split('\n---\n',1)[1].splitlines()
    if len(body)>500: return fail('SKILL.md body exceeds 500 lines')
    empties=[str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.stat().st_size==0]
    if empties: return fail('empty files: '+', '.join(empties))
    print(f'PASS: {root}')
    return 0
if __name__=='__main__': raise SystemExit(main(sys.argv))
