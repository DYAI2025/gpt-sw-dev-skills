#!/usr/bin/env python3
from pathlib import Path
import json,sys
def fail(m): print('FAIL: '+m,file=sys.stderr); return 1
def main(argv):
    if len(argv)!=2: return fail('usage: validate_schemas.py <skill-dir>')
    root=Path(argv[1])
    for rel in ['schemas/reflection-candidate.schema.json','schemas/reflection-report.schema.json','schemas/validation-routing-record.schema.json']:
        try: s=json.loads((root/rel).read_text(encoding='utf-8'))
        except Exception as e: return fail(f'{rel}: {e}')
        if s.get('type')!='object' or not s.get('required') or not s.get('properties'): return fail(f'{rel}: incomplete schema')
    print('PASS: schemas'); return 0
if __name__=='__main__': raise SystemExit(main(sys.argv))
