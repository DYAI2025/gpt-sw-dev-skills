#!/usr/bin/env python3
from pathlib import Path
import re,sys
RE=re.compile(r"\{[A-Z_][A-Z0-9_]*\}|\{\{[A-Z_][A-Z0-9_]*\}\}")
IGNORE={'evals','reports','schemas'}
def main(argv):
    if len(argv)!=2: print('FAIL: usage: validate_no_placeholders.py <skill-dir>',file=sys.stderr); return 1
    root=Path(argv[1]); hits=[]
    for p in root.rglob('*'):
        if not p.is_file() or set(p.relative_to(root).parts)&IGNORE: continue
        if p.suffix not in {'.md','.py','.yaml','.json'} and p.name!='SKILL.md': continue
        for m in RE.finditer(p.read_text(encoding='utf-8',errors='ignore')): hits.append(f'{p.relative_to(root)}:{m.group(0)}')
    if hits: print('FAIL: unresolved placeholders: '+', '.join(hits),file=sys.stderr); return 1
    print('PASS: no unresolved production placeholders'); return 0
if __name__=='__main__': raise SystemExit(main(sys.argv))
