#!/usr/bin/env python3
from pathlib import Path
import sys,xml.etree.ElementTree as ET
TAGS=['spec_compliance','research_quality','enterprise_readiness','architecture_quality','release_gate_integrity']
DEC={'PASS','PASS_WITH_MINOR_REVISIONS','REVISE','REBUILD','BLOCKED'}
def fail(m): print('FAIL: '+m,file=sys.stderr); return 1
def txt(n): return '' if n is None or n.text is None else n.text.strip()
def main(argv):
    if len(argv)!=2: return fail('usage: validate_enterprise_skill_evaluation.py <evaluation.xml>')
    p=Path(argv[1])
    try: root=ET.parse(p).getroot()
    except Exception as e: return fail(str(e))
    if root.tag!='enterprise_skill_evaluation': return fail('invalid root tag')
    scores=root.find('scores')
    if scores is None: return fail('scores missing')
    for tag in TAGS:
        if txt(scores.find(tag)) not in {'1','2','3','4','5'}: return fail(f'invalid score: {tag}')
    if txt(root.find('decision')) not in DEC: return fail('invalid decision')
    if not txt(root.find('reason')): return fail('reason missing')
    print('PASS: enterprise skill evaluation'); return 0
if __name__=='__main__': raise SystemExit(main(sys.argv))
