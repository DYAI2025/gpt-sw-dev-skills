#!/usr/bin/env python3
from __future__ import annotations
import argparse,subprocess,sys,zipfile
from pathlib import Path
VALIDATORS=['quick_validate.py','validate_source_map.py','validate_evals.py','validate_release_gate.py','validate_installability.py','validate_agent_agnostic.py','validate_core_parity.py','validate_no_placeholders.py','validate_schemas.py']
def run(skill, script):
    r=subprocess.run([sys.executable,str(script),str(skill)],text=True,capture_output=True)
    if r.stdout: print(r.stdout.strip())
    if r.returncode:
        if r.stderr: print(r.stderr.strip(),file=sys.stderr)
        raise SystemExit(r.returncode)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('skill_dir'); ap.add_argument('out_dir',nargs='?',default='./dist'); a=ap.parse_args()
    skill=Path(a.skill_dir).resolve(); scripts=skill/'scripts'
    for v in VALIDATORS: run(skill,scripts/v)
    sample=skill/'evals/sample-build-ready-candidate.json'
    run(sample, scripts/'validate_candidate_record.py')
    routing=skill/'evals/sample-validation-routing-record.json'
    run(routing, scripts/'validate_validation_routing.py')
    eval_xml=skill/'reports/enterprise-skill-evaluation.xml'
    run(eval_xml, scripts/'validate_enterprise_skill_evaluation.py')
    out=Path(a.out_dir).resolve(); out.mkdir(parents=True,exist_ok=True); z=out/'skill.zip'
    if z.exists(): z.unlink()
    with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED) as f:
        for p in sorted(skill.rglob('*')):
            if p.is_file(): f.write(p,p.relative_to(skill.parent))
    print(f'PACKAGED: {z}')
if __name__=='__main__': main()
