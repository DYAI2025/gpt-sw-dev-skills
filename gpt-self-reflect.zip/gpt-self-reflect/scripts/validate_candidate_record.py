#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path

REQUIRED = [
    "id", "candidate_type", "title", "observed_pattern", "underlying_value", "evidence",
    "recurrence_count", "evidence_strength", "transferability", "testability", "harm_if_wrong",
    "impact_attribution", "confidence", "counterevidence_status", "coverage", "scope", "status",
    "recommended_destination"
]

def fail(msg):
    print(f"FAIL: {msg}", file=sys.stderr)
    return 1

def main(argv):
    if len(argv) != 2:
        return fail("usage: validate_candidate_record.py <candidate.json>")
    try:
        c = json.loads(Path(argv[1]).read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(f"invalid candidate JSON: {exc}")
    missing = [k for k in REQUIRED if k not in c]
    if missing:
        return fail("missing fields: " + ", ".join(missing))
    for k in ["evidence_strength", "transferability", "testability", "harm_if_wrong", "confidence"]:
        if not isinstance(c[k], int) or not 1 <= c[k] <= 5:
            return fail(f"{k} must be integer 1-5")
    if not isinstance(c["recurrence_count"], int) or c["recurrence_count"] < 1:
        return fail("recurrence_count must be >= 1")
    if not isinstance(c["evidence"], list) or not c["evidence"]:
        return fail("evidence must be non-empty")
    if c["status"] == "BUILD_READY":
        if c["recurrence_count"] < 2:
            return fail("BUILD_READY requires recurrence_count >= 2")
        if c["evidence_strength"] < 4:
            return fail("BUILD_READY requires evidence_strength >= 4")
        if c["transferability"] < 4:
            return fail("BUILD_READY requires transferability >= 4")
        if c["testability"] < 3:
            return fail("BUILD_READY requires testability >= 3")
        if c["harm_if_wrong"] >= 4:
            return fail("BUILD_READY blocked when harm_if_wrong >= 4")
        if c["impact_attribution"] not in {"PLAUSIBLE_CONTRIBUTOR", "CONTRAST_SUPPORTED"}:
            return fail("BUILD_READY requires plausible or contrast-supported impact")
        if c["counterevidence_status"] == "COVERAGE_TOO_PARTIAL":
            return fail("BUILD_READY blocked by insufficient counterevidence coverage")
        if c.get("blockers"):
            return fail("BUILD_READY requires empty blockers")
        if c["candidate_type"] in {"skill", "skill_update"} and c.get("creator_route") not in {"skill-creator", "enterprise-skill-creator"}:
            return fail("Skill candidate requires creator_route")
    if c.get("auto_build_eligible") is True:
        if c["status"] != "BUILD_READY":
            return fail("auto_build_eligible requires BUILD_READY")
        if c["confidence"] < 5 or c["evidence_strength"] < 5:
            return fail("auto_build_eligible requires confidence and evidence_strength 5")
        if c["impact_attribution"] != "CONTRAST_SUPPORTED":
            return fail("auto_build_eligible requires CONTRAST_SUPPORTED")
        if c["testability"] < 4 or c["harm_if_wrong"] > 2:
            return fail("auto_build_eligible requires testability >= 4 and harm_if_wrong <= 2")
    print("PASS: reflection candidate")
    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
