#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

VALID_APPLICABILITY = {"APPLICABLE", "NOT_APPLICABLE", "SOURCE_NEEDED"}
VALID_RESULTS = {"PASS", "FAIL", "NOT_RUN"}
VALID_FAILURES = {
    "skill_defect",
    "validator_scope_mismatch",
    "execution_lapse",
    "tool_failure",
    "missing_context",
    "unknown",
}
VALID_ACTIONS = {
    "repair_target",
    "repair_validator_or_router",
    "rerun_correctly",
    "repair_tool",
    "stop_source_needed",
    "no_change",
}


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_validation_routing.py <routing-record.json>")

    path = Path(argv[1])
    if not path.exists():
        return fail(f"file not found: {path}")

    try:
        record = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(f"invalid JSON: {exc}")

    target = record.get("target_artifact", {})
    contract = record.get("governing_contract", {})
    validator = record.get("validator", {})
    applicability = record.get("applicability")
    result = record.get("observed_result")
    violated = record.get("target_contract_violated")
    classification = record.get("failure_classification")
    action = record.get("action")

    if not target.get("name") or not target.get("kind"):
        return fail("target_artifact.name and target_artifact.kind are required")
    if not isinstance(contract.get("sources"), list) or not contract.get("sources"):
        return fail("governing_contract.sources must be a non-empty list")
    if not isinstance(contract.get("contract_confirmed"), bool):
        return fail("governing_contract.contract_confirmed must be boolean")
    if not validator.get("name") or not validator.get("owner"):
        return fail("validator.name and validator.owner are required")
    if not isinstance(validator.get("declared_scope"), list) or not validator.get("declared_scope"):
        return fail("validator.declared_scope must be a non-empty list")
    if not validator.get("requirement_origin"):
        return fail("validator.requirement_origin is required")
    if applicability not in VALID_APPLICABILITY:
        return fail("invalid applicability")
    if result not in VALID_RESULTS:
        return fail("invalid observed_result")
    if not isinstance(violated, bool):
        return fail("target_contract_violated must be boolean")
    if classification not in VALID_FAILURES:
        return fail("invalid failure_classification")
    if action not in VALID_ACTIONS:
        return fail("invalid action")

    target_kind = target.get("kind")
    owner = validator.get("owner")
    scope = set(validator.get("declared_scope", []))
    origin = validator.get("requirement_origin")

    if applicability == "APPLICABLE":
        if not contract.get("contract_confirmed"):
            return fail("APPLICABLE requires a confirmed governing contract")
        if origin == "unknown":
            return fail("unknown requirement origin cannot be APPLICABLE")
        if target_kind == "generated_child_skill" and origin == "parent_internal_contract":
            return fail("parent-internal requirement cannot be APPLICABLE to a generated child without target/generic contract origin")
        if target_kind == "generated_child_skill" and owner == "parent":
            if "generated_child_skill" not in scope and "any_skill" not in scope:
                return fail("parent validator scope does not include generated_child_skill")

    if applicability == "NOT_APPLICABLE" and violated:
        return fail("NOT_APPLICABLE validator cannot establish target contract violation")

    if classification == "skill_defect":
        if applicability != "APPLICABLE" or result != "FAIL" or violated is not True:
            return fail("skill_defect requires APPLICABLE + FAIL + target_contract_violated=true")
        if action != "repair_target":
            return fail("skill_defect must route to repair_target")

    if classification == "validator_scope_mismatch":
        if applicability != "NOT_APPLICABLE" or result != "FAIL" or violated is not False:
            return fail("validator_scope_mismatch requires NOT_APPLICABLE + FAIL + no target contract violation")
        if action != "repair_validator_or_router":
            return fail("validator_scope_mismatch must route to repair_validator_or_router")

    if classification == "execution_lapse" and action != "rerun_correctly":
        return fail("execution_lapse must route to rerun_correctly")

    if classification == "tool_failure" and action != "repair_tool":
        return fail("tool_failure must route to repair_tool")

    if applicability == "SOURCE_NEEDED":
        if action != "stop_source_needed":
            return fail("SOURCE_NEEDED must route to stop_source_needed")
        if classification not in {"missing_context", "unknown"}:
            return fail("SOURCE_NEEDED must classify as missing_context or unknown")

    print("PASS: validation routing record")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
