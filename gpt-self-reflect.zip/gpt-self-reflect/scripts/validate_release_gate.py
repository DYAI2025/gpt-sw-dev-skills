#!/usr/bin/env python3
from pathlib import Path
import sys,json
def fail(m): print('FAIL: '+m,file=sys.stderr); return 1
def main(argv):
    if len(argv)!=2: return fail('usage: validate_release_gate.py <skill-dir>')
    root=Path(argv[1])
    try: r=json.loads((root/'reports/release-gate-report.json').read_text(encoding='utf-8'))
    except Exception as e: return fail(str(e))
    rg=r.get('release_gate',{}); c=r.get('craftsmanship_gate',{}); a=r.get('anti_confabulation_gate',{}); s=r.get('anti_sycophancy',{}); b=r.get('bias_gate',{})
    if rg.get('status')!='PASS' or rg.get('allowed_to_package') is not True: return fail('release gate not passed')
    if c.get('status')!='PASS': return fail('craftsmanship gate not passed')
    if a.get('status')!='PASS' or a.get('blocked_claims'): return fail('anti-confabulation gate not passed')
    if not isinstance(s.get('score'),int) or s.get('score')>=s.get('threshold',3): return fail('anti-sycophancy threshold failed')
    if b.get('status')=='BLOCKED': return fail('bias gate blocked')
    print('PASS: release gate'); return 0
if __name__=='__main__': raise SystemExit(main(sys.argv))
