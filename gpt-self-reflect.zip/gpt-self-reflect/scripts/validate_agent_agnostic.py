#!/usr/bin/env python3
from pathlib import Path
import json,sys
def fail(m): print('FAIL: '+m,file=sys.stderr); return 1
def main(argv):
    if len(argv)!=2: return fail('usage: validate_agent_agnostic.py <skill-dir>')
    root=Path(argv[1]); ref=root/'references/agent-agnostic-compatibility.md'; rep=root/'reports/agent-compatibility-report.json'
    if not ref.exists() or not rep.exists(): return fail('agent compatibility artifacts missing')
    r=json.loads(rep.read_text(encoding='utf-8'))
    if r.get('agent_agnostic_ready') is not True: return fail('agent_agnostic_ready must be true')
    if not r.get('not_guaranteed'): return fail('runtime limitations missing')
    print('PASS: agent-agnostic compatibility'); return 0
if __name__=='__main__': raise SystemExit(main(sys.argv))
