#!/usr/bin/env python3
from pathlib import Path
import json,sys
def fail(m): print('FAIL: '+m,file=sys.stderr); return 1
def main(argv):
    if len(argv)!=2: return fail('usage: validate_core_parity.py <skill-dir>')
    root=Path(argv[1]); p=root/'reports/core-functionality-preservation.json'
    if not p.exists(): return fail('core functionality report missing')
    r=json.loads(p.read_text(encoding='utf-8'))
    if r.get('status')!='PASS': return fail('core parity status not PASS')
    if r.get('unintended_changes'): return fail('unintended changes present')
    if r.get('baseline')!='new_skill' and not r.get('core_functions_preserved'): return fail('preserved core functions not documented')
    print('PASS: core functionality preservation'); return 0
if __name__=='__main__': raise SystemExit(main(sys.argv))
