#!/usr/bin/env python3
from pathlib import Path
import sys
REQ=['type:','purpose:','reliability:','limitations:','confidence_default:','user_provided','primary','SOURCE_NEEDED','MISSING']
def main(argv):
    if len(argv)!=2: print('FAIL: usage: validate_source_map.py <skill-dir>',file=sys.stderr); return 1
    root=Path(argv[1]); text=(root/'references/source-map.md').read_text(encoding='utf-8')+'\n'+(root/'references/source-policy.md').read_text(encoding='utf-8')
    miss=[x for x in REQ if x not in text]
    if miss: print('FAIL: missing source terms: '+', '.join(miss),file=sys.stderr); return 1
    print('PASS: source map and source policy'); return 0
if __name__=='__main__': raise SystemExit(main(sys.argv))
