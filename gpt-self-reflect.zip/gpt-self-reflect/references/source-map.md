# Source Map

## S001 - User request for GPT Self Reflect
- type: `user_provided`
- purpose: Defines desired workflow: session reflection, repeated behavior patterns, value extraction, persistence choices, and second-step Skill creation.
- reliability: Strong as product requirement.
- limitations: Does not prove technical platform capabilities or method effectiveness.
- confidence_default: 5 for user intent; 2 for external capability claims until verified.

## S002 - Enterprise Skill Creator operating policy
- type: `user_provided`
- purpose: Source discipline, architecture gate, release gate, installability, validation, and Skill-Creator routing constraints.
- reliability: Strong as the build policy for this package.
- limitations: Internal policy is not proof of external platform behavior.
- confidence_default: 5 for package requirements.

## S003 - dyai-llm-technology-radar.zip
- type: `user_provided`
- purpose: Candidate technology radar, evidence statuses, anti-tool-hopping rules, fit rubric, hard blockers, and external evaluation/observability candidates.
- reliability: Useful as internal design input.
- limitations: Candidate files explicitly mark listed technologies as `AUDIT_REQUIRED` and not source-inspected; they cannot justify adopting a dependency.
- confidence_default: 4 for the radar method; 2 for candidate technology claims.

## S004 - canon-resolver.zip
- type: `user_provided`
- purpose: Canonical/reference/derived trust separation, provenance retention, fail-closed source authority, and separation of retrieval from truth judgment.
- reliability: Strong as an inspected user-provided implementation pattern with its own test report.
- limitations: Its self-reported local validation does not independently prove production readiness; runtime dependency is not required by this Skill.
- confidence_default: 4 for the architecture pattern; 2-3 for unverified deployment claims.

## S005 - OpenAI Skills in ChatGPT
- type: `primary`
- location: `https://help.openai.com/en/articles/20001066-skills-in-chatgpt`
- purpose: Verifies that Skills are reusable workflows, can include instructions/examples/code, and that ChatGPT may use one or more installed Skills when helpful; also documents the built-in `skill-creator` for Skill creation/modification.
- reliability: Official OpenAI documentation, retrieved 2026-08-16.
- limitations: Does not guarantee direct nested Skill invocation from every runtime or complete historical-session access.
- confidence_default: 5.

## S006 - Reflexion: Language Agents with Verbal Reinforcement Learning
- type: `primary`
- location: `https://papers.neurips.cc/paper_files/paper/2023/hash/1b44b878bb782e6954cd888628510e90-Abstract-Conference.html`
- purpose: Supports feedback-conditioned verbal reflection as non-parametric learning across agent tasks.
- reliability: NeurIPS 2023 paper.
- limitations: Benchmark findings do not guarantee identical effects in ChatGPT session reflection.
- confidence_default: 5 for reported method; 3 for direct product transfer.

## S007 - ExpeL: LLM Agents Are Experiential Learners
- type: `primary`
- location: `https://arxiv.org/abs/2308.10144`
- purpose: Supports gathering experiences, extracting natural-language knowledge, and reusing insights for later tasks.
- reliability: Original research paper.
- limitations: Research setting differs from ChatGPT Skill runtime.
- confidence_default: 4.

## S008 - Voyager: An Open-Ended Embodied Agent with Large Language Models
- type: `primary`
- location: `https://arxiv.org/abs/2305.16291`
- purpose: Supports verified Skill-library accumulation, iterative feedback, error incorporation, and commit-after-verification as a transferable design pattern.
- reliability: Original research paper.
- limitations: Minecraft embodiment and executable-code skills differ materially from conversational Skill creation.
- confidence_default: 4 for design pattern transfer.

## S009 - Experiential Reflective Learning for Self-Improving LLM Agents
- type: `primary`
- location: `https://arxiv.org/abs/2603.24639`
- purpose: Supports reflecting on task trajectories and outcomes to produce transferable heuristics; reports selective retrieval as important and heuristics as more transferable than few-shot trajectory prompting in its benchmark.
- reliability: Original 2026 research paper / workshop publication.
- limitations: Reported benchmark effect sizes are not assumed for this Skill.
- confidence_default: 4.

## S010 - Large Language Model Agents Are Not Always Faithful Self-Evolvers
- type: `primary`
- location: `https://arxiv.org/abs/2601.22436`
- purpose: Supports preserving raw evidence pointers and testing whether condensed experience is actually used; reports faithfulness gaps for condensed experiences.
- reliability: Original 2026 research paper, ICML 2026.
- limitations: Does not imply all condensed heuristics are ineffective.
- confidence_default: 4.

## S011 - ReFlect: An Effective Harness System for Complex Long-Horizon LLM Reasoning
- type: `primary`
- location: `https://arxiv.org/abs/2605.05737`
- purpose: Supports deterministic verification/recovery around model reflection and cautions against relying on prompt-level self-critique alone.
- reliability: Original 2026 research paper.
- limitations: Results are benchmark- and harness-specific; used here as a design warning, not a universal performance claim.
- confidence_default: 4.

## S012 - Agent Skills Can Be Harmful: An Empirical Study of Skill-Induced Failures in LLM Agents
- type: `primary`
- location: `https://arxiv.org/abs/2608.11888`
- purpose: Supports differential validation of a generated Skill against a no-Skill or previous-Skill baseline and checking functional plus efficiency regressions.
- reliability: Original research paper submitted 2026-08-12.
- limitations: Very recent preprint; findings motivate evaluation rather than a hard universal claim.
- confidence_default: 4.

## S013 - BayramAnnakov/claude-reflect
- type: `primary`
- location: `https://github.com/BayramAnnakov/claude-reflect`
- purpose: Community reference implementation for capturing corrections/positive feedback and discovering repeating session patterns that may become reusable Skills.
- reliability: Original project repository.
- limitations: Community project, not an Anthropic built-in standard Skill; Claude Code hooks/history behavior must not be assumed for ChatGPT.
- confidence_default: 4 for repository-stated behavior; 2 for cross-platform transfer.

## S014 - Current session validator-scope incident
- type: `derived`
- location: current build/validation session for gpt-self-reflect
- purpose: Empirical design evidence that a parent/meta validator can fail on a generated child because the validator expects parent-only parity artifacts rather than because the child violates its own contract.
- reliability: Strong for the observed local mismatch and correction path; not a universal claim about all builders or validators.
- limitations: One direct incident supports a targeted safeguard and regression eval, not a general frequency claim.
- confidence_default: 5 for the observed incident; 3 for broader prevalence.
