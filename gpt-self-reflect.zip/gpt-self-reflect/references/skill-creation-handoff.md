# Skill Creation Handoff

## Purpose

The reflection phase identifies and qualifies capability candidates. The creator phase builds them. Keep these responsibilities separate.

## Creator routing

### `skill-creator`

Use for a bounded reusable workflow when:

- no regulated or compliance-sensitive claim is central;
- no complex API/MCP/browser/tool integration is required;
- no enterprise source map or formal release gate is required;
- the workflow can be expressed as a compact Skill plus optional deterministic scripts/references.

### `enterprise-skill-creator`

Use when any is true:

- team/firm/production workflow;
- source-backed external claims;
- security, privacy, compliance, or destructive-action risk;
- API, MCP, browser, connector, or external tool dependency;
- formal evals, validators, release gates, or packaging governance;
- complex architecture or multiple persistence components.

## Handoff packet

For every approved Skill candidate provide:

```yaml
skill_build_handoff:
  candidate_id: string
  proposed_name: string
  scope: global | project | task_family
  problem_solved: string
  value_created: string
  trigger_conditions: [string]
  required_behavior: [string]
  forbidden_behavior: [string]
  evidence_pointers: [string]
  recurrence_count: integer
  impact_attribution: OBSERVED_ASSOCIATION | PLAUSIBLE_CONTRIBUTOR | CONTRAST_SUPPORTED | UNVERIFIED
  confidence: 1-5
  expected_inputs: [string]
  expected_outputs: [string]
  verification_steps: [string]
  validation_contract:
    artifact_kind: generated_child_skill | existing_skill_update | parent_meta_skill
    governing_contract_sources: [string]
    applicable_validator_classes: [target | generic | parent]
    parent_specific_exclusions: [string]
  eval_candidates: [string]
  known_boundaries: [string]
  source_needed: [string]
  creator_route: skill-creator | enterprise-skill-creator
```

## Build behavior

If the selected creator is available in the host, route the approved packet to it. If not, emit the packet intact. Never silently substitute a handwritten pseudo-Skill while claiming the creator executed.

## Post-build impact gate

Before calling the new Skill `validated`, first resolve validator applicability using `child-artifact-validation.md`. Do not treat a parent-internal validator failure as a child defect. Then compare:

- baseline without Skill or previous version;
- new Skill on the same representative tasks;
- task success/quality;
- new failures or omissions;
- unnecessary procedural/tool/token overhead when observable.

Decision:

- `PROMOTE`: clear net improvement with no material regression.
- `REVISE`: some value but material issues remain.
- `REJECT`: no net value or harmful regression.
- `UNVERIFIED_IMPACT`: evidence insufficient.
