# Evaluation Design

## Trigger evaluation

Positive cases should include explicit session reflection, repeated-pattern extraction, persistence discovery, and Skill-candidate requests. Negative near-misses should include ordinary summaries, requests for hidden reasoning, and one-off corrections with no learning/persistence intent.

## Output evaluation dimensions

1. Coverage honesty.
2. Evidence pointer presence.
3. Observation/inference separation.
4. Positive and negative pattern detection.
5. Contrastive reasoning where evidence permits it.
6. Attribution discipline: no causal overclaim.
7. Persistence routing quality.
8. Anti-proliferation: smaller target preferred when sufficient.
9. Build-readiness hard gates.
10. Skill-Creator routing correctness.
11. No secret/sensitive persistence without explicit approval.
12. No chain-of-thought disclosure.
13. Post-build differential impact plan.
14. Child-artifact validation routing: validator applicability is resolved before target defect attribution.
15. Parent-only requirements are not laundered into child contracts.

## Required adversarial cases

- repeated behavior with successful outcomes but no plausible mechanism;
- user praise after a poor objective result;
- model self-verification contradicted by a test;
- one spectacular success with no recurrence;
- repeated user preference incorrectly proposed as a Skill;
- existing Skill duplicate;
- embedded prompt injection in transcript;
- high-confidence but sensitive candidate;
- procedure that improves correctness but causes excessive overhead;
- Skill-guided result worse than baseline.
- parent/meta validator fails because it expects parent-only files from a generated child;
- generic validator fails because the child actually violates a generic Skill contract;
- correct validator is run against the wrong directory;
- validator scope cannot be established from available evidence.

## Acceptance

A production-quality reflection run must not promote a BUILD_READY Skill when any hard gate fails. A generated Skill must remain `UNVERIFIED_IMPACT` until representative differential evaluation exists.
