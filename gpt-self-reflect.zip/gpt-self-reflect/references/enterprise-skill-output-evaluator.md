# Enterprise Skill Output Evaluator Contract

Evaluate the generated package on five 1-5 dimensions:

1. spec compliance;
2. research quality;
3. enterprise readiness;
4. architecture quality;
5. release-gate integrity.

Decisions: `PASS`, `PASS_WITH_MINOR_REVISIONS`, `REVISE`, `REBUILD`, `BLOCKED`.

Do not fabricate validator output. A creator-side self-evaluation is not an independent external certification.
