# Evidence and Attribution

## Evidence strength

Score 1-5 using the strongest defensible basis, not an average that hides blockers.

### 5 - strong contrast / direct verification

Examples:
- same task class, behavior changed after correction, outcome measurably improved;
- tool/test/readback directly confirms the claimed effect across repeated cases;
- independent evidence converges on the same mechanism.

### 4 - strong observational evidence

Repeated behavior is tied to repeated successful outcomes and the mechanism is plausible, but no clean matched contrast exists.

### 3 - plausible hypothesis

One strong example or several noisy examples; alternative explanations remain significant.

### 2 - weak

Sparse, contradictory, or highly context-specific evidence.

### 1 - unsupported

Narrative plausibility, model confidence, or post-hoc explanation without reconstructable evidence.

## Attribution labels

- `OBSERVED_ASSOCIATION`: co-occurrence only.
- `PLAUSIBLE_CONTRIBUTOR`: repeated evidence plus plausible mechanism.
- `CONTRAST_SUPPORTED`: matched or before/after contrast materially strengthens contribution inference.
- `UNVERIFIED`: no adequate attribution basis.

Never output `CAUSED_SUCCESS` unless the environment provides genuinely controlled causal evidence; normal chat trajectories rarely do.

## Strong evidence types

Prefer, roughly in this order when relevant:

1. independent deterministic test/tool result;
2. before/after or matched contrast;
3. artifact readback or exact state verification;
4. explicit user correction followed by demonstrably improved execution;
5. repeated successful observations;
6. explicit user acceptance/praise;
7. model self-verification;
8. model retrospective explanation.

The list is contextual, not a universal measurement scale.

## Counterevidence gate

Every BUILD_READY candidate must record at least one of:

- actual counterexample and explanation;
- explicit statement `NO_COUNTEREXAMPLE_FOUND_IN_AVAILABLE_EVIDENCE`;
- `COVERAGE_TOO_PARTIAL_FOR_COUNTEREVIDENCE_SEARCH`.

The last state blocks automatic build readiness.

## Coverage

- `COMPLETE`: the requested transcript/corpus was fully supplied and inspected.
- `PARTIAL`: only part of the relevant session/corpus is available.
- `UNKNOWN`: completeness cannot be determined.

Current chat context must not be described as historically complete unless that is actually established.
