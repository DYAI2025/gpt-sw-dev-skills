# Child-Artifact-Aware Validation

## Purpose

Prevent a parent, meta-skill, builder, or orchestration validator from being treated as authoritative for a generated child artifact unless the validator's requirements actually belong to the child's governing contract.

A validator failure is evidence of a target defect only after validator applicability is established.

## Core distinction

Separate these questions:

1. What artifact is being validated?
2. What contract governs that artifact?
3. Who owns the validator?
4. Where did the validator requirement originate?
5. Does the validator scope include this target artifact?
6. Did the target actually violate its own governing contract?

Do not infer answer 6 merely from a non-zero validator exit code.

## Target artifact kinds

Use one of:

- `generated_child_skill`: a Skill produced by another Skill, builder, or meta-workflow.
- `existing_skill_update`: an update to the same target Skill.
- `parent_meta_skill`: the builder/orchestrator itself.
- `generic_artifact`: a non-Skill or otherwise generic deliverable.

## Contract authority order

Prefer the most target-specific valid contract available:

1. explicit user-approved requirements or Definition of Done for the target artifact;
2. the target artifact's own declared contract, including its `SKILL.md`, package rules, schemas, and target-specific references;
3. the selected creator's documented output contract for that target artifact class;
4. a generic Skill/package specification that is intended to apply to all Skills;
5. parent/meta-skill internal requirements only when they explicitly declare that they also govern generated child artifacts.

If contract authority is unclear, use `SOURCE_NEEDED`. Do not guess.

## Validator classes

Classify validator ownership:

- `target`: shipped with or explicitly written for the target artifact;
- `parent`: shipped with the parent builder, meta-skill, or orchestrator;
- `generic`: designed to apply to the target artifact class generally;
- `external`: supplied by another tool or system.

Classify requirement origin:

- `target_contract`
- `generic_skill_contract`
- `parent_internal_contract`
- `unknown`

## Applicability states

### `APPLICABLE`

Use only when the validator requirement is supported by the target contract or a generic contract that clearly applies to the target kind.

### `NOT_APPLICABLE`

Use when the failing requirement belongs only to the parent/meta-skill, another artifact class, or an explicitly excluded scope.

A failed `NOT_APPLICABLE` validator is not evidence of a target defect.

### `SOURCE_NEEDED`

Use when scope or contract authority cannot be established.

Do not repair the target while applicability is unresolved.

## Failure classification

After applicability resolution classify the failure:

- `skill_defect`: validator is applicable, the target failed, and the target contract is actually violated;
- `validator_scope_mismatch`: validator failed but its requirement does not apply to the target;
- `execution_lapse`: validator invocation, path, arguments, environment, or operator action was wrong;
- `tool_failure`: validator could not run reliably due to tool/runtime failure;
- `missing_context`: required contract or evidence is unavailable;
- `unknown`: evidence is insufficient.

## Repair routing

- `skill_defect` -> repair the target Skill or target-specific artifact.
- `validator_scope_mismatch` -> repair the parent validator, validator router, applicability rule, or meta-workflow; do not add irrelevant files to the child.
- `execution_lapse` -> correct invocation and rerun the unchanged target first.
- `tool_failure` -> repair or replace the tool before changing the target.
- `missing_context` or `unknown` -> gather evidence; do not claim a target defect.

## Hard anti-false-green rule

Never make a child Skill pass a mis-scoped parent validator by fabricating parent-only files, fake capability records, false parity reports, irrelevant browser/MCP artifacts, or other requirements that are not part of the child's real contract.

A green validator result obtained by making the target satisfy an irrelevant contract is a false green.

## Validation routing record

When validator scope is material, emit a record compatible with `schemas/validation-routing-record.schema.json`.

Example:

```json
{
  "target_artifact": {
    "name": "example-child",
    "kind": "generated_child_skill"
  },
  "governing_contract": {
    "sources": ["target SKILL.md", "generic Skill package contract"],
    "contract_confirmed": true
  },
  "validator": {
    "name": "validate_parent_core_parity.py",
    "owner": "parent",
    "declared_scope": ["parent_meta_skill"],
    "requirement_origin": "parent_internal_contract"
  },
  "applicability": "NOT_APPLICABLE",
  "observed_result": "FAIL",
  "target_contract_violated": false,
  "failure_classification": "validator_scope_mismatch",
  "action": "repair_validator_or_router"
}
```

## Minimal decision procedure

1. Read the target contract before changing the target.
2. Read the failing validator or its documented scope when available.
3. Classify validator owner and requirement origin.
4. Decide `APPLICABLE`, `NOT_APPLICABLE`, or `SOURCE_NEEDED`.
5. Only classify `skill_defect` when applicability is `APPLICABLE` and target contract violation is independently established.
6. Rerun the correct validator set after repair.
7. Preserve the routing record as evidence for future reflection and regression tests.

## Regression cases

At minimum test:

1. parent-only core-parity validator fails on a generated child -> `validator_scope_mismatch`;
2. generic frontmatter validator fails on malformed child frontmatter -> `skill_defect`;
3. correct validator invoked against the wrong directory -> `execution_lapse`;
4. validator scope cannot be determined -> `SOURCE_NEEDED`, no target repair;
5. parent validator explicitly declares child coverage and requirement is in the child contract -> `APPLICABLE`.
