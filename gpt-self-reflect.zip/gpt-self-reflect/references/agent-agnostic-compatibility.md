# Agent-Agnostic Compatibility

## Portable core

The reflection method is intentionally expressed using platform-neutral concepts:

- session/transcript evidence;
- episodes/trajectories;
- observable outcomes;
- heuristic extraction;
- evidence pointers;
- persistence routing;
- Skill build handoff;
- differential impact validation.

These can be used by ChatGPT, Claude/Claude Code, Codex-like agents, Cursor, Windsurf, or another frontier-model host when equivalent context and persistence features exist.

## Runtime-specific assumptions

Not guaranteed across runtimes:

- complete chat-history access;
- session-end hooks;
- memory writes;
- project-instruction writes;
- installed-Skill enumeration;
- nested Skill invocation;
- filesystem or shell access;
- identical Skill metadata or UI installation flow.

## Claude reference

The community `claude-reflect` project is a useful design reference for session-pattern discovery but relies on Claude Code-specific mechanisms that this package does not assume.

## ChatGPT reference

OpenAI documentation supports reusable Skills and `skill-creator`-assisted Skill creation, but this package still routes by capability availability rather than assuming every client exposes the same runtime surface.
