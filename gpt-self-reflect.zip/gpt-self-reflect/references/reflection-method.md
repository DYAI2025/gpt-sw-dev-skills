# Reflection Method

## Method stack

The method deliberately combines complementary ideas rather than copying one research system.

### 1. Evidence-grounded reflection

Adapted from Reflexion: use feedback and outcomes to formulate reusable verbal lessons, but do not treat self-critique as authoritative.

### 2. Experience aggregation

Adapted from ExpeL: aggregate multiple experiences before promoting a reusable insight. A recurring pattern across episodes is stronger than a single persuasive anecdote.

### 3. Trajectory-to-heuristic abstraction

Adapted from ERL: reflect on trajectories and outcomes to generate actionable heuristics. Prefer selective, relevant heuristics over replaying all prior trajectories.

### 4. Commit only after verification

Adapted from Voyager: separate candidate generation from library commitment. Feedback, execution errors, and explicit verification should affect promotion.

### 5. Harness over pure self-critique

Informed by ReFlect: use deterministic structure, evidence requirements, explicit failure classes, and fixed recovery/promotion gates around the language model's reflective judgment.

### 6. Preserve raw evidence

Informed by experience-faithfulness research: condensed lessons can be ignored or distorted. Every heuristic retains evidence pointers so later review can reconstruct its basis.

### 7. Differential Skill validation

Informed by recent Skill-failure research: compare the new Skill with a baseline and check both functional correctness and unnecessary procedure/overhead before declaring impact.

## Episode segmentation

Create an episode when one of these changes materially:

- user goal;
- requested artifact;
- tool or environment state;
- strategy after a correction;
- explicit success/failure checkpoint.

An episode record should include:

```yaml
id: EP-001
goal: string
conditions: [string]
actions: [string]
feedback: [string]
result: string
outcome: success | partial | failure | mixed | unknown
evidence_pointers: [string]
```

## Pattern mining

Cluster by semantic function, not exact phrasing. Examples:

- `read-before-write verification`
- `primary-source verification before architectural commitment`
- `small deterministic validator before LLM judgment`
- `user correction captured before continuing`
- `overlong validation procedure that added no outcome value`

Do not claim semantic equivalence when the boundary conditions differ materially.

## Contrastive template

For a candidate pattern, ask:

1. Where did it appear?
2. What happened when it appeared?
3. Is there a comparable episode where it did not appear?
4. Did the outcome differ?
5. What alternative explanations remain?
6. What is the smallest transferable rule consistent with the evidence?

## Heuristic template

```yaml
heuristic:
  when: string
  do: string
  value: string
  verify: string
  avoid: string
  boundary_conditions: [string]
  evidence_pointers: [string]
```

## Failure classification

Classify failures before proposing a Skill update:

- `skill_defect`
- `validator_scope_mismatch`
- `execution_lapse`
- `missing_context`
- `tool_failure`
- `incorrect_external_assumption`
- `user_goal_change`
- `excessive_procedure`
- `unknown`

Only `skill_defect` directly supports modifying the validated target. `validator_scope_mismatch` supports changing the validator, validator router, or parent/meta-skill rather than the child target. Other classes may suggest evals, context changes, tool fixes, or no persistence. When validator scope is disputed, read `child-artifact-validation.md` before attributing a target defect.
