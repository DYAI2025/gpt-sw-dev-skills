# Persistence Routing

## Decision table

| Finding | Preferred target | Use when | Do not use when |
|---|---|---|---|
| Repeatable multi-step behavior | `skill` | Transferable workflow with triggers, verification, and repeated value | A smaller rule or script is sufficient |
| Existing Skill needs evidence-backed change | `skill_update` | Failure class is `skill_defect` or repeated better method is established | One execution lapse caused the failure |
| Stable personal preference/fact | `memory` | Useful across future chats and appropriate for memory | Project-only, sensitive, transient, or user did not approve |
| Project-local operating rule | `project_instruction` | Should shape work inside one project | It is global or merely reference knowledge |
| Stable background knowledge | `reference` | Needed for lookup but not behavior orchestration | Dynamic/current fact requires live source verification |
| Deterministic transformation | `script` | Same logic is repeatedly re-generated and can be tested | Judgment-heavy or tool-unavailable |
| Deterministic quality gate | `validator` | Pass/fail rule can be checked mechanically | Rule depends on subjective unsupported judgment |
| Recurrent failure/success test | `eval` | Future regression can be reproduced | No stable expected behavior exists |
| Validator scope mismatch | `skill_update` or `validator` on the validator owner | Parent/meta validation rules were applied outside the target contract | The child target actually violates an applicable contract |
| Missing technical function | `capability_candidate` | Need may require API/MCP/tool/embedding/tracing/etc. | Existing native capability already covers it |
| One-off/transient/unsafe/noisy | `no_persist` | Persistence would add noise or risk | A stable recurring value exists |

## Scope routing

- `global`: broadly applicable across unrelated work.
- `project`: belongs to a specific project, repository, client, or domain.
- `task_family`: reusable for a bounded class of tasks.
- `user_specific`: personal preference or context; usually memory/instruction rather than Skill.

## Anti-proliferation test

Before creating a Skill ask:

1. Is this truly behavioral rather than informational?
2. Does it recur?
3. Does it generalize?
4. Is it testable?
5. Is there already an equivalent Skill?
6. Could a one-line project rule solve it?
7. Could a deterministic script/validator solve it better?
8. What is the cost of loading this Skill when relevant?

If a smaller target covers the value, choose it.

For `validator_scope_mismatch`, persist the correction where the invalid applicability rule lives. Do not change the child Skill merely to satisfy a parent-internal validator.
