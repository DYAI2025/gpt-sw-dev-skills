# Research Bag

## Build recommendation

`PROCEED_WITH_ASSUMPTIONS`

V1 should analyze evidence available in the current conversation or an explicitly supplied transcript/corpus. It must not promise exhaustive historical ChatGPT access or a deterministic session-end hook.

## Knowledge model

Core operational concepts:

- `trajectory`: goal, conditions, observable actions, feedback, result, outcome, evidence pointer.
- `pattern`: recurrence across relevant trajectories.
- `heuristic`: conditional reusable action with value, verification, and boundary conditions.
- `persistence target`: the smallest durable representation of a finding.
- `impact attribution`: disciplined label describing how strongly evidence links behavior to outcome.
- `build gate`: non-compensatory requirements before a Skill candidate is eligible for creation.
- `impact validation`: post-build differential test to determine whether a Skill improves or degrades behavior.

## Adopted methodological capabilities

1. Evidence-bound trajectory reconstruction.
2. Positive and negative pattern mining.
3. Contrastive reflection before generalization.
4. Heuristic extraction with trigger/action/value/verify/avoid fields.
5. Raw evidence retention for every condensed heuristic.
6. Persistence routing rather than Skill proliferation.
7. Non-compensatory promotion gates.
8. User review before persistence by default.
9. Skill-Creator routing by complexity/risk.
10. Differential validation of newly built Skills.

## Deferred capabilities

- automatic enumeration of all historical ChatGPT sessions;
- guaranteed session-end hooks;
- vector database or embedding dependency;
- external evaluation framework dependency;
- agent tracing dependency;
- Canon Resolver runtime/MCP dependency.

These may become V2 capabilities only after a concrete requirement and primary-source/runtime verification.
