# Source Policy

## Purpose

Reflection must distinguish observed evidence from model-generated interpretation. The analyzed session is not automatically canonical truth; it is a record of what was said and what tools reported.

## Source classes

- `primary`: official documentation, original research paper, original repository, direct tool/test output, or source system record.
- `secondary`: reputable explanation used for context only.
- `user_provided`: user messages, files, transcripts, internal policies, claims, or corrections supplied by the user.
- `derived`: model summaries, inferred heuristics, semantic clusters, scores, retrospectives, and generated candidate descriptions.
- `uncertain`: unattributed, contradictory, incomplete, or unverifiable material.

## Session evidence classes

- `direct_observation`: visible message, tool result, test result, readback, or artifact state.
- `user_feedback`: explicit correction, acceptance, rejection, or preference from the user.
- `external_verified`: claim checked against a primary source.
- `derived_inference`: model interpretation of observations.
- `unknown`: evidence basis cannot be reconstructed.

## Confidence scale

- `5`: directly supported by strong primary evidence plus consistent outcome/contrast where relevant.
- `4`: strong observable evidence with limited uncertainty.
- `3`: plausible but indirect, incomplete, or only single-context evidence.
- `2`: weak, conflicting, or strongly context-dependent.
- `1`: unsupported or contradicted.

Only confidence 4-5 can support `BUILD_READY`. Confidence 3 can support an experiment. Confidence 1-2 must not become hard persistence rules.

## MISSING and SOURCE_NEEDED

Use `MISSING` when required information is absent. Use `SOURCE_NEEDED` when a claim exists but requires stronger evidence. Never fill either state by guessing.

## Claim discipline

Every substantive reflection output should be classifiable as:

- `fact/observation`
- `inference`
- `recommendation`
- `decision`

A fluent explanation does not increase evidence strength.
