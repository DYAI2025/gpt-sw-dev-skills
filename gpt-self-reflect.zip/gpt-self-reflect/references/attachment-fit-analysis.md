# Attachment Fit Analysis

## dyai-llm-technology-radar.zip

### Highly useful methods - adopted

1. **Discovery is not adoption.** Candidate technologies remain unverified until primary-source/runtime evidence exists.
2. **Evidence-status separation.** `provided`, `source_inspected`, `runtime_verified`, `derived`, and `unverified` is adapted into reflection evidence classes.
3. **Non-compensatory gates.** Critical evidence/security/canonicality failures cannot be averaged away by a high total score.
4. **Anti-tool-hopping.** Prefer native behavior and deterministic scripts before frameworks or services.
5. **Project value before novelty.** A candidate must solve a real repeated constraint.
6. **LLM-as-judge is evidence, not truth.** Adopted directly as a reflection rule.

### Technology candidates - not embedded in V1

- `AgentEvals`: potentially useful for later automated agent-regression suites; package marks it `AUDIT_REQUIRED`.
- `StructEval`: potentially useful for schema/output regression; unnecessary because V1 can validate its own JSON deterministically.
- `DeepEval`: potentially useful for future evaluation experiments; LLM-as-judge dependence needs audit and is not required for core reflection.
- `agenttrace` / `traceAI` / `Phoenix`: useful only when host-level tracing is available and a concrete telemetry requirement exists.
- `RAGChecker`, `Rerankers`, `Model2Vec`, `Sentence-Transformers`: potentially useful for a large multi-session corpus and retrieval, but over-engineering for current-session V1.
- `FastGraphRAG`: potentially relevant only for a future longitudinal experience graph; not justified for V1.

Decision: `DEFER_EXTERNAL_DEPENDENCIES`. The attachment itself says these candidate claims are discovery-level and not production evidence.

## canon-resolver.zip

### Highly useful methods - adopted as patterns

1. **Authority and semantic judgment are separate.** A source can be authorized without proving an inferred conclusion.
2. **Canonical/reference/derived separation.** Adapted so direct observations and verified sources outrank model-derived summaries.
3. **Provenance retention.** Every promoted heuristic keeps source/session evidence pointers.
4. **Semantic retrieval is navigation, not truth.** Similarity can locate candidates but cannot raise evidence authority.
5. **Fail-closed on missing critical evidence.** Missing coverage or unsupported external claims block hard persistence.
6. **Typed dependencies are useful.** Candidates link to episodes, evidence, outcomes, and downstream persistence targets.

### Not adopted as runtime dependencies

- SQLite/FTS5 store;
- Canon Resolver MCP service;
- live provider adapters;
- snapshot ingestion infrastructure.

Reason: they add operational surface without being required for V1. A future cross-session corpus mode may integrate a canonical/provenance service after explicit need and runtime verification.

## Overall decision

The attachments are most valuable as **governance and evidence architecture**, not as a reason to add frameworks. Their strongest contribution is preventing self-reflection from becoming source laundering or tool proliferation.
