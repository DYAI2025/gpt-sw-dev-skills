# Semantic Brain Graph baseline example

This reference captures a baseline pattern for Semantic Brain Graph UI/frontend gap analysis. Use it as a feature vocabulary and example, not as evergreen truth. Re-score from current repository evidence whenever possible.

## Baseline checks from user-provided report

| Check | Result | Interpretation |
|---|---|---|
| npm ci | passed | Dependency installation baseline is good. |
| npm run lint:architecture | passed, but checker is too weak | Architecture lint has false-negative risk. |
| npm run typecheck | passed | TypeScript baseline is good. |
| npm run build | passed, with Vite chunk warning | Build baseline is good; chunking may need follow-up. |
| npm test | passed: 8 testfiles, 71 tests | Unit/integration baseline is good. |
| npm run import:fixture | passed: 4 nodes, 5 edges | Fixture import path works at small scale. |
| npm run test:e2e | failed: Electron binary download or fetch failed | UI/runtime truth remains partially unverified. |

Key interpretation: unit/build baseline is good. UI/frontend truth is not sufficiently proven while E2E/runtime proof is missing.

## Example feature scores from the provided baseline

| Feature | Score | Evidence class | Main gap |
|---|---:|---|---|
| Schema v0.2 / Types | 90 | local-verified | Needs broader runtime proof for full confidence. |
| Migration + G-Brain integration | 85 | local-verified | Needs runtime and larger fixture verification. |
| Bridge Candidate generation | 85 | local-verified | Candidates may not become graph-visible edges. |
| WhyThisEdgePanel | 70 | source-inspected | Explanation UI path needs runtime proof. |
| BridgeReviewInbox | 65 | source-inspected | Review flow exists but show-in-graph path is incomplete. |
| Bridge Edge Visibility | 60 | source-inspected | GraphCanvas renders projectData.edges, not candidate-only edges. |
| GitHub CI/CD Gates | 60 | local-verified | Architecture lint may miss renderer/main boundary violations. |
| Vector/Legend Visualization | 55 | source-inspected | v2 semantic axes and actual layout semantics may diverge. |
| Frontend UI Tests | 35 | reported-only | UI assertions are too weak or incomplete. |
| Electron/E2E Smoke | 25 | reported-only | Electron download/fetch failure blocks proof. |

## Known critical gaps to verify

### P0 - Bridge candidates are not reliably graphically visible

Claim to verify: BridgeReviewInbox generates bridge candidates and updates `bridge_candidates`, while GraphCanvas renders only `projectData.edges`.

Consequence: candidates may exist as cards but not as clickable visual graph edges. This breaks the core visual bridge explorer promise.

### P0 - GraphCanvas may use legacy axes for layout

Claim to verify: UI explains v2 axes such as `purpose`, `domain`, `capability`, `architecture`, `interface`, `agent_context`, and `extension`, while graphical positioning still uses fields such as `shared_concepts`, `connectedness`, or `evidence_strength`.

Consequence: the visualization may communicate semantics different from what the UI claims.

### P0 - BridgeReviewInbox lacks a clean show-in-graph flow

Claim to verify: bridge cards can be reviewed but cannot directly focus or jump to a visual edge because `selectEdge` is not passed through the needed component path.

Consequence: users see bridge cards, but the path to visual explanation is broken.

### P0 - Architecture lint is false-negative

Claim to verify: renderer code imports from main/parser boundaries while `npm run lint:architecture` still passes.

Consequence: renderer/main boundaries are not sufficiently protected.

### P1 - E2E is not a strong CI proof

Claim to verify: `npm run test:e2e` fails due to Electron binary download or fetch failure, and the script may log some UI deviations without failing hard.

Consequence: UI readiness is overstated unless E2E setup and assertions are hardened.
