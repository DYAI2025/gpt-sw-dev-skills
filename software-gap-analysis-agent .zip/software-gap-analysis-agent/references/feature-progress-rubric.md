# Feature progress rubric

Use this rubric to produce exact, evidence-bound feature progress scores from 0 to 100. Exact means exact relative to this rubric, not exact as a production telemetry measurement.

## Score bands

| Score | Meaning |
|---:|---|
| 0 | Feature absent. No code, no docs, no credible evidence. |
| 10 | Feature named or planned only. |
| 25 | Data model, type, schema, or placeholder exists, but no useful flow. |
| 40 | Partial implementation exists, but integration is incomplete or fragile. |
| 55 | Integrated in at least one internal path with local checks or focused tests. |
| 70 | Source-inspected implementation supports the intended behavior, but runtime/UI proof is missing or partial. |
| 85 | Local baseline checks pass and implementation is mostly aligned, but target architecture is not fully runtime-proven. |
| 100 | Target architecture behavior is implemented, integrated, and proven by appropriate runtime/E2E or equivalent acceptance evidence. |

Intermediate values may be used only when evidence supports a specific position between bands. Prefer multiples of 5 unless the user provides a more precise scoring formula.

## Evidence caps

Apply caps after assigning the preliminary score.

| Evidence condition | Maximum score |
|---|---:|
| No direct evidence | 15 |
| Reported-only evidence | 35 |
| Source-inspected only | 70 |
| Local build/type/unit proof, no runtime proof | 85 |
| Known user-visible break in the core path | 70 |
| E2E unavailable or failed for UI feature | 85 |
| Architecture boundary violation not caught by lint | 60 for the architecture-gate feature |
| Target architecture uses different semantics than implementation | 70 for the affected visualization feature |

## Feature table fields

For every feature, record:

- `feature`: short name shown in the chart.
- `score`: integer 0-100 after caps.
- `evidence_class`: one of `runtime-verified`, `local-verified`, `source-inspected`, `reported-only`, `unverified`.
- `target_state`: what the target architecture requires.
- `current_state`: what evidence shows now.
- `main_gap`: most important remaining gap.
- `cap_reason`: why the score cannot go higher, if capped.

## Chart rules

Every chart must:

- use horizontal bars;
- show every feature in the inventory;
- use a 0-100 percent x-axis;
- include ticks at 0, 25, 50, 75, 100;
- display exact score labels;
- include a title and evidence subtitle;
- sort descending by score unless architecture order is explicitly requested;
- preserve the matching data table next to the visual.

## Bias checks

Watch for these recurring distortions:

- Build-pass bias: assuming build success proves user-visible behavior.
- Unit-test overconfidence: assuming component tests prove integrated UI flow.
- Screenshot anchoring: copying old chart values without recomputing from current evidence.
- Source-inspection optimism: believing plausible code paths are actually reachable.
- Architecture-label drift: UI labels describe v2 semantics while layout or graph behavior still uses legacy fields.
