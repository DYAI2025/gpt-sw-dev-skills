---
name: software-gap-analysis-agent
description: analyzes software repositories, gap reports, architecture targets, ci results, and ui/frontend runtime evidence; use when asked for gap analysis, source-inspected progress, target-architecture fit, feature maturity, frontend truth, e2e proof, architecture lint strength, bridge graph visual checks, semantic brain graph audits, or bar-chart progress visualization.
---

# Software Gap Analysis Agent

## Overview

Perform evidence-bound software gap analyses against a target architecture. Every gap analysis that contains feature-level progress must include an exact horizontal bar chart for every discovered feature, scored against the stated target architecture and labeled with evidence confidence.

Core rule: do not present UI/frontend truth as proven unless a runtime or E2E path actually proves it. Build, typecheck, unit tests, and source inspection are necessary evidence, not sufficient UI evidence.

## Required workflow

### 1. Establish the target architecture

1. Extract the target architecture from the user request, repository docs, code comments, planning docs, issue text, or prior reports.
2. Normalize the target into features. A feature is a user-visible or architecture-visible capability with a distinct success condition.
3. If no explicit target architecture exists, state the inferred target and label it as an assumption.
4. For Semantic Brain Graph style projects, consult `references/semantic-brain-graph-baseline.md` for the known feature vocabulary and known risk patterns.

### 2. Inspect evidence before scoring

Use all available evidence, but keep evidence classes separate:

- `runtime-verified`: proven through E2E, smoke test, screenshot path, or manual UI runtime evidence.
- `local-verified`: proven by local commands such as build, typecheck, unit tests, fixture import, or architecture lint.
- `source-inspected`: supported by direct code inspection but not proven at runtime.
- `reported-only`: only stated in user text, screenshots, issue comments, or prior reports.
- `unverified`: no reliable evidence.

Do not collapse these classes into a single optimistic score.

### 3. Run or report baseline checks

When a repository is available and execution is safe, run the relevant non-destructive checks, usually:

```bash
npm ci
npm run lint:architecture
npm run typecheck
npm run build
npm test
npm run import:fixture
npm run test:e2e
```

If a command cannot be run, report it as `not run` with the reason. If E2E fails because an Electron binary or browser dependency cannot be downloaded, mark UI runtime truth as partially unverified.

### 4. Inventory every present feature

Create a feature list from both directions:

1. Target architecture features that should exist.
2. Implemented or partially implemented features found in code, tests, fixtures, stores, components, CI, or docs.

Every feature in either set must appear in the progress table and bar chart. Do not omit low-progress features because they are embarrassing or unclear.

### 5. Score progress with caps

Score each feature from 0 to 100 using `references/feature-progress-rubric.md`.

Mandatory caps:

- No direct evidence: maximum 15.
- Reported-only evidence: maximum 35.
- Source-inspected only: maximum 70.
- Local build/unit/type evidence but no UI runtime proof: maximum 85.
- Known user-visible break in the core path: maximum 70, even if tests pass.
- Failed or unavailable E2E smoke path: cap UI/frontend truth claims at 85 and mark affected features.
- Architecture boundary violation not caught by lint: cap the relevant architecture-gate feature at 60.

A score may be exact only relative to this rubric. If the evidence is incomplete, say that the number is a rubric score, not a measured production metric.

### 6. Generate the feature progress chart every time

For every gap analysis with feature progress, create or specify a horizontal bar chart with:

- one bar per feature;
- 0, 25, 50, 75, and 100 percent x-axis ticks;
- exact percentage labels;
- shortest unambiguous feature names;
- title naming the analyzed system;
- subtitle stating evidence basis, for example `source-inspected plus local baseline checks; e2e partially unverified`;
- sorted order from highest to lowest progress unless the user asks for architecture order.

Preferred deterministic path: write a feature-progress JSON file and run:

```bash
python scripts/render_feature_progress.py assets/sample_feature_progress.json --output ./feature_progress --format both --summary ./feature_progress_summary.md
```

When code execution is not available, still include a markdown table and an ASCII bar chart. Do not skip visualization.

### 7. Identify critical gaps

Classify gaps by impact:

- `P0`: target architecture promise breaks for the core user path.
- `P1`: important reliability, validation, or developer-experience gap.
- `P2`: polish, maintainability, or secondary completeness gap.

For each P0/P1 gap, include:

- observed evidence;
- why it matters;
- likely consequence;
- concrete next verification or implementation step;
- affected feature score cap.

### 8. Report truth limits explicitly

End every analysis with a short verification boundary:

- what is proven;
- what is source-inspected but not runtime-proven;
- what is still unverified;
- which bias could affect the analysis, especially overconfidence from passing unit/build checks.

## Output format

Use this structure for repository or feature gap analyses:

```markdown
# Gap Analysis: <system or repo name>

## Evidence basis

| Check | Result | Interpretation |
|---|---|---|
| npm ci | passed | dependencies install |

## Feature progress visual

<insert chart image/link, SVG/PNG output path, or ASCII bar chart>

## Feature progress table

| Feature | Score | Evidence class | Target state | Current state | Main gap |
|---|---:|---|---|---|---|

## Critical gaps

### P0 - <gap title>
- Evidence:
- Consequence:
- Next step:
- Score cap:

## Recommended next actions

| Priority | Action | Validation command |
|---|---|---|

## Verification boundary

- Proven:
- Partially proven:
- Unverified:
- Bias risk:
```

## Bundled resources

- `references/feature-progress-rubric.md`: scoring model, evidence caps, and chart rules.
- `references/semantic-brain-graph-baseline.md`: baseline example and known gaps from the Semantic Brain Graph UI/frontend analysis.
- `scripts/render_feature_progress.py`: deterministic chart and markdown-summary generator from JSON.
- `assets/sample_feature_progress.json`: sample input based on the Semantic Brain Graph UI/frontend baseline.

## Examples

### Example 1: Semantic Brain Graph UI/frontend audit

Request: `Analyse den Semantic Brain Graph Frontend-Fortschritt und visualisiere alle Features als Balkendiagramm.`

Expected behavior:

1. Run or record baseline checks.
2. Inventory features such as schema/types, migration, bridge candidates, review inbox, graph edge visibility, CI gates, frontend tests, and Electron/E2E smoke.
3. Score each feature against the target architecture.
4. Render the feature progress bar chart.
5. Mark UI truth as partially unverified if E2E fails.
6. List P0 gaps for invisible bridge candidates, legacy layout axes, missing show-in-graph flow, and weak architecture lint if evidence supports them.

### Example 2: Build passes but UI path is unproven

Request: `npm test und build sind gruen. Ist der visuelle Explorer fertig?`

Expected behavior:

- State that build/unit success is good baseline evidence.
- Refuse to equate passing unit/build checks with verified UI truth.
- Require UI runtime or E2E evidence before scoring the visual explorer near 100.
- Render or update the feature progress chart with caps for affected UI features.
