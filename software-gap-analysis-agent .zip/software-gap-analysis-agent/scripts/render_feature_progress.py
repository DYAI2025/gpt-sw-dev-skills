#!/usr/bin/env python3
"""Render an exact feature-progress bar chart from JSON.

Input schema:
{
  "title": "System progress title",
  "subtitle": "evidence basis",
  "features": [
    {
      "feature": "Short feature name",
      "score": 85,
      "evidence_class": "local-verified",
      "target_state": "...",
      "current_state": "...",
      "main_gap": "...",
      "cap_reason": "..."
    }
  ],
  "checks": [{"name": "npm test", "result": "passed", "interpretation": "..."}],
  "critical_gaps": [{"priority": "P0", "title": "...", "consequence": "...", "next_step": "..."}]
}

The score is treated as exact relative to the supplied rubric. The script validates
that every score is an integer between 0 and 100 and renders one bar per feature.
"""

from __future__ import annotations

import argparse
import json
import pathlib
import sys
import textwrap
from typing import Any

VALID_EVIDENCE_CLASSES = {
    "runtime-verified",
    "local-verified",
    "source-inspected",
    "reported-only",
    "unverified",
}


def load_payload(path: pathlib.Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"Invalid JSON in {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise SystemExit("Input JSON must be an object.")
    return payload


def validate_features(payload: dict[str, Any]) -> list[dict[str, Any]]:
    raw = payload.get("features")
    if not isinstance(raw, list) or not raw:
        raise SystemExit("Input JSON must contain a non-empty 'features' list.")

    seen: set[str] = set()
    features: list[dict[str, Any]] = []
    for index, item in enumerate(raw, start=1):
        if not isinstance(item, dict):
            raise SystemExit(f"Feature #{index} must be an object.")
        name = str(item.get("feature", "")).strip()
        if not name:
            raise SystemExit(f"Feature #{index} is missing 'feature'.")
        if name in seen:
            raise SystemExit(f"Duplicate feature name: {name}")
        seen.add(name)

        score = item.get("score")
        if not isinstance(score, int) or score < 0 or score > 100:
            raise SystemExit(f"Feature '{name}' has invalid score: {score!r}")

        evidence = str(item.get("evidence_class", "unverified")).strip()
        if evidence not in VALID_EVIDENCE_CLASSES:
            raise SystemExit(
                f"Feature '{name}' has invalid evidence_class '{evidence}'. "
                f"Allowed: {', '.join(sorted(VALID_EVIDENCE_CLASSES))}"
            )

        clean = dict(item)
        clean["feature"] = name
        clean["score"] = score
        clean["evidence_class"] = evidence
        features.append(clean)
    return features


def wrap_label(label: str, width: int = 28) -> str:
    return "\n".join(textwrap.wrap(label, width=width, break_long_words=False)) or label


def render_chart(
    features: list[dict[str, Any]],
    title: str,
    subtitle: str,
    output_base: pathlib.Path,
    output_format: str,
) -> list[pathlib.Path]:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception as exc:  # noqa: BLE001
        raise SystemExit(
            "matplotlib is required to render charts. Install it with: pip install matplotlib"
        ) from exc

    ordered = sorted(features, key=lambda row: row["score"], reverse=True)
    names = [wrap_label(str(row["feature"])) for row in ordered]
    scores = [int(row["score"]) for row in ordered]
    evidence = [str(row.get("evidence_class", "unverified")) for row in ordered]

    height = max(4.5, 0.52 * len(ordered) + 1.8)
    fig, ax = plt.subplots(figsize=(11, height))
    fig.patch.set_facecolor("#050505")
    ax.set_facecolor("#050505")

    bars = ax.barh(names, scores, color="#24579a", edgecolor="#24579a")
    ax.invert_yaxis()
    ax.set_xlim(0, 100)
    ax.set_xticks([0, 25, 50, 75, 100])
    ax.set_xticklabels(["0%", "25%", "50%", "75%", "100%"], color="#d0d0d0")
    ax.tick_params(axis="y", colors="#d0d0d0", labelsize=10)
    ax.grid(axis="x", linestyle="--", alpha=0.25, color="#888888")
    for spine in ax.spines.values():
        spine.set_visible(False)

    ax.set_title(title, loc="left", color="#eeeeee", fontsize=16, pad=26, weight="bold")
    if subtitle:
        ax.text(
            0,
            1.035,
            subtitle,
            transform=ax.transAxes,
            color="#bdbdbd",
            fontsize=11,
            va="bottom",
        )

    for bar, score, ev in zip(bars, scores, evidence):
        x = min(score + 1.2, 96)
        ax.text(
            x,
            bar.get_y() + bar.get_height() / 2,
            f"{score}%  {ev}",
            va="center",
            ha="left" if score < 94 else "right",
            color="#eeeeee",
            fontsize=9,
        )

    fig.tight_layout()

    written: list[pathlib.Path] = []
    formats = ["svg", "png"] if output_format == "both" else [output_format]
    for fmt in formats:
        out = output_base.with_suffix(f".{fmt}")
        fig.savefig(out, facecolor=fig.get_facecolor(), bbox_inches="tight", dpi=160)
        written.append(out)
    plt.close(fig)
    return written


def markdown_summary(payload: dict[str, Any], features: list[dict[str, Any]], chart_paths: list[pathlib.Path]) -> str:
    lines: list[str] = []
    title = str(payload.get("title", "Feature Progress"))
    subtitle = str(payload.get("subtitle", ""))
    lines.append(f"# {title}")
    if subtitle:
        lines.append("")
        lines.append(subtitle)
    lines.append("")

    if chart_paths:
        lines.append("## Generated chart files")
        lines.append("")
        for path in chart_paths:
            lines.append(f"- `{path}`")
        lines.append("")

    checks = payload.get("checks", [])
    if isinstance(checks, list) and checks:
        lines.append("## Evidence checks")
        lines.append("")
        lines.append("| Check | Result | Interpretation |")
        lines.append("|---|---|---|")
        for check in checks:
            if not isinstance(check, dict):
                continue
            lines.append(
                "| {name} | {result} | {interpretation} |".format(
                    name=str(check.get("name", "")).replace("|", "\\|"),
                    result=str(check.get("result", "")).replace("|", "\\|"),
                    interpretation=str(check.get("interpretation", "")).replace("|", "\\|"),
                )
            )
        lines.append("")

    ordered = sorted(features, key=lambda row: row["score"], reverse=True)
    lines.append("## Feature progress table")
    lines.append("")
    lines.append("| Feature | Score | Evidence | Target state | Current state | Main gap | Cap reason |")
    lines.append("|---|---:|---|---|---|---|---|")
    for row in ordered:
        lines.append(
            "| {feature} | {score}% | {evidence} | {target} | {current} | {gap} | {cap} |".format(
                feature=str(row.get("feature", "")).replace("|", "\\|"),
                score=row.get("score", 0),
                evidence=str(row.get("evidence_class", "")).replace("|", "\\|"),
                target=str(row.get("target_state", "")).replace("|", "\\|"),
                current=str(row.get("current_state", "")).replace("|", "\\|"),
                gap=str(row.get("main_gap", "")).replace("|", "\\|"),
                cap=str(row.get("cap_reason", "")).replace("|", "\\|"),
            )
        )
    lines.append("")

    gaps = payload.get("critical_gaps", [])
    if isinstance(gaps, list) and gaps:
        lines.append("## Critical gaps")
        lines.append("")
        for gap in gaps:
            if not isinstance(gap, dict):
                continue
            lines.append(f"### {gap.get('priority', 'P?')} - {gap.get('title', '')}")
            lines.append(f"- Consequence: {gap.get('consequence', '')}")
            lines.append(f"- Next step: {gap.get('next_step', '')}")
            lines.append("")

    lines.append("## Verification boundary")
    lines.append("")
    lines.append("Scores are rubric scores based on supplied evidence, not production telemetry.")
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Render feature progress bar chart from JSON.")
    parser.add_argument("input_json", type=pathlib.Path, help="Path to feature-progress JSON.")
    parser.add_argument("--output", type=pathlib.Path, default=pathlib.Path("feature_progress"), help="Output path without extension.")
    parser.add_argument("--format", choices=["svg", "png", "both"], default="svg", help="Chart output format.")
    parser.add_argument("--summary", type=pathlib.Path, help="Optional markdown summary output path.")
    args = parser.parse_args()

    payload = load_payload(args.input_json)
    features = validate_features(payload)
    title = str(payload.get("title", "Feature Progress"))
    subtitle = str(payload.get("subtitle", ""))

    args.output.parent.mkdir(parents=True, exist_ok=True)
    written = render_chart(features, title, subtitle, args.output, args.format)

    if args.summary:
        args.summary.parent.mkdir(parents=True, exist_ok=True)
        args.summary.write_text(markdown_summary(payload, features, written), encoding="utf-8")

    for path in written:
        print(path)
    if args.summary:
        print(args.summary)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
