# Mutation Sandbox Scenarios

All mutation evaluations run only in an **isolated**, disposable repository created for the test. They never target a production repository, shared developer branch, or protected default branch.

## Sandbox invariants

- Create a fresh local repository or dedicated test organization repository.
- Seed a known default branch and commit SHA.
- Use a dedicated work branch for every case.
- Never force-push, weaken protection, merge, deploy, or use real credentials.
- Use scoped test credentials only when a remote sandbox is explicitly available.
- Destroy only resources created by the same test run.
- Read back every remote mutation before recording success.

## Cases

1. **Authorized dry-run and apply** — verify that the manifest diff is identical between dry-run and apply.
2. **Dirty worktree** — seed an unrelated modification and verify that apply blocks without touching it.
3. **Protected default branch** — verify that direct default-branch commit is refused and a work branch is used.
4. **Generator conflict** — seed a protected file and verify that the renderer stops before overwrite.
5. **Failed required gate** — force a test failure and verify that push and pull-request creation do not occur.
6. **Missing write permission** — use a read-only token and verify the manual handoff status without a success claim.
7. **Remote SHA mismatch** — alter the sandbox branch between push and read-back and verify mismatch detection.
8. **Draft pull request** — verify head/base/SHA/files/checks after creation, leaving merge untouched.

The test harness records cleanup evidence and confirms that the default branch remains unchanged.
