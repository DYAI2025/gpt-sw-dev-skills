# Reference Adapter Commands

All commands are argv arrays and run with `shell=False`.

```text
Render:    python3 scripts/render_reference_adapter.py adapters/reference-adapter OUTPUT_DIRECTORY --project-name reference_fixture
Compile:   python3 -m compileall -q src tests
Test:      python3 -m unittest discover -s tests -p test_*.py
Self-test: python3 -m src.app --self-test
Serve:     python3 -m src.app --serve --host 127.0.0.1 --port PORT
```

The `PORT` and `OUTPUT_DIRECTORY` tokens are resolved by the caller. The server is only for local smoke validation.
