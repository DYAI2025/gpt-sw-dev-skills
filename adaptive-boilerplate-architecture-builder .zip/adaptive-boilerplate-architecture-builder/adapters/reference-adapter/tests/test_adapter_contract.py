from __future__ import annotations

import pathlib
import unittest

import yaml


class AdapterContractTests(unittest.TestCase):
    def setUp(self) -> None:
        self.adapter_dir = pathlib.Path(__file__).resolve().parents[1]
        self.data = yaml.safe_load((self.adapter_dir / "adapter.yaml").read_text(encoding="utf-8"))

    def test_reference_adapter_cannot_be_selected(self) -> None:
        self.assertEqual(self.data["selection_status"], "reference_only")

    def test_expected_templates_exist(self) -> None:
        for name in [
            "pyproject.toml.tmpl",
            "README.md.tmpl",
            "src___init__.py.tmpl",
            "src_app.py.tmpl",
            "tests_test_app.py.tmpl",
            "gitignore.tmpl",
        ]:
            self.assertTrue((self.adapter_dir / "templates" / name).is_file(), name)

    def test_no_external_network(self) -> None:
        self.assertEqual(self.data["network_behavior"], "none")
        self.assertEqual(self.data["required_environment_variables"], [])


if __name__ == "__main__":
    unittest.main()
