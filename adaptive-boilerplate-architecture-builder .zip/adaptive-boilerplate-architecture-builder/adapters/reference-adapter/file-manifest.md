# Reference Adapter File Manifest

| Path | Action | Purpose |
|---|---|---|
| `pyproject.toml` | create | Declares project metadata and Python minimum |
| `README.md` | create | States fixture scope and limitations |
| `src/__init__.py` | create | Marks the source package |
| `src/app.py` | create | Self-test and localhost health endpoint |
| `tests/test_app.py` | create | Unit tests for health payload and parser |
| `.gitignore` | create | Ignores Python cache and local environments |

No existing file may be overwritten unless the renderer is called with `--force` inside an isolated workspace.
