# Reference Adapter Compatibility

This adapter is a deterministic contract fixture, not a recommended production stack.

- Verified interpreter during package build: Python 3.13.5.
- Declared minimum for scripts and fixture: Python 3.11.
- Third-party runtime dependencies: none.
- External network access: none.
- Runtime smoke target: localhost only.
- Production serving: explicitly unsupported because `http.server` provides basic test functionality rather than a hardened application server.
