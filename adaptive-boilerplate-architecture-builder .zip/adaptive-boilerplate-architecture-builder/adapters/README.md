# Stack Adapters

Adapters carry stack-specific commands, templates, compatibility, and test evidence. The core skill remains architecture- and framework-neutral.

## Registry rules

- Only entries with `selection_status: selectable` may be used automatically.
- `conditional` requires an explicit assumption and review trigger.
- `reference_only` exists to test the contract and must not be recommended as a production stack.
- `retired` is blocked for new projects.

Run:

```bash
python3 scripts/validate_adapter.py adapters/reference-adapter --json
```

A production adapter must be researched, built, and tested in `ADAPTER_BUILD` before registry promotion.
