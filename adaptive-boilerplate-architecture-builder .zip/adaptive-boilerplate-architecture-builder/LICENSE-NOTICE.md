# License Notice

This package was generated for the requesting user as an original operational skill package. No third-party source code, paid standard text, or vendor template is embedded beyond short factual references, file-format conventions, and independently authored examples.

The skill frontmatter marks the package as proprietary because no public redistribution license was supplied. Before public or commercial redistribution, the owner must select an explicit license and review every included dependency, copied template, and future stack adapter for provenance and compatibility.

External specifications and documentation retain their respective owners' rights. Citations in `references/source-map.md` are references, not license grants.
