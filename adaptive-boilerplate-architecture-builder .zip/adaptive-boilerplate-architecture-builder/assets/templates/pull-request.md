## Decision and scope

- Architecture decision: {{DECISION_ID}}
- ADRs: {{ADR_PATHS}}
- Work branch: {{WORK_BRANCH}}
- Base branch and verified SHA: {{BASE_BRANCH_AND_SHA}}
- Included scope: {{INCLUDED_SCOPE}}
- Explicit exclusions: {{EXCLUDED_SCOPE}}

## Changes

{{CHANGE_SUMMARY}}

## Evidence

- Build manifest: {{BUILD_MANIFEST_PATH}}
- Evidence ledger: {{EVIDENCE_LEDGER_PATH}}
- Validation report: {{VALIDATION_REPORT_PATH}}
- Runtime smoke: {{RUNTIME_SMOKE_RESULT}}

## Risks and review focus

{{RISKS_AND_REVIEW_FOCUS}}

## Rollback

{{ROLLBACK}}

## Remote read-back

- Head SHA: {{HEAD_SHA}}
- Changed files verified: {{CHANGED_FILES_STATUS}}
- Required checks: {{CHECKS_STATUS}}
- Pull request state: {{PR_STATE}}
