workspace "{{PROJECT_NAME}} - Containers" "Container view derived from ADR {{DECISION_ID}}" {
  model {
    primaryUser = person "{{PRIMARY_USER}}" "{{PRIMARY_USER_DESCRIPTION}}"
    system = softwareSystem "{{SYSTEM_NAME}}" "{{SYSTEM_DESCRIPTION}}" {
      application = container "{{APPLICATION_NAME}}" "{{APPLICATION_DESCRIPTION}}" "{{APPLICATION_TECHNOLOGY}}"
      dataStore = container "{{DATA_STORE_NAME}}" "{{DATA_STORE_DESCRIPTION}}" "{{DATA_STORE_TECHNOLOGY}}" "Database"
      application -> dataStore "Reads and writes" "{{DATA_PROTOCOL}}"
    }
    primaryUser -> system.application "{{PRIMARY_RELATIONSHIP}}"
  }
  views {
    container system "Containers" {
      include *
      autoLayout lr
    }
    styles {
      element "Person" { shape person }
      element "Container" { background #438dd5 color #ffffff }
      element "Database" { shape cylinder }
    }
  }
}
