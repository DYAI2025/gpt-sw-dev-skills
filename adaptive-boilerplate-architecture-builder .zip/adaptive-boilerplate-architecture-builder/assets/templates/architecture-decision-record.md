# ADR-{{ADR_NUMBER}}: {{DECISION_TITLE}}

- Status: {{STATUS}}
- Date: {{DATE}}
- Decision owners: {{OWNERS}}
- Related requirements: {{REQUIREMENT_IDS}}
- Related evidence: {{EVIDENCE_IDS}}

## Context

{{CONTEXT}}

## Quality scenarios and hard constraints

{{SCENARIOS_AND_CONSTRAINTS}}

## Considered options

{{CANDIDATE_SUMMARIES}}

## Decision

{{DECISION}}

## Rationale

{{RATIONALE}}

## Strongest counterargument

{{COUNTERARGUMENT}}

## Consequences

### Positive

{{POSITIVE_CONSEQUENCES}}

### Negative

{{NEGATIVE_CONSEQUENCES}}

## Risks and mitigations

{{RISKS_AND_MITIGATIONS}}

## Assumptions

{{ASSUMPTIONS}}

## Review triggers and migration signals

{{REVIEW_TRIGGERS}}
