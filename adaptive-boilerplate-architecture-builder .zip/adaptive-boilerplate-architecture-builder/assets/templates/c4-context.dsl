workspace "{{PROJECT_NAME}} - System Context" "Context view derived from ADR {{DECISION_ID}}" {
  model {
    primaryUser = person "{{PRIMARY_USER}}" "{{PRIMARY_USER_DESCRIPTION}}"
    system = softwareSystem "{{SYSTEM_NAME}}" "{{SYSTEM_DESCRIPTION}}"
    primaryUser -> system "{{PRIMARY_RELATIONSHIP}}"
  }
  views {
    systemContext system "SystemContext" {
      include *
      autoLayout lr
    }
    styles {
      element "Person" { shape person }
      element "Software System" { background #1168bd color #ffffff }
    }
  }
}
