# Changelog

## 1.0.0 - 2026-07-27

### Added

- Ten explicit operating modes with non-silent mutation boundaries.
- Evidence-classified project intake and confidence gates.
- Quality-scenario derivation and hard-constraint separation.
- Multi-candidate architecture generation and ATAM-inspired challenge.
- Machine-readable intake, decision, manifest, adapter, ledger, and release schemas.
- Versioned stack-adapter contract and a non-selectable reference fixture.
- Dry-run-first implementation and complete foundation checklist.
- Deterministic quality-gate, runtime-smoke, repository-inventory, and GitHub read-back scripts.
- Trigger, non-trigger, decision, build, adversarial, GitHub, and mutation-sandbox evaluations.
- Installability, portability, security, bias, and release reports.

### Corrected from source corpus

- Removed deterministic architecture rules based on team-size bands.
- Removed automatic mappings from B2B to multi-tenancy or SSO.
- Removed automatic mappings from compliance labels to database topology.
- Removed automatic mappings from load to cache, queue, CQRS, event sourcing, Kubernetes, or microservices.
- Replaced “build succeeded” with evidence-based maturity levels.
