# Agent-Agnostic Compatibility

The core workflow is semantic and can be followed by capable agents that support file inspection, command execution, Git, and optional GitHub access. Compatibility does not mean identical tool schemas, UI behavior, sandboxing, permissions, or context loading.

## Portable parts

- operating modes and mutation boundary;
- evidence classifications and confidence model;
- project-intake, architecture-decision, build-manifest, adapter, ledger, and release schemas;
- candidate and trade-off logic;
- deterministic Python validators;
- dry-run, rollback, gate, and read-back requirements;
- GitHub safety invariants.

## Client-specific parts

Each host must map these abstract capabilities:

- repository file read/write;
- shell or process execution;
- temporary workspaces or worktrees;
- Git operations;
- GitHub read and write operations;
- web research and official-source access;
- user authorization prompts;
- artifact packaging and download.

If a capability is missing, the agent must emit the defined manual fallback instead of pretending parity.
