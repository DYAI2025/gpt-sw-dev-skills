# GitHub Delivery

## Read-before-write preflight

Read the repository identity, default branch, current branch, remote, existing pull requests, permissions, rulesets or branch protection, required reviews and checks, Actions configuration, CODEOWNERS, and current branch SHA before changing anything.

Use the current supported GitHub REST API version verified during `RESEARCH`; the package was researched against `2026-03-10`. Treat the version as a checked dependency, not a permanent constant.

## Non-negotiable rules

- No direct commit to `main`, `master`, or the protected default branch.
- No force push.
- No deletion of foreign branches.
- No change to rulesets, branch protection, CODEOWNERS, repository permissions, or required checks without a separate explicit instruction.
- No token, credential, or secret in files, commands, logs, or responses.
- No bypass of review or status-check requirements.
- No automatic merge without explicit authorization.
- No success claim without remote read-back.

## Work-branch flow

1. Confirm the expected default-branch SHA.
2. Create a descriptive branch such as `chore/bootstrap-architecture-<short-id>`.
3. Apply only the approved build manifest.
4. Validate each coherent slice.
5. Commit with requirement/decision references.
6. Push to the authorized remote.
7. Create or update a draft pull request.
8. Include decision, scope, exclusions, risks, evidence, gates, rollback, and review focus.
9. Read back branch SHA, commits, changed files, pull-request number/state/head/base, and checks.
10. Leave merge to the authorized human or governance process unless separately authorized.

## Read-back contract

The remote result must match:

- expected owner/repository;
- expected work branch and head SHA;
- expected base branch;
- expected commit set;
- expected changed-file set or documented generated additions;
- draft/open pull-request state;
- status checks and review requirements.

A successful HTTP response to a mutation is insufficient. Verify with independent GET operations.

## Capability fallback

When no authenticated write capability exists, return:

```text
MANUAL_OR_EXTERNAL_GITHUB_ADAPTER_REQUIRED
```

Provide the local branch or patch, exact non-force push command, full pull-request body, expected remote state, and remaining verification commands. Do not imply that a branch or pull request exists.
