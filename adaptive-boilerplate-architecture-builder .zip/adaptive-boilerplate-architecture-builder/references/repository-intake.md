# Repository Intake and Safety Preflight

## Preflight before any mutation

Collect and report:

- canonical owner and repository name;
- remote URL and host;
- default branch and current branch;
- current commit SHA;
- clean, dirty, or detached worktree state;
- untracked and modified files;
- existing local worktrees and candidate work branch;
- open pull requests that overlap the intended scope;
- readable branch protection or rulesets;
- write permissions and available Git/GitHub capability;
- CI workflows and required checks;
- CODEOWNERS and review requirements;
- ADRs, architecture documents, contributor instructions, and generated-file policies;
- package, runtime, lock, container, and infrastructure manifests;
- license, security policy, and dependency-update configuration.

Stop mutating work when the repository is unknown, authorization is ambiguous, foreign changes cannot be isolated, branch safety is unresolved, or project rules conflict.

## Project intake domains

Capture each value with evidence references and confidence:

1. product vision and target users;
2. user problems and intended outcomes;
3. scope and explicit exclusions;
4. capabilities and central user journeys;
5. domain concepts, invariants, consistency boundaries, and expected volatility;
6. data classes, residency, retention, deletion, backup, and recovery needs;
7. integrations, APIs, events, files, identities, and third-party dependencies;
8. measurable quality requirements;
9. security, privacy, assurance, and audit objectives;
10. regulatory control objectives without assuming a technical topology;
11. team skills, ownership, on-call, incident, and release capabilities;
12. delivery model, environments, platform, and operational ownership;
13. budget, time, cost ceilings, and reversibility requirements;
14. existing technology commitments and compatibility constraints;
15. migration, coexistence, data-import, and legacy requirements.

Validate the output against `schemas/project-intake.schema.json`.

## Critical gaps

Treat a gap as critical when it can reverse the macroarchitecture or make a write unsafe. Examples:

- unknown target repository;
- unknown data sensitivity for a system storing personal or regulated data;
- contradictory platform mandate;
- absent ownership for a distributed runtime;
- unspecified offline requirement for a mobile product;
- missing API contract that is already externally committed;
- unknown identity or tenant boundary when access-control design depends on it.

Output `MISSING_CRITICAL_CONTEXT` and stay in a read-only mode until the gap is resolved or an authorized, reversible assumption is accepted.
