# Trade-off and Decision Review

## Feasibility before scoring

1. Evaluate every candidate against every hard constraint.
2. Mark a violating candidate `infeasible`.
3. Do not allow weighted scores to rescue it.
4. Score only feasible candidates against minimums and preferences.

## ATAM-inspired record

For each candidate capture:

- **Risks:** decisions that may fail a quality scenario.
- **Non-risks:** decisions supported by evidence for the stated scope.
- **Sensitivity points:** parameters where small changes materially affect quality.
- **Trade-off points:** decisions influencing multiple quality attributes in competing directions.
- **Assumptions:** unverified premises with owners and review triggers.
- **Failure modes:** credible chains from trigger to impact and detection gap.
- **Open evidence:** information required before a conditional decision can become recommended.

## Comparison matrix

Use normalized, documented weights only after feasibility. Include at least:

- requirement fit;
- security and privacy fit;
- consistency and data integrity;
- modifiability and testability;
- delivery speed;
- operability and recovery;
- organizational fit;
- total cost;
- reversibility and migration cost;
- vendor lock-in;
- template and dependency drift;
- evidence strength.

Keep raw evidence next to scores. A matrix is a conversation aid, not a truth machine.

## Mandatory counterargument

Write the strongest technically credible case against the preferred architecture. Then state:

- which evidence would make that counterargument decisive;
- whether the preferred option remains recommended, becomes conditional, or becomes blocked;
- which review trigger reopens the decision.

## Bias audit

Check explicitly for:

- confirmation bias;
- architecture astronautics;
- premature distribution;
- resume-driven development;
- overengineering;
- framework or cloud fixation;
- sunk-cost bias from an existing template;
- false precision in scoring;
- cultural mismatch between prescribed process and actual team capability;
- overconfidence from successful generation without runtime evidence.
