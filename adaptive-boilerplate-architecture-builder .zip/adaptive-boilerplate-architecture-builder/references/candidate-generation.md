# Candidate Generation

## Default candidate set

Generate meaningful alternatives after hard constraints and quality scenarios are visible:

1. **Minimum viable architecture** — the smallest complete foundation that satisfies all hard constraints and immediate minimums.
2. **Balanced architecture** — added modularity, assurance, or operating structure where evidence predicts near-term value.
3. **Assurance or scale architecture** — stronger isolation, distribution, governance, or platform investment only when corresponding drivers exist.

A candidate can be omitted when a hard constraint makes it incoherent. Record the reason.

## Candidate dimensions

Specify each candidate across:

- macroarchitecture and deployment units;
- module or bounded-context boundaries;
- data ownership and consistency;
- synchronous and asynchronous communication;
- identity, authorization, tenancy, and trust boundaries;
- runtime, framework, package manager, and supported versions;
- build, test, CI, release, rollback, and migration model;
- observability, recovery, and incident model;
- security and supply-chain controls;
- template lifecycle and drift handling;
- team ownership and cognitive load;
- cost and vendor-lock-in profile;
- reversible seams and extraction signals.

## Distribution gate

Do not prefer network-separated services unless several independent signals exist, such as:

- a genuinely independent release cadence with business value;
- materially different scaling or availability profiles;
- clear domain and data ownership;
- failure isolation that cannot be achieved economically in-process;
- an organization able to operate service discovery, observability, incidents, deployment, and data consistency;
- a measured benefit that exceeds network, coordination, and platform cost.

A single “scalability” statement is insufficient.

## Event-driven gate

Use asynchronous messaging only when temporal decoupling, buffering/backpressure, multiple independent reactions, or durable event semantics are required. Model delivery, ordering, idempotency, retries, poison messages, replay, schema evolution, observability, and recovery before accepting the candidate.
