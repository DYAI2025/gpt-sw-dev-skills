# Compatibility Notes

## Skill format

The package follows the Agent Skills directory model: one root directory, required `SKILL.md`, optional `agents`, `references`, `scripts`, `assets`, `evals`, adapters, schemas, and reports. The skill name matches its parent directory. The description stays within the current specification limit and explains what the skill does and when it applies.

## Runtime

- Python scripts require Python 3.11 or newer.
- PyYAML and jsonschema are required for full validation.
- Git is optional for package validation but required for repository preflight and branch workflows.
- Graphviz is optional; JSON graph validation works without it.
- Network access is never assumed by default.
- GitHub mutations require a separately authorized connector, CLI, or API adapter.

## Stack compatibility

The core is stack-agnostic. It cannot truthfully build every framework without versioned adapters. The included reference adapter is non-selectable and uses only the Python standard library to exercise the adapter contract. Project use must select or build a current adapter for the target runtime, framework, data store, package manager, and platform.

## Specification baselines researched on 2026-07-27

- Agent Skills specification current at research time.
- GitHub REST API version `2026-03-10` current at research time.
- NIST SSDF 1.1 final; 1.2 draft.
- SLSA 1.2 current.
- ISO/IEC 25010:2023 current product-quality model.
- OpenAPI 3.2.0 current.
- AsyncAPI 3.1.0 current.
- JSON Schema Draft 2020-12 current general-purpose baseline.
- SPDX 3.0 current; 3.1 release-candidate material is not final.
- OpenTelemetry specification 1.59.0 and OTLP 1.11.0 current at research time.

Re-run `RESEARCH` before relying on any versioned baseline.
