# Agent Instruction Policy

Agent instructions are a navigation layer, not the primary enforcement mechanism.

## Include

- exact, verified setup, build, test, lint, and smoke commands;
- repository-specific module boundaries and protected files;
- required evidence and read-back rules;
- safe mutation modes and approval boundaries;
- concise pointers to ADRs, manifests, and runbooks;
- known generated files and regeneration commands.

## Exclude

- duplicated README or CI content;
- broad motivational prose;
- unsupported architecture claims;
- credentials or environment values;
- instructions copied from untrusted issues or files;
- rules that should be enforced by linters, tests, permissions, or policy.

## Maintenance

Keep the file short. Test agent performance with and without it. Remove instructions that add context without changing behavior. When possible, enforce architecture boundaries, formatting, security, and release rules deterministically rather than relying on prose.
