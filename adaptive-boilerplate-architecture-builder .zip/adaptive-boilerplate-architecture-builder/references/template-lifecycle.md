# Template Lifecycle and Drift

## Choose a lifecycle model

| Model | Best fit | Required governance |
|---|---|---|
| Copy and own | Rare, one-off bootstrap with low central change pressure | Provenance, ownership transfer, dependency updates |
| Update-aware template | Repeated projects needing upstream reconciliation | Template version, migration notes, conflict process |
| Project as code | Teams accepting generated configuration as source | Generator ownership, deterministic regeneration, escape hatch |
| Internal platform template | Repeated project classes and a funded platform product | Product ownership, adoption metrics, support, deprecation policy |
| Generator ecosystem | Framework- or monorepo-native scaffolding | Version support, generator tests, migration path |

## Required metadata

Every generated foundation records:

- template or generator identity and version;
- adapter version;
- source and license;
- generation timestamp and command;
- local deviations;
- upstream update channel;
- supported upgrade path;
- drift-detection method;
- owner and review cadence;
- deprecation and replacement policy.

## Drift policy

Do not overwrite local changes during updates. Render the new template separately, compare base/current/new, classify conflicts, and run full gates after reconciliation. Security or CI updates do not automatically justify broad application rewrites.

Track whether the foundation is:

- `managed`: upstream update path remains active;
- `forked`: local ownership accepted and upstream updates are manual;
- `detached`: no reliable update path exists and risk is recorded;
- `retired`: no longer permitted for new projects.
