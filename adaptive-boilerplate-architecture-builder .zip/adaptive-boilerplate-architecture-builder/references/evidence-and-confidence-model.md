# Evidence and Confidence Model

## Confidence scale

| Score | Basis | Allowed use |
|---|---|---|
| 5 | Direct runtime/repository evidence or current primary source applied to the exact scope | Hard rule or verified fact |
| 4 | Strong primary source or several independent, consistent sources | Hard rule with normal qualification |
| 3 | Plausible, partial, indirect, or context-sensitive evidence | Explicit assumption or conditional recommendation |
| 2 | Weak, conflicting, stale, or poorly scoped evidence | Research lead only |
| 1 | Unsupported, speculative, or contradicted | Block or remove |

Confidence is claim-specific. A reputable source does not make every inference high-confidence.

## Evidence record

Every decision-relevant record should contain:

```json
{
  "id": "EV-001",
  "claim": "The default branch requires a pull request and two approvals.",
  "classification": "project_internal",
  "label": "OBSERVED",
  "confidence": 5,
  "source": "github-ruleset-readback",
  "checked_at": "2026-07-27T00:00:00Z",
  "scope": "owner/repository",
  "limitations": [],
  "hash": "sha256:..."
}
```

## Evidence ledger discipline

- Preserve exact commands as argv arrays, not reconstructed shell strings.
- Hash material reports and generated artifacts.
- Record the tool version and timestamp.
- Link decisions to evidence IDs.
- Link build-manifest changes to decision and requirement IDs.
- Link release status to gate results.
- Mark `skipped` and `not_run` with reasons; neither equals success.

## Inference discipline

An inference must name its premises and a falsifier. Example:

```text
Premises: separate release cadence is required; the workload scales independently;
          ownership and observability capabilities exist.
Inference: isolating the worker may reduce deployment and scaling coupling.
Falsifier: one team owns both components and the workload remains low and synchronized.
```

Do not hide an inference inside a factual sentence.
