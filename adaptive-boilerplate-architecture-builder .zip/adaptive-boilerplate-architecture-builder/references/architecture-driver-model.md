# Architecture Driver Model

Architecture drivers are the small subset of requirements that materially change structure, technology, deployment, data ownership, or operating cost.

## Driver groups

| Group | Questions |
|---|---|
| Business | What outcome, market, revenue, time-to-learning, cost ceiling, or contractual commitment matters? |
| Domain | Which invariants, consistency boundaries, workflows, and areas of volatility exist? |
| Data | What classes, volumes, lifecycles, locality, lineage, retention, deletion, and recovery obligations exist? |
| Integration | Which synchronous, asynchronous, batch, file, identity, or partner contracts are committed? |
| Security and privacy | What threats, trust boundaries, identities, authorization rules, evidence, and control objectives exist? |
| Reliability | What failures must be isolated, tolerated, recovered, or degraded? |
| Performance | Which workloads, percentiles, throughput, concurrency, payloads, and resource ceilings matter? |
| Modifiability | Which changes must remain local, frequent, reversible, or independently releasable? |
| Operability | Who deploys, observes, supports, restores, and responds to incidents? |
| Cost | What build, cloud, license, support, and cognitive-load ceilings apply? |
| Team and governance | What skills, ownership, review, compliance, and decision rights exist? |
| Delivery | What environments, cadence, rollback, release, and migration constraints exist? |
| Platform | Which operating systems, clouds, devices, runtimes, or internal platforms are mandatory? |

## Classification

For each driver, assign exactly one primary class:

- `hard_constraint`: violation makes a candidate infeasible;
- `minimum_requirement`: must reach a threshold;
- `weighted_preference`: useful for comparison after feasibility;
- `assumption`: accepted temporarily and tied to a review trigger;
- `later_optimization`: explicitly excluded from the initial foundation.

## Anti-shortcut rules

- Team size does not select an architecture by itself.
- “B2B” does not imply tenancy, billing, SSO, or audit-log requirements.
- A compliance label does not prescribe a database topology.
- Performance does not automatically require distribution, caching, or messaging.
- “Cloud native” does not require Kubernetes.
- “Complex domain” does not automatically require full DDD or Clean Architecture.
- A preferred framework is a constraint only when it is an authorized commitment.
