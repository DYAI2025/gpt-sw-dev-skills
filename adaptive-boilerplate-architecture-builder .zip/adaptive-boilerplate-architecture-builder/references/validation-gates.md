# Validation Gates

## Status contract

Every gate uses one status: `passed`, `failed`, `skipped`, or `not_run`.

Each result records:

- gate ID and requirement IDs;
- required flag;
- UTC timestamp;
- exact argv array;
- working directory;
- tool name and version;
- exit code;
- duration;
- stdout/stderr log paths;
- report path;
- hashes of material artifacts;
- reason when skipped or not run.

A required `failed`, `skipped`, or `not_run` result blocks `release_candidate` unless the project governance explicitly reclassifies the gate and records that decision.

## Gate catalog

| Gate | Minimum proof |
|---|---|
| Scope and evidence | validated intake, critical gaps, conflicts, source and confidence records |
| Adapter and generator | adapter schema, support/provenance, clean render, adapter tests |
| Repository structure | expected files, no unknown overwrite, protected files unchanged |
| Toolchain and reproducibility | pinned tools, clean install/build, lock integrity |
| Format/lint/type/compile | configured commands pass with recorded versions |
| Architecture | forbidden dependencies and cycles are blocked |
| Unit tests | deterministic pass and report |
| Integration tests | real or approved ephemeral dependencies, isolation and cleanup |
| Contract and schema | APIs/events/files validate; compatibility policy applied |
| Data and migrations | clean-up, upgrade, rollback or recovery evidence as applicable |
| Security and privacy | threat-relevant negative tests, secret/vulnerability/license checks |
| IaC and policy | syntax/plan/policy checks without unapproved apply |
| Supply chain | dependency provenance, SBOM and build provenance when required |
| Observability and operability | startup/shutdown, logs, health/readiness, runbook evidence |
| Runtime smoke | process starts and critical path responds under a clean environment |
| Documentation | README, ADR, operations, security, source and drift notes agree with code |
| GitHub read-back | branch SHA, changed files, commits, PR state, and checks read from remote |
| Evidence ledger | complete, schema-valid, hashed, and linked to release decision |

## Maturity mapping

- `generated`: files exist.
- `structurally_valid`: format, schema, structure, and manifest gates pass.
- `buildable`: clean installation and build pass.
- `tested`: required automated tests pass.
- `runtime_verified`: required runtime smoke passes.
- `release_candidate`: all project-required gates and governance checks pass.

Do not use `production_ready` unless project-specific deployment, operations, security, privacy, recovery, monitoring, and approval evidence exists.
