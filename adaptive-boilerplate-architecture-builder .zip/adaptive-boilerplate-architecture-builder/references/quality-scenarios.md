# Quality Scenarios

Convert vague quality words into testable scenarios before scoring architecture candidates.

## Scenario structure

| Field | Meaning |
|---|---|
| `source` | Actor or condition producing the stimulus |
| `stimulus` | Event that exercises the quality attribute |
| `environment` | Normal, peak, degraded, deployment, recovery, attack, or other state |
| `artifact` | System, component, data set, interface, deployment unit, or workflow affected |
| `response` | Required observable behavior |
| `response_measure` | Numeric or binary acceptance threshold |
| `evidence` | Source IDs and confidence |
| `priority` | Hard, minimum, preference, or later |

## Examples

### Performance

```text
Source: authenticated mobile client
Stimulus: requests the current dashboard
Environment: normal weekday peak, 500 concurrent sessions
Artifact: dashboard read path
Response: returns a complete response without stale authorization context
Measure: p95 <= 350 ms and error rate < 0.5% over a 15-minute load test
```

### Modifiability

```text
Source: product team
Stimulus: adds a new notification channel
Environment: normal development
Artifact: notification module
Response: adds the channel without changing domain policy or existing adapters
Measure: changes remain within one module plus contract registration; architecture tests pass
```

### Recovery

```text
Source: database outage
Stimulus: primary storage becomes unavailable
Environment: production incident
Artifact: write path
Response: rejects unsafe writes, exposes degraded health, and preserves diagnostic evidence
Measure: no acknowledged lost write; recovery procedure meets recorded RTO/RPO
```

### Security

```text
Source: authenticated user from another organization
Stimulus: requests an object outside the authorized boundary
Environment: normal operation and negative-security test
Artifact: authorization boundary
Response: denies access without disclosing object existence or sensitive metadata
Measure: deterministic denial; audit event recorded; zero cross-boundary data returned
```

## Validation rules

Reject a scenario that lacks a measurable response, mixes several unrelated stimuli, or uses a threshold without a source. If a target is unknown, retain it as `SOURCE_NEEDED` rather than inventing a number.
