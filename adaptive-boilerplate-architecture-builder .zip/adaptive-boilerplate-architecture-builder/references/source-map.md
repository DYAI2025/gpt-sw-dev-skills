# Source Map

The machine-readable inventory is `source-map.yaml`. This summary explains how sources influenced the package.

## Primary sources

- Agent Skills specification and official skill-creation guidance: package format, frontmatter, progressive disclosure, scripts, trigger tests, and output evaluations.
- GitHub official documentation: REST API versioning, pull requests, branch protection, rulesets, Actions permissions, and read-back requirements.
- NIST SSDF: stable secure-development baseline and draft-status distinction.
- SLSA, SPDX, OpenAPI, AsyncAPI, JSON Schema, and OpenTelemetry official specifications: current version/status boundaries.
- ISO/IEC 25010 official summary, SEI ATAM/QAW material, and official C4 Model documentation: quality vocabulary, scenario analysis, trade-offs, and architecture views.

## User and project sources

- The attached enterprise build prompt defines the required modes, package tree, safety constraints, scripts, evaluations, and release states.
- Two supplied boilerplate-research documents contribute vocabulary, pattern candidates, and initial derivation ideas. Their deterministic team-size, compliance-topology, performance-pattern, and “production-ready” claims were not accepted as hard rules.
- The prior `boilerplate-architecture-research` package supplies a corrected decision model, implementation playbook, validation gates, tool catalog, schemas, and evaluation scenarios.
- Enterprise Skill Creator and Research-Backed Skill Builder instructions supply source, confidence, release, packaging, installability, and portability gates.

## Important corrections

- Team-size bands are context signals, not architecture laws.
- B2B is not equivalent to multi-tenancy, SSO, or billing.
- GDPR, HIPAA, SOC 2, and similar labels do not by themselves mandate a physical database topology.
- Performance targets do not automatically mandate Redis, a broker, CQRS, event sourcing, or microservices.
- A build pass is not production-readiness evidence.
- `AGENTS.md` is useful navigation but not a security or architecture enforcement boundary.
