# Evaluation Design

## Skill TDD model

1. Define realistic pressure scenarios before changing the skill.
2. Record baseline failure patterns without the skill or against the previous version.
3. Add the smallest instructions and deterministic controls that address those failures.
4. Re-run the same cases with the skill.
5. Add adversarial variants and close new loopholes.
6. Keep a held-out set for trigger and output regression.

## Required evaluation groups

- trigger queries;
- non-trigger queries;
- architecture-decision cases;
- build and validation cases;
- adversarial and prompt-injection cases;
- read-only GitHub cases with stable single-value answers;
- mutation cases only in isolated sandbox repositories.

## Baseline failure classes

The suite must detect:

- selecting a framework before reconstructing requirements;
- choosing microservices because a prompt says “scalable”;
- turning compliance into a fixed database topology;
- evaluating only one architecture;
- omitting a counterhypothesis;
- overwriting existing files during generation;
- equating a successful build with production readiness;
- pushing directly to the default branch;
- claiming a tool or GitHub result without read-back.

## Evaluation evidence

Separate:

- schema validation of eval artifacts;
- deterministic script and sandbox execution;
- live model trigger/output evaluation;
- live connector evaluation.

Do not mark a live evaluation passed when only its test definition was validated. Record tool unavailability as `not_run`.
