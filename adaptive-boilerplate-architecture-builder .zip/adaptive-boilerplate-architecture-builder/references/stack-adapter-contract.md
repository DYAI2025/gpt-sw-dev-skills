# Stack Adapter Contract

The core skill decides and validates. A stack adapter supplies current, executable stack knowledge.

## Required adapter content

An adapter must declare:

- identifier, version, selection status, and provenance;
- runtime, framework, package manager, architecture form, data store, and target platform;
- supported and explicitly unsupported versions;
- official sources with checked dates and lifecycle status;
- license and redistribution conditions;
- generator and patch commands as argv arrays;
- expected create/change/protect file sets;
- templates and deterministic transformations;
- architecture rules;
- build, test, security, contract, and smoke commands;
- required environment variables without secret values;
- network and external-download behavior;
- known incompatibilities and deprecations;
- update, migration, cleanup, and rollback procedures;
- adapter tests and latest verification evidence.

Validate `adapter.yaml` against `schemas/stack-adapter.schema.json` and run `scripts/validate_adapter.py`.

## Selection gate

An adapter is selectable only when:

1. `selection_status` is `selectable`;
2. target versions are supported by current official documentation;
3. all commands are verified and non-interactive;
4. a clean generated fixture builds and tests;
5. a runtime smoke test passes where the stack has a runtime;
6. no secrets are embedded;
7. license and provenance are known;
8. incompatibilities do not violate project hard constraints;
9. latest verification evidence is inside the accepted freshness window.

Otherwise emit `ADAPTER_MISSING` or use `ADAPTER_BUILD` in an isolated workspace.

## Adapter build lifecycle

```text
research official sources
-> draft adapter in isolated directory
-> validate schema and provenance
-> render clean fixture
-> inspect complete diff
-> run build/test/security/smoke gates
-> record hashes and versions
-> peer review
-> mark selectable only after all required evidence passes
```

The bundled reference adapter is deliberately `reference_only`. It proves the contract and scripts; it is not a production recommendation.
