# Architecture Pattern Catalog

This catalog provides candidates, not defaults.

| Pattern | Useful signals | Primary costs and cautions |
|---|---|---|
| Simple monolith | High learning rate, small operational surface, strong consistency, one release unit | Coupled deployment and scaling; boundaries can decay without tests |
| Modular monolith | Clear domain seams, one deployment remains advantageous, future extraction may matter | Requires enforced dependencies and disciplined data ownership |
| Modular monorepo | Several applications or libraries benefit from coordinated tooling and contracts | Repository-wide CI and ownership can become coupled |
| Application plus isolated worker | One workload has different CPU, memory, latency, or scheduling needs | Queue/contract/retry/observability semantics become real obligations |
| Service-oriented system | Independent ownership and releases with stable contracts | Network, consistency, incident, deployment, and governance overhead |
| Microservices | Many independently operated capabilities with justified isolation and mature platform support | Highest distributed-systems and organizational coordination cost |
| Event-driven architecture | Temporal decoupling, buffering, fan-out, or event history is a genuine requirement | Delivery, ordering, idempotency, replay, schema, and debugging complexity |
| Serverless-oriented | Bursty event workloads, managed operations, short execution, acceptable platform constraints | Cold starts, limits, local parity, observability, and lock-in |
| Offline-first client | Connectivity gaps are central and conflict resolution is domain-defined | Synchronization, local security, migrations, and conflict semantics |
| Platform golden path | Repeated project classes and sufficient platform-team capacity | Product ownership, template drift, adoption, and escape-hatch governance |

## Supporting patterns

Use only with explicit drivers:

- Hexagonal or ports-and-adapters boundaries;
- layered architecture;
- vertical slices;
- domain events;
- transactional outbox;
- cache-aside;
- circuit breaker and bulkhead;
- saga or process manager;
- CQRS;
- event sourcing;
- database-per-tenant, schema-per-tenant, or shared-schema tenancy;
- API gateway, BFF, service mesh;
- strangler migration.

Every supporting pattern must name the problem it solves, its failure modes, and its removal or migration path.
