# Portability Report

The workflow is semantically portable across capable coding agents. The Python validators and schemas are agent-neutral. Tool parity is not assumed.

## Portable

- modes and approval boundaries;
- evidence, confidence, and source policy;
- driver/scenario/candidate/decision logic;
- schemas, templates, and adapter contract;
- quality gate and evidence ledger;
- GitHub safety and read-back invariants.

## Host-dependent

- file and process tools;
- isolated worktree support;
- authenticated GitHub connector or CLI;
- web research;
- user authorization UX;
- artifact packaging and download;
- cloud or deployment capabilities.

When a host lacks a capability, the skill emits a manual or external-adapter status instead of claiming equivalent execution.
