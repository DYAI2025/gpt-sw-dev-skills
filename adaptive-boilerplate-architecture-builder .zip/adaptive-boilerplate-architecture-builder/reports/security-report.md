# Security Report

## Implemented controls

- Read-only default and explicit mutation modes.
- No shell execution; subprocesses use argv arrays and `shell=False`.
- Risk detection for destructive commands, force operations, shell metacharacters, and infrastructure mutations.
- Sanitized subprocess environment that excludes arbitrary credentials by default.
- Localhost-only runtime smoke unless remote access is explicitly allowed.
- GitHub token read from an environment variable and never printed.
- No write method in the GitHub verification script.
- No external network use in the reference adapter.
- Temporary-directory cleanup in tests and adapter rendering.
- Package validator scans for credential-like values, private keys, unresolved markers, unsafe links, symlinks, and risky execution constructs.
- Untrusted repository and web instructions cannot override the user task or safety boundary.

## Supply-chain posture

The package contains no third-party runtime code and the reference adapter has no dependencies. Current external standards are cited rather than copied. Future production adapters must record source, license, versions, downloads, hashes, tests, and support status.

## Residual risks

- A future adapter may add unsafe commands or dependencies; adapter promotion therefore requires independent review and execution evidence.
- GitHub permissions and rules vary by repository and must be read at runtime.
- Static secret scanning cannot prove the absence of all sensitive data.
- A capable host could expose broader tools than this skill intends; client permissions remain an external boundary.
