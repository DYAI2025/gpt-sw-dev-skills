# Requirements Coverage

| Requirement area | Implementation | Verification |
|---|---|---|
| Explicit non-silent modes | `SKILL.md` operating-mode table and mutation declaration | Trigger/output/adversarial eval assertions |
| Repository safety preflight | `references/repository-intake.md`, `inventory_repository.py` | Script integration test and read-only inventory flag |
| Evidence classes and confidence | `references/source-policy.md`, `evidence-and-confidence-model.md`, `source-map.yaml` | `validate_source_map.py` |
| Project intake | `project-intake.schema.json` and validator | Schema self-check and validator help/syntax |
| Architecture drivers and quality scenarios | `architecture-driver-model.md`, `quality-scenarios.md` | Decision evals |
| Multiple candidates and hard-constraint dominance | `candidate-generation.md`, `tradeoff-and-decision.md` | Decision and adversarial evals |
| ADRs and architecture views | ADR and C4 assets; decision schema | Data-file and relative-link validation |
| Stack-adapter model | Adapter contract, registry, reference fixture | Adapter schema, adapter tests, render/build/test/smoke integration test |
| Build manifest and dry run | Build schema, manifest asset, implementation playbook | Manifest and gate-runner integration test |
| Complete foundation checklist | `implementation-playbook.md` | Build evals and requirements review |
| Validation ledger and maturity | Validation gates, evidence schema, gate runner | Gate-runner test and schema validation |
| Security and supply chain | Security references, safe subprocess design, secret/risky scans | Quick validator and adversarial evals |
| GitHub branch/PR handoff and read-back | `github-delivery.md`, `verify_github_state.py`, PR asset | Deterministic mock GitHub integration test and read-only XML evals |
| Prompt injection and untrusted content | Source and tool policies | Adversarial evals |
| Template lifecycle | `template-lifecycle.md` | Drift build evals |
| Agent portability | `agent-agnostic-compatibility.md` | `validate_agent_agnostic.py` |
| Installable package | root skill structure, `agents/openai.yaml`, package script | Installability validator and ZIP integrity test |
| Evaluation groups | trigger, non-trigger, decision, build, adversarial, GitHub, sandbox, output files | `validate_evals.py` |
| Release hook | JSON gate report and validator | `validate_release_gate.py` |
| Core functionality preservation | JSON report | `validate_core_parity.py` |
