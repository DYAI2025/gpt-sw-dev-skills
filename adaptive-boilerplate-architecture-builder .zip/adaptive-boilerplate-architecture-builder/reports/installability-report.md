# Installability Report

## Controlled invariants

- Skill directory name matches frontmatter name.
- `SKILL.md` is below 500 lines and contains current-format YAML frontmatter.
- `agents/openai.yaml` exists.
- The primary artifact is named exactly `skill.zip`.
- The archive contains one root directory and no outer transport folder.
- Relative references, JSON, YAML, schemas, Python syntax, script help, eval artifacts, and release reports are validated before packaging.
- Symlinks, empty files, cache files, compiled Python artifacts, and nested ZIP files are excluded.

## Not controlled by the package

- Whether a particular ChatGPT or other client exposes an install button.
- User permissions to upload or install skills.
- Client support for every optional Agent Skills field.
- Availability of Git, GitHub, web, shell, or filesystem capabilities at runtime.

Frontend install suggestion status: **prepared**, never guaranteed.
