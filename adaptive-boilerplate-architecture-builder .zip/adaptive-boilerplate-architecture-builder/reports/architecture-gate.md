# Pre-Build Architecture Gate

Status: **PASS**

## Skill type

Enterprise orchestrator with deterministic validators, schemas, templates, evaluations, and versioned stack-adapter extension points.

## Chosen architecture

- Compact `SKILL.md` control plane.
- Directly linked reference files; no nested reference dependency is required.
- Machine-readable contracts for intake, decision, build, adapter, evidence, and release.
- Stack-specific knowledge isolated in versioned adapters.
- Read-only assessment and decision separated from authorized mutations.
- Dry-run and read-back gates before success claims.

## Smaller solution considered

A single long `SKILL.md` was rejected because current framework commands, adapter tests, schemas, evals, and GitHub safety need independent validation and updates. A generic knowledge document was rejected because it cannot execute or prove repository changes.

## Strongest counterargument

The package is large and may impose more ceremony than a tiny experimental project needs. A narrower skill with one verified stack adapter would be easier to maintain and evaluate.

## Resolution

The core keeps all project controls conditional and selects the minimum viable architecture by default. The bundle's breadth is primarily validation infrastructure rather than mandatory project architecture. The reference adapter is non-selectable. Production use should begin with one real adapter and a small held-out evaluation set.

## Failure-mode chain addressed

```text
vague project request
-> fashionable framework selected
-> unsupported generator command invented
-> existing files overwritten
-> tests/build claimed from tool intent
-> direct default-branch push
-> unverified pull request state
```

The mode boundary, source gate, adapter contract, manifest, dry run, quality ledger, branch policy, and remote read-back interrupt this chain at multiple points.
