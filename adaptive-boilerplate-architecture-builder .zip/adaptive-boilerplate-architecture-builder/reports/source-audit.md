# Source Audit

Audit date: 2026-07-27

## Accessible corpus

| Source | Class | SHA-256 | Use | Confidence |
|---|---|---|---|---:|
| `_system_instruction_identity_du_bist_ein_enter.md` | user_provided | `a4a5ccdfd7c16774c28ef746d6af036b6a1565f9b41f8d03c9872e9eef41afc0` | Required behavior, package, scripts, evaluations, safety, and release contract | 5 |
| `systematische_analyse_architekturderivation_und_k.md` | user_provided | `baff8a77e28fa03c7bc7863ab559d10bf85ac81fdd00134cf9e8cab76c365d66` | Taxonomy, derivation, pattern, and implementation candidates | 3 |
| `technische_ans_tze_f_r_boilerplate_architekturen_ (1).md` | user_provided | `c18dc3c0010cb7eab601654ad48366615af3baf89dc0921bd86fdb0cbddd8460` | Scaffolding, platform, architecture, metrics, and lifecycle candidates | 3 |
| `boilerplate-architecture-research.zip` | derived | `1f6a1fbef22a71ce40e4392d62fdd999c27ffd27bc0477698581fab5850e6c49` | Corrected decision model, playbook, schemas, gates, and eval scenarios | 4 |
| `evaluation.md` | project_internal | `8c99479f8a2d22a636c38e274537aac3610879e26f34e0709825077c4576f427` | Stable, read-only MCP/tool evaluation design | 4 |
| `self_bias_check.md` | project_internal | `c892d4fb5a8f5ea675bbd181b9c93d2c0b585e976e3ecdce4e724d58b7c3fcaf` | Claim, hallucination, and bias audit model | 4 |
| `skill-building-orchestrator.md` | project_internal | `42b0a3eefd341eba4dc9dd5e34c90628b2b9b184ab9a6a463bd76e08c8322107` | Package structure and progressive disclosure | 4 |
| `Skillcreator Modernisierung Recherche.txt` | derived | `03ed518391216892d51f0ad21b9aa8312a23e3ca84244429cfbf3819d1e22480` | Enterprise pipeline, source gates, validators, and eval architecture | 4 |
| `graphviz-conventions.dot` | project_internal | `e2890a593c91370e384b42f2f67b1a6232c9e69dddea7891a0c1c46d7b20b694` | Process diagram conventions | 4 |
| `persuasion-principles.md` | secondary | `c3c84f572a51dd8b6d4fc6e5cbdc2bc3b9e07ba381a45bdabfce7ad2894dd828` | Bright-line wording assessment | 3 |
| Enterprise Skill Creator instructions | project_internal | resource-loaded | Research, release hook, installability, portability, and packaging | 5 |
| Research-Backed Skill Builder instructions | project_internal | resource-loaded | Source inventory, confidence, and missing-information discipline | 5 |

The research ZIP was fully extracted and its README, decision model, document audit, skill blueprint, implementation playbook, source map, tool catalog, validation gates, schemas, evaluations, and diagrams were read and used.

## Current primary-source research

| Source family | Status used in package | Confidence |
|---|---|---:|
| Agent Skills specification and official skill-creation guidance | Current at audit date; package/frontmatter/progressive-disclosure/script/eval rules | 5 |
| GitHub REST, pull requests, branch protection, rulesets, and Actions docs | REST version `2026-03-10` used as researched baseline; permissions remain repository-specific | 5 |
| NIST SSDF | 1.1 final; later 1.2 material treated as draft | 5 |
| SLSA | 1.2 current | 5 |
| ISO/IEC 25010 | 2023 published model; protected text not reproduced | 5 |
| SEI ATAM and QAW | Used as inspiration for trade-off and scenario discipline, not formal certification | 5 |
| C4 Model | Context and container views default; extra views only when useful | 5 |
| OpenAPI | 3.2.0 current | 5 |
| AsyncAPI | 3.1.0 current | 5 |
| JSON Schema | Draft 2020-12 | 5 |
| SPDX | 3.0 final; 3.1 release-candidate material excluded as final baseline | 5 |
| OpenTelemetry | Specification 1.59.0 and OTLP 1.11.0 current at audit date | 5 |

## Preserve, correct, reject

| Source idea | Decision | Reason |
|---|---|---|
| Feature/commonality/variability analysis | Preserve | Useful for deciding mandatory, optional, and alternative foundation capabilities |
| Architecture drivers over isolated features | Preserve | Aligns architecture with business, quality, data, integration, and operating constraints |
| Multiple candidates and trade-off analysis | Preserve and strengthen | Prevents framework-first and single-option bias |
| Cross-cutting foundation capabilities | Preserve conditionally | Include only when a project driver exists |
| Template drift and update lifecycle | Preserve | Copied starters require ownership and update strategy |
| Team-size bands select architecture | Reject as hard rule | Team size is a signal; domain, release, scaling, ownership, and operating evidence can reverse the conclusion |
| B2B automatically requires tenancy, SSO, billing, or audit | Reject | These are separate product and contract requirements |
| Compliance label mandates physical database isolation | Reject | Translate into control and evidence objectives, then select controls from risk and data-flow analysis |
| High load mandates Redis, a broker, event sourcing, CQRS, or microservices | Reject | Measurable scenarios and workload evidence must precede pattern selection |
| Clean Architecture or DDD is mandatory for complex domains | Correct | Apply only the boundary and modeling practices that produce measurable value |
| Kubernetes signals production readiness | Reject | Operating capability and workload drivers determine platform need |
| Successful generation or compilation proves production readiness | Reject | Use the maturity ladder and project-specific release gates |
| Agent instruction file is a project constitution | Correct | Use concise navigation; enforce critical rules through code, tests, permissions, and policy |

## Conflicts

1. User research documents contain deterministic thresholds and topology claims that conflict with risk- and evidence-based decision making. The package records and rejects those hard mappings.
2. The prompt requests complete project building for arbitrary stacks, while current stack knowledge changes. The package resolves this through versioned adapters and `ADAPTER_MISSING` rather than fabricated universality.
3. The prompt requires GitHub verification, but no live repository or credential was supplied for this package build. The script is tested against a deterministic mock; live verification remains runtime-dependent.

## MISSING and SOURCE_NEEDED

- `MISSING`: target project repository, product facts, architecture commitments, branch rules, and authorization. These are runtime inputs, not blockers for packaging the generic skill.
- `MISSING`: authenticated GitHub environment for live end-to-end read-back.
- `MISSING`: live model-evaluation harness for empirical with-skill versus without-skill A/B runs.
- `MISSING`: official `skills-ref` CLI in the container. Equivalent structural invariants are covered by bundled validators, but official CLI validation is `not_run`.
- `SOURCE_NEEDED`: every future stack/framework version, generator command, support window, license, and advisory must be rechecked during `RESEARCH` or `ADAPTER_BUILD`.
