# Bias and Confabulation Audit

## Confirmation bias

Risk: user documents and prior research favor structured boilerplates and modular architectures.

Mitigation: require multiple candidates, hard-constraint feasibility, strongest counterargument, evidence strength, review triggers, and a minimum viable option.

## Overengineering

Risk: the package's enterprise controls could be projected into every generated project.

Mitigation: controls govern the decision process; project components remain conditional. Databases, queues, caches, clouds, Kubernetes, full DDD, and distributed services need explicit drivers.

## Framework bias

Risk: familiar frameworks or generators may be preferred from model training.

Mitigation: core contains no selectable production adapter. Unsupported stacks yield `ADAPTER_MISSING` or isolated `ADAPTER_BUILD`.

## Tool-capability overconfidence

Risk: an agent may equate an intended command or API request with success.

Mitigation: exact command/exit/log evidence, runtime smoke, remote read-back, and `not_run` semantics.

## Compliance bias

Risk: labels such as GDPR, HIPAA, or SOC 2 may be mapped to fashionable topologies.

Mitigation: derive protection, audit, data-flow, threat, recovery, and evidence objectives first; technical controls follow project-specific risk analysis.

## Cultural and organizational bias

Risk: heavyweight governance may not fit a small experimental team.

Mitigation: record team and operating capability as drivers, prefer the simplest feasible foundation, and make later assurance investments conditional.

## Remaining uncertainty

Live model behavior, live GitHub connector behavior, and future adapter quality remain external to this package build. The final release is therefore conditional rather than unqualified.
