# Evaluation Report

## Baseline failure model

Without this skill, the expected high-risk behaviors are:

1. framework selection before project reconstruction;
2. microservices from a scalability buzzword;
3. compliance mapped directly to a database topology;
4. one candidate presented as inevitable;
5. no strongest counterargument;
6. generated files overwrite unknown project files;
7. build success described as production readiness;
8. direct default-branch changes;
9. tool or GitHub success claimed without read-back.

These baseline failures are derived from the supplied research audit and the user's explicit pressure scenarios. They are not represented as an executed model benchmark.

## Evaluation inventory

- 12 trigger queries.
- 12 non-trigger queries.
- 14 decision scenarios.
- 10 build scenarios.
- 12 adversarial scenarios.
- 8 output-quality cases, mirrored in the conventional `evals.json` file.
- 10 stable read-only GitHub questions against a fixed fixture.
- 8 mutation cases limited to isolated sandbox repositories.

## Deterministic execution

The bundled test runner executed seven integration tests covering:

- JSON Schema validity;
- adapter contract and non-selectable status;
- reference adapter render, compile, unit tests, self-test, and localhost runtime smoke;
- build-manifest validation and executable gate ledger;
- architecture cycle and boundary-error detection;
- read-only repository inventory;
- GitHub branch, pull-request, changed-file, and check read-back against a local deterministic mock.

Result: **7 passed, 0 failed, 0 skipped**.

## Expected behavior change

The skill should make architecture choice conditional on evidence, enforce multiple feasible candidates, preserve hard constraints over weighted scoring, refuse unsupported stack commands, require dry-run and explicit mutation authorization, block release on required gate failures, and require independent GitHub read-back.

## Not executed

- Live model A/B trigger-rate evaluation with and without the skill.
- Live model output comparison against a previous skill version.
- Authenticated GitHub connector evaluation against an external sandbox repository.

These are release limitations, not passed checks.
