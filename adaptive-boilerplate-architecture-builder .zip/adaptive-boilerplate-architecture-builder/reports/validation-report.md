# Validation Report

Validation date: 2026-07-27

## Executed and passed

| Check | Command | Result |
|---|---|---|
| Full package validation | `python3 scripts/quick_validate.py . --json` | passed |
| Source map | `python3 scripts/validate_source_map.py . --json` | passed; 22 sources and 4 explicit missing-capability records |
| Evaluation artifacts | `python3 scripts/validate_evals.py . --json` | passed |
| Enterprise release hook | `python3 scripts/validate_release_gate.py . --json` | passed |
| Installable structure | `python3 scripts/validate_installability.py . --json` | passed |
| Agent-agnostic notes | `python3 scripts/validate_agent_agnostic.py . --json` | passed |
| Core-function parity | `python3 scripts/validate_core_parity.py . --json` | passed |
| Stack-adapter contract | `python3 scripts/validate_adapter.py adapters/reference-adapter --json` | passed; status remains `reference_only` |
| Enterprise evaluation XML | `python3 scripts/validate_enterprise_skill_evaluation.py reports/enterprise-skill-evaluation.xml --json` | passed |
| Workflow DOT rendering | `python3 scripts/validate_architecture_graph.py references/workflow.dot --json` | passed with Graphviz |
| Script and integration tests | `python3 scripts/test_scripts.py --json` | 7 passed, 0 failed, 0 skipped |
| Reference-adapter tests | `python3 -m unittest discover -s adapters/reference-adapter/tests -p 'test_*.py'` | 3 passed |
| Python syntax | `python3 -m compileall -q scripts adapters/reference-adapter/tests` | passed |
| Schema-bound examples | Draft 2020-12 validation for build-manifest and evidence-ledger assets | passed |
| Unresolved-marker, secret, risky-command, symlink, empty-file, YAML/JSON, link, and script-help scans | Included in `quick_validate.py` | passed |

The integration suite executed adapter rendering, compilation, unit tests, self-test, localhost runtime smoke, quality-gate evidence generation, architecture-boundary failure detection, read-only repository inventory, and GitHub state read-back against a deterministic local mock.

## Archive verification policy

`package_skill.py` reruns the complete package validator, writes exactly `skill.zip`, reopens the archive, checks CRC integrity, confirms one skill root, verifies `SKILL.md` and `agents/openai.yaml`, checks safe member paths, and compares the read-back member list with the written list. The final archive hash and member count are reported outside the archive because embedding an archive's own hash would change that hash.

## Not executed

| Check | Status | Consequence |
|---|---|---|
| Official `skills-ref validate` | `not_run`: command unavailable | Bundled validators cover the researched structural invariants, but official CLI parity is not claimed |
| Live model A/B trigger and output evaluation | `not_run`: harness unavailable | Trigger and output definitions are validated; empirical model rates are not claimed |
| Authenticated GitHub external-sandbox evaluation | `not_run`: no repository or scoped credential supplied | GitHub read-back logic is mock-tested; live connector behavior is not claimed |

These limitations reduce the final release decision to `CONDITIONALLY_READY`.
