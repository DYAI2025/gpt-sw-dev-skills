# Adaptive Boilerplate Architecture Builder

An enterprise Agent Skill for deciding and constructing evidence-bound project foundations in new or code-light repositories.

## What it does

The skill separates investigation, decision, planning, isolated adapter development, dry-run generation, authorized application, verification, and GitHub handoff. It does not treat a framework, team-size threshold, architecture pattern, cloud, compliance label, or “production-ready” claim as a substitute for project evidence.

## What it does not do

- It does not mutate a repository unless a mutating mode, target, branch, rollback, and authorization are explicit.
- It does not choose a production stack without a validated adapter.
- It does not equate a successful build with production readiness.
- It does not claim GitHub success without remote read-back.
- It does not contain credentials or assume access to a particular connector.

## Install

Install `skill.zip` through a client that supports the Agent Skills format. The ZIP contains exactly one root directory named `adaptive-boilerplate-architecture-builder`.

## Local validation

From the package root:

```bash
python3 scripts/quick_validate.py . --json
python3 scripts/test_scripts.py --json
python3 scripts/validate_source_map.py . --json
python3 scripts/validate_evals.py . --json
python3 scripts/validate_release_gate.py . --json
python3 scripts/validate_installability.py . --archive ../skill.zip --json
```

Create the archive only after the release gate passes:

```bash
python3 scripts/package_skill.py . --output ../skill.zip --json
```

## Runtime use

A typical safe sequence is:

```text
ASSESS -> RESEARCH -> DECIDE -> PLAN -> BUILD_DRY_RUN
                                      -> ADAPTER_BUILD (only when needed)
                                      -> BUILD_APPLY (explicit authorization)
                                      -> VERIFY -> PR_HANDOFF
```

Detailed contracts are linked directly from `SKILL.md`.
