"""Create a read-only inventory of a repository or project directory."""

from __future__ import annotations

import argparse
import json
import pathlib
import subprocess
from collections import Counter
from typing import Any

from _common import emit, main_guard, sha256_file, utc_now, write_json

IGNORED_DIRS = {".git", ".hg", ".svn", "node_modules", ".venv", "venv", "dist", "build", "target", ".next", ".cache", "__pycache__"}
SENSITIVE_NAMES = {".env", ".env.local", "id_rsa", "id_ed25519", "credentials", "secrets"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repository", type=pathlib.Path)
    parser.add_argument("--output", type=pathlib.Path)
    parser.add_argument("--hash-limit-bytes", type=int, default=2_000_000)
    parser.add_argument("--max-files", type=int, default=20000)
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def git_value(repo: pathlib.Path, argv: list[str]) -> str | None:
    try:
        completed = subprocess.run(["git", *argv], cwd=repo, capture_output=True, text=True, timeout=15, shell=False, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return None
    if completed.returncode != 0:
        return None
    value = completed.stdout.strip()
    return value or None


def parse_remote(remote: str | None) -> dict[str, str | None]:
    if not remote:
        return {"host": None, "owner": None, "name": None}
    normalized = remote.removesuffix(".git")
    if normalized.startswith("git@") and ":" in normalized:
        host_part, path = normalized.split(":", 1)
        host = host_part.split("@", 1)[1]
    elif "://" in normalized:
        from urllib.parse import urlparse

        parsed = urlparse(normalized)
        host = parsed.hostname
        path = parsed.path.lstrip("/")
    else:
        return {"host": None, "owner": None, "name": None}
    parts = path.strip("/").split("/")
    return {"host": host, "owner": parts[-2] if len(parts) >= 2 else None, "name": parts[-1] if parts else None}


def run() -> int:
    args = build_parser().parse_args()
    root = args.repository.resolve()
    if not root.is_dir():
        result = {"status": "failed", "errors": [f"Not a directory: {root}"]}
        emit(result, as_json=args.as_json)
        return 1

    files: list[dict[str, Any]] = []
    extensions: Counter[str] = Counter()
    sensitive_paths: list[str] = []
    truncated = False
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if any(part in IGNORED_DIRS for part in relative.parts):
            continue
        if path.is_symlink() or not path.is_file():
            continue
        if len(files) >= args.max_files:
            truncated = True
            break
        stat = path.stat()
        rel = relative.as_posix()
        suffix = path.suffix.lower() or "[none]"
        extensions[suffix] += 1
        record: dict[str, Any] = {"path": rel, "size": stat.st_size, "suffix": suffix}
        if stat.st_size <= args.hash_limit_bytes:
            record["sha256"] = sha256_file(path)
        else:
            record["sha256"] = None
        files.append(record)
        if path.name.lower() in SENSITIVE_NAMES or "secret" in path.name.lower() or "credential" in path.name.lower():
            sensitive_paths.append(rel)

    git_root = git_value(root, ["rev-parse", "--show-toplevel"])
    is_git = git_root is not None
    remote = git_value(root, ["remote", "get-url", "origin"]) if is_git else None
    current_branch = git_value(root, ["branch", "--show-current"]) if is_git else None
    head_sha = git_value(root, ["rev-parse", "HEAD"]) if is_git else None
    status_porcelain = git_value(root, ["status", "--porcelain=v1", "--untracked-files=all"]) if is_git else None
    default_branch = None
    if is_git:
        symbolic = git_value(root, ["symbolic-ref", "refs/remotes/origin/HEAD"])
        if symbolic and "/" in symbolic:
            default_branch = symbolic.rsplit("/", 1)[-1]

    categories = {
        "architecture": [item["path"] for item in files if "adr" in item["path"].lower() or "architecture" in item["path"].lower()],
        "ci": [item["path"] for item in files if item["path"].startswith(".github/workflows/") or item["path"].lower() in {"jenkinsfile", ".gitlab-ci.yml"}],
        "manifests": [item["path"] for item in files if pathlib.PurePosixPath(item["path"]).name in {"package.json", "pyproject.toml", "pom.xml", "build.gradle", "build.gradle.kts", "go.mod", "Cargo.toml", "Gemfile", "composer.json", "Dockerfile", "compose.yaml", "docker-compose.yml"}],
        "contracts": [item["path"] for item in files if item["path"].lower().endswith(("openapi.yaml", "openapi.yml", "openapi.json", "asyncapi.yaml", "asyncapi.yml", ".graphql", ".proto"))],
        "agent_instructions": [item["path"] for item in files if pathlib.PurePosixPath(item["path"]).name.lower() in {"agents.md", "claude.md", "copilot-instructions.md"}],
        "ownership": [item["path"] for item in files if pathlib.PurePosixPath(item["path"]).name == "CODEOWNERS"],
    }

    inventory = {
        "schema_version": "1.0",
        "generated_at": utc_now(),
        "root": str(root),
        "read_only": True,
        "truncated": truncated,
        "file_count": len(files),
        "extension_counts": dict(sorted(extensions.items())),
        "files": files,
        "categories": categories,
        "sensitive_name_candidates": sensitive_paths,
        "git": {
            "is_repository": is_git,
            "git_root": git_root,
            "remote": remote,
            "remote_identity": parse_remote(remote),
            "current_branch": current_branch,
            "default_branch": default_branch,
            "head_sha": head_sha,
            "worktree_status": "dirty" if status_porcelain else "clean" if is_git else "not_a_git_repository",
            "porcelain": status_porcelain.splitlines() if status_porcelain else [],
        },
    }
    if args.output:
        write_json(args.output, inventory)
    result = {"status": "passed", "inventory": inventory if args.as_json and not args.output else None, "output": str(args.output) if args.output else None, "file_count": len(files), "truncated": truncated}
    emit(result, as_json=args.as_json)
    return 0


if __name__ == "__main__":
    main_guard(run)
