"""Validate installable Agent Skill structure and an optional skill.zip archive."""

from __future__ import annotations

import argparse
import pathlib
import re
import zipfile

from _common import emit, load_data, main_guard

NAME_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


def parse_frontmatter(path: pathlib.Path) -> dict:
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        raise ValueError("SKILL.md lacks YAML frontmatter")
    end = text.find("\n---\n", 4)
    if end < 0:
        raise ValueError("SKILL.md frontmatter is not closed")
    import yaml

    data = yaml.safe_load(text[4:end])
    if not isinstance(data, dict):
        raise ValueError("SKILL.md frontmatter must be an object")
    return data


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_dir", type=pathlib.Path)
    parser.add_argument("--archive", type=pathlib.Path)
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def run() -> int:
    args = build_parser().parse_args()
    root = args.skill_dir.resolve()
    errors: list[str] = []
    if not root.is_dir():
        errors.append(f"skill directory missing: {root}")
        data = {}
    else:
        try:
            data = parse_frontmatter(root / "SKILL.md")
        except (OSError, ValueError) as exc:
            errors.append(str(exc))
            data = {}
    name = data.get("name")
    if name != root.name:
        errors.append(f"frontmatter name {name!r} must match directory {root.name!r}")
    if not isinstance(name, str) or not NAME_PATTERN.fullmatch(name):
        errors.append("invalid skill name")
    for relative in ["SKILL.md", "agents/openai.yaml"]:
        if not (root / relative).is_file():
            errors.append(f"missing installability file: {relative}")
    archive_summary = None
    if args.archive:
        archive = args.archive.resolve()
        if archive.name != "skill.zip":
            errors.append("primary archive must be named skill.zip")
        try:
            with zipfile.ZipFile(archive) as handle:
                bad = handle.testzip()
                names = [name for name in handle.namelist() if name and not name.endswith("/")]
                roots = {pathlib.PurePosixPath(name).parts[0] for name in names}
                if bad:
                    errors.append(f"corrupt archive member: {bad}")
                if roots != {root.name}:
                    errors.append(f"archive must contain exactly one root {root.name}; found {sorted(roots)}")
                if f"{root.name}/SKILL.md" not in names:
                    errors.append("archive lacks root SKILL.md")
                if f"{root.name}/agents/openai.yaml" not in names:
                    errors.append("archive lacks agents/openai.yaml")
                if any(".." in pathlib.PurePosixPath(name).parts or pathlib.PurePosixPath(name).is_absolute() for name in names):
                    errors.append("archive contains unsafe paths")
                archive_summary = {"path": str(archive), "file_count": len(names), "roots": sorted(roots), "corrupt_member": bad}
        except (OSError, zipfile.BadZipFile) as exc:
            errors.append(f"invalid archive: {exc}")
    result = {
        "status": "passed" if not errors else "failed",
        "skill_dir": str(root),
        "archive": archive_summary,
        "chatgpt_install_ready": not errors,
        "frontend_install_suggestion_status": "prepared" if not errors else "blocked",
        "not_controlled_by_skill": ["Client UI behavior", "Upload permissions", "Frontend install-button display"],
        "errors": errors,
    }
    emit(result, as_json=args.as_json)
    return 0 if not errors else 1


if __name__ == "__main__":
    main_guard(run)
