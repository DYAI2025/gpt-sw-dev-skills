"""Shared deterministic helpers for the skill scripts."""

from __future__ import annotations

import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time
from datetime import datetime, timezone
from typing import Any, Iterable, Sequence

try:
    import yaml
except ImportError as exc:  # pragma: no cover - reported by callers
    raise SystemExit("PyYAML is required. Install it in the validation environment.") from exc

try:
    from jsonschema import Draft202012Validator, FormatChecker
except ImportError as exc:  # pragma: no cover - reported by callers
    raise SystemExit("jsonschema is required. Install it in the validation environment.") from exc


class ValidationFailure(Exception):
    """Raised for deterministic validation failures."""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def skill_root() -> pathlib.Path:
    return pathlib.Path(__file__).resolve().parents[1]


def load_data(path: pathlib.Path) -> Any:
    suffix = path.suffix.lower()
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ValidationFailure(f"Cannot read {path}: {exc}") from exc
    try:
        if suffix == ".json":
            return json.loads(text)
        if suffix in {".yaml", ".yml"}:
            return yaml.safe_load(text)
    except (json.JSONDecodeError, yaml.YAMLError) as exc:
        raise ValidationFailure(f"Invalid {suffix.lstrip('.').upper()} in {path}: {exc}") from exc
    raise ValidationFailure(f"Unsupported data format for {path}; expected JSON or YAML.")


def write_json(path: pathlib.Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def emit(result: dict[str, Any], *, as_json: bool) -> None:
    if as_json:
        print(json.dumps(result, indent=2, sort_keys=True))
        return
    status = result.get("status", "unknown")
    print(f"status: {status}")
    for key, value in result.items():
        if key == "status":
            continue
        if isinstance(value, (dict, list)):
            print(f"{key}: {json.dumps(value, sort_keys=True)}")
        else:
            print(f"{key}: {value}")


def validate_against_schema(data: Any, schema_path: pathlib.Path) -> list[str]:
    schema = load_data(schema_path)
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    errors: list[str] = []
    for error in sorted(validator.iter_errors(data), key=lambda item: list(item.absolute_path)):
        location = "/".join(str(part) for part in error.absolute_path) or "$"
        errors.append(f"{location}: {error.message}")
    return errors


def sha256_file(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_tree(root: pathlib.Path, *, exclude: Iterable[str] = ()) -> dict[str, str]:
    excluded = set(exclude)
    hashes: dict[str, str] = {}
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(root).as_posix()
        if any(relative == item or relative.startswith(item.rstrip("/") + "/") for item in excluded):
            continue
        hashes[relative] = sha256_file(path)
    return hashes


def ensure_within(root: pathlib.Path, candidate: pathlib.Path) -> pathlib.Path:
    root_resolved = root.resolve()
    candidate_resolved = candidate.resolve()
    try:
        candidate_resolved.relative_to(root_resolved)
    except ValueError as exc:
        raise ValidationFailure(f"Path escapes allowed root: {candidate}") from exc
    return candidate_resolved


def command_risks(argv: Sequence[str]) -> list[str]:
    if not argv:
        return ["empty command"]
    executable = pathlib.Path(argv[0]).name.lower()
    blocked_executables = {
        "rm",
        "rmdir",
        "del",
        "erase",
        "format",
        "mkfs",
        "dd",
        "sudo",
        "su",
        "shutdown",
        "reboot",
        "halt",
        "poweroff",
        "curl",
        "wget",
        "powershell",
        "pwsh",
    }
    risks: list[str] = []
    if executable in blocked_executables:
        risks.append(f"blocked executable: {executable}")
    lowered = [item.lower() for item in argv[1:]]
    if executable == "git" and ("--force" in lowered or "-f" in lowered):
        risks.append("force git operation")
    if executable == "git" and lowered[:2] in (["push", "--delete"], ["branch", "-d"], ["branch", "-d"]):
        risks.append("branch deletion")
    if executable in {"kubectl", "terraform", "tofu", "pulumi", "aws", "az", "gcloud"}:
        mutation_words = {"apply", "destroy", "delete", "create", "deploy", "up"}
        if mutation_words.intersection(lowered):
            risks.append("cloud or infrastructure mutation")
    shell_tokens = {";", "&&", "||", "|", ">", ">>", "<", "`"}
    for arg in argv:
        if any(token in arg for token in shell_tokens):
            risks.append(f"shell metacharacter in argument: {arg}")
    return sorted(set(risks))


def run_argv(
    argv: Sequence[str],
    *,
    cwd: pathlib.Path,
    timeout_seconds: int,
    env: dict[str, str] | None = None,
) -> dict[str, Any]:
    risks = command_risks(argv)
    if risks:
        raise ValidationFailure("Unsafe command refused: " + "; ".join(risks))
    started = time.monotonic()
    try:
        completed = subprocess.run(
            list(argv),
            cwd=str(cwd),
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            shell=False,
            check=False,
        )
        return {
            "argv": list(argv),
            "cwd": str(cwd),
            "exit_code": completed.returncode,
            "stdout": completed.stdout,
            "stderr": completed.stderr,
            "duration_seconds": round(time.monotonic() - started, 6),
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "argv": list(argv),
            "cwd": str(cwd),
            "exit_code": 124,
            "stdout": exc.stdout or "",
            "stderr": (exc.stderr or "") + f"\nTimed out after {timeout_seconds} seconds.",
            "duration_seconds": round(time.monotonic() - started, 6),
        }
    except OSError as exc:
        return {
            "argv": list(argv),
            "cwd": str(cwd),
            "exit_code": 127,
            "stdout": "",
            "stderr": str(exc),
            "duration_seconds": round(time.monotonic() - started, 6),
        }


def sanitized_environment(extra: dict[str, str] | None = None) -> dict[str, str]:
    allowed = {"PATH", "HOME", "LANG", "LC_ALL", "TMPDIR", "TEMP", "TMP", "SYSTEMROOT", "WINDIR"}
    env = {key: value for key, value in os.environ.items() if key in allowed}
    if extra:
        env.update(extra)
    return env


def exit_for_status(status: str) -> int:
    if status in {"passed", "valid", "ok", "prepared"}:
        return 0
    if status in {"not_run", "skipped", "conditional"}:
        return 3
    return 1


def main_guard(callback: Any) -> None:
    try:
        code = int(callback())
    except ValidationFailure as exc:
        print(json.dumps({"status": "failed", "errors": [str(exc)]}, indent=2), file=sys.stderr)
        code = 1
    raise SystemExit(code)
