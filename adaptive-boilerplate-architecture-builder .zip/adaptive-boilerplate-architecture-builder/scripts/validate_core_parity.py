"""Validate the core-functionality preservation report."""

from __future__ import annotations

import argparse
import pathlib

from _common import emit, load_data, main_guard


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_dir", type=pathlib.Path)
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def run() -> int:
    args = build_parser().parse_args()
    path = args.skill_dir.resolve() / "reports/core-functionality-preservation.json"
    data = load_data(path)
    errors: list[str] = []
    if not isinstance(data, dict):
        errors.append("core parity report must be an object")
    else:
        if data.get("status") != "PASS":
            errors.append("core parity status must be PASS")
        if not data.get("preserved_core_functions"):
            errors.append("preserved_core_functions is required")
        if data.get("unintended_changes"):
            errors.append("unintended_changes must be empty")
        if not isinstance(data.get("minimal_additions"), list):
            errors.append("minimal_additions must be a list")
    result = {"status": "passed" if not errors else "failed", "path": str(path), "errors": errors}
    emit(result, as_json=args.as_json)
    return 0 if not errors else 1


if __name__ == "__main__":
    main_guard(run)
