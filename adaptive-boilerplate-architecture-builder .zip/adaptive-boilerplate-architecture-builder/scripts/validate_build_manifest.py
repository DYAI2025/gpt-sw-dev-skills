"""Validate a build-manifest JSON or YAML document and its command safety."""

from __future__ import annotations

import argparse
import pathlib

from _common import command_risks, emit, load_data, main_guard, skill_root, validate_against_schema


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=pathlib.Path)
    parser.add_argument("--schema", type=pathlib.Path, default=skill_root() / "schemas/build-manifest.schema.json")
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def run() -> int:
    args = build_parser().parse_args()
    data = load_data(args.input)
    errors = validate_against_schema(data, args.schema)
    if isinstance(data, dict):
        for section in ("commands", "validation_gates"):
            for item in data.get(section, []):
                argv = item.get("argv", []) if isinstance(item, dict) else []
                risks = command_risks(argv)
                if risks:
                    errors.append(f"{section}/{item.get('id', 'unknown')}: " + "; ".join(risks))
        target = data.get("target_branch")
        if target in {"main", "master"}:
            errors.append("target_branch must not be a default branch")
        if data.get("mode") == "BUILD_APPLY" and not data.get("authorization_evidence"):
            errors.append("BUILD_APPLY requires authorization_evidence")
    result = {"status": "passed" if not errors else "failed", "input": str(args.input), "errors": errors}
    emit(result, as_json=args.as_json)
    return 0 if not errors else 1


if __name__ == "__main__":
    main_guard(run)
