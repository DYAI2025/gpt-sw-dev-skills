"""Validate the enterprise release-hook report required before packaging."""

from __future__ import annotations

import argparse
import pathlib

from _common import emit, load_data, main_guard


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_dir", type=pathlib.Path)
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def run() -> int:
    args = build_parser().parse_args()
    path = args.skill_dir.resolve() / "reports/release-gate-report.json"
    data = load_data(path)
    errors: list[str] = []
    if not isinstance(data, dict):
        errors.append("release-gate report must be an object")
    else:
        if data.get("status") != "PASS":
            errors.append("status must be PASS before packaging")
        if data.get("craftsmanship_gate") != "PASS":
            errors.append("craftsmanship_gate must be PASS")
        if data.get("anti_confabulation_gate") != "PASS":
            errors.append("anti_confabulation_gate must be PASS")
        score = data.get("anti_sycophancy_score")
        if not isinstance(score, int) or score >= 3:
            errors.append("anti_sycophancy_score must be an integer below 3")
        if data.get("bias_gate") == "BLOCKED":
            errors.append("bias_gate is blocked")
        if data.get("blocked_claims"):
            errors.append("blocked_claims must be empty")
        if data.get("corrections_applied") is not True:
            errors.append("corrections_applied must be true")
        if not data.get("validated_at"):
            errors.append("validated_at is required")
    result = {"status": "passed" if not errors else "failed", "report": str(path), "errors": errors}
    emit(result, as_json=args.as_json)
    return 0 if not errors else 1


if __name__ == "__main__":
    main_guard(run)
