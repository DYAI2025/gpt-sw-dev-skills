"""Launch an optional process and verify a localhost HTTP smoke endpoint."""

from __future__ import annotations

import argparse
import json
import pathlib
import socket
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Sequence

from _common import command_risks, emit, main_guard, sanitized_environment, utc_now


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", required=True)
    parser.add_argument("--expect-status", type=int, default=200)
    parser.add_argument("--expect-json", help="JSON object whose key/value pairs must be present in the response.")
    parser.add_argument("--command-json", help="JSON argv array for a process started before the probe.")
    parser.add_argument("--cwd", type=pathlib.Path, default=pathlib.Path.cwd())
    parser.add_argument("--timeout-seconds", type=int, default=30)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--allow-remote", action="store_true")
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def localhost_only(url: str) -> bool:
    host = urllib.parse.urlparse(url).hostname
    return host in {"127.0.0.1", "localhost", "::1"}


def subset(expected: object, actual: object) -> bool:
    if isinstance(expected, dict) and isinstance(actual, dict):
        return all(key in actual and subset(value, actual[key]) for key, value in expected.items())
    return expected == actual


def terminate(process: subprocess.Popen[str]) -> None:
    if process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


def run() -> int:
    args = build_parser().parse_args()
    errors: list[str] = []
    if not localhost_only(args.url) and not args.allow_remote:
        errors.append("remote smoke URLs require --allow-remote")
    command: Sequence[str] | None = None
    if args.command_json:
        try:
            parsed = json.loads(args.command_json)
            if not isinstance(parsed, list) or not parsed or not all(isinstance(item, str) for item in parsed):
                raise ValueError
            command = parsed
        except (json.JSONDecodeError, ValueError):
            errors.append("--command-json must be a non-empty JSON array of strings")
        if command:
            errors.extend(command_risks(command))
    if errors:
        result = {"status": "failed", "errors": errors}
        emit(result, as_json=args.as_json)
        return 1
    if not args.execute:
        result = {"status": "not_run", "reason": "Pass --execute to launch/probe.", "url": args.url, "command": command}
        emit(result, as_json=args.as_json)
        return 0

    process: subprocess.Popen[str] | None = None
    started = time.monotonic()
    try:
        if command:
            process = subprocess.Popen(list(command), cwd=args.cwd.resolve(), env=sanitized_environment(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, shell=False)
        deadline = started + args.timeout_seconds
        last_error = "not attempted"
        body = b""
        status_code: int | None = None
        while time.monotonic() < deadline:
            if process and process.poll() is not None:
                stdout, stderr = process.communicate(timeout=1)
                last_error = f"process exited {process.returncode}; stdout={stdout[-500:]}; stderr={stderr[-500:]}"
                break
            try:
                with urllib.request.urlopen(args.url, timeout=2) as response:
                    status_code = response.status
                    body = response.read(2_000_000)
                if status_code == args.expect_status:
                    last_error = ""
                    break
                last_error = f"unexpected status {status_code}"
            except (urllib.error.URLError, TimeoutError, socket.timeout) as exc:
                last_error = str(exc)
            time.sleep(0.2)
        if last_error:
            result = {"status": "failed", "checked_at": utc_now(), "url": args.url, "error": last_error, "duration_seconds": round(time.monotonic() - started, 6)}
            emit(result, as_json=args.as_json)
            return 1
        if args.expect_json:
            expected = json.loads(args.expect_json)
            actual = json.loads(body.decode("utf-8"))
            if not subset(expected, actual):
                result = {"status": "failed", "error": "JSON response does not contain expected subset", "expected": expected, "actual": actual}
                emit(result, as_json=args.as_json)
                return 1
        result = {"status": "passed", "checked_at": utc_now(), "url": args.url, "status_code": status_code, "duration_seconds": round(time.monotonic() - started, 6)}
        emit(result, as_json=args.as_json)
        return 0
    finally:
        if process:
            terminate(process)


if __name__ == "__main__":
    main_guard(run)
