"""Validate a compact enterprise-skill evaluation XML report."""

from __future__ import annotations

import argparse
import pathlib
import xml.etree.ElementTree as ET

from _common import emit, main_guard


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("evaluation", type=pathlib.Path)
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def run() -> int:
    args = build_parser().parse_args()
    errors: list[str] = []
    try:
        root = ET.parse(args.evaluation).getroot()
    except (ET.ParseError, OSError) as exc:
        root = None
        errors.append(str(exc))
    if root is not None:
        if root.tag != "enterprise_skill_evaluation":
            errors.append("root must be enterprise_skill_evaluation")
        for tag in ["agent_skills_conformity", "research_quality", "enterprise_readiness", "architecture_quality", "release_gate_integrity", "decision"]:
            if root.find(tag) is None:
                errors.append(f"missing element: {tag}")
        decision = (root.findtext("decision") or "").strip()
        if decision not in {"PASS", "PASS_WITH_LIMITATIONS", "BLOCKED"}:
            errors.append("invalid decision")
    result = {"status": "passed" if not errors else "failed", "errors": errors}
    emit(result, as_json=args.as_json)
    return 0 if not errors else 1


if __name__ == "__main__":
    main_guard(run)
