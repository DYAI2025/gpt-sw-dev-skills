"""Validate a stack-adapter directory, schema, companion files, and command safety."""

from __future__ import annotations

import argparse
import pathlib

from _common import command_risks, emit, load_data, main_guard, skill_root, validate_against_schema


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("adapter_dir", type=pathlib.Path)
    parser.add_argument("--schema", type=pathlib.Path, default=skill_root() / "schemas/stack-adapter.schema.json")
    parser.add_argument("--require-selectable", action="store_true")
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def run() -> int:
    args = build_parser().parse_args()
    adapter_dir = args.adapter_dir.resolve()
    adapter_file = adapter_dir / "adapter.yaml"
    data = load_data(adapter_file)
    errors = validate_against_schema(data, args.schema)
    for relative in ["compatibility.md", "commands.md", "file-manifest.md", "tests", "templates"]:
        if not (adapter_dir / relative).exists():
            errors.append(f"missing companion path: {relative}")
    if isinstance(data, dict):
        for name, argv in data.get("commands", {}).items():
            resolved = ["127.0.0.1" if value == "HOST" else "8080" if value == "PORT" else "/tmp/output" if value == "OUTPUT_DIRECTORY" else value for value in argv]
            risks = command_risks(resolved)
            if risks:
                errors.append(f"commands/{name}: " + "; ".join(risks))
        if args.require_selectable and data.get("selection_status") != "selectable":
            errors.append(f"adapter is not selectable: {data.get('selection_status')}")
        for expected in data.get("expected_files", []):
            if pathlib.PurePosixPath(expected).is_absolute() or ".." in pathlib.PurePosixPath(expected).parts:
                errors.append(f"unsafe expected file path: {expected}")
    result = {
        "status": "passed" if not errors else "failed",
        "adapter": str(adapter_dir),
        "selection_status": data.get("selection_status") if isinstance(data, dict) else None,
        "errors": errors,
    }
    emit(result, as_json=args.as_json)
    return 0 if not errors else 1


if __name__ == "__main__":
    main_guard(run)
