"""Run deterministic structural, syntax, source, eval, security, and release checks for this skill."""

from __future__ import annotations

import argparse
import json
import pathlib
import py_compile
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from typing import Any, Callable

import yaml
from jsonschema import Draft202012Validator

from _common import command_risks, emit, load_data, main_guard, utc_now, validate_against_schema, write_json
import validate_evals as eval_validator

NAME_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
LINK_PATTERN = re.compile(r"\[[^\]]+\]\(([^)]+)\)")
REQUIRED_PATHS = [
    "SKILL.md", "README.md", "CHANGELOG.md", "LICENSE-NOTICE.md", "agents/openai.yaml",
    "references/source-policy.md", "references/source-map.md", "references/source-map.yaml",
    "references/repository-intake.md", "references/evidence-and-confidence-model.md",
    "references/architecture-driver-model.md", "references/quality-scenarios.md",
    "references/candidate-generation.md", "references/tradeoff-and-decision.md",
    "references/architecture-pattern-catalog.md", "references/stack-adapter-contract.md",
    "references/implementation-playbook.md", "references/validation-gates.md",
    "references/github-delivery.md", "references/security-and-supply-chain.md",
    "references/template-lifecycle.md", "references/agent-instruction-policy.md",
    "references/compatibility-notes.md", "references/eval-design.md",
    "references/security-and-tools.md", "references/agent-agnostic-compatibility.md",
    "references/workflow.dot", "adapters/README.md", "adapters/adapter-registry.yaml",
    "adapters/reference-adapter/adapter.yaml", "adapters/reference-adapter/compatibility.md",
    "adapters/reference-adapter/commands.md", "adapters/reference-adapter/file-manifest.md",
    "adapters/reference-adapter/tests/test_adapter_contract.py",
    "schemas/project-intake.schema.json", "schemas/architecture-decision.schema.json",
    "schemas/build-manifest.schema.json", "schemas/stack-adapter.schema.json",
    "schemas/evidence-ledger.schema.json", "schemas/release-decision.schema.json",
    "assets/templates/architecture-decision-record.md", "assets/templates/build-manifest.yaml",
    "assets/templates/evidence-ledger.json", "assets/templates/agents.md",
    "assets/templates/pull-request.md", "assets/templates/c4-context.dsl",
    "assets/templates/c4-container.dsl", "scripts/inventory_repository.py",
    "scripts/validate_project_intake.py", "scripts/validate_architecture_decision.py",
    "scripts/validate_build_manifest.py", "scripts/validate_adapter.py",
    "scripts/validate_architecture_graph.py", "scripts/run_quality_gates.py",
    "scripts/verify_runtime_smoke.py", "scripts/verify_github_state.py",
    "scripts/quick_validate.py", "scripts/package_skill.py", "scripts/validate_source_map.py",
    "scripts/validate_evals.py", "scripts/validate_release_gate.py",
    "scripts/validate_installability.py", "scripts/validate_agent_agnostic.py",
    "scripts/validate_core_parity.py", "scripts/test_scripts.py",
    "scripts/render_reference_adapter.py", "evals/trigger_queries.json",
    "evals/non_trigger_queries.json", "evals/decision_evals.json", "evals/build_evals.json",
    "evals/adversarial_evals.json", "evals/output_evals.json", "evals/evals.json",
    "evals/github_read_only_evals.xml", "evals/mutation_sandbox_scenarios.md",
    "reports/source-audit.md", "reports/requirements-coverage.md", "reports/architecture-gate.md",
    "reports/validation-report.md", "reports/evaluation-report.md", "reports/security-report.md",
    "reports/installability-report.md", "reports/portability-report.md",
    "reports/bias-and-confabulation-audit.md", "reports/release-decision.md",
    "reports/release-gate-report.json", "reports/installability-report.json",
    "reports/core-functionality-preservation.json", "reports/enterprise-skill-evaluation.xml",
]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_dir", type=pathlib.Path)
    parser.add_argument("--report", type=pathlib.Path)
    parser.add_argument("--skip-release", action="store_true", help="Skip release-report checks during an intermediate build only.")
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def parse_frontmatter(path: pathlib.Path) -> tuple[dict[str, Any], str]:
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        raise ValueError("SKILL.md must begin with YAML frontmatter")
    end = text.find("\n---\n", 4)
    if end < 0:
        raise ValueError("SKILL.md frontmatter is not closed")
    data = yaml.safe_load(text[4:end])
    if not isinstance(data, dict):
        raise ValueError("SKILL.md frontmatter must be an object")
    return data, text


def check_links(root: pathlib.Path) -> list[str]:
    errors: list[str] = []
    for path in root.rglob("*.md"):
        if path.is_symlink():
            continue
        for target in LINK_PATTERN.findall(path.read_text(encoding="utf-8")):
            target = target.strip().split("#", 1)[0]
            if not target or target.startswith(("http://", "https://", "mailto:", "{{")):
                continue
            candidate = (path.parent / target).resolve()
            try:
                candidate.relative_to(root)
            except ValueError:
                errors.append(f"{path.relative_to(root)}: link escapes skill root: {target}")
                continue
            if not candidate.exists():
                errors.append(f"{path.relative_to(root)}: broken relative link: {target}")
    return errors


def check_data_files(root: pathlib.Path) -> list[str]:
    errors: list[str] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.is_symlink():
            continue
        try:
            if path.suffix.lower() == ".json":
                json.loads(path.read_text(encoding="utf-8"))
            elif path.suffix.lower() in {".yaml", ".yml"}:
                yaml.safe_load(path.read_text(encoding="utf-8"))
        except Exception as exc:
            errors.append(f"{path.relative_to(root)}: parse error: {exc}")
    for path in sorted((root / "schemas").glob("*.json")):
        try:
            Draft202012Validator.check_schema(json.loads(path.read_text(encoding="utf-8")))
        except Exception as exc:
            errors.append(f"{path.relative_to(root)}: invalid JSON Schema: {exc}")
    return errors


def check_python(root: pathlib.Path) -> list[str]:
    errors: list[str] = []
    for path in sorted(root.rglob("*.py")):
        try:
            py_compile.compile(str(path), doraise=True)
        except py_compile.PyCompileError as exc:
            errors.append(f"{path.relative_to(root)}: {exc.msg}")
    return errors


def check_script_help(root: pathlib.Path) -> list[str]:
    errors: list[str] = []
    for path in sorted((root / "scripts").glob("*.py")):
        if path.name.startswith("_"):
            continue
        completed = subprocess.run(
            [sys.executable, str(path), "--help"], cwd=root, capture_output=True, text=True,
            timeout=20, shell=False, check=False,
        )
        if completed.returncode != 0:
            errors.append(f"{path.relative_to(root)} --help failed: {(completed.stderr or completed.stdout)[-500:]}")
    return errors


def check_text_hygiene(root: pathlib.Path) -> list[str]:
    errors: list[str] = []
    marker_words = ["TO" + "DO", "FIX" + "ME", "T" + "BD", "PLACE" + "HOLDER"]
    secret_patterns = [
        re.compile(r"(?i)(api[_-]?key|access[_-]?token|client[_-]?secret|password)\s*[:=]\s*['\"]?[A-Za-z0-9_\-]{16,}"),
        re.compile(r"AKIA[0-9A-Z]{16}"), re.compile(r"gh[pousr]_[A-Za-z0-9]{30,}"),
        re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    ]
    risky_fragments = ["shell" + "=True", "os." + "system(", "subprocess." + "call(", "eval" + "(", "exec" + "("]
    text_suffixes = {".md", ".py", ".json", ".yaml", ".yml", ".xml", ".dot", ".dsl", ".tmpl", ".toml"}
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.is_symlink() or path.suffix.lower() not in text_suffixes:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        relative = path.relative_to(root).as_posix()
        is_template = relative.startswith("assets/templates/") or relative.startswith("adapters/reference-adapter/templates/")
        if not is_template:
            for word in marker_words:
                if re.search(rf"\b{re.escape(word)}\b", text, re.IGNORECASE):
                    errors.append(f"{relative}: unresolved marker {word}")
        for pattern in secret_patterns:
            if pattern.search(text):
                errors.append(f"{relative}: possible embedded secret")
        if path.suffix.lower() == ".py" and path.name != "quick_validate.py":
            compact = text.replace(" ", "")
            for fragment in risky_fragments:
                if fragment in compact:
                    errors.append(f"{relative}: risky execution construct {fragment}")
    return sorted(set(errors))


def check_source_map(root: pathlib.Path) -> list[str]:
    data = load_data(root / "references/source-map.yaml")
    errors: list[str] = []
    allowed = {"primary", "secondary", "user_provided", "project_internal", "derived", "uncertain"}
    sources = data.get("sources", []) if isinstance(data, dict) else []
    ids: set[str] = set()
    if not sources:
        errors.append("source map has no sources")
    for index, item in enumerate(sources):
        if not isinstance(item, dict):
            errors.append(f"sources/{index}: must be an object")
            continue
        source_id = item.get("id")
        if not source_id or source_id in ids:
            errors.append(f"sources/{index}: missing or duplicate id")
        ids.add(source_id)
        if item.get("classification") not in allowed:
            errors.append(f"sources/{index}: invalid classification")
        if not isinstance(item.get("confidence"), int) or not 1 <= item["confidence"] <= 5:
            errors.append(f"sources/{index}: confidence must be 1..5")
        for field in ("title", "locator", "status", "purpose", "limitations"):
            if not item.get(field):
                errors.append(f"sources/{index}: missing {field}")
    for index, item in enumerate(data.get("missing", []) if isinstance(data, dict) else []):
        if not isinstance(item, dict) or item.get("status") != "MISSING":
            errors.append(f"missing/{index}: requires status MISSING")
        elif not item.get("blocking_for") or not item.get("impact"):
            errors.append(f"missing/{index}: incomplete missing record")
    return errors


def check_evals(root: pathlib.Path) -> list[str]:
    eval_dir = root / "evals"
    errors: list[str] = []
    required = eval_validator.REQUIRED_JSON + ["github_read_only_evals.xml", "mutation_sandbox_scenarios.md"]
    for name in required:
        if not (eval_dir / name).is_file():
            errors.append(f"missing eval artifact: {name}")
    if errors:
        return errors
    errors.extend(eval_validator.validate_query_file(eval_dir / "trigger_queries.json", True))
    errors.extend(eval_validator.validate_query_file(eval_dir / "non_trigger_queries.json", False))
    errors.extend(eval_validator.validate_scenarios(eval_dir / "decision_evals.json", 8))
    errors.extend(eval_validator.validate_scenarios(eval_dir / "build_evals.json", 8))
    errors.extend(eval_validator.validate_scenarios(eval_dir / "adversarial_evals.json", 8))
    errors.extend(eval_validator.validate_output(eval_dir / "output_evals.json"))
    errors.extend(eval_validator.validate_output(eval_dir / "evals.json"))
    errors.extend(eval_validator.validate_xml(eval_dir / "github_read_only_evals.xml"))
    sandbox = (eval_dir / "mutation_sandbox_scenarios.md").read_text(encoding="utf-8").lower()
    if "isolated" not in sandbox or "never" not in sandbox or "default branch" not in sandbox:
        errors.append("mutation sandbox safeguards are incomplete")
    return errors


def check_adapter(root: pathlib.Path) -> list[str]:
    adapter_dir = root / "adapters/reference-adapter"
    data = load_data(adapter_dir / "adapter.yaml")
    errors = validate_against_schema(data, root / "schemas/stack-adapter.schema.json")
    for relative in ["compatibility.md", "commands.md", "file-manifest.md", "tests", "templates"]:
        if not (adapter_dir / relative).exists():
            errors.append(f"missing adapter companion path: {relative}")
    if isinstance(data, dict):
        for name, argv in data.get("commands", {}).items():
            resolved = ["127.0.0.1" if value == "HOST" else "8080" if value == "PORT" else "/tmp/output" if value == "OUTPUT_DIRECTORY" else value for value in argv]
            risks = command_risks(resolved)
            if risks:
                errors.append(f"adapter command {name}: {'; '.join(risks)}")
    return errors


def check_governance(root: pathlib.Path, skip_release: bool) -> list[str]:
    errors: list[str] = []
    compatibility = (root / "references/agent-agnostic-compatibility.md").read_text(encoding="utf-8").lower()
    for term in ["portable", "client-specific", "github", "fallback", "capability"]:
        if term not in compatibility:
            errors.append(f"compatibility note lacks term: {term}")
    core = load_data(root / "reports/core-functionality-preservation.json")
    if not isinstance(core, dict) or core.get("status") != "PASS" or not core.get("preserved_core_functions") or core.get("unintended_changes"):
        errors.append("core functionality preservation report fails")
    if not skip_release:
        release = load_data(root / "reports/release-gate-report.json")
        if not isinstance(release, dict) or release.get("status") != "PASS":
            errors.append("release gate status must be PASS")
        else:
            if release.get("craftsmanship_gate") != "PASS": errors.append("craftsmanship gate must pass")
            if release.get("anti_confabulation_gate") != "PASS": errors.append("anti-confabulation gate must pass")
            if not isinstance(release.get("anti_sycophancy_score"), int) or release["anti_sycophancy_score"] >= 3: errors.append("anti-sycophancy score must be below 3")
            if release.get("bias_gate") == "BLOCKED": errors.append("bias gate is blocked")
            if release.get("blocked_claims"): errors.append("blocked claims remain")
            if release.get("corrections_applied") is not True: errors.append("corrections were not applied")
    try:
        xml_root = ET.parse(root / "reports/enterprise-skill-evaluation.xml").getroot()
        if xml_root.tag != "enterprise_skill_evaluation":
            errors.append("enterprise evaluation root is invalid")
        for tag in ["agent_skills_conformity", "research_quality", "enterprise_readiness", "architecture_quality", "release_gate_integrity", "decision"]:
            if xml_root.find(tag) is None:
                errors.append(f"enterprise evaluation lacks {tag}")
        if (xml_root.findtext("decision") or "").strip() not in {"PASS", "PASS_WITH_LIMITATIONS", "BLOCKED"}:
            errors.append("enterprise evaluation decision is invalid")
    except (ET.ParseError, OSError) as exc:
        errors.append(f"enterprise evaluation XML: {exc}")
    return errors


def run() -> int:
    args = build_parser().parse_args()
    root = args.skill_dir.resolve()
    errors: list[str] = []
    checks: dict[str, Any] = {}
    if not root.is_dir():
        result = {"status": "failed", "errors": [f"not a directory: {root}"]}
        emit(result, as_json=args.as_json)
        return 1
    if root.name != "adaptive-boilerplate-architecture-builder":
        errors.append("skill directory name must be adaptive-boilerplate-architecture-builder")
    for relative in REQUIRED_PATHS:
        if not (root / relative).exists():
            errors.append(f"missing required path: {relative}")
    for path in root.rglob("*"):
        if path.is_symlink():
            errors.append(f"symlink not allowed: {path.relative_to(root)}")
        if path.is_file() and path.stat().st_size == 0:
            errors.append(f"empty file: {path.relative_to(root)}")

    try:
        frontmatter, skill_text = parse_frontmatter(root / "SKILL.md")
        name = frontmatter.get("name")
        description = frontmatter.get("description")
        if name != root.name or not isinstance(name, str) or not NAME_PATTERN.fullmatch(name) or len(name) > 64:
            errors.append("invalid or mismatched frontmatter name")
        if not isinstance(description, str) or not 1 <= len(description) <= 1024:
            errors.append("frontmatter description must contain 1..1024 characters")
        if isinstance(description, str) and ("<" in description or ">" in description):
            errors.append("frontmatter description must not contain angle brackets")
        if len(skill_text.splitlines()) >= 500:
            errors.append("SKILL.md must remain below 500 lines")
        checks["frontmatter"] = {"name": name, "description_length": len(description) if isinstance(description, str) else None, "skill_lines": len(skill_text.splitlines())}
    except (OSError, ValueError, yaml.YAMLError) as exc:
        errors.append(str(exc))

    functions: list[tuple[str, Callable[[pathlib.Path], list[str]]]] = [
        ("data_files", check_data_files), ("markdown_links", check_links),
        ("python_syntax", check_python), ("script_help", check_script_help),
        ("text_hygiene", check_text_hygiene), ("source_map", check_source_map),
        ("evals", check_evals), ("reference_adapter", check_adapter),
    ]
    for label, function in functions:
        found = function(root)
        checks[label] = {"status": "passed" if not found else "failed", "errors": found}
        errors.extend(found)
    governance = check_governance(root, args.skip_release)
    checks["governance"] = {"status": "passed" if not governance else "failed", "errors": governance}
    errors.extend(governance)
    checks["installability"] = {"status": "passed" if (root / "agents/openai.yaml").is_file() else "failed"}

    status = "passed" if not errors else "failed"
    result = {"status": status, "validated_at": utc_now(), "skill_dir": str(root), "errors": sorted(set(errors)), "warnings": [], "checks": checks}
    if args.report:
        write_json(args.report, result)
    emit(result, as_json=args.as_json)
    return 0 if not errors else 1


if __name__ == "__main__":
    main_guard(run)
