"""Validate an architecture-decision JSON document."""

from __future__ import annotations

import argparse
import pathlib

from _common import emit, load_data, main_guard, skill_root, validate_against_schema


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=pathlib.Path)
    parser.add_argument("--schema", type=pathlib.Path, default=skill_root() / "schemas/architecture-decision.schema.json")
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def run() -> int:
    args = build_parser().parse_args()
    data = load_data(args.input)
    errors = validate_against_schema(data, args.schema)
    preferred = data.get("preferred_candidate_id") if isinstance(data, dict) else None
    if isinstance(data, dict) and data.get("status") == "blocked" and preferred is not None:
        errors.append("preferred_candidate_id must be null when status is blocked")
    ids = {item.get("id") for item in data.get("candidates", []) if isinstance(item, dict)} if isinstance(data, dict) else set()
    if preferred is not None and preferred not in ids:
        errors.append("preferred_candidate_id does not identify a candidate")
    result = {"status": "passed" if not errors else "failed", "input": str(args.input), "errors": errors}
    emit(result, as_json=args.as_json)
    return 0 if not errors else 1


if __name__ == "__main__":
    main_guard(run)
