"""Validate the machine-readable source map and confidence policy."""

from __future__ import annotations

import argparse
import pathlib

from _common import emit, load_data, main_guard

ALLOWED_CLASSES = {"primary", "secondary", "user_provided", "project_internal", "derived", "uncertain"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_dir", type=pathlib.Path)
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def run() -> int:
    args = build_parser().parse_args()
    path = args.skill_dir.resolve() / "references/source-map.yaml"
    data = load_data(path)
    errors: list[str] = []
    ids: set[str] = set()
    sources = data.get("sources", []) if isinstance(data, dict) else []
    if not sources:
        errors.append("source map has no sources")
    for index, item in enumerate(sources):
        if not isinstance(item, dict):
            errors.append(f"sources/{index}: must be an object")
            continue
        source_id = item.get("id")
        if not source_id or source_id in ids:
            errors.append(f"sources/{index}: missing or duplicate id")
        ids.add(source_id)
        if item.get("classification") not in ALLOWED_CLASSES:
            errors.append(f"sources/{index}: invalid classification")
        confidence = item.get("confidence")
        if not isinstance(confidence, int) or not 1 <= confidence <= 5:
            errors.append(f"sources/{index}: confidence must be 1..5")
        for field in ("title", "locator", "status", "purpose", "limitations"):
            if not item.get(field):
                errors.append(f"sources/{index}: missing {field}")
    missing = data.get("missing", []) if isinstance(data, dict) else []
    for index, item in enumerate(missing):
        if not isinstance(item, dict) or item.get("status") != "MISSING":
            errors.append(f"missing/{index}: requires status MISSING")
        for field in ("id", "blocking_for", "impact"):
            if not item.get(field):
                errors.append(f"missing/{index}: missing {field}")
    result = {"status": "passed" if not errors else "failed", "source_count": len(sources), "missing_count": len(missing), "errors": errors}
    emit(result, as_json=args.as_json)
    return 0 if not errors else 1


if __name__ == "__main__":
    main_guard(run)
