"""Read GitHub repository, branch, pull-request, changed-file, and check state without mutation."""

from __future__ import annotations

import argparse
import json
import os
import pathlib
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from _common import emit, main_guard, utc_now

DEFAULT_API_VERSION = "2026-03-10"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repository", help="owner/name")
    parser.add_argument("--branch", required=True)
    parser.add_argument("--pull-request", type=int)
    parser.add_argument("--expected-sha")
    parser.add_argument("--expected-base")
    parser.add_argument("--expected-files", type=pathlib.Path, help="JSON array of expected changed file paths.")
    parser.add_argument("--token-env", default="GITHUB_TOKEN")
    parser.add_argument("--api-version", default=DEFAULT_API_VERSION)
    parser.add_argument("--api-base", default="https://api.github.com")
    parser.add_argument("--allow-insecure-localhost", action="store_true", help="Testing only: permit an http://localhost mock API.")
    parser.add_argument("--timeout-seconds", type=int, default=20)
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def safe_api_base(value: str, allow_local: bool) -> str:
    parsed = urllib.parse.urlparse(value)
    if parsed.scheme == "https" and parsed.hostname in {"api.github.com", "github.example.com"}:
        return value.rstrip("/")
    if allow_local and parsed.scheme == "http" and parsed.hostname in {"127.0.0.1", "localhost", "::1"}:
        return value.rstrip("/")
    raise ValueError("api base must be https://api.github.com or an explicitly allowed localhost mock")


def request_json(url: str, token: str | None, api_version: str, timeout: int) -> Any:
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": api_version,
        "User-Agent": "adaptive-boilerplate-architecture-builder/1.0",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers, method="GET")
    with urllib.request.urlopen(request, timeout=timeout) as response:
        raw = response.read(10_000_000)
    return json.loads(raw.decode("utf-8"))


def run() -> int:
    args = build_parser().parse_args()
    if args.repository.count("/") != 1:
        result = {"status": "failed", "errors": ["repository must be owner/name"]}
        emit(result, as_json=args.as_json)
        return 1
    try:
        base = safe_api_base(args.api_base, args.allow_insecure_localhost)
    except ValueError as exc:
        result = {"status": "failed", "errors": [str(exc)]}
        emit(result, as_json=args.as_json)
        return 1
    token = os.environ.get(args.token_env)
    owner_repo = urllib.parse.quote(args.repository, safe="/")
    branch_name = urllib.parse.quote(args.branch, safe="")
    errors: list[str] = []
    try:
        repo = request_json(f"{base}/repos/{owner_repo}", token, args.api_version, args.timeout_seconds)
        branch = request_json(f"{base}/repos/{owner_repo}/branches/{branch_name}", token, args.api_version, args.timeout_seconds)
        head_sha = branch.get("commit", {}).get("sha")
        if args.expected_sha and head_sha != args.expected_sha:
            errors.append(f"branch SHA mismatch: expected {args.expected_sha}, got {head_sha}")
        pull = None
        files: list[str] = []
        checks = None
        if args.pull_request is not None:
            pull = request_json(f"{base}/repos/{owner_repo}/pulls/{args.pull_request}", token, args.api_version, args.timeout_seconds)
            file_records = request_json(f"{base}/repos/{owner_repo}/pulls/{args.pull_request}/files?per_page=100", token, args.api_version, args.timeout_seconds)
            files = sorted(item.get("filename") for item in file_records if isinstance(item, dict) and item.get("filename"))
            if args.expected_base and pull.get("base", {}).get("ref") != args.expected_base:
                errors.append(f"pull-request base mismatch: expected {args.expected_base}, got {pull.get('base', {}).get('ref')}")
            if pull.get("head", {}).get("sha") != head_sha:
                errors.append("pull-request head SHA differs from branch SHA")
            checks = request_json(f"{base}/repos/{owner_repo}/commits/{head_sha}/check-runs?per_page=100", token, args.api_version, args.timeout_seconds)
        if args.expected_files:
            expected = sorted(json.loads(args.expected_files.read_text(encoding="utf-8")))
            if files != expected:
                errors.append(f"changed-file mismatch: expected {expected}, got {files}")
        result = {
            "status": "passed" if not errors else "failed",
            "checked_at": utc_now(),
            "repository": {"full_name": repo.get("full_name"), "default_branch": repo.get("default_branch"), "private": repo.get("private")},
            "branch": {"name": args.branch, "sha": head_sha, "protected": branch.get("protected")},
            "pull_request": None if pull is None else {"number": pull.get("number"), "state": pull.get("state"), "draft": pull.get("draft"), "base": pull.get("base", {}).get("ref"), "head": pull.get("head", {}).get("ref"), "head_sha": pull.get("head", {}).get("sha")},
            "changed_files": files,
            "check_runs": None if checks is None else [{"name": item.get("name"), "status": item.get("status"), "conclusion": item.get("conclusion")} for item in checks.get("check_runs", [])],
            "errors": errors,
        }
        emit(result, as_json=args.as_json)
        return 0 if not errors else 1
    except urllib.error.HTTPError as exc:
        body = exc.read(2000).decode("utf-8", errors="replace")
        result = {"status": "failed", "errors": [f"GitHub HTTP {exc.code}: {body}"]}
        emit(result, as_json=args.as_json)
        return 1
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError) as exc:
        result = {"status": "failed", "errors": [f"GitHub read-back failed: {exc}"]}
        emit(result, as_json=args.as_json)
        return 1


if __name__ == "__main__":
    main_guard(run)
