"""Validate that agent-agnostic compatibility and capability fallbacks are documented."""

from __future__ import annotations

import argparse
import pathlib

from _common import emit, main_guard


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_dir", type=pathlib.Path)
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def run() -> int:
    args = build_parser().parse_args()
    path = args.skill_dir.resolve() / "references/agent-agnostic-compatibility.md"
    errors: list[str] = []
    try:
        text = path.read_text(encoding="utf-8").lower()
    except OSError as exc:
        errors.append(str(exc))
        text = ""
    for term in ["portable", "client-specific", "github", "fallback", "capability"]:
        if term not in text:
            errors.append(f"compatibility note lacks term: {term}")
    result = {"status": "passed" if not errors else "failed", "path": str(path), "errors": errors}
    emit(result, as_json=args.as_json)
    return 0 if not errors else 1


if __name__ == "__main__":
    main_guard(run)
