"""Validate and create exactly one deterministic installable skill.zip archive."""

from __future__ import annotations

import argparse
import json
import pathlib
import subprocess
import sys
import zipfile

from _common import emit, main_guard, sha256_file

EXCLUDED_NAMES = {"__pycache__", ".DS_Store", ".pytest_cache", ".mypy_cache", ".ruff_cache"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".zip"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_dir", type=pathlib.Path)
    parser.add_argument("--output", type=pathlib.Path, default=pathlib.Path("skill.zip"))
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def run() -> int:
    args = build_parser().parse_args()
    root = args.skill_dir.resolve()
    output = args.output.resolve()
    errors: list[str] = []
    if output.name != "skill.zip":
        errors.append("output archive must be named skill.zip")
    if not root.is_dir():
        errors.append(f"skill directory missing: {root}")
    if errors:
        emit({"status": "failed", "errors": errors}, as_json=args.as_json)
        return 1

    validation = subprocess.run(
        [sys.executable, str(root / "scripts/quick_validate.py"), str(root), "--json"],
        cwd=root,
        capture_output=True,
        text=True,
        timeout=180,
        shell=False,
        check=False,
    )
    if validation.returncode != 0:
        emit(
            {
                "status": "failed",
                "errors": ["pre-package quick validation failed"],
                "validation_stdout": validation.stdout[-10000:],
                "validation_stderr": validation.stderr[-10000:],
            },
            as_json=args.as_json,
        )
        return 1

    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(".tmp")
    temporary.unlink(missing_ok=True)
    members: list[str] = []
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(root.rglob("*")):
            if path.is_symlink() or not path.is_file():
                continue
            relative = path.relative_to(root)
            if any(part in EXCLUDED_NAMES for part in relative.parts) or path.suffix.lower() in EXCLUDED_SUFFIXES:
                continue
            arcname = pathlib.PurePosixPath(root.name, *relative.parts).as_posix()
            info = zipfile.ZipInfo(arcname, date_time=(2026, 7, 27, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o644 & 0xFFFF) << 16
            archive.writestr(info, path.read_bytes())
            members.append(arcname)
    temporary.replace(output)

    with zipfile.ZipFile(output) as archive:
        corrupt = archive.testzip()
        archived_names = [name for name in archive.namelist() if name and not name.endswith("/")]
    roots = {pathlib.PurePosixPath(name).parts[0] for name in archived_names}
    archive_errors: list[str] = []
    if corrupt:
        archive_errors.append(f"corrupt archive member: {corrupt}")
    if roots != {root.name}:
        archive_errors.append(f"archive must contain exactly one root {root.name}; found {sorted(roots)}")
    for required in [f"{root.name}/SKILL.md", f"{root.name}/agents/openai.yaml"]:
        if required not in archived_names:
            archive_errors.append(f"archive lacks {required}")
    if any(".." in pathlib.PurePosixPath(name).parts or pathlib.PurePosixPath(name).is_absolute() for name in archived_names):
        archive_errors.append("archive contains unsafe paths")
    if sorted(members) != sorted(archived_names):
        archive_errors.append("archive read-back member list differs from written list")
    if archive_errors:
        output.unlink(missing_ok=True)
        emit({"status": "failed", "errors": archive_errors}, as_json=args.as_json)
        return 1

    result = {
        "status": "passed",
        "archive": str(output),
        "sha256": sha256_file(output),
        "member_count": len(archived_names),
        "root": root.name,
        "corrupt_member": None,
        "quick_validation": json.loads(validation.stdout),
    }
    emit(result, as_json=args.as_json)
    return 0


if __name__ == "__main__":
    main_guard(run)
