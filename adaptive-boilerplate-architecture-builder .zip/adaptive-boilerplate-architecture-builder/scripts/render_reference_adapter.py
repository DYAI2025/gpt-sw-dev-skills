"""Render the non-production reference adapter into an isolated directory."""

from __future__ import annotations

import argparse
import pathlib
import re
import shutil

from _common import emit, main_guard, ValidationFailure

NAME_PATTERN = re.compile(r"^[a-z][a-z0-9_]{1,62}$")
TEMPLATE_MAP = {
    "pyproject.toml.tmpl": "pyproject.toml",
    "README.md.tmpl": "README.md",
    "src___init__.py.tmpl": "src/__init__.py",
    "src_app.py.tmpl": "src/app.py",
    "tests_test_app.py.tmpl": "tests/test_app.py",
    "gitignore.tmpl": ".gitignore",
}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("adapter_dir", type=pathlib.Path)
    parser.add_argument("output_dir", type=pathlib.Path)
    parser.add_argument("--project-name", required=True)
    parser.add_argument("--force", action="store_true", help="Replace files only inside the explicitly supplied output directory.")
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def run() -> int:
    args = build_parser().parse_args()
    if not NAME_PATTERN.fullmatch(args.project_name):
        raise ValidationFailure("project name must match ^[a-z][a-z0-9_]{1,62}$")
    adapter_dir = args.adapter_dir.resolve()
    templates = adapter_dir / "templates"
    output = args.output_dir.resolve()
    if output == pathlib.Path("/") or output == pathlib.Path.home().resolve():
        raise ValidationFailure("refusing unsafe output directory")
    if output.exists() and any(output.iterdir()) and not args.force:
        raise ValidationFailure("output directory is not empty; use --force only in an isolated workspace")
    output.mkdir(parents=True, exist_ok=True)
    rendered: list[str] = []
    for template_name, relative in TEMPLATE_MAP.items():
        source = templates / template_name
        if not source.is_file():
            raise ValidationFailure(f"missing template: {template_name}")
        destination = output / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists() and not args.force:
            raise ValidationFailure(f"refusing to overwrite: {destination}")
        text = source.read_text(encoding="utf-8").replace("{{PROJECT_NAME}}", args.project_name)
        destination.write_text(text, encoding="utf-8")
        rendered.append(relative)
    for cache in output.rglob("__pycache__"):
        if cache.is_dir():
            shutil.rmtree(cache)
    result = {"status": "passed", "output": str(output), "project_name": args.project_name, "rendered_files": sorted(rendered)}
    emit(result, as_json=args.as_json)
    return 0


if __name__ == "__main__":
    main_guard(run)
