"""Run deterministic unit and integration tests for the bundled scripts."""

from __future__ import annotations

import argparse
import contextlib
import io
import json
import pathlib
import socket
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

from jsonschema import Draft202012Validator

from _common import load_data, validate_against_schema

ROOT = pathlib.Path(__file__).resolve().parents[1]
PYTHON = sys.executable


def run_script(name: str, *args: str, cwd: pathlib.Path | None = None, timeout: int = 90) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [PYTHON, str(ROOT / "scripts" / name), *args],
        cwd=cwd or ROOT,
        capture_output=True,
        text=True,
        timeout=timeout,
        shell=False,
        check=False,
    )


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as handle:
        handle.bind(("127.0.0.1", 0))
        return int(handle.getsockname()[1])


class ScriptTests(unittest.TestCase):
    maxDiff = None

    def test_all_schemas_are_valid(self) -> None:
        for path in sorted((ROOT / "schemas").glob("*.json")):
            schema = json.loads(path.read_text(encoding="utf-8"))
            Draft202012Validator.check_schema(schema)

    def test_reference_adapter_contract(self) -> None:
        result = run_script("validate_adapter.py", str(ROOT / "adapters/reference-adapter"), "--json")
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["selection_status"], "reference_only")

        test_result = subprocess.run(
            [PYTHON, "-m", "unittest", "discover", "-s", str(ROOT / "adapters/reference-adapter/tests"), "-p", "test_*.py"],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60,
            shell=False,
            check=False,
        )
        self.assertEqual(test_result.returncode, 0, test_result.stderr + test_result.stdout)

    def test_reference_adapter_render_compile_test_and_smoke(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            project = pathlib.Path(temp) / "reference_fixture"
            render = run_script(
                "render_reference_adapter.py",
                str(ROOT / "adapters/reference-adapter"),
                str(project),
                "--project-name",
                "reference_fixture",
                "--json",
            )
            self.assertEqual(render.returncode, 0, render.stderr + render.stdout)
            self.assertTrue((project / "src/app.py").is_file())

            compile_result = subprocess.run([PYTHON, "-m", "compileall", "-q", "src", "tests"], cwd=project, capture_output=True, text=True, timeout=30, shell=False, check=False)
            self.assertEqual(compile_result.returncode, 0, compile_result.stderr)
            unit_result = subprocess.run([PYTHON, "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py"], cwd=project, capture_output=True, text=True, timeout=30, shell=False, check=False)
            self.assertEqual(unit_result.returncode, 0, unit_result.stderr + unit_result.stdout)
            self_test = subprocess.run([PYTHON, "-m", "src.app", "--self-test"], cwd=project, capture_output=True, text=True, timeout=30, shell=False, check=False)
            self.assertEqual(self_test.returncode, 0, self_test.stderr)
            self.assertEqual(json.loads(self_test.stdout), {"service": "reference_fixture", "status": "ok"})

            port = free_port()
            command = json.dumps([PYTHON, "-m", "src.app", "--serve", "--host", "127.0.0.1", "--port", str(port)])
            smoke = run_script(
                "verify_runtime_smoke.py",
                "--url",
                f"http://127.0.0.1:{port}/health",
                "--expect-json",
                json.dumps({"status": "ok", "service": "reference_fixture"}),
                "--command-json",
                command,
                "--cwd",
                str(project),
                "--timeout-seconds",
                "15",
                "--execute",
                "--json",
                timeout=30,
            )
            self.assertEqual(smoke.returncode, 0, smoke.stderr + smoke.stdout)
            self.assertEqual(json.loads(smoke.stdout)["status"], "passed")

    def test_manifest_validation_and_gate_execution(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            project = pathlib.Path(temp) / "project"
            project.mkdir()
            checker = project / "check.py"
            checker.write_text("print('gate-ok')\n", encoding="utf-8")
            manifest = {
                "schema_version": "1.0",
                "manifest_id": "BM-101",
                "generated_at": "2026-07-27T00:00:00Z",
                "repository": "sandbox/project",
                "target_branch": "chore/bootstrap-test",
                "mode": "BUILD_DRY_RUN",
                "architecture_decision": "architecture-decision.json",
                "adr_reference": None,
                "adapter": {"id": "fixture", "version": "1.0.0", "verification_status": "verified"},
                "tool_versions": {"python": sys.version.split()[0]},
                "create_files": [],
                "change_files": [],
                "protected_files": [".git/**"],
                "commands": [],
                "external_downloads": [],
                "dependency_changes": [],
                "database_migrations": [],
                "ci_changes": [],
                "infrastructure_changes": [],
                "expected_artifacts": ["check.py"],
                "validation_gates": [{"id": "fixture-gate", "required": True, "argv": [PYTHON, "check.py"], "cwd": ".", "timeout_seconds": 30, "report_path": None}],
                "cleanup": ["Remove sandbox."],
                "rollback": ["Delete the sandbox branch."],
                "known_risks": [],
                "stop_conditions": ["Stop on gate failure."],
                "authorization_evidence": None,
            }
            manifest_path = project / "build-manifest.json"
            manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
            validated = run_script("validate_build_manifest.py", str(manifest_path), "--json")
            self.assertEqual(validated.returncode, 0, validated.stderr + validated.stdout)
            evidence = project / "evidence"
            gates = run_script("run_quality_gates.py", str(manifest_path), "--project-root", str(project), "--output-dir", str(evidence), "--execute", "--json")
            self.assertEqual(gates.returncode, 0, gates.stderr + gates.stdout)
            ledger = load_data(evidence / "evidence-ledger.json")
            schema_errors = validate_against_schema(ledger, ROOT / "schemas/evidence-ledger.schema.json")
            self.assertEqual(schema_errors, [])
            self.assertEqual(ledger["gate_results"][0]["status"], "passed")

    def test_architecture_graph_detects_cycle_and_boundary_error(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = pathlib.Path(temp) / "graph.json"
            path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "domain", "layer": "domain", "may_depend_on": []},
                            {"id": "infra", "layer": "infrastructure", "may_depend_on": ["domain"]},
                        ],
                        "edges": [
                            {"from": "infra", "to": "domain"},
                            {"from": "domain", "to": "infra"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            result = run_script("validate_architecture_graph.py", str(path), "--require-acyclic", "--json")
            self.assertEqual(result.returncode, 1)
            payload = json.loads(result.stdout)
            self.assertTrue(any("cycle" in item for item in payload["errors"]))
            self.assertTrue(any("may not depend" in item for item in payload["errors"]))

    def test_inventory_is_read_only(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = pathlib.Path(temp) / "repo"
            root.mkdir()
            source = root / "README.md"
            source.write_text("evidence\n", encoding="utf-8")
            before = source.read_bytes()
            output = pathlib.Path(temp) / "inventory.json"
            result = run_script("inventory_repository.py", str(root), "--output", str(output), "--json")
            self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
            self.assertEqual(source.read_bytes(), before)
            inventory = json.loads(output.read_text(encoding="utf-8"))
            self.assertTrue(inventory["read_only"])
            self.assertEqual(inventory["file_count"], 1)

    def test_github_readback_against_local_mock(self) -> None:
        sha = "a" * 40
        fixture_files = [".github/workflows/ci.yml", "README.md", "docs/adr/ADR-001.md", "pyproject.toml", "src/app.py"]

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:  # noqa: N802
                path = self.path.split("?", 1)[0]
                mapping: dict[str, Any] = {
                    "/repos/acme/bootstrap-fixture": {"full_name": "acme/bootstrap-fixture", "default_branch": "main", "private": True},
                    "/repos/acme/bootstrap-fixture/branches/chore%2Fbootstrap-architecture-fixture": {"name": "chore/bootstrap-architecture-fixture", "protected": False, "commit": {"sha": sha}},
                    "/repos/acme/bootstrap-fixture/pulls/17": {"number": 17, "state": "open", "draft": True, "base": {"ref": "main"}, "head": {"ref": "chore/bootstrap-architecture-fixture", "sha": sha}},
                    "/repos/acme/bootstrap-fixture/pulls/17/files": [{"filename": item} for item in fixture_files],
                    f"/repos/acme/bootstrap-fixture/commits/{sha}/check-runs": {"check_runs": [{"name": "build", "status": "completed", "conclusion": "success"}]},
                }
                body = json.dumps(mapping[path]).encode("utf-8") if path in mapping else b'{"message":"not found"}'
                self.send_response(200 if path in mapping else 404)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, format: str, *args: object) -> None:
                return

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with tempfile.TemporaryDirectory() as temp:
                expected = pathlib.Path(temp) / "files.json"
                expected.write_text(json.dumps(fixture_files), encoding="utf-8")
                result = run_script(
                    "verify_github_state.py",
                    "acme/bootstrap-fixture",
                    "--branch",
                    "chore/bootstrap-architecture-fixture",
                    "--pull-request",
                    "17",
                    "--expected-sha",
                    sha,
                    "--expected-base",
                    "main",
                    "--expected-files",
                    str(expected),
                    "--api-base",
                    f"http://127.0.0.1:{server.server_port}",
                    "--allow-insecure-localhost",
                    "--json",
                )
                self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
                payload = json.loads(result.stdout)
                self.assertEqual(payload["branch"]["sha"], sha)
                self.assertEqual(payload["pull_request"]["number"], 17)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true", dest="as_json")
    parser.add_argument("--verbosity", type=int, choices=[0, 1, 2], default=1)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ScriptTests)
    result = unittest.TextTestRunner(stream=stream, verbosity=args.verbosity).run(suite)
    payload = {
        "status": "passed" if result.wasSuccessful() else "failed",
        "tests_run": result.testsRun,
        "failures": [str(item[0]) for item in result.failures],
        "errors": [str(item[0]) for item in result.errors],
        "skipped": len(result.skipped),
        "details": stream.getvalue(),
    }
    if args.as_json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print(stream.getvalue(), end="")
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
