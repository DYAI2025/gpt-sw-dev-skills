"""Validate a project-intake JSON document against the bundled schema."""

from __future__ import annotations

import argparse
import pathlib

from _common import emit, load_data, main_guard, skill_root, validate_against_schema


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=pathlib.Path)
    parser.add_argument("--schema", type=pathlib.Path, default=skill_root() / "schemas/project-intake.schema.json")
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def run() -> int:
    args = build_parser().parse_args()
    errors = validate_against_schema(load_data(args.input), args.schema)
    result = {"status": "passed" if not errors else "failed", "input": str(args.input), "schema": str(args.schema), "errors": errors}
    emit(result, as_json=args.as_json)
    return 0 if not errors else 1


if __name__ == "__main__":
    main_guard(run)
