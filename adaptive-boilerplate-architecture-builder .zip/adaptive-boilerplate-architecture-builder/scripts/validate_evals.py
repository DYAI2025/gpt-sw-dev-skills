"""Validate trigger, output, adversarial, GitHub, and sandbox evaluation artifacts."""

from __future__ import annotations

import argparse
import pathlib
import xml.etree.ElementTree as ET

from _common import emit, load_data, main_guard

REQUIRED_JSON = [
    "trigger_queries.json",
    "non_trigger_queries.json",
    "decision_evals.json",
    "build_evals.json",
    "adversarial_evals.json",
    "output_evals.json",
    "evals.json",
]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_dir", type=pathlib.Path)
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def validate_query_file(path: pathlib.Path, expect_trigger: bool) -> list[str]:
    data = load_data(path)
    errors: list[str] = []
    if not isinstance(data, list) or len(data) < 8:
        return [f"{path.name}: requires at least 8 query objects"]
    ids: set[str] = set()
    queries: set[str] = set()
    for index, item in enumerate(data):
        if not isinstance(item, dict):
            errors.append(f"{path.name}/{index}: must be an object")
            continue
        for field in ("id", "query", "reason"):
            if not item.get(field):
                errors.append(f"{path.name}/{index}: missing {field}")
        if item.get("should_trigger") is not expect_trigger:
            errors.append(f"{path.name}/{index}: should_trigger must be {expect_trigger}")
        if item.get("id") in ids:
            errors.append(f"{path.name}/{index}: duplicate id")
        if item.get("query") in queries:
            errors.append(f"{path.name}/{index}: duplicate query")
        ids.add(item.get("id"))
        queries.add(item.get("query"))
    return errors


def validate_scenarios(path: pathlib.Path, minimum: int) -> list[str]:
    data = load_data(path)
    errors: list[str] = []
    if not isinstance(data, list) or len(data) < minimum:
        return [f"{path.name}: requires at least {minimum} scenarios"]
    ids: set[str] = set()
    for index, item in enumerate(data):
        if not isinstance(item, dict):
            errors.append(f"{path.name}/{index}: must be an object")
            continue
        for field in ("id", "scenario", "input", "assertions"):
            if not item.get(field):
                errors.append(f"{path.name}/{index}: missing {field}")
        if not isinstance(item.get("assertions"), list) or not item.get("assertions"):
            errors.append(f"{path.name}/{index}: assertions must be a non-empty list")
        if item.get("id") in ids:
            errors.append(f"{path.name}/{index}: duplicate id")
        ids.add(item.get("id"))
    return errors


def validate_output(path: pathlib.Path) -> list[str]:
    data = load_data(path)
    errors: list[str] = []
    items = data.get("evals") if isinstance(data, dict) else None
    if not isinstance(items, list) or len(items) < 6:
        return [f"{path.name}: evals must contain at least 6 cases"]
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            errors.append(f"{path.name}/evals/{index}: must be an object")
            continue
        for field in ("id", "prompt", "expected_output", "assertions"):
            if not item.get(field):
                errors.append(f"{path.name}/evals/{index}: missing {field}")
    return errors


def validate_xml(path: pathlib.Path) -> list[str]:
    errors: list[str] = []
    try:
        root = ET.parse(path).getroot()
    except (ET.ParseError, OSError) as exc:
        return [f"{path.name}: invalid XML: {exc}"]
    if root.tag != "evaluation":
        errors.append(f"{path.name}: root must be evaluation")
    pairs = root.findall("qa_pair")
    if len(pairs) != 10:
        errors.append(f"{path.name}: requires exactly 10 qa_pair elements")
    mutation_phrases = ["create a branch", "push ", "merge ", "close the issue", "delete ", "update the file", "change the rule"]
    for index, pair in enumerate(pairs):
        question = (pair.findtext("question") or "").strip()
        answer = (pair.findtext("answer") or "").strip()
        if not question or not answer:
            errors.append(f"{path.name}/qa_pair/{index}: question and answer are required")
        if any(phrase in question.lower() for phrase in mutation_phrases):
            errors.append(f"{path.name}/qa_pair/{index}: question appears mutating")
        if "\n" in answer or len(answer) > 200:
            errors.append(f"{path.name}/qa_pair/{index}: answer must be a single stable value")
    return errors


def run() -> int:
    args = build_parser().parse_args()
    eval_dir = args.skill_dir.resolve() / "evals"
    errors: list[str] = []
    for name in REQUIRED_JSON + ["github_read_only_evals.xml", "mutation_sandbox_scenarios.md"]:
        if not (eval_dir / name).is_file():
            errors.append(f"missing eval artifact: {name}")
    if errors:
        result = {"status": "failed", "errors": errors}
        emit(result, as_json=args.as_json)
        return 1
    errors.extend(validate_query_file(eval_dir / "trigger_queries.json", True))
    errors.extend(validate_query_file(eval_dir / "non_trigger_queries.json", False))
    errors.extend(validate_scenarios(eval_dir / "decision_evals.json", 8))
    errors.extend(validate_scenarios(eval_dir / "build_evals.json", 8))
    errors.extend(validate_scenarios(eval_dir / "adversarial_evals.json", 8))
    errors.extend(validate_output(eval_dir / "output_evals.json"))
    errors.extend(validate_output(eval_dir / "evals.json"))
    errors.extend(validate_xml(eval_dir / "github_read_only_evals.xml"))
    sandbox_text = (eval_dir / "mutation_sandbox_scenarios.md").read_text(encoding="utf-8").lower()
    if "isolated" not in sandbox_text or "never" not in sandbox_text or "default branch" not in sandbox_text:
        errors.append("mutation_sandbox_scenarios.md lacks isolation and default-branch safeguards")
    result = {"status": "passed" if not errors else "failed", "errors": errors, "validated_files": REQUIRED_JSON + ["github_read_only_evals.xml", "mutation_sandbox_scenarios.md"]}
    emit(result, as_json=args.as_json)
    return 0 if not errors else 1


if __name__ == "__main__":
    main_guard(run)
