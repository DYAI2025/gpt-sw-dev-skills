"""Validate an architecture dependency graph in JSON or syntax-check a DOT file."""

from __future__ import annotations

import argparse
import json
import pathlib
import shutil
import subprocess
import tempfile

from _common import emit, load_data, main_guard


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("graph", type=pathlib.Path)
    parser.add_argument("--require-acyclic", action="store_true")
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def validate_json_graph(path: pathlib.Path, require_acyclic: bool) -> list[str]:
    data = load_data(path)
    errors: list[str] = []
    if not isinstance(data, dict):
        return ["graph root must be an object"]
    nodes = data.get("nodes", [])
    edges = data.get("edges", [])
    node_map: dict[str, dict] = {}
    for index, node in enumerate(nodes):
        if not isinstance(node, dict) or not node.get("id"):
            errors.append(f"nodes/{index}: missing id")
            continue
        if node["id"] in node_map:
            errors.append(f"nodes/{index}: duplicate id {node['id']}")
        node_map[node["id"]] = node
    adjacency = {node_id: [] for node_id in node_map}
    for index, edge in enumerate(edges):
        if not isinstance(edge, dict):
            errors.append(f"edges/{index}: must be an object")
            continue
        source = edge.get("from")
        target = edge.get("to")
        if source not in node_map or target not in node_map:
            errors.append(f"edges/{index}: unknown endpoint {source!r}->{target!r}")
            continue
        if source == target:
            errors.append(f"edges/{index}: self dependency {source}")
        adjacency[source].append(target)
        allowed = node_map[source].get("may_depend_on")
        target_layer = node_map[target].get("layer")
        if isinstance(allowed, list) and target_layer not in allowed:
            errors.append(f"edges/{index}: {source} may not depend on layer {target_layer}")
    if require_acyclic:
        visiting: set[str] = set()
        visited: set[str] = set()

        def visit(node_id: str, trail: list[str]) -> None:
            if node_id in visiting:
                cycle = trail[trail.index(node_id):] + [node_id]
                errors.append("cycle: " + " -> ".join(cycle))
                return
            if node_id in visited:
                return
            visiting.add(node_id)
            trail.append(node_id)
            for child in adjacency.get(node_id, []):
                visit(child, trail)
            trail.pop()
            visiting.remove(node_id)
            visited.add(node_id)

        for node_id in sorted(node_map):
            visit(node_id, [])
    return sorted(set(errors))


def validate_dot(path: pathlib.Path) -> tuple[list[str], str]:
    executable = shutil.which("dot")
    if not executable:
        return ["Graphviz dot executable is unavailable"], "not_run"
    with tempfile.NamedTemporaryFile(suffix=".svg") as output:
        completed = subprocess.run([executable, "-Tsvg", str(path), "-o", output.name], capture_output=True, text=True, timeout=30, shell=False, check=False)
    if completed.returncode != 0:
        return [completed.stderr.strip() or "dot validation failed"], "failed"
    return [], "passed"


def run() -> int:
    args = build_parser().parse_args()
    suffix = args.graph.suffix.lower()
    if suffix == ".json":
        errors = validate_json_graph(args.graph, args.require_acyclic)
        status = "passed" if not errors else "failed"
    elif suffix == ".dot":
        errors, status = validate_dot(args.graph)
    else:
        errors = ["supported formats are .json and .dot"]
        status = "failed"
    result = {"status": status, "graph": str(args.graph), "errors": errors}
    emit(result, as_json=args.as_json)
    return 0 if status == "passed" else 3 if status == "not_run" else 1


if __name__ == "__main__":
    main_guard(run)
