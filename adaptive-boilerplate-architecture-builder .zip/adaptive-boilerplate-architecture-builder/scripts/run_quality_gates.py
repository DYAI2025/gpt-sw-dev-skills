"""Run build-manifest validation gates safely and write an evidence ledger."""

from __future__ import annotations

import argparse
import json
import pathlib
import platform
import shutil

from _common import emit, load_data, main_guard, run_argv, sanitized_environment, sha256_file, utc_now, validate_against_schema, write_json


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=pathlib.Path)
    parser.add_argument("--project-root", type=pathlib.Path, required=True)
    parser.add_argument("--output-dir", type=pathlib.Path, required=True)
    parser.add_argument("--execute", action="store_true", help="Execute gates. Without this flag the script reports a dry run.")
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser


def tool_version(executable: str) -> str:
    path = shutil.which(executable)
    if not path:
        return "unavailable"
    result = run_argv([path, "--version"], cwd=pathlib.Path.cwd(), timeout_seconds=10, env=sanitized_environment())
    first = (result["stdout"] or result["stderr"]).strip().splitlines()
    return first[0][:300] if first else "available-version-unknown"


def run() -> int:
    args = build_parser().parse_args()
    manifest_path = args.manifest.resolve()
    project_root = args.project_root.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    data = load_data(manifest_path)
    schema = pathlib.Path(__file__).resolve().parents[1] / "schemas/build-manifest.schema.json"
    schema_errors = validate_against_schema(data, schema)
    if schema_errors:
        result = {"status": "failed", "errors": schema_errors}
        emit(result, as_json=args.as_json)
        return 1

    results: list[dict] = []
    required_failure = False
    for gate in data["validation_gates"]:
        gate_id = gate["id"]
        cwd = (project_root / gate["cwd"]).resolve()
        try:
            cwd.relative_to(project_root)
        except ValueError:
            result = {"status": "failed", "errors": [f"gate {gate_id} escapes project root"]}
            emit(result, as_json=args.as_json)
            return 1
        stdout_path = output_dir / f"{gate_id}.stdout.log"
        stderr_path = output_dir / f"{gate_id}.stderr.log"
        if not args.execute:
            gate_result = {
                "id": gate_id,
                "required": bool(gate["required"]),
                "status": "not_run",
                "timestamp": utc_now(),
                "argv": gate["argv"],
                "cwd": str(cwd),
                "tool": gate["argv"][0],
                "tool_version": "not_run",
                "exit_code": None,
                "duration_seconds": 0,
                "stdout_log": None,
                "stderr_log": None,
                "report_path": gate.get("report_path"),
                "artifact_hashes": {},
                "reason": "Dry run; pass --execute to run gates.",
            }
        else:
            execution = run_argv(gate["argv"], cwd=cwd, timeout_seconds=gate["timeout_seconds"], env=sanitized_environment())
            stdout_path.write_text(execution["stdout"], encoding="utf-8")
            stderr_path.write_text(execution["stderr"], encoding="utf-8")
            status = "passed" if execution["exit_code"] == 0 else "failed"
            artifact_hashes = {"manifest": sha256_file(manifest_path)}
            report_path = gate.get("report_path")
            if report_path:
                report = (project_root / report_path).resolve()
                if report.is_file():
                    artifact_hashes[report_path] = sha256_file(report)
            gate_result = {
                "id": gate_id,
                "required": bool(gate["required"]),
                "status": status,
                "timestamp": utc_now(),
                "argv": execution["argv"],
                "cwd": execution["cwd"],
                "tool": gate["argv"][0],
                "tool_version": tool_version(gate["argv"][0]),
                "exit_code": execution["exit_code"],
                "duration_seconds": execution["duration_seconds"],
                "stdout_log": str(stdout_path),
                "stderr_log": str(stderr_path),
                "report_path": report_path,
                "artifact_hashes": artifact_hashes,
                "reason": "Command completed." if status == "passed" else "Command failed; inspect logs.",
            }
            if status == "failed" and gate["required"]:
                required_failure = True
        results.append(gate_result)

    overall = "failed" if required_failure else "not_run" if not args.execute else "passed"
    ledger = {
        "schema_version": "1.0",
        "generated_at": utc_now(),
        "subject": f"quality gates for {project_root}",
        "records": [],
        "gate_results": results,
        "overall_status": overall,
        "runner": {"python": platform.python_version(), "platform": platform.platform()},
    }
    ledger_path = output_dir / "evidence-ledger.json"
    write_json(ledger_path, ledger)
    result = {"status": overall, "ledger": str(ledger_path), "gate_count": len(results), "required_failure": required_failure}
    emit(result, as_json=args.as_json)
    return 1 if required_failure else 0


if __name__ == "__main__":
    main_guard(run)
