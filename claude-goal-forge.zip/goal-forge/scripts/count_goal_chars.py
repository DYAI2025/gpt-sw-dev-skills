#!/usr/bin/env python3
"""Validate and count a Goal Forge output.

Usage:
  python scripts/count_goal_chars.py goal.txt
  python scripts/count_goal_chars.py --body-only goal_body.txt

Default mode validates the complete runtime output and the embedded body.
Counts Unicode code points with Python len(str), not UTF-8 bytes.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

REQUIRED_SECTIONS = [
    "Goal:",
    "Ziel.",
    "Scope.",
    "Bedingungen (hart).",
    "Akzeptanzkriterien.",
    "Explizit out-of-scope.",
    "Done-Definition.",
    "Reference-Doc:",
]

FORBIDDEN_WEAK_WORDS = [
    " maybe ",
    " possibly ",
    " should ",
    " could ",
    " nice ",
    " good ",
    " better ",
    " ggf. ",
    " eventuell ",
    " vielleicht ",
    " sollte ",
    " koennte ",
    " könnte ",
]

TOTAL_LIMIT = 3999
BODY_TARGET = 3600


def extract_body(text: str) -> str:
    start = text.find("Goal:")
    if start == -1:
        return text.strip()
    match = re.search(r"^Reference-Doc:.*$", text[start:], flags=re.MULTILINE)
    if not match:
        return text[start:].strip()
    end = start + match.end()
    return text[start:end].strip()


def count_out_of_scope(body: str) -> int:
    pattern = r"Explizit out-of-scope\.\s*(.*?)(?:\n\s*Done-Definition\.|\Z)"
    match = re.search(pattern, body, flags=re.DOTALL)
    if not match:
        return 0
    return len(re.findall(r"^\s*-\s+", match.group(1), flags=re.MULTILINE))


def validate_body(body: str) -> list[str]:
    errors: list[str] = []
    last_index = -1
    for section in REQUIRED_SECTIONS:
        index = body.find(section)
        if index == -1:
            errors.append(f"missing section: {section}")
        elif index < last_index:
            errors.append(f"section out of order: {section}")
        else:
            last_index = index

    if count_out_of_scope(body) < 3:
        errors.append("Explizit out-of-scope must contain at least 3 bullets")

    title_line = next((line for line in body.splitlines() if line.startswith("Goal:")), "")
    if len(title_line.removeprefix("Goal:").strip()) > 80:
        errors.append("Goal title is longer than 80 characters")

    lower = f" {body.lower()} "
    weak_hits = [word.strip() for word in FORBIDDEN_WEAK_WORDS if word in lower]
    if weak_hits:
        errors.append("weak or optional language found: " + ", ".join(sorted(set(weak_hits))))
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", help="Path to a Goal Forge output or body file")
    parser.add_argument("--body-only", action="store_true", help="Input is only the goal body")
    args = parser.parse_args()

    text = Path(args.path).read_text(encoding="utf-8").strip()
    body = text if args.body_only else extract_body(text)
    total_count = len(text)
    body_count = len(body)

    errors: list[str] = []
    if not args.body_only and total_count > TOTAL_LIMIT:
        errors.append(f"complete output too long: {total_count}/{TOTAL_LIMIT} characters")
    if body_count > BODY_TARGET:
        errors.append(f"goal body exceeds target: {body_count}/{BODY_TARGET} characters")
    errors.extend(validate_body(body))

    print(f"total={total_count}/{TOTAL_LIMIT}")
    print(f"body={body_count}/{BODY_TARGET}")
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print("goal forge output valid")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
