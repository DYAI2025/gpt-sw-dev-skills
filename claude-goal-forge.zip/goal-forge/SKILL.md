---
name: goal-forge
description: creates software-project-management grade /goal objectives under a hard 3999-character total output limit. use when the user asks for a goal, /goal, coding-agent objective, implementation target, backlog-ready work package, acceptance criteria, definition of done, branch/test constrained task, or a bounded software change that must avoid ambiguity, scope creep, secrets, and destructive actions.
---

# Goal Forge

## Purpose
Forge vague work requests into one executable software-project objective for `/goal`. The output must be short, bounded, testable, and safe enough for a coding agent to execute without avoidable follow-up questions.

Hard limit: the complete skill response, including wrapper, goal body, and any count line, must never exceed 3999 Unicode characters. Prefer 1800-3200 characters total. Use `scripts/count_goal_chars.py` when Python can run.

Consult references only when needed:
- `references/goal-contract.md` for the output contract and validation rules.
- `references/software-pm-objective-criteria.md` for objective-quality gates.

## Non-negotiable rules

1. Keep the entire runtime output at or below 3999 Unicode characters. The goal body should normally stay at or below 3600 characters to leave room for the compact wrapper.
2. Produce one executable goal unless the user explicitly asks for a sequence. If one safe goal cannot fit, output only Goal 1 and place detail in `Reference-Doc:`.
3. Do not invent repo facts. If branch, tests, framework, package manager, or baseline are unobserved, state a conservative default.
4. Ask at most one focused clarification only when the missing decision changes architecture, target, authorization, or destructive risk. Include a default.
5. Never include literal secrets, credentials, private keys, tokens, or destructive commands as acceptance criteria.
6. Reject vague objective quality. Every acceptance criterion must be pass/fail verifiable.
7. Avoid option language inside the goal: no `maybe`, `possibly`, `should`, `could`, `eventuell`, `vielleicht`, `sollte`, `koennte`, or open `X or Y` alternatives. Choose a default or ask once.
8. Include at least three explicit out-of-scope bullets to prevent scope creep.

## Workflow

### 1. Parse the request
Extract: main verb, target object, stakeholder/user value, expected deliverable, repo/tool context, constraints, risks, forbidden actions, and existing evidence.

### 2. Classify the work type
Choose one type and let it drive defaults:
- `feat`: new behavior or capability.
- `fix`: defect correction.
- `refactor`: internal change with unchanged behavior.
- `chore`: tooling, config, maintenance.
- `spike`: bounded research with a decision artifact.

### 3. Apply software-PM objective criteria
Create a goal that satisfies:
- Outcome clarity: what changes and who benefits.
- Scope boundary: branch, layers, modules, integration surface.
- Quality gate: tests, review, security, observability, or documentation as relevant.
- Acceptance criteria: binary, measurable, externally checkable.
- Done definition: final artifact plus verification path.
- Traceability: reference issue, document, or `n/a`.

### 4. Set safe defaults
Use these defaults unless contradicted by user input or observed repo conventions:
- Branch: `feat/<slug>`, `fix/<slug>`, `refactor/<slug>`, `chore/<slug>`, or `spike/<slug>`.
- Dependencies: no new runtime dependencies.
- Git: never commit directly to `main` or `master`; no `push --force`, no `--no-verify`, no history rewrite.
- Tests: run existing project tests before and after. Preserve or improve the baseline.
- TDD: required for domain logic, validation logic, API behavior, data transforms, and bug fixes.
- Large files: inspect before editing and change in small coherent patches.

### 5. Compose the compact goal
Use exactly this body order:
1. `Goal:` short title, max 80 characters.
2. `Ziel.` two to four short sentences: outcome, user value, reason.
3. `Scope.` branch, files/modules/layers, boundaries.
4. `Bedingungen (hart).` hard constraints.
5. `Akzeptanzkriterien.` measurable bullets.
6. `Explizit out-of-scope.` at least three bullets.
7. `Done-Definition.` one sentence with artifact and verification.
8. `Reference-Doc:` path or `n/a`.

### 6. Enforce character budget
Draft, count, compress, recount.
- If total output is above 3600 characters, shorten `Ziel.` and `Scope.`, merge conditions, keep only the top acceptance criteria, and move detail to `Reference-Doc:`.
- If exact counting is impossible, keep the total visibly short and omit all commentary except the compact output.
- Never output an over-budget goal.

### 7. Self-check
Before final output verify:
- total output <=3999 characters;
- body <=3600 characters unless wrapper is still within total limit;
- all mandatory sections exist in order;
- at least three out-of-scope bullets exist;
- acceptance criteria are binary and testable;
- no invented repo fact, literal secret, destructive action, weak option wording, or hidden scope expansion exists.

## Output format

If clarification is mandatory, output only one question plus the default and keep it under 3999 characters.

Otherwise return exactly this compact wrapper and body:

```text
GF total=<t>/3999 body=<b>/3600
Goal: <title>

Ziel. <2-4 short sentences>

Scope. <branch, layers/files/modules, boundaries>

Bedingungen (hart).
- <hard condition>
- <hard condition>

Akzeptanzkriterien.
- <measurable pass/fail criterion>
- <measurable pass/fail criterion>

Explizit out-of-scope.
- <exclusion>
- <exclusion>
- <exclusion>

Done-Definition. <one sentence with artifact and verification path>

Reference-Doc: <path or n/a>
END
```

The copyable `/goal` body starts at `Goal:` and ends at `Reference-Doc:`. The complete response including `GF` and `END` must be <=3999 characters.

## Examples

### Vague but actionable
Input: `mach ein goal fuer email-validierung im login-flow`
Behavior: choose `feat/login-email-validation`, require no new runtime dependencies, require validation tests, exclude OAuth, magic links, password policy, and UI redesign.

### Ambiguous mandate
Input: `goal fuer: verbessere auth`
Behavior: ask one question: `Meinst du Refactor ohne Verhaltensaenderung, neue Security-Funktion oder Provider-Migration? Default: Refactor ohne Verhaltensaenderung.`

### Too large
Input: full sprint plan with many tasks.
Behavior: create only the first executable goal, put detail into `Reference-Doc: docs/goals/<slug>.md`, and keep total output <=3999 characters.
