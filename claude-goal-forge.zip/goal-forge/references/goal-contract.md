# Goal Forge Contract

## Character budget

- Hard maximum: 3999 Unicode characters for the complete runtime output.
- Complete output includes the `GF` line, goal body, blank lines, and `END`.
- Goal body starts at `Goal:` and ends at the `Reference-Doc:` line.
- Body target: <=3600 characters. This leaves room for wrapper and exact counts.
- Preferred total range for ordinary work: 1800-3200 characters.
- Start compression at 3200 total characters. Mandatory compression above 3600.

## Required body sections

1. `Goal:`
   - One identifier line under 80 characters.
   - No vague verbs such as improve, optimize, clean up, or fix stuff without a target.

2. `Ziel.`
   - Two to four short sentences.
   - State outcome, user/stakeholder value, and reason.
   - Do not list implementation steps.

3. `Scope.`
   - State branch, affected layer, files/modules, integration surface, and hard boundaries.

4. `Bedingungen (hart).`
   Include relevant constraints:
   - branch rule;
   - dependency lock;
   - test baseline;
   - TDD requirement where applicable;
   - no direct main/master work;
   - no destructive git/database/production actions without authorization;
   - no secrets in code, logs, prompts, or output.

5. `Akzeptanzkriterien.`
   - Every bullet must be externally checkable.
   - Use evidence such as tests pass, file exists, endpoint returns status, UI state visible, metric threshold reached, or report generated.
   - Avoid subjective wording unless operationalized.

6. `Explizit out-of-scope.`
   - At least three bullets.
   - Name plausible scope temptations: UI redesign, provider migration, new dependencies, unrelated refactor, production deploy.

7. `Done-Definition.`
   - One sentence only.
   - Name final artifact: PR, branch, commit range, tag, deploy URL, report, or generated file.
   - Include verification path.

8. `Reference-Doc:`
   - Use `n/a` when no external plan document is needed.
   - Use a path when detail must move out of the goal body.

## Safe defaults

| Missing item | Default |
|---|---|
| Branch | derive `feat/`, `fix/`, `refactor/`, `chore/`, or `spike/` from work type |
| Dependency policy | no new runtime dependencies |
| Test baseline observed | preserve exact pass count and command |
| Test baseline not observed | require baseline run before and after changes |
| Done artifact unknown | PR against the repository base branch with green tests |
| Out-of-scope missing | generate at least three likely exclusions |
| Secrets mentioned | replace literal secret with env-var or secret-manager reference |

## Mandatory clarification triggers

Ask one focused question before producing the goal when:
- the main verb changes architecture;
- several targets compete for priority;
- the final artifact cannot be inferred and matters;
- the user asks for destructive or irreversible operations;
- authorization, credentials, production access, or compliance scope is unclear.

## Compression strategy

1. Remove adjectives and narrative filler.
2. Merge related hard conditions.
3. Keep only top acceptance criteria.
4. Move implementation plan detail to `Reference-Doc:`.
5. Split into sequential goals if one goal cannot stay under the total limit without losing executability.
