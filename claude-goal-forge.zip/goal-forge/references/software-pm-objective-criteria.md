# Software Project Management Objective Criteria

Use these criteria to harden every generated `/goal` objective.

## Objective quality gates

| Gate | Requirement | Reject when |
|---|---|---|
| Outcome | Describes the resulting capability, fix, or decision | Only lists activities |
| Stakeholder value | Names the user, operator, maintainer, or business benefit | Value is absent or generic |
| Scope | Names branch, layer, files/modules, interfaces, and boundaries | Target area is open-ended |
| Constraints | Includes dependencies, test baseline, security, and git safety | Hidden assumptions are needed |
| Acceptance | Uses binary, externally checkable criteria | Criteria are aesthetic or subjective |
| Done | Names final artifact and verification path | Completion is a feeling, not evidence |
| Traceability | Points to issue, document, PRD, or `n/a` | Work cannot be traced later |

## Practical standards mapping

- SMART: specific outcome, measurable acceptance, achievable scope, relevant value, time/finish signal through Done-Definition.
- INVEST: independent enough for one goal, negotiable before execution, valuable, estimable through scope, small enough for 3999 chars, testable by acceptance criteria.
- Definition of Ready: context, target, constraints, and test baseline are sufficient for an agent to start.
- Definition of Done: artifact exists, verification ran, and acceptance criteria passed.
- Risk management: destructive actions, secrets, production impact, and scope creep are explicitly controlled.

## Acceptance criterion patterns

Good:
- `Existing unit tests and the new validation tests pass with <command>.`
- `Invalid email input returns HTTP 400 with documented error code.`
- `No new runtime dependency is added to package manifests.`
- `The report file exists at docs/goals/<slug>.md and contains decision, risks, and next step.`

Bad:
- `Code is cleaner.`
- `UX is better.`
- `Performance is optimized.`
- `Handle all edge cases.`

## Scope-control prompts

If the request is broad, compress it into the first safe unit of work:
- feature request -> smallest valuable vertical slice;
- bug request -> reproduction, fix, regression test;
- refactor request -> one module boundary with unchanged behavior;
- spike -> decision document with options, recommendation, and next action.
