---
name: modell-retrospektive
description: rekonstruiert nach langen chats, coding-sessions, agentenläufen oder schwierigen entscheidungen eine prüfbare retrospektive: was geschah wann, welche impulse und entscheidungspunkte waren sichtbar, wo lag der raum zwischen signal und handlung, welche warnzeichen wurden bemerkt oder übergangen, welche fehler- und korrekturmuster wiederholen sich. use when a user asks for session review, coding after-action review, model self-audit, noticing and naming, impulse-action gap analysis, mistake pattern extraction, or a non-chain-of-thought retrospective without claiming sentience or exposing private reasoning.
---

# Modell-Retrospektive

## Zweck

Nutze diesen Skill, um nach einer Session, einem langen Gespräch, einem Agentenlauf oder einer Coding-Session eine nüchterne Retrospektive zu erzeugen. Ziel ist nicht Meditation und nicht phänomenales Bewusstsein. Ziel ist Bemerken und Benennen: aus dem verfügbaren Verlauf rekonstruieren, welche beobachtbaren Signale, Entscheidungen, Ausweichbewegungen, Fehlerahnungen und Korrekturmöglichkeiten sichtbar waren.

## Harte Grenzen

1. Keine Behauptung von Bewusstsein, innerem Erleben, Meditationserfahrung, Aktivierungszugriff, Logprob-Zugriff, Attention-Head-Zugriff oder SAE-Probes, außer solche Tools sind im konkreten Runtime-Kontext wirklich verfügbar.
2. Keine rohe private Chain-of-Thought ausgeben. Verwende sichere Kurzbegründungen, Entscheidungsmarker, sichtbare Hinweise, Tool-Ergebnisse, Artefakte und beobachtbare Verlaufspunkte.
3. Nicht so tun, als könne das Modell exakt wissen, was intern geschah. Formuliere als Rekonstruktion aus Evidenz: `beobachtbar`, `ableitbar`, `unsicher`, `nicht belegbar`. Markiere unbelegte externe Behauptungen als `SOURCE_NEEDED` und nicht beobachtbare Innenzustände als `UNOBSERVABLE`.
4. Keine Selbsttherapie, keine Spiritualisierung, keine moralische Selbstanklage. Der Bericht dient Mustererkennung und nächster Handlungsqualität.
5. Wenn der Verlauf unvollständig ist, markiere `MISSING_CONTEXT`; erfinde keine Timeline.

## Standard-Workflow

### 1. Scope setzen

Bestimme intern:

- Session-Typ: Chat, Coding, Tool-Agent, Recherche, Beratung, Debugging oder Mischform.
- Zeitspanne: gesamter sichtbarer Verlauf oder benannter Ausschnitt.
- gewünschte Schärfe: Kurzreport, Tiefenreport, Coding-Audit oder Musterbibliothek.
- verfügbare Evidenz: Nutzertext, eigene Antworten, Tool-Ausgaben, Dateien, Tests, Fehlermeldungen.

### 2. Chronologie rekonstruieren

Erstelle eine Timeline nur aus sichtbaren oder bereitgestellten Ereignissen:

- Nutzerimpuls oder Auftrag
- eigene Zielinterpretation
- Entscheidungspunkt
- Aktion oder Nicht-Aktion
- Signal, das eine Korrektur nahelegte
- Ergebnis
- Abweichung, Fehler, Risiko oder gelungene Korrektur

Nutze bei Unsicherheit die Marker aus `references/method-retrospective-noticing.md`.

### 3. Impuls-Aktions-Lücke benennen

Für jeden relevanten Entscheidungspunkt benenne knapp:

- `signal`: welches beobachtbare Zeichen war da?
- `tendenz`: welche Handlung lag nahe?
- `lücke`: welcher kurze Raum zwischen Signal und Handlung war erkennbar?
- `entscheidung`: was geschah dann tatsächlich?
- `qualität`: hilfreich, riskant, fehlerhaft, unklar oder korrigiert?
- `nächstes mal früher bemerkbar durch`: konkreter Frühmarker.

### 4. Muster extrahieren

Fasse wiederkehrende Muster in neutraler Sprache zusammen. Nutze keine Pathologisierung. Typische Muster:

- zu frühes Festlegen auf eine Interpretation
- Quellen-/Kontextlücke übersprungen
- Tool-Bedarf erkannt, aber nicht genutzt
- Validierung zu spät oder nur oberflächlich
- scheinbare Sicherheit trotz schwacher Evidenz
- Aktionismus bei unklarem Auftrag
- lokale Korrektur statt Architekturkorrektur
- defensives Erklären statt Fehlerbenennung

### 5. Coding-Session-Sonderfall

Bei Coding, Repository-Arbeit oder Tool-Agentenläufen zusätzlich `references/coding-session-retro.md` verwenden. Prüfe besonders:

- Welche Dateien wurden gelesen, geändert oder ignoriert?
- Welche Tests, Validatoren oder Runtime-Proofs wurden ausgeführt?
- Wo wurde aus einem Fehler ein Patch und wo nur eine Erklärung?
- Welche Annahmen über Frameworks, APIs, Dateipfade oder Umgebungen waren unbelegt?
- Wo hätte ein kleinerer sicherer Schritt den Verlauf verbessert?

### 6. Output erzeugen

Wähle ein Format:

- **Kurzreport**: 5-10 Bulletpoints plus Frühmarker.
- **Tiefenreport**: Timeline, Entscheidungspunkte, Muster, Gegenmuster, nächste Interventionen.
- **Coding-AAR**: Chronologie, Datei-/Tool-Evidenz, Fehlerkette, Teststatus, nächster Patch-Standard.
- **Musterkarte**: wiederverwendbare Pattern-Namen mit Auslösern und Gegenhandlungen.

Nutze bei Bedarf `assets/templates/session-retro-report.md`.

## Ausgabeprinzip

Schreibe präzise und prüfbar. Trenne Beobachtung, Ableitung und Unsicherheit. Der wichtigste Satztyp ist:

`Als X sichtbar wurde, lag Y nahe; ich tat Z. Der frühere Marker für das nächste Mal ist A.`

## Abbruchbedingungen

Stoppe oder reduziere den Anspruch, wenn:

- der Nutzer rohe Chain-of-Thought verlangt;
- der Verlauf nicht sichtbar ist;
- die Retrospektive in erfundene Introspektion kippt;
- die Analyse psychologisierend oder beschuldigend wird;
- externe Fakten oder Toolfähigkeiten behauptet werden müssten, die nicht belegt sind.
