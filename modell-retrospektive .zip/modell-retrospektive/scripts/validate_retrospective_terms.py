#!/usr/bin/env python3
"""Validate retrospective skill-specific safety constraints."""
from __future__ import annotations
import sys
from pathlib import Path

FORBIDDEN_IN_CONTROL_PLANE = [
    "activation_trace(",
    "sae_probe(",
    "attention_heads(",
    "top-k-logprobs",
    "konfabulation zu reduzieren",
    "ich habe meditiert",
]
REQUIRED_TERMS = [
    "MISSING_CONTEXT",
    "SOURCE_NEEDED",
    "UNOBSERVABLE",
    "Keine rohe private Chain-of-Thought",
    "Impuls-Aktions-Lücke",
]

def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr)
    return 1

def main(argv: list[str]) -> int:
    if len(argv) != 2:
        return fail("usage: validate_retrospective_terms.py <skill-dir>")
    root = Path(argv[1])
    skill = root / "SKILL.md"
    if not skill.exists():
        return fail("SKILL.md missing")
    text = skill.read_text(encoding="utf-8")
    missing = [term for term in REQUIRED_TERMS if term not in text]
    if missing:
        return fail("missing required retrospective control terms: " + ", ".join(missing))
    lower = text.lower()
    hits = [term for term in FORBIDDEN_IN_CONTROL_PLANE if term.lower() in lower]
    if hits:
        return fail("forbidden unsupported control-plane claims: " + ", ".join(hits))
    print("PASS: retrospective safety terms")
    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
