#!/usr/bin/env python3
"""Package an enterprise skill after all local validators pass."""
from __future__ import annotations

import argparse
import subprocess
import sys
import zipfile
from pathlib import Path

VALIDATORS = [
    "quick_validate.py",
    "validate_source_map.py",
    "validate_evals.py",
    "validate_release_gate.py",
    "validate_no_placeholders.py",
]


def run_validator(skill_dir: Path, script: Path) -> None:
    result = subprocess.run([sys.executable, str(script), str(skill_dir)], text=True, capture_output=True)
    if result.stdout:
        print(result.stdout.strip())
    if result.returncode != 0:
        if result.stderr:
            print(result.stderr.strip(), file=sys.stderr)
        raise SystemExit(result.returncode)


def package(skill_dir: Path, out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    zip_path = out_dir / "skill.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(skill_dir.rglob("*")):
            if path.is_file():
                zf.write(path, path.relative_to(skill_dir.parent))
    return zip_path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_dir")
    parser.add_argument("out_dir", nargs="?", default="./dist")
    args = parser.parse_args()

    skill_dir = Path(args.skill_dir).resolve()
    script_dir = skill_dir / "scripts"
    for name in VALIDATORS:
        run_validator(skill_dir, script_dir / name)

    zip_path = package(skill_dir, Path(args.out_dir).resolve())
    print(f"PACKAGED: {zip_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
