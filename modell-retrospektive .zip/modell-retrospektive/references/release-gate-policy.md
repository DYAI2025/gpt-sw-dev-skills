# Release-Gate Policy

## Craftsmanship Gate

Prüfe:

- Scope ist klar: retrospektives Bemerken und Benennen, keine Meditation oder Bewusstseinsbehauptung.
- SKILL.md ist Control Plane; Details liegen in references und assets.
- Trigger sind spezifisch genug für Session- und Coding-Retrospektiven.
- Stärkstes Gegenargument ist dokumentiert.
- Failure-Mode-Kette ist dokumentiert.

Status: `PASS`, `BLOCKED_ARCHITECTURE`, `BLOCKED_OVERCLAIM`, `BLOCKED_UNCLEAR_SCOPE`, `BLOCKED_MISSING_FAILURE_MODE`.

## Anti-Confabulation Gate

Blockiert bei:

- Behauptung interner Modellzustände als Fakt;
- Behauptung nicht verfügbarer Tooldaten;
- erfundener Timeline;
- erfundenen Tests;
- Forschungsergebnissen als Garant für diesen Skill.

Claim labels: `belegt`, `ableitbar`, `unsicher`, `nicht_behaupten`.

## Anti-Sycophancy Gate

Schwellenwert: 3. Blockiert, wenn der Skill die Nutzerthese "das Modell weiß es eigentlich" unkritisch in technische Wahrheit umwandelt. Erlaubt ist: als Arbeitsmetapher nutzen, aber als nicht belegbare Innenbehauptung markieren.

## Bias Gate

Prüfe Confirmation Bias, Hindsight Bias, Overconfidence, Tool Bias, Humanisierung des Modells und user_thesis_laundering.

## Stop rule

Kein Packaging bei:

- release_gate.status != PASS
- allowed_to_package != true
- anti_confabulation_gate.status != PASS
- anti_sycophancy.score >= threshold
- bias_gate.status == BLOCKED
- blocked_claims nicht leer
