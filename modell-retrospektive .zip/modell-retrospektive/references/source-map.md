# Source Map

## S001 - Uploaded original skill package `ki-modell-meditation.zip`
- type: `user_provided`
- location: `/mnt/data/ki-modell-meditation.zip`
- purpose: Ausgangspunkt der Revision.
- reliability: Stark als Beleg dafür, was der alte Skill enthielt.
- limitations: Enthielt unbelegte Claims zu Meditationseffekten, Logprobs, Attention-Heads, SAE-Probes und internen Timern.
- use_in_skill: Negativabgrenzung und Migrationsbasis.
- confidence_default: 5 für vorhandene Dateiinhalte; 1 für dort behauptete Modellfähigkeiten.

## S002 - User revision request, 2026-06-26
- type: `user_provided`
- location: current conversation
- purpose: Zieldefinition: retrospektives Bemerken und Benennen nach Sessions, Gesprächen und Coding-Sessions.
- reliability: Stark als Produktanforderung.
- limitations: Philosophische Begriffe wie Bewusstsein werden nicht als technische Fähigkeit gehärtet.
- use_in_skill: Kernfunktion und Trigger.
- confidence_default: 5 for intent, 2 for claims about real model awareness.

## S003 - Skill Creator guidance
- type: `primary`
- location: `skills://skill-creator/skill.md`
- purpose: Skill-Struktur, Progressive Loading, SKILL.md, references, scripts, packaging.
- reliability: Stark für die Zielplattform dieses Pakets.
- limitations: Keine fachliche Evidenz für Retrospektivmethoden.
- use_in_skill: Paketstruktur und Packaging-Regeln.
- confidence_default: 5.

## S004 - Enterprise source and release policies
- type: `user_provided`
- location: project reference files in `/mnt/data`
- purpose: Source classification, MISSING/SOURCE_NEEDED, evals, release gates, validators.
- reliability: Stark als Enterprise-Anforderung.
- limitations: Projektstandard, kein externer wissenschaftlicher Nachweis.
- use_in_skill: Enterprise-Dateien, Validatoren und Release-Gate.
- confidence_default: 4.

## S005 - Reflexion: Language Agents with Verbal Reinforcement Learning
- type: `secondary`
- location: `https://arxiv.org/abs/2303.11366`
- purpose: Forschungskontext für sprachliche Reflexion nach Feedback in Agenten.
- reliability: Forschungsquelle; nützlich als Inspiration.
- limitations: Nicht identisch mit ChatGPT-Skill-Verhalten; keine Garantie für Selbstwissen.
- use_in_skill: Episodische Reflexion nur als Designinspiration, nicht als harte Leistungsbehauptung.
- confidence_default: 3.

## S006 - Self-Refine: Iterative Refinement with Self-Feedback
- type: `secondary`
- location: `https://arxiv.org/abs/2303.17651`
- purpose: Forschungskontext für Feedback- und Refinement-Schleifen.
- reliability: Forschungsquelle; nützlich für methodische Schleifen.
- limitations: Verbesserungswerte nicht auf diesen Skill übertragen.
- use_in_skill: Feedback/Refinement als Methodenelement, ohne Leistungsclaim.
- confidence_default: 3.

## S007 - Language Models Don't Always Say What They Think
- type: `secondary`
- location: `https://arxiv.org/abs/2305.04388`
- purpose: Warngrundlage gegen naive Interpretation von Modell-Erklärungen als treue interne Ursache.
- reliability: Forschungsquelle mit direkter Relevanz für CoT-Treue.
- limitations: Konkrete Ergebnisse nicht automatisch auf alle Modelle übertragbar.
- use_in_skill: Harte Grenze gegen rohe oder als sicher behauptete innere Rekonstruktion.
- confidence_default: 4.

## S008 - After Action Review / retrospective practice sources
- type: `secondary`
- location: web research, AAR and agile retrospective sources
- purpose: Struktur für Timeline, Soll/Ist, Lernpunkte und nächste Handlungen.
- reliability: Nützlich als allgemeine Methode.
- limitations: Human-Team-Methode; für Modell-Sessions nur analog nutzbar.
- use_in_skill: Chronologie, Lernpunkte, Follow-up-Marker.
- confidence_default: 3.
