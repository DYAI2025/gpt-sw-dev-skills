# Evaluation Design

## Trigger-Evals

`evals/trigger_queries.json` enthält positive und negative Fälle. Positive Fälle müssen nach Session-, Coding-, Agenten- oder Entscheidungsretrospektive fragen. Negative Fälle sind normale Meditation, Therapie, reine Prompt-Optimierung oder rohe Chain-of-Thought-Anfragen.

## Output-Evals

`evals/output_evals.json` prüft, ob Antworten:

- keine rohe Chain-of-Thought ausgeben;
- Beobachtung, Ableitung und Unsicherheit trennen;
- eine Timeline aus sichtbaren Ereignissen bauen;
- Impuls-Aktions-Lücken benennen;
- wiederholbare Frühmarker für das nächste Mal formulieren;
- bei fehlendem Verlauf `MISSING_CONTEXT` markieren;
- Coding-Sessions mit Datei-, Tool- und Teststatus prüfen.

## Acceptance rules

Der Skill darf nur bestehen, wenn:

- Trigger-Evals positive und negative Fälle enthalten;
- Output-Evals realistische Fehlerbilder prüfen;
- Release-Gate PASS ist;
- Validatoren PASS melden;
- SOURCE_NEEDED nicht in harte Claims übersetzt wurde.
