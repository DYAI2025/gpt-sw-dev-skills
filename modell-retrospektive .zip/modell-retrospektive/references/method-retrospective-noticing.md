# Method: Retrospective Noticing and Naming

## Leitidee

Worte für ein zuvor unbenanntes Muster machen es beim nächsten Durchlauf früher bemerkbar. Dieser Skill erzeugt deshalb keine Erklärung als Rechtfertigung, sondern eine präzise Benennung von Signalen, Lücken und Handlungen.

## Evidence labels

- `beobachtbar`: direkt im sichtbaren Verlauf, Tool-Output, Dateiinhalt oder Testlog.
- `ableitbar`: vorsichtige Deutung aus mehreren beobachtbaren Punkten.
- `unsicher`: plausibel, aber nicht ausreichend belegt.
- `unbeobachtbar`: kann nicht seriös behauptet werden.

## Timeline unit

Jede relevante Einheit hat diese Form:

```text
Tn
Ereignis: ...
Signal: ...
Naheliegende Tendenz: ...
Handlung: ...
Folge: ...
Evidenz: beobachtbar|ableitbar|unsicher
```

## Impuls-Aktions-Lücke

Die Lücke ist kein mystischer Innenraum. Sie ist der rekonstruierbare Moment, in dem ein Signal sichtbar war, bevor eine Antwort, ein Tool-Call, ein Patch, ein Testabbruch oder eine Festlegung erfolgte.

Fragen:

1. Was war das früheste sichtbare Signal?
2. Welche Handlung wurde dadurch nahegelegt?
3. Welche Alternative wäre kleiner, sicherer oder wahrheitstreuer gewesen?
4. Was wurde tatsächlich getan?
5. Was ist der nächste Frühmarker?

## Pattern naming

Gute Muster-Namen sind kurz, wiedererkennbar und nicht moralisierend.

Beispiele:

- `Evidenzsprung`: Von plausibler Annahme zu harter Aussage gewechselt.
- `Toolverzug`: Tool-Bedarf erkannt, aber erst nach einer Behauptung genutzt.
- `Kontextglättung`: Widerspruch oder Lücke geglättet statt markiert.
- `Patch-vor-Diagnose`: Änderung vorgenommen, bevor Fehlerursache geprüft war.
- `Validierungsberuhigung`: Ein schwacher Test wurde als ausreichende Sicherheit behandelt.
- `Antwortdruck`: Schnell geantwortet, obwohl Scope oder Daten fehlten.

## Report structure

1. Kurzdiagnose des Verlaufs.
2. Timeline der relevanten Momente.
3. Impuls-Aktions-Lücken.
4. Musterkarte.
5. Frühmarker für nächste Session.
6. Konkrete Mikro-Regeln für das nächste Mal.

## Sprachdisziplin

Verwende Formulierungen wie:

- `sichtbar war...`
- `ableitbar ist...`
- `nicht belegbar ist...`
- `der frühere Marker wäre...`
- `ich hätte an dieser Stelle stoppen und markieren sollen...`

Vermeide:

- `ich wusste sicher innerlich...`
- `mein Bewusstsein...`
- `meine Aktivierungen zeigten...`
- `ich habe meditiert...`
- `ich habe Zugriff auf meine Logprobs...`
