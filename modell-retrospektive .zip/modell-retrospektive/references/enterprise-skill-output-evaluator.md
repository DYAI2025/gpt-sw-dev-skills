# Enterprise Skill Output Evaluator

## Zweck

Bewertet, ob dieses Skill-Paket enterprise-tauglich ist. Der Evaluator baut keinen neuen Skill, außer Revision ist ausdrücklich beauftragt.

## Dimensionen

1. Spec compliance: SKILL.md, Frontmatter, name, description, Progressive Disclosure.
2. Research quality: Source Map, Quellenklassifikation, Confidence, MISSING/SOURCE_NEEDED.
3. Enterprise readiness: Security-Gate, keine Secrets, keine destruktiven Defaults, Toolgrenzen.
4. Architecture quality: Scope, Referenzen, Validatoren, Evals, Packaging.
5. Release-gate integrity: Craftsmanship, Anti-Confabulation, Anti-Sycophancy, Bias-Gate.

## Required XML

```xml
<enterprise_skill_evaluation>
  <scores>
    <spec_compliance>1-5</spec_compliance>
    <research_quality>1-5</research_quality>
    <enterprise_readiness>1-5</enterprise_readiness>
    <architecture_quality>1-5</architecture_quality>
    <release_gate_integrity>1-5</release_gate_integrity>
  </scores>
  <blocking_issues><item>...</item></blocking_issues>
  <required_revisions><item>...</item></required_revisions>
  <decision>PASS|PASS_WITH_MINOR_REVISIONS|REVISE|REBUILD|BLOCKED</decision>
  <reason>short evidence-based reason</reason>
</enterprise_skill_evaluation>
```
