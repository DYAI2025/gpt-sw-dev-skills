# Source Policy

## Zweck

Diese Policy verhindert, dass Nutzerthesen, Modellrekonstruktionen oder plausible Erklärungen als sichere innere Wahrheit behandelt werden.

## Source classes

| Class | Definition | Allowed use |
|---|---|---|
| `primary` | Originalquelle, offizielles Dokument, ausgeführter Test, sichtbarer Tool-Output, konkrete Datei im aktuellen Verlauf | Darf harte Aussagen über den konkreten Verlauf stützen |
| `secondary` | Forschungspapier, Fachartikel, Lehrmaterial, Frameworkbeschreibung | Darf Methode inspirieren, aber keine konkrete Session-Tatsache ersetzen |
| `user_provided` | Nutzerdatei, Nutzerbeschreibung, Chat-Ausschnitt, Screenshot, ZIP, Repo-Upload | Projektkontext; nicht automatisch Wahrheit |
| `derived` | Zusammenfassung, Modellanalyse, extrahierte Timeline, Mustername | Nur als Ableitung kennzeichnen |
| `uncertain` | unvollständige, widersprüchliche oder nicht prüfbare Angabe | Nicht als Fakt verwenden |

## Required source map fields

```yaml
source_id:
  title: string
  type: primary | secondary | user_provided | derived | uncertain
  location: string
  purpose: string
  reliability: string
  limitations: string
  use_in_skill: string
  confidence_default: 1-5
```

## MISSING und SOURCE_NEEDED

- Nutze `MISSING_CONTEXT`, wenn der benötigte Session-Verlauf fehlt.
- Nutze `SOURCE_NEEDED`, wenn eine Methode, Studie, Toolfähigkeit oder externe Tatsache nicht belegt ist.
- Nutze `UNOBSERVABLE`, wenn ein angeblicher innerer Zustand nicht aus dem Verlauf ableitbar ist.

## Confidence scale

| Score | Bedeutung | Nutzung |
|---:|---|---|
| 5 | direkt aus sichtbarem Verlauf, Datei, Test oder offizieller Quelle belegt | Fakt oder harte Regel |
| 4 | stark gestützt durch mehrere sichtbare Hinweise oder belastbare Quelle | robuste Ableitung |
| 3 | plausibel, aber indirekt | Annahme mit Warnhinweis |
| 2 | schwach, lückenhaft, widersprüchlich | nicht operationalisieren |
| 1 | spekulativ oder widerlegt | blockieren oder als Fehler markieren |

## Claim discipline

Jeder Bericht trennt:

1. `Beobachtung`: sichtbar im Verlauf.
2. `Ableitung`: vorsichtige Deutung aus Beobachtungen.
3. `Unsicherheit`: fehlender Kontext oder nicht beobachtbarer Innenzustand.
4. `Nächster Marker`: konkret früher erkennbares Signal.
