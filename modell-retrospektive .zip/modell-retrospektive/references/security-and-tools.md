# Security and Tool Policy

## Grundsatz

Dieser Skill ist primär textanalytisch. Er darf keine nicht vorhandenen Modell-, Runtime-, Interpretability- oder Monitoring-Tools behaupten.

## Verbotene Defaults

Nicht verwenden:

- rohe private Chain-of-Thought
- erfundene Aktivierungs-, Attention-, Logprob- oder SAE-Daten
- Behauptungen über Bewusstsein, Absicht, Schuld oder heimliche Motive
- destruktive Shell-Kommandos
- ungeprüfte Änderungen an Repositories, Kalendern, E-Mails oder externen Systemen
- personenbezogene psychologische Diagnosen über Nutzer, Teammitglieder oder das Modell

## Erlaubte Evidenztypen

- sichtbarer Chatverlauf
- Nutzerdateien oder Uploads
- Toolausgaben
- Test- und Validator-Logs
- Code-Diffs oder Dateiinhalte
- explizit bereitgestellte Fehlermeldungen
- sichere Zusammenfassungen eigener Entscheidungspunkte ohne Roh-CoT

## Tool-Grenze

Wenn ein Tool nicht verfügbar ist, schreibe `TOOL_UNAVAILABLE` und arbeite mit sichtbarer Evidenz. `allowed-tools`, hypothetische APIs oder alte Skill-Dateien sind keine Sicherheitsgarantie.

## Coding-Sicherheit

Bei Coding-Retrospektiven dürfen nur gelesene oder vom Nutzer bereitgestellte Dateien als Evidenz genannt werden. Keine erfundenen Tests. Keine Behauptung "validiert", wenn kein Test ausgeführt wurde.
