# Coding Session Retrospective

## Wann laden

Nutze diese Referenz nach Coding-Sessions, Repo-Arbeit, Dateiänderungen, Tests, Validierungen, Debugging oder Agentenläufen.

## Zusätzliche Evidenzfelder

- Gelesene Dateien
- Geänderte Dateien
- Ausgeführte Kommandos
- Test-/Validator-Ergebnisse
- Fehlermeldungen
- Nicht ausgeführte, aber notwendige Prüfungen
- Annahmen über Pfade, APIs, Frameworks oder Laufzeit

## Coding-Timeline

```text
Tn: Auftrag/Problem
Tn: Datei/Quelle gelesen
Tn: Hypothese gebildet
Tn: Änderung vorgenommen
Tn: Test/Validator ausgeführt oder ausgelassen
Tn: Ergebnis
Tn: Korrektur oder offener Blocker
```

## Entscheidungsmarker

- `read-before-write`: Wurde vor Änderung genug gelesen?
- `test-before-claim`: Wurde vor Erfolgsbehauptung getestet?
- `smallest-safe-change`: War der Patch minimal?
- `scope-drift`: Wurde mehr geändert als nötig?
- `error-surface`: Wurden Fehlermeldungen vollständig genutzt?
- `unknown-runtime`: Wurde Laufzeitverhalten behauptet, ohne es zu prüfen?

## Fehlerkettenanalyse

Form:

```text
Wenn A übersehen wurde,
dann wurde B angenommen,
dadurch wurde C getan,
das erzeugte Risiko D.
Frühmarker: E.
Nächste Mikro-Regel: F.
```

## Validierungsstatus

Nutze klare Statuswörter:

- `VALIDATED`: Test/Validator lief erfolgreich; Befehl und Ergebnis nennen.
- `PARTIALLY_VALIDATED`: nur Teilprüfung; Lücke nennen.
- `NOT_VALIDATED`: kein Test ausgeführt; nicht als Erfolg behaupten.
- `BLOCKED`: Prüfung nicht möglich; Ursache nennen.

## Output: Coding-AAR

1. Ziel und tatsächlicher Verlauf.
2. Datei-/Tool-Evidenz.
3. Entscheidungspunkte.
4. Fehler- oder Risikokette.
5. Validierungsstatus.
6. Nächste Mikro-Regeln.
