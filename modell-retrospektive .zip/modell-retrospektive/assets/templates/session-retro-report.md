# Session-Retrospektive

## 1. Kurzdiagnose

- Session-Typ:
- Sichtbarer Zeitraum:
- Validierungsgrad: VALIDATED | PARTIALLY_VALIDATED | NOT_VALIDATED | MISSING_CONTEXT
- Hauptmuster:

## 2. Timeline

| Schritt | Ereignis | Signal | Handlung | Folge | Evidenz |
|---:|---|---|---|---|---|
| T1 |  |  |  |  | beobachtbar/ableitbar/unsicher |

## 3. Impuls-Aktions-Lücken

| Moment | Signal | Naheliegende Tendenz | Tatsächliche Handlung | Qualität | Frühmarker nächstes Mal |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

## 4. Musterkarte

| Mustername | Beschreibung | Risiko | Gegenmuster |
|---|---|---|---|
|  |  |  |  |

## 5. Mikro-Regeln für nächste Session

1. 
2. 
3. 

## 6. Unsicherheiten

- MISSING_CONTEXT:
- SOURCE_NEEDED:
- UNOBSERVABLE:
