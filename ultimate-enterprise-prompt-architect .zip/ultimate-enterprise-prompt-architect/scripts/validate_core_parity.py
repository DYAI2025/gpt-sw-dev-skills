#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
def fail(msg): print(f"FAIL: {msg}", file=sys.stderr); return 1
def main(argv):
    if len(argv)!=2: return fail('usage: validate_core_parity.py <skill-dir>')
    root=Path(argv[1]); path=root/'reports/core-functionality-preservation.json'
    if not path.exists(): return fail('core-functionality-preservation report missing')
    data=json.loads(path.read_text(encoding='utf-8'))
    if data.get('status')!='PASS': return fail('core parity status must be PASS')
    required={'new prompt generation','prompt optimization','prompt audit','method selection'}
    preserved=set(data.get('preserved_core_functions',[]))
    missing=[x for x in required if x not in preserved]
    if missing: return fail('missing preserved core functions: '+', '.join(missing))
    if data.get('unintentional_core_function_changes'): return fail('unintentional core function changes must be empty')
    print('PASS: core functionality parity')
    return 0
if __name__ == '__main__': raise SystemExit(main(sys.argv))
