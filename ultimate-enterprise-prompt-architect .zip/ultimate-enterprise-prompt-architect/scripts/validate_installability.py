#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
def fail(msg): print(f"FAIL: {msg}", file=sys.stderr); return 1
def main(argv):
    if len(argv)!=2: return fail('usage: validate_installability.py <skill-dir>')
    root=Path(argv[1]); report=root/'reports/installability-report.json'
    if not (root/'SKILL.md').exists(): return fail('SKILL.md missing')
    if not (root/'agents/openai.yaml').exists(): return fail('agents/openai.yaml missing')
    if not report.exists(): return fail('installability report missing')
    data=json.loads(report.read_text(encoding='utf-8'))
    if data.get('artifact_name')!='skill.zip': return fail('artifact_name must be skill.zip')
    if data.get('frontend_install_suggestion_status')=='guaranteed': return fail('frontend install suggestion must not be guaranteed')
    if data.get('blocking_issues'): return fail('installability blocking issues must be empty')
    print('PASS: installability')
    return 0
if __name__ == '__main__': raise SystemExit(main(sys.argv))
