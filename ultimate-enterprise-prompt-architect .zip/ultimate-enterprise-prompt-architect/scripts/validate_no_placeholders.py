#!/usr/bin/env python3
from __future__ import annotations
import re, sys
from pathlib import Path
PLACEHOLDER_RE = re.compile(r"\{[A-Z_][A-Z0-9_]*\}|\{\{[A-Z_][A-Z0-9_]*\}\}")
IGNORE_PARTS = {"assets", "evals", "reports"}
def fail(msg): print(f"FAIL: {msg}", file=sys.stderr); return 1
def main(argv):
    if len(argv)!=2: return fail('usage: validate_no_placeholders.py <skill-dir>')
    root=Path(argv[1]); hits=[]
    for path in root.rglob('*'):
        if not path.is_file(): continue
        rel=path.relative_to(root)
        if set(rel.parts) & IGNORE_PARTS: continue
        if path.suffix not in {'.md','.py','.yaml','.json'} and path.name!='SKILL.md': continue
        text=path.read_text(encoding='utf-8', errors='ignore')
        for match in PLACEHOLDER_RE.finditer(text): hits.append(f'{rel}:{match.group(0)}')
    if hits: return fail('unresolved placeholders: '+', '.join(hits))
    print('PASS: no unresolved production placeholders')
    return 0
if __name__ == '__main__': raise SystemExit(main(sys.argv))
