#!/usr/bin/env python3
from __future__ import annotations
import re, sys
from pathlib import Path
NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
REQUIRED_PATHS = [
    "SKILL.md", "agents/openai.yaml",
    "references/source-policy.md", "references/source-map.md", "references/security-and-tools.md",
    "references/eval-design.md", "references/release-gate-policy.md",
    "references/enterprise-skill-output-evaluator.md", "references/prompt-method-selection.md",
    "references/prompt-generation-blueprint.md", "references/prompt-audit-framework.md",
    "scripts/validate_release_gate.py", "evals/trigger_queries.json", "evals/output_evals.json",
    "reports/release-gate-report.json", "reports/installability-report.json", "reports/core-functionality-preservation.json"
]
def fail(msg): print(f"FAIL: {msg}", file=sys.stderr); return 1
def parse_frontmatter(text):
    if not text.startswith('---\n'): raise ValueError('SKILL.md must start with YAML frontmatter')
    end = text.find('\n---\n', 4)
    if end == -1: raise ValueError('frontmatter closing marker not found')
    data = {}
    for line in text[4:end].splitlines():
        if not line.strip(): continue
        if ':' not in line: raise ValueError(f'invalid frontmatter line: {line}')
        k,v=line.split(':',1); data[k.strip()] = v.strip().strip('"').strip("'")
    return data
def main(argv):
    if len(argv)!=2: return fail('usage: quick_validate.py <skill-dir>')
    root=Path(argv[1])
    if not root.is_dir(): return fail(f'not a directory: {root}')
    for rel in REQUIRED_PATHS:
        if not (root/rel).exists(): return fail(f'missing required path: {rel}')
    text=(root/'SKILL.md').read_text(encoding='utf-8')
    try: fm=parse_frontmatter(text)
    except ValueError as exc: return fail(str(exc))
    name=fm.get('name'); desc=fm.get('description')
    if not name or not NAME_RE.match(name): return fail('frontmatter name missing or invalid')
    if root.name != name: return fail(f'directory name {root.name!r} does not match name {name!r}')
    if not desc: return fail('frontmatter description missing')
    if '<' in desc or '>' in desc: return fail('description must not contain angle brackets')
    if len(desc)>1024: return fail('description exceeds 1024 characters')
    body=text.split('\n---\n',1)[1].splitlines() if '\n---\n' in text else []
    if len(body)>500: return fail('SKILL.md body exceeds 500 lines')
    empty=[str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.stat().st_size==0]
    if empty: return fail('empty files found: '+', '.join(empty))
    print(f'PASS: {root}')
    return 0
if __name__ == '__main__': raise SystemExit(main(sys.argv))
