#!/usr/bin/env python3
from __future__ import annotations
import sys
from pathlib import Path
def fail(msg): print(f"FAIL: {msg}", file=sys.stderr); return 1
def main(argv):
    if len(argv)!=2: return fail('usage: validate_agent_agnostic.py <skill-dir>')
    root=Path(argv[1]); path=root/'references/agent-agnostic-compatibility.md'
    if not path.exists(): return fail('agent-agnostic compatibility reference missing')
    text=path.read_text(encoding='utf-8').lower()
    for term in ['portable parts','non-portable parts','semantic portability']:
        if term not in text: return fail(f'missing agent-agnostic term: {term}')
    print('PASS: agent agnostic compatibility')
    return 0
if __name__ == '__main__': raise SystemExit(main(sys.argv))
