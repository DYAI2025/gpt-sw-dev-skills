#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
def fail(msg): print(f"FAIL: {msg}", file=sys.stderr); return 1
def load(path):
    try: return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc: raise ValueError(f'{path}: {exc}')
def main(argv):
    if len(argv)!=2: return fail('usage: validate_evals.py <skill-dir>')
    root=Path(argv[1]); tp=root/'evals/trigger_queries.json'; op=root/'evals/output_evals.json'
    if not tp.exists() or not op.exists(): return fail('evals/trigger_queries.json and evals/output_evals.json are required')
    try: trigger=load(tp); output=load(op)
    except ValueError as exc: return fail(str(exc))
    if not isinstance(trigger, list) or len(trigger)<4: return fail('trigger_queries.json must contain at least 4 cases')
    if not any(isinstance(i,dict) and i.get('should_trigger') is True for i in trigger): return fail('need positive trigger cases')
    if not any(isinstance(i,dict) and i.get('should_trigger') is False for i in trigger): return fail('need negative trigger cases')
    if not isinstance(output, list) or len(output)<3: return fail('output_evals.json must contain at least 3 evals')
    for item in output:
        if not isinstance(item, dict) or not all(k in item for k in ('id','prompt','expected_properties','failure_modes')):
            return fail('each output eval requires id, prompt, expected_properties and failure_modes')
    print('PASS: eval files')
    return 0
if __name__ == '__main__': raise SystemExit(main(sys.argv))
