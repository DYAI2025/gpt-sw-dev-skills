# Installability and Distribution

## Package invariant

The primary artifact must be named exactly `skill.zip`.

The ZIP must contain one root folder named `ultimate-enterprise-prompt-architect` with:

- `SKILL.md`
- `agents/openai.yaml`
- `references/`
- `scripts/`
- `evals/`
- `reports/`

## Frontend limitation

The package can prepare installability evidence. It cannot guarantee that any specific ChatGPT frontend will display a particular install button, suggestion, or UI path.

## User action

Upload `skill.zip` through the Skills upload interface available in the user's ChatGPT environment.
