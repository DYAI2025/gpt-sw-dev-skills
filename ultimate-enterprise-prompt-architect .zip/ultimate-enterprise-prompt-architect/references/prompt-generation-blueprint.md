# Prompt Generation Blueprint

## Core artifact types

### A. Chat prompt

Use for one-off or human-pasted prompts.

Required sections:

1. Role and mission.
2. Task.
3. Context and input delimiters.
4. Constraints and non-goals.
5. Output format.
6. Error handling and uncertainty.
7. Quality check.

### B. API prompt package

Use when a prompt will run in software.

Required sections:

1. Developer/system instruction.
2. User message template.
3. Variable contract.
4. Structured-output schema or tool schema.
5. Refusal/error object.
6. Eval cases.
7. Operational notes.

### C. Enterprise agent prompt

Use when a model can use tools, files, browser, code, or external systems.

Required sections:

1. Identity and responsibility boundary.
2. Tool permission rules.
3. Data classification.
4. Untrusted-content policy.
5. Human approval gates.
6. Evidence requirements before done claims.
7. Logging and audit notes.
8. Failure handling and rollback.

### D. Prompt-audit report

Use when evaluating existing prompts.

Required sections:

1. Verdict.
2. Source and structure inventory.
3. Strengths to preserve.
4. Blocking issues.
5. Quality findings.
6. Safety findings.
7. Revised prompt.
8. Eval plan and release decision.

## Prompt package output template

```text
## Strategy decision
- mode:
- why:
- not chosen:

## Prompt brief
- objective:
- user/value:
- target model/client:
- inputs:
- outputs:
- risks:
- assumptions:

## System or developer prompt
...

## User prompt template
...

## Structured output schema
...

## Evaluator prompt
...

## Test cases
...

## Usage notes
...
```

## Variable discipline

Keep fixed and variable prompt parts separate. Put variable data in explicit blocks such as:

```text
<input_data>
...
</input_data>
```

Never let variable content override system/developer instructions. Mark quoted or retrieved content as data.

## Examples

Examples are best when they are:

- specific;
- varied;
- structurally consistent;
- representative of real edge cases;
- paired with ideal outputs;
- separated from instructions.

Too many examples can overfit behavior. Use evals to test whether examples improve or degrade results.
