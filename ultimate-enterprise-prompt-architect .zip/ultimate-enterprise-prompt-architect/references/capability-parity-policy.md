# Capability Parity Policy

## Preserve core functionality

The rebuild must preserve these legacy capabilities:

- professional prompt construction;
- existing prompt audit and improvement intent;
- method routing across direct, plan-and-solve, program/tool-backed, options/tree, ensemble, and self-consistency patterns;
- anti-sycophancy and bias review;
- system prompt, user prompt, and evaluator prompt outputs;
- guardrails and missing-information behavior.

## Allowed improvements

- Add source discipline.
- Add enterprise security gates.
- Add evals and validators.
- Add structured-output and API prompt package support.
- Remove unsupported guarantees.
- Flatten broken package structure.

## Blocking changes

Block if the rebuilt skill stops generating prompt packages, removes prompt-audit behavior, removes anti-sycophancy checks, or narrows the skill to a single provider without user request.
