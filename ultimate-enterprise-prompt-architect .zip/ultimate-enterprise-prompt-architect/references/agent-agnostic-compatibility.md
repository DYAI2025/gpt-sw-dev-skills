# Agent-Agnostic Compatibility

## Scope

This skill is written for ChatGPT Skill packaging but the prompt methodology can be adapted to other frontier models and coding agents.

## Portable parts

- Prompt audit framework.
- Source classification.
- Method-selection matrix.
- Prompt package structure.
- Eval-first improvement loop.
- Security and injection gates.
- Anti-sycophancy and bias checks.

## Non-portable parts

- ChatGPT Skill discovery and packaging behavior.
- `agents/openai.yaml` metadata.
- Any tool or connector availability in a specific runtime.
- Provider-specific structured-output, tool-calling, or reasoning controls.

## Handoff rule

When adapting this skill to Claude, Gemini, Codex, Cursor, Windsurf, or another agent, translate the workflow and output contracts, then re-check provider documentation for current tool, schema, and prompt-behavior support.

Compatibility means semantic portability, not identical execution.
