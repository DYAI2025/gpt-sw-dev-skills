# Source Map

This source map records the material used to design the Ultimate Enterprise Prompt Architect. It is not proof that every target model or platform behaves the same way today.

## S001 - Uploaded `ultimativer-prompt-architekt.zip`
- type: `user_provided`
- location: conversation upload; inspected at `/mnt/data/ultimativer-prompt-architekt.zip`
- purpose: Original prompt-architect concept, method list, prompt templates, and existing Skill entrypoint.
- reliability: Strong as user intent and legacy design context.
- limitations: Broken internal references were found in the outer package; many claims are not externally sourced; placeholder templates were mixed with production files.
- use_in_skill: Preserved the core purpose: professional prompt construction, prompt audit, method selection, anti-sycophancy, and prompt-package outputs.
- confidence_default: 4 for user intent; 2 for external claims.

## S002 - Uploaded `superprompt-architekt-kompakt.zip`
- type: `user_provided`
- location: conversation upload; inspected at `/mnt/data/superprompt-architekt-kompakt.zip`
- purpose: Compact prior skill package with resolved references, advanced templates, and self-bias check.
- reliability: Strong as inherited design material.
- limitations: Still lacks enterprise source map, release-gate report, deterministic evals, and explicit installability reports.
- use_in_skill: Used as source for preserving core capabilities while moving method details into enterprise references.
- confidence_default: 4 for internal workflow intention; 2 for unsourced external quality claims.

## S003 - OpenAI prompt engineering documentation
- type: `primary`
- location: `https://developers.openai.com/api/docs/guides/prompt-engineering`
- purpose: Current OpenAI guidance on precise instructions, explicit roles, tool use examples, testing, and markdown standards for model prompting.
- reliability: Primary vendor documentation.
- limitations: Provider-specific and dynamic; must be checked when model-specific behavior matters.
- use_in_skill: Supports role clarity, explicit workflow instructions, tool-use examples, and testing requirements.
- confidence_default: 5 for OpenAI-specific guidance; 4 for general prompting principles.

## S004 - OpenAI Structured Outputs documentation
- type: `primary`
- location: `https://developers.openai.com/api/docs/guides/structured-outputs`
- purpose: Structured response schemas, JSON Schema constraints, and schema-vs-function-calling distinction.
- reliability: Primary vendor documentation.
- limitations: Provider/model support changes over time; unsupported schema features must be checked before API use.
- use_in_skill: Supports schema-first output design, strict response contracts, and eval-backed schema selection.
- confidence_default: 5 for OpenAI API guidance.

## S005 - OpenAI evals documentation
- type: `primary`
- location: `https://developers.openai.com/api/docs/guides/evals`
- purpose: Evaluation workflow: describe task, run with test inputs, analyze and iterate.
- reliability: Primary vendor documentation.
- limitations: The referenced OpenAI Evals platform has a documented deprecation timeline; use current evaluation facilities when implementing.
- use_in_skill: Supports behavior-driven eval design and prompt improvement loops.
- confidence_default: 5 for documented workflow, 3 for future platform status without re-checking.

## S006 - OpenAI function calling documentation
- type: `primary`
- location: `https://developers.openai.com/api/docs/guides/function-calling`
- purpose: Tool/function calling concepts, schema-bound tools, and model-to-system interface design.
- reliability: Primary vendor documentation.
- limitations: Provider-specific; tool support and strict-mode behavior can change.
- use_in_skill: Supports tool boundary prompts and distinction between response schema and tool invocation.
- confidence_default: 5 for documented API behavior.

## S007 - Anthropic prompt engineering overview and console prompting tools
- type: `primary`
- location: `https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/overview` and prompting-tools page
- purpose: Success criteria before prompt engineering, prompt generator/improver concepts, fixed vs variable prompt parts, examples, XML tags, and test case generation.
- reliability: Primary vendor documentation.
- limitations: Provider-specific; do not claim identical OpenAI or Gemini behavior.
- use_in_skill: Supports template variable separation, prompt improver loop, and eval-first prompt engineering.
- confidence_default: 5 for Anthropic-specific guidance; 4 for generalizable concepts.

## S008 - Google Gemini prompt design strategies
- type: `primary`
- location: `https://ai.google.dev/gemini-api/docs/prompting-strategies`
- purpose: Clear instructions, constraints, response format, few-shot examples, consistent formatting, and structured output recommendation for complex schemas.
- reliability: Primary vendor documentation.
- limitations: Gemini-specific examples; model behavior and recommended APIs change over time.
- use_in_skill: Supports few-shot discipline, consistent formatting, and context injection boundaries.
- confidence_default: 5 for Gemini-specific guidance; 4 for general prompt design.

## S009 - OWASP Top 10 for LLM Applications 2025 and LLM01 Prompt Injection
- type: `primary`
- location: `https://genai.owasp.org/llm-top-10/` and `https://genai.owasp.org/llmrisk/llm01-prompt-injection/`
- purpose: Enterprise security risks: prompt injection, sensitive information disclosure, improper output handling, excessive agency, system prompt leakage, and mitigations.
- reliability: Recognized security project documentation.
- limitations: Guidance does not prove a specific application is secure; controls require implementation and testing.
- use_in_skill: Supports injection-resistant prompt architecture, untrusted-content boundaries, least privilege, human approval, and adversarial testing.
- confidence_default: 5 for risk taxonomy and mitigation families.

## S010 - NIST AI Risk Management Framework and Generative AI Profile
- type: `primary`
- location: `https://www.nist.gov/itl/ai-risk-management-framework`
- purpose: Risk governance framing for trustworthy AI systems and generative AI risk management.
- reliability: Primary government standard/resource.
- limitations: Voluntary framework; not a certification and not a prompt-specific recipe.
- use_in_skill: Supports governance language, risk register, evaluation, and release decision framing.
- confidence_default: 5 for framework existence and stated purpose; 4 for adaptation into prompt workflow.

## S011 - Enterprise Skill Creator project instructions
- type: `user_provided`
- location: active project skill instructions
- purpose: Required package structure, source discipline, release hook, installability, agent-agnostic handoff, evals, and validation workflow.
- reliability: Strong as local project contract.
- limitations: Does not prove external platform UI behavior.
- use_in_skill: Defines enterprise package shape and validator expectations.
- confidence_default: 5 for this delivery context.
