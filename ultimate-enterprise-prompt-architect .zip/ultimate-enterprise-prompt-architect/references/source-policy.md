# Source Policy

## Purpose

Use this policy for every prompt audit, prompt generation, skill rebuild, and enterprise prompt package. The policy prevents source laundering: user-provided prompt notes are useful design context, but they are not external proof.

## Source classes

| Class | Definition | Allowed use |
|---|---|---|
| `primary` | Official vendor documentation, standards, specifications, original repository, legal/regulatory text, or original research paper for a research claim | May support hard rules if current enough |
| `secondary` | Reputable expert article, textbook, tutorial, course, or curated explanation | Context and interpretation; do not override primary sources |
| `user_provided` | Uploaded prompt packs, notes, screenshots, prior prompts, templates, internal rules, or user claims | Project context; verify before factual hardening |
| `derived` | Model summaries, OCR, transformed files, generated audits, or extracted tables | Navigation and synthesis only; check against source |
| `uncertain` | Unattributed, contradictory, incomplete, stale, or unverifiable material | Do not convert into hard rules |

## Required source map fields

Each source record must include these fields:

```yaml
source_id:
  title: string
  type: primary | secondary | user_provided | derived | uncertain
  location: string
  purpose: string
  reliability: string
  limitations: string
  use_in_skill: string
  confidence_default: 1-5
```

## Confidence scale

| Score | Meaning | Allowed usage |
|---:|---|---|
| 5 | Directly supported by current primary source | Hard rule or requirement |
| 4 | Strong source or convergent evidence | Recommendation or operational rule |
| 3 | Plausible but indirect or incomplete | Assumption only |
| 2 | Weak, stale, conflicting, or context-specific | Do not operationalize without warning |
| 1 | Unsupported, speculative, or contradicted | Block or mark `SOURCE_NEEDED` |

## MISSING and SOURCE_NEEDED

Use `MISSING` when required information is absent. Use `SOURCE_NEEDED` when a claim exists but lacks adequate support.

Never invent:

- current model capabilities, prices, API behavior, or version support;
- security guarantees;
- legal, medical, financial, or safety rules;
- benchmark claims or quality percentages;
- hidden tool availability;
- model/provider compatibility.

## Claim discipline

Split outputs into:

1. `fact`: backed by inspected source.
2. `inference`: explicit reasoning from facts.
3. `recommendation`: design choice based on goal and constraints.

Recommendations may be useful without being facts. Do not let wording imply certainty that the evidence does not support.
