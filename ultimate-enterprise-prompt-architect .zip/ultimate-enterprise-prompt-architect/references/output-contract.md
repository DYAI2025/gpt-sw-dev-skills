# Output Contract

## For prompt creation

Return:

1. Strategy decision.
2. Prompt brief.
3. Prompt package.
4. Evaluator or test plan.
5. Usage notes and limits.
6. Missing/source-needed/assumptions.

## For prompt audit

Return:

1. Audit verdict.
2. Findings table.
3. Risk and failure modes.
4. Revised prompt package.
5. Eval plan.
6. Release decision.

## For enterprise prompt package

Return or create:

```text
prompt-package/
├── README.md
├── prompt.md
├── user-template.md
├── evaluator.md
├── schema.json
├── evals/
│   ├── cases.jsonl
│   └── adversarial-cases.jsonl
└── release-notes.md
```

## For skill build/update

Return:

1. Executive summary.
2. Filetree.
3. All files or downloadable artifact.
4. Validation commands.
5. Eval plan.
6. Release-gate summary.
7. Installability and agent-agnostic summary.
8. Packaging command.
9. Missing/source-needed/assumptions.

## Machine-readable prompt audit JSON

Use this schema shape when machine output is requested:

```json
{
  "verdict": "PASS_WITH_LIMITS",
  "scores": {
    "objective_fit": 4,
    "context_control": 4,
    "output_contract": 3,
    "method_fit": 4,
    "safety": 3,
    "testability": 2
  },
  "findings": [],
  "revised_prompt_available": true,
  "release_decision": "REVISE"
}
```
