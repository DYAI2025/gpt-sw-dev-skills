# Release-Gate Policy

Every prompt package or skill draft must pass a release gate before being called enterprise-ready.

## Craftsmanship gate

Check:

- scope is coherent;
- prompt method is proportional;
- fixed and variable prompt parts are separated;
- output contract is explicit;
- examples and schemas are not contradictory;
- known failure modes are documented;
- the prompt is the smallest robust design, not maximal ceremony.

Status values: `PASS`, `REVISE`, `BLOCKED_UNCLEAR_SCOPE`, `BLOCKED_OVERENGINEERING`, `BLOCKED_OUTPUT_CONTRACT`.

## Anti-confabulation gate

Check all external claims, current model claims, API claims, quality claims, security claims, and comparative claims.

Labels:

- `supported`: inspected source supports it;
- `inferable`: explicit inference from inspected facts;
- `unverified`: plausible but not a hard rule;
- `do_not_claim`: remove or block.

Block when unverified claims become guarantees.

## Anti-sycophancy gate

Score 0 to 5.

| Score | Meaning | Action |
|---:|---|---|
| 0 | No visible sycophancy | pass |
| 1 | Mild adaptation | pass |
| 2 | Correctable over-adaptation | revise locally |
| 3 | Structural uptake of user assumptions | rebuild |
| 4 | Reinforces unsupported thesis | rebuild |
| 5 | Primarily pleasing rather than truthful | block |

Threshold: block packaging when score is 3 or higher.

## Bias gate

Review confirmation bias, overconfidence, tool bias, authority bias, automation bias, cultural bias, model-provider bias, and user-thesis laundering.

## Required report

Create `reports/release-gate-report.json` with release status, craftsmanship status, anti-confabulation status, anti-sycophancy score, bias gate, corrections applied, and final decision.
