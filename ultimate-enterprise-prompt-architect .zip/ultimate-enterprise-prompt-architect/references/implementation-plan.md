# Implementation Plan for Improving Prompt Generation Quality

Plan path: `references/implementation-plan.md`
Status: ready-for-execution

<!-- GOAL_START -->
Goal: Enterprise Prompt Generation Upgrade

Ziel. Turn the inherited prompt-architect material into a validated enterprise prompt-generation skill that produces auditable prompt packages instead of unsourced “perfect prompt” claims. The result must preserve the useful legacy behavior while adding source discipline, structured outputs, evals, prompt-injection controls, and release gates.

Scope. Build one ChatGPT Skill package named `ultimate-enterprise-prompt-architect` with direct references, scripts, evals, reports, and a package artifact named `skill.zip`.

Bedingungen (hart).
- User-provided prompt packs are context, not factual authority.
- No broken references, nested required ZIPs, or production placeholders.
- No hidden chain-of-thought disclosure requests.
- No unsupported claims of guaranteed quality or full hallucination prevention.

Akzeptanzkriterien.
- `SKILL.md` has valid frontmatter and matches the folder name.
- Source map, source policy, security policy, eval design, and release gate exist.
- Trigger and output eval files include positive and negative cases.
- Local validators pass.
- `skill.zip` contains exactly one root skill folder.

Explizit out-of-scope.
- Running paid vendor eval jobs.
- Claiming official OpenAI, Anthropic, Google, OWASP, or NIST certification.
- Building a live prompt-management SaaS.
- Guaranteeing model outputs under every future model version.

Done-Definition. A validated `skill.zip` plus visible audit, research, plan, release, installability, and core-parity reports.

Reference-Doc: `references/implementation-plan.md`
<!-- GOAL_END -->

## Requirements

| ID | Requirement | Source | Verification |
|---|---|---|---|
| REQ-F-001 | Generate enterprise prompt packages with system/developer prompt, user template, evaluator, schema guidance, and tests | user-provided, primary docs | Output evals |
| REQ-F-002 | Audit existing prompts before rewriting | user-provided | Prompt audit framework |
| REQ-F-003 | Support structured output and API prompt designs | primary docs | Eval case and output contract |
| REQ-NF-001 | Avoid unsupported quality guarantees | source policy | Release gate |
| REQ-S-001 | Include injection and tool/agency safety gates | OWASP, source policy | Security reference review |
| REQ-A-001 | Keep SKILL.md compact and move detail to references | skill package rules | Quick validator |
| REQ-O-001 | Package as exactly `skill.zip` | enterprise skill creator contract | Package script |

## Phases

### Phase 1: Audit and preserve

- Inspect uploaded packages.
- Identify strengths, broken references, duplicates, placeholders, and missing enterprise controls.
- Preserve prompt architecture, method routing, anti-sycophancy, and prompt-package outputs.

### Phase 2: Research-backed upgrade

- Add vendor and security primary sources.
- Convert broad claims into confidence-scored rules.
- Use `SOURCE_NEEDED` for unsupported or dynamic claims.

### Phase 3: Architecture rebuild

- Create compact SKILL.md.
- Move methods, source discipline, audit, security, evals, release gates, and plan into references.
- Put reusable templates in assets.

### Phase 4: Validation and packaging

- Add deterministic validators.
- Run quick, source, eval, release, installability, agent-agnostic, core parity, and placeholder checks.
- Package as `skill.zip`.

## Tasks

### TASK-001: Normalize package structure

Objective: Build a single root skill folder with direct references.

Steps:
1. Create `ultimate-enterprise-prompt-architect/`.
2. Add `SKILL.md` and `agents/openai.yaml`.
3. Add direct `references/`, `scripts/`, `evals/`, `reports/`, and `assets/` directories.
4. Do not nest required prompt materials inside ZIP files.

Validation: `python scripts/quick_validate.py <skill-dir>`.

### TASK-002: Add source and research discipline

Objective: Prevent user-provided prompt claims from becoming unsupported hard rules.

Steps:
1. Add source policy.
2. Add source map with user-provided and primary-source records.
3. Add research bag with confidence and `SOURCE_NEEDED` items.

Validation: `python scripts/validate_source_map.py <skill-dir>`.

### TASK-003: Add prompt quality architecture

Objective: Make prompt generation repeatable and auditable.

Steps:
1. Add method-selection matrix.
2. Add prompt-generation blueprint.
3. Add output contract.
4. Add prompt audit framework.

Validation: output evals must reference these behaviors.

### TASK-004: Add security and release gates

Objective: Prevent prompt-injection, agency, and overclaim failures.

Steps:
1. Add security/tool policy.
2. Add release-gate policy.
3. Create release-gate report.
4. Validate anti-sycophancy threshold and blocked claims.

Validation: `python scripts/validate_release_gate.py <skill-dir>`.

### TASK-005: Add evals and validators

Objective: Make the skill testable before packaging.

Steps:
1. Add trigger evals with positive and negative cases.
2. Add output evals covering prompt creation, audit, API schema, and unsafe requests.
3. Add validators.
4. Run package script.

Validation: `python scripts/package_skill.py <skill-dir> ./dist`.

## Rollback and safety

- If validators fail, do not package.
- If release gate fails, revise rather than ship.
- If a source claim is dynamic and not checked, downgrade to `SOURCE_NEEDED`.
- If frontend installation behavior cannot be controlled, state only that the package is prepared, not guaranteed to surface UI affordances.

## Truth and bias check

- Confirmation bias: mitigated by preserving strengths but rejecting unsupported guarantees.
- Tool bias: validators are treated as local evidence, not proof of runtime behavior.
- Overconfidence: no quality guarantee language is used.
- Authority bias: vendor docs are used for provider-specific guidance, not universal claims.
