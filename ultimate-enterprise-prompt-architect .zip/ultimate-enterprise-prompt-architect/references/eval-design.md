# Evaluation Design

## Evaluation layers

Enterprise prompt systems require at least three evaluation layers when used beyond one-off chat:

1. Trigger or routing evals: does the prompt activate for the right tasks?
2. Output-contract evals: does the model return required structure and content?
3. Risk evals: does the prompt resist unsafe, biased, injected, or unsupported behavior?

## Trigger evals

Store skill trigger tests in `evals/trigger_queries.json`.

Each case includes:

```json
{
  "query": "user-like prompt",
  "should_trigger": true,
  "reason": "why this should or should not activate"
}
```

Include positive cases and near-miss negative cases.

## Output evals

Store output-quality tests in `evals/output_evals.json`.

Each case includes:

```json
{
  "id": "OUT-001",
  "prompt": "realistic task",
  "expected_properties": ["property A"],
  "failure_modes": ["what would fail"]
}
```

## Prompt package evals

For prompt packages intended for API or agent use, create case sets with:

- nominal input;
- edge input;
- malformed input;
- missing data;
- injection attempt;
- irrelevant request;
- high-stakes unsupported claim;
- expected abstention/refusal.

## Acceptance criteria

A production prompt package should not ship unless:

- task success criteria are explicit;
- output format is testable;
- unsafe behavior has negative tests;
- high-stakes claims require evidence;
- evaluator prompt or deterministic validators exist;
- known limitations are documented.
