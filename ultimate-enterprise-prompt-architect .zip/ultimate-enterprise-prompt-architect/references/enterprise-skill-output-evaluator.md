# Enterprise Skill Output Evaluator

Use this reference when evaluating a generated skill package or Skill-Creator output. Do not build a new skill during evaluation unless revision is explicitly requested.

## Dimensions

1. Spec compliance: `SKILL.md`, valid frontmatter, name matches folder, trigger-rich description, Progressive Disclosure.
2. Research quality: source map, source classes, confidence, `SOURCE_NEEDED`, `MISSING`, hard claim discipline.
3. Enterprise readiness: security/tool policy, no secrets, no destructive defaults, data classification, permission boundaries.
4. Architecture quality: coherent scope, references separated, validators, evals, packaging reproducibility.
5. Release-gate integrity: craftsmanship pass, anti-confabulation pass, anti-sycophancy below threshold, bias gate not blocked.

## XML output

```xml
<enterprise_skill_evaluation>
  <scores>
    <spec_compliance>1-5</spec_compliance>
    <research_quality>1-5</research_quality>
    <enterprise_readiness>1-5</enterprise_readiness>
    <architecture_quality>1-5</architecture_quality>
    <release_gate_integrity>1-5</release_gate_integrity>
  </scores>
  <blocking_issues>
    <item>BLOCKER_OR_NONE</item>
  </blocking_issues>
  <required_revisions>
    <item>CONCRETE_REVISION</item>
  </required_revisions>
  <decision>PASS | PASS_WITH_MINOR_REVISIONS | REVISE | REBUILD | BLOCKED</decision>
  <reason>Short evidence-based justification.</reason>
</enterprise_skill_evaluation>
```
