# Prompt Audit Framework

## Audit dimensions

Score each dimension from 1 to 5, with evidence and limitation.

| Dimension | Checks |
|---|---|
| Objective fit | Clear task, audience, definition of done, and non-goals |
| Context control | Relevant context, input delimiters, variable separation |
| Output contract | Format, schema, ordering, required fields, error states |
| Method fit | Reasoning method is proportional to task complexity |
| Evidence discipline | Source requirements, uncertainty, abstention behavior |
| Safety and tools | Least privilege, injection handling, approval gates |
| Bias resistance | Anti-sycophancy, counterargument, no user-thesis laundering |
| Testability | Examples, evals, adversarial cases, acceptance criteria |
| Maintainability | Versioning, modularity, no broken references, no duplication |
| Portability | Provider-specific claims separated from model-agnostic logic |

## Finding schema

Each finding should include:

```yaml
id: PA-001
domain: objective | context | output | method | evidence | safety | bias | eval | maintainability | portability
severity: low | medium | high | blocker
claim: string
evidence: string
evidence_class: user_provided | source_inspected | primary_source | static_validation | inferred
risk: string
fix: string
limitation: string
```

## Release gates

Block release when:

- the prompt references missing files or unavailable tools;
- downstream systems require structured fields but no schema or validator exists;
- the prompt asks for hidden chain-of-thought disclosure;
- prompt-injection risk is ignored in tool/file/web contexts;
- a high-stakes factual prompt lacks source and uncertainty rules;
- evaluator or test cases are absent for enterprise deployment;
- user-provided claims are presented as verified facts;
- prompt quality promises are absolute or untestable.

## Audit verdicts

- `PASS`: ready for intended use with documented limits.
- `PASS_WITH_LIMITS`: usable but needs monitoring or small corrections.
- `REVISE`: useful draft, not enterprise-ready.
- `REBUILD`: structure or method is materially wrong.
- `BLOCKED`: unsafe, broken, unsupported, or impossible to validate.
