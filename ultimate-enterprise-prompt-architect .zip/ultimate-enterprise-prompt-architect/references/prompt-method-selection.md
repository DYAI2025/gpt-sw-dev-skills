# Prompt Method Selection

## Principle

Choose the smallest sufficient method. Heavy reasoning scaffolds can improve difficult tasks but can also increase latency, cost, verbosity, and false confidence.

## Decision matrix

| Task type | Recommended method | Required additions | Avoid |
|---|---|---|---|
| Simple transformation, rewrite, formatting | Direct structured instruction | Output examples or style constraints | Tree search or ensemble language |
| Multi-step plan or implementation work | Plan-and-solve with checkpoints | Goal, requirements, validation, rollback | Hidden chain-of-thought request |
| Numeric, tabular, financial, or deterministic calculation | Program-of-thought or tool-backed calculation | Deterministic script/tool result, error handling | Mental arithmetic for complex values |
| Ambiguous strategy, product, architecture, concept design | Options with scored convergence | Criteria, trade-offs, counterargument | Premature single answer |
| High-stakes factual analysis | Evidence-first audit | Source map, claim matrix, uncertainty | Unsupported confident claims |
| Prompt optimization from examples | Diff-driven improvement loop | Failure examples, ideal outputs, eval cases | Blind rewrite without preserving variables |
| API integration | Schema-first prompt package | JSON schema, enum constraints, refusal/errors, test cases | Free-form outputs required by downstream code |
| Tool-using or agent prompt | Tool boundary architecture | Least privilege, human approval, evidence requirements | Giving broad tool freedom |
| Creative prompt | Constraint hierarchy | Style intent, non-goals, examples | Overconstraining every detail |
| Image or video prompt | Scene/component prompt | locked elements, camera, lighting, composition, negative constraints | Asking image model to reliably render long exact text |

## Public reasoning rule

Prompts may ask models to plan, check, compare, or summarize their reasoning. Do not ask models to reveal private hidden chain-of-thought. Prefer:

- `provide a concise rationale`
- `show assumptions and checks`
- `list alternatives considered`
- `state confidence and missing evidence`
- `return a validation table`

## Method escalation

Escalate method only when the failure mode justifies it:

1. direct structured prompt
2. prompt plus examples
3. prompt plus evaluator
4. prompt plus schema and validators
5. prompt plus eval dataset
6. prompt plus tool/API workflow
7. prompt plus red-team and release gate

## Method de-escalation

De-escalate when:

- speed or cost matters more than marginal quality;
- task has low ambiguity;
- user needs a short artifact;
- model/provider already has built-in structured-output controls;
- examples are clearer than abstract rules.
