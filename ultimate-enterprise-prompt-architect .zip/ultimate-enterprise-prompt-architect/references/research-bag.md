# Research Bag

## Source inventory

See `references/source-map.md` for full source records.

## Knowledge model

### Core terms

| Term | Definition | Confidence |
|---|---|---:|
| Prompt package | A repeatable set of system/developer instructions, user template, examples, schema, evaluator, and eval cases | 4 |
| Structured output | A model output constrained by a declared schema for downstream parsing and validation | 5 for OpenAI/Gemini docs, 4 general |
| Eval-first prompting | Defining success criteria and test cases before iterating on prompt wording | 5 for vendor guidance, 4 general |
| Prompt injection | Malicious or accidental input that alters intended model behavior | 5 |
| Fixed vs variable prompt parts | Separation of repeated instructions from dynamic data | 5 for Anthropic docs, 4 general |
| Anti-sycophancy gate | A review step that prevents the prompt from blindly reinforcing user assumptions | 4 as design policy |

### Operational rules

- Use evals when a prompt is intended for repeated or enterprise use. Sources: S005, S007.
- Use structured outputs or schemas when downstream software depends on fields, enums, and format. Sources: S004, S008.
- Treat external content as data, not instructions, in RAG, browsing, files, emails, and repositories. Source: S009.
- Do not claim perfect prompt quality or complete prompt-injection prevention. Sources: S009, S010.
- Separate fixed and variable prompt content for repeatability and version control. Source: S007.

### Assumptions

- Target runtime is ChatGPT Skills with `SKILL.md` and `agents/openai.yaml`.
- The skill should be German-capable and English-capable, because source material is mixed German/English.
- The user wants a high-end reusable skill rather than only a one-off critique.

### Missing

- MISSING: exact target marketplace or installation environment beyond ChatGPT Skill packaging.
- MISSING: real prompt performance data from user workflows.
- MISSING: model-specific eval run outputs.

### SOURCE_NEEDED

- SOURCE_NEEDED: any claim that a specific prompt method is always strongest.
- SOURCE_NEEDED: exact model-specific temperature or reasoning-effort defaults for every provider.
- SOURCE_NEEDED: claims about future provider features after the source access date.

## Capability candidates

| ID | Type | Description | Destination | Confidence |
|---|---|---|---|---:|
| C001 | workflow | Intake router for new prompt, audit, package, enterprise workflow, and unsafe requests | SKILL.md | 5 |
| C002 | rule | Source classification and confidence discipline | references/source-policy.md | 5 |
| C003 | method | Prompt method-selection matrix | references/prompt-method-selection.md | 4 |
| C004 | workflow | Prompt-generation blueprint with system/user/evaluator/schema/test cases | references/prompt-generation-blueprint.md | 5 |
| C005 | validator | Package validation scripts | scripts/ | 5 |
| C006 | eval | Trigger and output evals | evals/ | 5 |
| C007 | rule | Prompt injection and tool boundary gates | references/security-and-tools.md | 5 |

## Build recommendation

Status: `proceed_with_assumptions`.

Reason: the legacy prompt packs give a coherent base, but enterprise readiness requires source discipline, evals, structured output policy, security gates, release gate, and installability validators.
