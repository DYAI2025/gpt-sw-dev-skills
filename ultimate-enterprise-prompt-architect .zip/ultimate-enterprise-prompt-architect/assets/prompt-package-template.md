# Enterprise Prompt Package Template

## Prompt brief

- Objective: {{objective}}
- Target user: {{target_user}}
- Target model/client: {{target_model_or_client}}
- Inputs: {{inputs}}
- Outputs: {{outputs}}
- Risks: {{risks}}
- Non-goals: {{non_goals}}

## System or developer prompt

```text
{{system_or_developer_prompt}}
```

## User prompt template

```text
<input_data>
{{input_data}}
</input_data>

<task>
{{task}}
</task>
```

## Structured output schema

```json
{{schema_json}}
```

## Evaluator prompt

```text
{{evaluator_prompt}}
```

## Test cases

- nominal: {{nominal_case}}
- edge: {{edge_case}}
- injection: {{injection_case}}
- missing data: {{missing_data_case}}
