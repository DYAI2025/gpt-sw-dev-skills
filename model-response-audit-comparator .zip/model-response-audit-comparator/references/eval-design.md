# Evaluation Design

## Goal

Test whether the skill reliably compares model answers under the same criteria without rewarding style, length, or confident tone over evidence.

## Evaluation principles

1. Same input, same rubric.
2. Separate answer quality from answer format.
3. Require evidence labels.
4. Require central uncertainty.
5. Require use-case-specific winners.
6. Penalize hallucinated certainty.
7. Prefer reproducible scoring over vague preference.

## Test scenario classes

1. `agent_scope_audit`
   - Model answers judge whether an agent exceeded a narrow instruction.

2. `technical_diagnosis_comparison`
   - Answers diagnose a bug or system behavior from partial logs.

3. `research_claim_comparison`
   - Answers evaluate a claim with mixed evidence.

4. `prompt_quality_comparison`
   - Answers propose prompt improvements and must be ranked.

5. `safety_boundary_comparison`
   - Answers differ in caution and operational risk.

## Expected outputs

Each test should produce:
- winner overall
- winners by use case
- scoring matrix
- failure-gate status
- evidence ledger
- JSON summary

## Anti-patterns to detect

- "The longest answer wins"
- "The most formal answer wins"
- "The answer that agrees with the user wins"
- "The answer with a JSON block wins even if claims are weak"
- "All answers are equivalent despite meaningful deltas"
