# Source Policy

## Source classes

- `primary`: official documentation, original logs, repo diffs, source files, standards, API docs.
- `secondary`: benchmark papers, technical articles, educational explainers.
- `user_provided`: user-pasted answers, notes, prompts, transcripts, screenshots.
- `derived`: summaries, OCR, model-generated reconstructions.
- `uncertain`: material with unclear origin.

## Confidence scale

| Score | Meaning | Use rule |
|---|---|---|
| 5 | Directly supported by primary evidence | May support hard claims |
| 4 | Strong source or multiple independent supports | May support recommendations |
| 3 | Plausible but indirect or partial | Mark as assumption |
| 2 | Weak, contradictory, or context dependent | Do not use as hard rule |
| 1 | Unsupported or speculative | Block or mark SOURCE_NEEDED |

## Claim labels

Use these labels in audits:
- `FACT`: directly supported by source material.
- `INFERENCE`: logically derived from supported facts.
- `INTERPRETATION`: evaluative or contextual reading.
- `ASSUMPTION`: plausible but not established.
- `SOURCE_NEEDED`: claim lacks enough evidence.
- `MISSING`: required input or artifact is absent.

## Non-negotiable rules

1. User-provided model answers are objects of evaluation, not truth.
2. Do not infer file system state, commit history, tool history, or UI actions unless evidence is supplied.
3. A visible status line is evidence of visibility, not necessarily evidence of active creation.
4. A long answer is not automatically deeper.
5. A structured answer is not automatically more correct.
6. Confidence must decrease when source material is partial.
