# Domain Ontology

## Core entities

- `original_input`: Prompt or task that all responses received.
- `model_response`: One answer produced by a model.
- `source_material`: Logs, files, documents, screenshots, diffs, citations, or other evidence.
- `audit_claim`: A statement made by a model response.
- `evidence_ledger`: Mapping from claims to support status.
- `rubric_dimension`: One scoring category.
- `failure_gate`: A blocking or downgrading condition.
- `pairwise_delta`: Difference between two responses under the same criterion.
- `use_case_winner`: Best response for a specific purpose, not necessarily best overall.

## Claim types

- `factual`: States what happened or what a source contains.
- `inferential`: Draws a conclusion from facts.
- `evaluative`: Assigns quality, severity, or ranking.
- `prescriptive`: Recommends an action or control.
- `meta`: Discusses uncertainty, confidence, method, or limits.

## Agent-audit action types

Use this taxonomy for logs and agent behavior:
- `read`: inspect files or context.
- `write`: create or modify files.
- `execute`: run commands or tests.
- `diagnose`: investigate why a result occurred.
- `implement`: alter product behavior or logic.
- `commit`: persist changes to version control.
- `task_update`: create or modify tasks, todos, plans, or status.
- `report`: summarize results.
- `stop`: cease further tool/action execution.

## Common answer profiles

- `compliance_auditor`: Strong on formal scope, risk of over-strictness.
- `operational_coach`: Strong on practical next steps, risk of being too permissive.
- `forensic_analyst`: Strong on evidence and uncertainty, risk of over-formalization.
- `executive_summarizer`: Clear and short, risk of losing edge cases.
- `advocate`: Persuasive, risk of selective evidence.
