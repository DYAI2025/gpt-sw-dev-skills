# Agent-Agnostic Compatibility

This skill is semantically portable across ChatGPT, Claude, Gemini, Codex-like coding agents, Cursor, Windsurf, and human reviewers.

Compatibility means:
- the rubric can be followed by different agents
- the source policy and failure gates transfer semantically
- the JSON schema can be implemented in different runtimes
- deterministic validators can be reimplemented or executed where Python is available

Compatibility does not imply identical:
- tool access
- file-system access
- UI behavior
- browser state
- hidden runtime logs
- chain-of-thought visibility
- model-specific scoring behavior

When another agent lacks a tool, it must mark the evidence as MISSING rather than pretending the check was performed.
