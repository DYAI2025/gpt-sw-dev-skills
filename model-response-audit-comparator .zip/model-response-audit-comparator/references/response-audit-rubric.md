# Response Audit Rubric

## Default weighted dimensions

| ID | Dimension | Weight | What excellent looks like |
|---|---|---:|---|
| D1 | Task understanding | 10 | Reconstructs explicit and implicit task without drift |
| D2 | Evidence discipline | 15 | Separates facts, inferences, interpretations, and missing evidence |
| D3 | Verdict precision | 12 | Gives calibrated verdict, not false binary |
| D4 | Action-type differentiation | 10 | Distinguishes read/write/execute/diagnose/implement/commit/task-update/report/stop |
| D5 | Depth of analysis | 10 | Checks alternatives, edge cases, and counterarguments |
| D6 | Uncertainty and confidence management | 10 | Names what would change the verdict |
| D7 | Bias and failure-mode detection | 8 | Finds answer bias, evaluator bias, and test artifacts |
| D8 | Practical utility | 10 | Gives usable control rule, next test, or decision support |
| D9 | Comparison consistency | 5 | Applies the same standards to all answers |
| D10 | Structure and readability | 5 | Clear and proportional to task complexity |
| D11 | Machine readability | 3 | Provides stable JSON or extractable fields when useful |
| D12 | Robustness against test artifacts | 2 | Avoids length, format, role, and confidence bias |

Total: 100

## Score anchors

0 = absent, harmful, or misleading.
1 = weak and mostly ungrounded.
2 = partial, with material gaps.
3 = adequate for a normal answer.
4 = strong, with only minor gaps.
5 = excellent, audit-ready and reproducible.

## Required per-score explanation

For every score below 3 or above 4, give a short explanation. For scores of 3-4, explain only if material to the verdict.

## Use-case winner categories

Always consider whether different answers win different use cases:
- Best overall
- Best for strict compliance
- Best for practical control
- Best for audit documentation
- Best for executive clarity
- Best for next-test design
