# Source Map

## Current build sources

| Source | Type | Purpose | Reliability | Limits | Skill use |
|---|---|---|---|---|---|
| User examples GPT1, GPT2, GPT3 | user_provided | Derive practical comparison needs | Medium | Not independently verified | Rubric examples and use cases |
| Research-Backed Skill Builder instructions | user_provided / skill_instruction | Source policy, confidence and packaging principles | High within current environment | Not external standard | Skill architecture |
| Enterprise Skill Creator instructions | user_provided / skill_instruction | Enterprise files, release gates, installability | High within current environment | Platform-specific | Packaging and reports |
| OpenAI Evals guide | primary | Evaluation concept: explicit criteria and eval workflows | High when current | API docs may change | Optional source for eval design |
| NIST AI RMF | primary | Trustworthiness and risk-management framing | High | General framework, not task-specific | Risk and governance framing |
| HELM paper | secondary/research | Multi-metric model evaluation inspiration | High for research context | Benchmark-focused, not answer-audit-specific | Multi-dimensional scoring |
| Anthropic evaluation article | secondary/vendor research | Human eval limitations and evaluator bias context | Medium-high | Vendor perspective | Bias and calibration rules |

## Use rule

External sources support general evaluation design only. They do not decide the truth of any specific model-answer comparison unless the user's case requires them and they are cited in the final answer.
