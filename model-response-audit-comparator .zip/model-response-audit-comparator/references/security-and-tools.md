# Security and Tools

## Permission boundary

This skill is read-only by default. It audits texts, logs, files, and model answers. It must not modify user systems, execute destructive commands, or infer hidden runtime state without evidence.

## Tool use

Use tools only when needed:
- `file_search`: inspect user-uploaded files.
- `web_search`: verify current official docs, standards, APIs, or benchmark sources.
- `python`: validate JSON, calculate weighted scores, package skill artifacts.

## Prohibited behavior

- Do not claim access to hidden model internals.
- Do not ask for or expose private chain-of-thought.
- Do not infer commits, file writes, or task updates unless shown.
- Do not recommend bypassing approvals, auth, or safety gates.
- Do not turn a visible UI artifact into a hard causal claim without evidence.

## Data classification

- Pasted model answers: `user_provided`.
- Logs and screenshots: `user_provided` unless provenance is independently verified.
- Repo diffs or command transcripts: stronger evidence, still limited to supplied scope.
- Official docs: `primary`, but may require freshness checks.
