#!/usr/bin/env python3
from pathlib import Path
import sys, json

def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    report_path = root / "reports/release-gate-report.json"
    report = json.loads(report_path.read_text(encoding="utf-8"))
    blockers = []
    if report.get("release_gate", {}).get("status") not in ["PASS", "PASS_WITH_ASSUMPTIONS"]:
        blockers.append("release_gate not pass")
    for gate in ["craftsmanship_gate", "anti_confabulation_gate", "bias_gate"]:
        if report.get(gate, {}).get("status") not in ["PASS", "PASS_WITH_ASSUMPTIONS"]:
            blockers.append(f"{gate} not pass")
    if report.get("blocked_claims"):
        blockers.append("blocked_claims not empty")
    status = "PASS" if not blockers else "FAIL"
    print(json.dumps({"status": status, "blockers": blockers}, indent=2))
    sys.exit(0 if status == "PASS" else 1)

if __name__ == "__main__":
    main()
