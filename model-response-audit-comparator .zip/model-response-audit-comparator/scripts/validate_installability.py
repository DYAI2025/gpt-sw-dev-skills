#!/usr/bin/env python3
from pathlib import Path
import sys, json

def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    issues = []
    if not (root / "SKILL.md").exists():
        issues.append("missing SKILL.md")
    if not (root / "agents/openai.yaml").exists():
        issues.append("missing agents/openai.yaml")
    report = root / "reports/installability-report.json"
    if not report.exists():
        issues.append("missing installability-report.json")
    else:
        data = json.loads(report.read_text(encoding="utf-8"))
        if data.get("frontend_install_suggestion_status") == "guaranteed":
            issues.append("frontend install suggestion must not be guaranteed")
    status = "PASS" if not issues else "FAIL"
    print(json.dumps({"status": status, "issues": issues}, indent=2))
    sys.exit(0 if status == "PASS" else 1)

if __name__ == "__main__":
    main()
