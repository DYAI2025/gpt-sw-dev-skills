#!/usr/bin/env python3
from pathlib import Path
import sys, json, re

REQUIRED_TERMS = ["user_provided", "primary", "secondary", "derived", "uncertain"]

def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    path = root / "references/source-map.md"
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    missing = [t for t in REQUIRED_TERMS if t not in text and t not in (root / "references/source-policy.md").read_text(encoding="utf-8")]
    status = "PASS" if not missing else "FAIL"
    print(json.dumps({"status": status, "missing_terms": missing}, indent=2))
    sys.exit(0 if status == "PASS" else 1)

if __name__ == "__main__":
    main()
