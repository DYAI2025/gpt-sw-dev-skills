#!/usr/bin/env python3
from pathlib import Path
import sys, json

def load(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    triggers = load(root / "evals/trigger_queries.json")
    outputs = load(root / "evals/output_evals.json")
    errors = []
    if not isinstance(triggers, list) or len(triggers) < 5:
        errors.append("Need at least 5 trigger evals")
    if not isinstance(outputs, list) or len(outputs) < 3:
        errors.append("Need at least 3 output evals")
    for i, item in enumerate(triggers):
        if "query" not in item or "expected_mode" not in item:
            errors.append(f"trigger {i} missing query or expected_mode")
    for i, item in enumerate(outputs):
        if "name" not in item or "must_include" not in item:
            errors.append(f"output eval {i} missing name or must_include")
    status = "PASS" if not errors else "FAIL"
    print(json.dumps({"status": status, "errors": errors}, indent=2))
    sys.exit(0 if status == "PASS" else 1)

if __name__ == "__main__":
    main()
