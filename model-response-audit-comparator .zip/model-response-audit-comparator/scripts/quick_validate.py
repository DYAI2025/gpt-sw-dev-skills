#!/usr/bin/env python3
from pathlib import Path
import sys, yaml, json

REQUIRED = [
    "SKILL.md",
    "agents/openai.yaml",
    "references/source-policy.md",
    "references/source-map.md",
    "references/security-and-tools.md",
    "references/eval-design.md",
    "evals/trigger_queries.json",
    "evals/output_evals.json",
    "reports/release-gate-report.json"
]

def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    missing = [p for p in REQUIRED if not (root / p).exists()]
    if missing:
        print(json.dumps({"status": "FAIL", "missing": missing}, indent=2))
        sys.exit(1)
    skill = (root / "SKILL.md").read_text(encoding="utf-8")
    if not skill.startswith("---"):
        print(json.dumps({"status": "FAIL", "error": "SKILL.md missing frontmatter"}, indent=2))
        sys.exit(1)
    print(json.dumps({"status": "PASS", "checked": len(REQUIRED)}, indent=2))

if __name__ == "__main__":
    main()
