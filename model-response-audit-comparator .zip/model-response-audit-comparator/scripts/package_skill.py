#!/usr/bin/env python3
from pathlib import Path
import sys, zipfile, json

def main():
    if len(sys.argv) < 3:
        print("Usage: package_skill.py <skill-dir> <dist-dir>")
        sys.exit(2)
    skill_dir = Path(sys.argv[1]).resolve()
    dist_dir = Path(sys.argv[2]).resolve()
    dist_dir.mkdir(parents=True, exist_ok=True)
    zip_path = dist_dir / "skill.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in skill_dir.rglob("*"):
            if p.is_file():
                z.write(p, arcname=str(Path(skill_dir.name) / p.relative_to(skill_dir)))
    print(json.dumps({"status": "PASS", "artifact": str(zip_path)}, indent=2))

if __name__ == "__main__":
    main()
