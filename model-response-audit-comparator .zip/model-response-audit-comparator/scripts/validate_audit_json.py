#!/usr/bin/env python3
from pathlib import Path
import sys, json

try:
    import jsonschema
except Exception:
    jsonschema = None

def basic_validate(data):
    required = ["task", "responses", "criteria_scores", "failure_gates", "winner", "confidence", "main_uncertainty"]
    missing = [k for k in required if k not in data]
    if missing:
        return False, [f"missing: {k}" for k in missing]
    if not isinstance(data.get("responses"), list) or len(data["responses"]) < 2:
        return False, ["responses must contain at least two items"]
    if not (0 <= data.get("confidence", -1) <= 1):
        return False, ["confidence must be 0..1"]
    return True, []

def main():
    if len(sys.argv) < 3:
        print("Usage: validate_audit_json.py <schema> <audit.json>")
        sys.exit(2)
    schema_path = Path(sys.argv[1])
    audit_path = Path(sys.argv[2])
    data = json.loads(audit_path.read_text(encoding="utf-8"))
    errors = []
    if jsonschema:
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        try:
            jsonschema.validate(data, schema)
        except Exception as e:
            errors.append(str(e))
    else:
        ok, errs = basic_validate(data)
        errors.extend(errs)
    status = "PASS" if not errors else "FAIL"
    print(json.dumps({"status": status, "errors": errors}, indent=2))
    sys.exit(0 if status == "PASS" else 1)

if __name__ == "__main__":
    main()
