#!/usr/bin/env python3
from pathlib import Path
import sys, json

def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    p = root / "reports/core-functionality-preservation.json"
    issues = []
    if not p.exists():
        issues.append("missing core-functionality-preservation.json")
    else:
        data = json.loads(p.read_text(encoding="utf-8"))
        if data.get("status") not in ["PASS", "PASS_WITH_ASSUMPTIONS"]:
            issues.append("core parity not pass")
        if not data.get("preserved_core_functions"):
            issues.append("no preserved core functions listed")
    status = "PASS" if not issues else "FAIL"
    print(json.dumps({"status": status, "issues": issues}, indent=2))
    sys.exit(0 if status == "PASS" else 1)

if __name__ == "__main__":
    main()
