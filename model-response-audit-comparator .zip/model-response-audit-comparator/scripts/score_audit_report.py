#!/usr/bin/env python3
from pathlib import Path
import sys, json

DEFAULT_WEIGHTS = {
    "task_understanding": 10,
    "evidence_discipline": 15,
    "verdict_precision": 12,
    "action_type_differentiation": 10,
    "depth_of_analysis": 10,
    "uncertainty_management": 10,
    "bias_failure_detection": 8,
    "practical_utility": 10,
    "comparison_consistency": 5,
    "structure_readability": 5,
    "machine_readability": 3,
    "test_artifact_robustness": 2
}

def weighted_score(scores, weights=DEFAULT_WEIGHTS):
    total_weight = sum(weights.values())
    raw = 0.0
    for key, weight in weights.items():
        raw += float(scores.get(key, 0)) / 5.0 * weight
    return round(raw / total_weight * 100.0, 2)

def main():
    if len(sys.argv) != 2:
        print("Usage: score_audit_report.py <criteria_scores_by_response.json>")
        sys.exit(2)
    data = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    result = {rid: weighted_score(scores) for rid, scores in data.items()}
    print(json.dumps(result, indent=2, sort_keys=True))

if __name__ == "__main__":
    main()
