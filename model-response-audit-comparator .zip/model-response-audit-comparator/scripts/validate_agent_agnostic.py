#!/usr/bin/env python3
from pathlib import Path
import sys, json

def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    p = root / "references/agent-agnostic-compatibility.md"
    issues = []
    if not p.exists():
        issues.append("missing agent-agnostic compatibility note")
    else:
        text = p.read_text(encoding="utf-8").lower()
        for term in ["semantic", "tool", "runtime", "not imply identical"]:
            if term not in text:
                issues.append(f"missing concept: {term}")
    status = "PASS" if not issues else "FAIL"
    print(json.dumps({"status": status, "issues": issues}, indent=2))
    sys.exit(0 if status == "PASS" else 1)

if __name__ == "__main__":
    main()
