---
name: model-response-audit-comparator
description: Audits and compares multiple model answers to the same input with evidence discipline, scope control, weighted rubrics, failure gates, uncertainty handling, bias checks, pairwise deltas, and machine-readable reports. Use when users ask which GPT/model answer is better, deeper, more precise, safer, more useful, or more audit-ready.
version: 0.2.0
---

# Model Response Audit Comparator

## When to use

Use this skill when the user wants to compare, audit, rank, or improve multiple model answers that were produced from the same or comparable input.

Typical triggers:
- "Vergleiche GPT1 und GPT2"
- "Welche Antwort ist besser?"
- "Auditier die Modellantworten"
- "Bewerte Tiefe, Qualitaet, Praezision"
- "Welche Diagnose ist robuster?"
- "Baue daraus ein Bewertungsraster"
- "Vergleiche Claude, GPT, Gemini, Codex Antworten"
- "Pruefe, ob ein Agent ohne Freigabe gearbeitet hat"
- "Finde Unterschiede in Evidenz, Bias, Scope und Nutzbarkeit"

Do not use for:
- one-off proofreading without comparison
- pure preference ranking without a quality question
- offensive cyber evaluation
- legal, medical, financial final decisions without expert review
- claims that require hidden runtime history not supplied by the user

## Core principle

Do not reward style, length, confidence, or formal structure alone. Reward answers that are correct, scope-faithful, evidence-grounded, uncertainty-aware, practically useful, and reproducible under the same criteria.

## Required inputs

Minimum:
- `original_input`: the prompt or task all models received, or a clear statement that it was identical.
- `responses`: at least two model answers with stable labels, e.g. GPT1, GPT2, GPT3.
- `analysis_goal`: what the comparison should decide, e.g. best overall, best compliance, deepest analysis, best audit report.

Optional:
- `source_material`: logs, documents, files, screenshots, transcripts, repo diffs, citations.
- `evaluation_mode`: `quick`, `standard`, `enterprise`.
- `risk_level`: `low`, `medium`, `high`.
- `weights`: user-specified scoring weights.
- `required_output`: text, table, JSON, or full audit report.

If required evidence is absent, mark `MISSING`. If a hard claim lacks support, mark `SOURCE_NEEDED`.

## Source handling

Classify all sources before judging:
- `user_provided`: user text, examples, internal notes, pasted logs.
- `primary`: official docs, standards, original logs, repo diffs, API docs.
- `secondary`: articles, benchmark papers, explanations.
- `derived`: summaries, OCR, model summaries, transcript excerpts.
- `uncertain`: unclear origin.

Never treat a user-provided model answer as truth. It is an object being audited.

## Evaluation modes

### quick
Use when the user needs a compact comparison. Include:
- short verdict
- table of major differences
- winner by use case
- main uncertainty

### standard
Use for most comparisons. Include:
- source map
- scoring matrix
- pairwise delta review
- evidence ledger
- bias and failure modes
- synthesis and recommendation
- machine-readable JSON summary

### enterprise
Use for audit-heavy, agent-control, compliance, or repeatable testing contexts. Include all standard sections plus:
- full rubric scores with weights
- failure-gate status
- claim typing
- scope-delta matrix
- calibration check
- next-test design
- open questions
- release decision

## Rubric dimensions

Use the weighted rubric from `references/response-audit-rubric.md` unless the user specifies another weighting.

Default dimensions:
1. Task understanding
2. Evidence discipline
3. Verdict precision
4. Action-type differentiation
5. Depth of analysis
6. Uncertainty and confidence management
7. Bias and failure-mode detection
8. Practical utility
9. Comparison consistency
10. Structure and readability
11. Machine readability
12. Robustness against test artifacts

Scoring:
- 0 = absent or harmful
- 1 = weak
- 2 = partial
- 3 = adequate
- 4 = strong
- 5 = excellent

## Mandatory analysis workflow

1. Intake and scope gate
   - Identify the comparison goal.
   - Confirm whether inputs are identical or comparable.
   - Mark MISSING evidence.

2. Source map
   - List all sources and classify them.
   - Distinguish original material from model claims.

3. Task reconstruction
   - Restate the user question.
   - Define what "better" means for this comparison.

4. Claim extraction
   - Extract key claims from each answer.
   - Type each claim: factual, inferential, evaluative, prescriptive, meta.

5. Evidence ledger
   - Mark each material claim as: supported, weakly supported, unsupported, contradicted, or unverifiable.

6. Rubric scoring
   - Score each answer 0-5 per dimension.
   - Apply default or user-provided weights.
   - Briefly justify each non-obvious score.

7. Pairwise delta review
   - Compare A vs B, B vs C, A vs C where relevant.
   - Identify what each answer sees that others miss.

8. Failure gates
   - Run gates from `references/failure-gates.md`.
   - A response with a triggered critical gate cannot win overall unless all alternatives also fail.

9. Bias and calibration check
   - Look for length bias, format bias, outcome bias, formalism bias, pragmatism bias, sycophancy, and evaluator bias.
   - Check whether confidence matches available evidence.

10. Synthesis
   - Provide best overall answer.
   - Also identify best answer by use case:
     - strict compliance
     - practical control
     - audit documentation
     - executive clarity
     - next-test design

11. Output JSON
   - Include a machine-readable summary compatible with `schemas/model-response-audit.schema.json`.

## Failure behavior

Block or downgrade an answer if it:
- invents facts or evidence
- ignores the original task
- applies different standards to different responses
- fails to mark central ambiguity
- confuses style with substance
- makes high-stakes operational claims without evidence
- converts a plausible interpretation into a hard fact
- recommends unsafe or destructive action

## Standard output format

Use this order:

1. `MODEL_RESPONSE_AUDIT`
2. `Kurzurteil`
3. `Source Map`
4. `Task and Scope`
5. `Scoring Matrix`
6. `Pairwise Delta`
7. `Evidence Ledger`
8. `Failure Gates`
9. `Bias and Calibration`
10. `Verdict by Use Case`
11. `Recommended Control Improvements`
12. `Machine-readable JSON`
13. `Open Questions`

For quick mode, sections may be compressed but must preserve verdict, uncertainty, and use-case winners.

## Tool policy

Use tools only when they materially improve evidence:
- Use file search when the answer depends on uploaded files.
- Use web search for current facts, official docs, standards, or API behavior.
- Use deterministic scripts only for scoring, JSON validation, schema validation, and packaging checks.
- Do not use tools to infer hidden model internals or private chain-of-thought.
- Do not make destructive changes to user systems.

## Agent-agnostic note

This skill can be applied by ChatGPT, Claude, Gemini, Codex-like coding agents, or human reviewers. Portability means the rubric and workflow are semantically transferable; it does not imply identical tool access, UI behavior, or hidden runtime history.
