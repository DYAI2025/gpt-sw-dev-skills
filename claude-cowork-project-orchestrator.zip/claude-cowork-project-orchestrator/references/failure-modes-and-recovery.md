# Failure Modes and Recovery

## Ziel

Dieser Skill muss auch bei vagen, widersprüchlichen oder unvollständigen Inputs nützlich bleiben und trotzdem einen Claude-Project-Systemprompt ausgeben.

## Typische Fehler und Reparaturen

### Fehler 1: Prompt fehlt am Ende

Symptom:
- Antwort endet mit Plan, PAD oder Goal.
- Kein kopierbarer Claude-Systemprompt vorhanden.

Reparatur:
- Abschnitt `## Claude-Project-Systemprompt` ergänzen.
- Wenn Ziel unklar ist, Discovery-Modus verwenden.
- Wenn Plan klar ist, Execution-Ready-Modus verwenden.
- Wenn Bestand geprüft wird, Review-/Repair-Modus verwenden.

### Fehler 2: Zu viele Rückfragen

Symptom:
- Der Skill stellt 8–20 Fragen.
- User wird in ein Formular gedrückt.

Reparatur:
- Maximal drei Fragen.
- Nur Fragen, die die nächste Entscheidung blockieren.
- Rest als ASSUMPTION/MISSING dokumentieren.

### Fehler 3: Hidden Assumption

Symptom:
- Zielgruppe, Tech Stack, Budget, Datenmodell oder Umfang werden erfunden.

Reparatur:
- Fakt/Annahme/Missing/Blocker getrennt ausgeben.
- Reversible Annahmen nur als Arbeitsannahmen verwenden.
- Irreversible Entscheidungen als Blocker markieren.

### Fehler 4: GoalForge wird zum Langplan

Symptom:
- Goal enthält mehrere Ziele, lange Roadmap oder mehr als 3999 Zeichen.

Reparatur:
- Ein Ziel, unter 3999 Unicode-Zeichen.
- Detail in PAD/Plan auslagern.
- Drei Out-of-scope-Bullets ergänzen.

### Fehler 5: Plan ist nicht testbar

Symptom:
- Sprintplan enthält nur Aktivitäten, keine Akzeptanz oder Tests.

Reparatur:
- Pro Sprint Ziel, Ergebnis und Checks/TDD ergänzen.
- Bei Konzeptarbeit Reviewkriterien statt Code-Tests verwenden.

### Fehler 6: Claude wird zu eng

Symptom:
- Prompt klingt wie starres Formular.
- Keine kreative Alternativen oder Reibung erlaubt.

Reparatur:
- Kreativer Freiraum und Reibungsmodus ergänzen.
- Kreativität an Nutzerwert binden.

### Fehler 7: Claude darf zu früh ausführen

Symptom:
- Prompt erlaubt Programmierung ohne Freigabe.

Reparatur:
- Plan-vor-Aktion-Regel.
- Keine Datei-/Code-/Daten-/UX-Änderungen ohne expliziten Auftrag.
- Stop-Bedingungen ergänzen.

## Recovery-Output

Wenn ein Fehler erkannt wird, antworte kompakt:

```markdown
## Reparatur
- Problem:
- Korrektur:
- Prompt-Modus:
- Geänderte Artefakte:

## Claude-Project-Systemprompt
```text
...
```
```
