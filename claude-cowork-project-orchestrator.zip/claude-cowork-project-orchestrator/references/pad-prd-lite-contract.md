# PAD/PRD-lite Contract

Ziel: Ein Product Alignment Document, das gerade genug Klarheit schafft, damit ein Ziel, ein iterativer Plan und ein Claude-Project-Systemprompt entstehen können.

## Prinzip

PAD/PRD-lite ist kein vollständiges Produktlastenheft. Es ist eine kompakte Entscheidungsgrundlage.

## Pflichtstruktur

```markdown
# PAD/PRD-lite: <Projektname>

## 1. Zielbild
Ein bis drei Sätze: Was wird gebaut, für wen, warum?

## 2. Semantische Einordnung
- Werk/Produkt:
- Bedeutung:
- Problemraum:
- Designthese:
- Konfidenz:

## 3. Zielgruppe und Nutzerwert
- Primär:
- Sekundär:
- Nutzerwert:

## 4. Scope
### In
- ...
### Out
- ...

## 5. Requirements
- REQ-F-001:
- REQ-NF-001:
- REQ-A-001:
- REQ-DOC-001:

## 6. Akzeptanzkriterien
- ...

## 7. Architekturidee
- Frontend/Interface:
- Backend/Daten:
- Integrationen:
- Qualität:

## 8. Risiken und offene Punkte
### ASSUMPTION
### MISSING
### OPEN QUESTION
### BLOCKER
```

## Requirement-Grenzen

Standard: 5–12 Requirements.

Empfohlene Typen:
- `REQ-F`: Funktionalität
- `REQ-NF`: Qualität, Performance, UX, Accessibility
- `REQ-A`: Architektur und Schnittstellen
- `REQ-S`: Sicherheit/Privacy
- `REQ-D`: Daten
- `REQ-DOC`: Dokumentation/Handoff

## Beispiele für gute Requirements

Gut:
- `REQ-F-001: Besucher können innerhalb einer Bildschirmhöhe verstehen, welches Angebot gemacht wird und welche nächste Handlung vorgesehen ist.`
- `REQ-NF-001: Die erste Version priorisiert schnelle Ladezeit, klare Informationsarchitektur und mobil nutzbare Darstellung.`
- `REQ-A-001: Die Seite wird komponentenbasiert aufgebaut, damit spätere Sektionen ohne Komplettumbau ergänzt werden können.`

Zu vage:
- `Die Website soll schön sein.`
- `Die App soll modern funktionieren.`
- `Alles soll automatisiert sein.`

## Akzeptanzkriterien

Akzeptanzkriterien müssen beobachtbar sein. Bei frühen Konzeptphasen darf die Prüfung reviewbasiert sein, muss aber klar bleiben.

Beispiele:
- `Eine Person aus der Zielgruppe kann nach Lesen des Hero-Bereichs Angebot, Zielgruppe und CTA benennen.`
- `Alle Must-have-Sektionen sind im Informationsarchitektur-Entwurf enthalten.`
- `Nicht-Ziele sind dokumentiert und verhindern Scope-Creep in der ersten Umsetzung.`
