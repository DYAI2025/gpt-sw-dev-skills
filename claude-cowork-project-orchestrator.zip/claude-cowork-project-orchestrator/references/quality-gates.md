# Quality Gates

## Gate 0 — Prompt Guarantee

Fragen:
- Ist die Anfrage projektbezogen?
- Ist die Prompt-Garantie aktiv?
- Enthält die finale Antwort `Claude-Project-Systemprompt`?
- Ist der Prompt bei fehlendem Kontext als Discovery-Systemprompt nutzbar?

Fehler:
- Antwort endet mit PAD, Goal oder Plan ohne Prompt.
- Es wird auf weitere Informationen gewartet, ohne provisorischen Prompt auszugeben.
- Prompt hat keine Stop-Bedingungen.

## Gate 1 — Semantic Fit

Fragen:
- Ist klar, was der User wirklich erreichen will?
- Ist das Ziel semantisch eingeordnet oder nur als Featureliste übersetzt?
- Sind Zielgruppe, Nutzerwert und Wirkung benannt?
- Sind vage Begriffe wie "modern", "professionell", "automatisiert" in Wirkung übersetzt?

Fehler:
- Generische "Website bauen"-Antwort.
- Kein Unterschied zwischen Marke, Produkt, Plattform, Tool oder Content-Hub.
- Designwünsche ohne Nutzersignal.

## Gate 2 — PAD/PRD-lite Fit

Fragen:
- Ist der Scope klein genug für die erste Version?
- Sind Nicht-Ziele sichtbar?
- Sind Requirements prüfbar oder wenigstens reviewfähig?
- Gibt es höchstens 12 Requirements im ersten Durchlauf?

Fehler:
- Voll-PRD mit Overhead.
- Viele Features, kein Wert-Slice.
- Akzeptanzkriterien wie "sieht gut aus".

## Gate 3 — GoalForge Fit

Fragen:
- Unter 3999 Unicode-Zeichen?
- Ein Ziel, nicht fünf Ziele?
- Harte Bedingungen, AC, Out-of-scope, Done-Definition enthalten?
- Mindestens drei Out-of-scope-Bullets?

Fehler:
- 4000 Wörter statt 3999 Zeichen.
- Mehrere konkurrierende Ziele.
- Keine Scope-Grenzen.
- Offene Alternativen im Goal statt Default oder Frage.

## Gate 4 — Plan Fit

Fragen:
- Iterativ?
- TDD/Teststrategie vorhanden?
- Sprintziele outcome-orientiert?
- Startet der Plan mit Baseline/Klärung?
- Gibt es einen Minimal Value Slice?

Fehler:
- Taskliste ohne Tests.
- Zu großer Sprint 1.
- Implementation ohne bestätigtes Ziel.

## Gate 5 — Ultrathink Fit

Fragen:
- Verb-Mandat klar?
- Triage Hotfix/Standard/Tief plausibel?
- Realer Engpass formuliert?
- Stärkster Gegenpunkt benannt?
- Overengineering geprüft?
- Fehlende Fakten markiert?
- Keine externe Behauptung ohne Prüfung?

Fehler:
- Selbstsichere Behauptungen ohne Basis.
- Kreative Idee als Fakt.
- Architekturentscheidung ohne Alternative.
- Kein Gegenargument.

## Gate 6 — Claude Prompt Fit

Fragen:
- Claude hat kreative Freiheit.
- Claude hat klare Grenzen.
- Claude wird als Projektmanager geführt.
- Keine Phantomtools.
- Projektartefakte sind wiederholbar.
- Plan-vor-Aktion ist explizit.
- Keine Umsetzung ohne Freigabe.
- Prompt enthält Fakten/Annahmen/Missing/Blocker.
- Prompt hat Stop-Bedingungen und nächsten Schritt.

Fehler:
- Prompt ist nur ein Rollenlabel.
- Prompt ist zu restriktiv.
- Prompt enthält volatile Projektdetails statt Verhalten.
- Prompt lässt sofortiges Losprogrammieren zu.
- Prompt fehlt komplett.

## Gate 7 — Recovery Fit

Fragen:
- Wenn ein Schritt scheitert: Gibt es sichere Fortsetzung?
- Wird `contract-mode` sauber markiert?
- Wird trotzdem ein Systemprompt erzeugt?

Fehler:
- Subskill-Ausfall blockiert die Ausgabe.
- Fehlende Informationen werden als Entschuldigung genutzt, keinen Prompt zu erzeugen.
