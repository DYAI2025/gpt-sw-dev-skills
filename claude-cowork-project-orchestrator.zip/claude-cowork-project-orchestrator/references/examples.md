# Examples

## Beispiel 1: Vage Website-Idee

### User sagt

> Ich möchte eine moderne Website für meine KI-Beratung bauen. Sie soll professionell wirken und Kunden überzeugen.

### Schritt 1 — Semantische Einordnung

```markdown
## Semantische Einordnung
- Werk/Produkt: Vertrauensbildende Beratungswebsite
- Bedeutung: Die Website soll Kompetenz, Klarheit und Handlungsfähigkeit sichtbar machen.
- Problemraum: Potenzielle Kunden verstehen KI-Beratung oft abstrakt, riskant oder überverkauft.
- Primäre Zielgruppe: B2B-Entscheider, wahrscheinlich KMU oder Teams mit Automatisierungsbedarf.
- Nutzerwert: Schnelles Verständnis, ob die Beratung konkret hilft und wie der nächste Schritt aussieht.
- Systemgrenze: Website, Positionierung, Lead-Anbahnung; keine vollständige Plattform.
- Designthese: Weniger Hype, mehr Orientierung und konkrete Use-Cases.
- Konfidenz: mittel; Zielgruppe und Angebotstiefe sind noch offen.
```

### Maximal drei Rückfragen

```markdown
1. Welche Zielgruppe ist wichtiger: Geschäftsführer, Fachabteilungen oder technische Entscheider?
2. Was soll die primäre Handlung sein: Erstgespräch buchen, Anfrage senden oder Angebot verstehen?
3. Gibt es schon konkrete Beratungsangebote oder sollen diese mitentwickelt werden?
```

### PAD/PRD-lite-Auszug

```markdown
# PAD/PRD-lite: KI-Beratungswebsite

## Zielbild
Eine moderne, vertrauensbildende Website für eine KI-Beratung, die B2B-Besuchern schnell erklärt, welches Problem gelöst wird, welche Ergebnisse möglich sind und wie sie ein Erstgespräch starten.

## Scope
### In
- Onepage oder kleine Website mit klarer Angebotsstruktur
- Hero, Problem, Nutzen, Leistungen, Prozess, Vertrauen, CTA
- SEO-/AI-SEO-fähige Grundstruktur
- Erweiterbare Komponentenstruktur

### Out
- Kundenportal
- Vollständiger Blog/Content-Hub
- Automatisierte CRM-Integration in Version 1

## Requirements
- REQ-F-001: Besucher erkennen im Hero Zielgruppe, Angebot und nächsten Schritt.
- REQ-F-002: Die Website erklärt mindestens drei konkrete Use-Cases der Beratung.
- REQ-NF-001: Die Informationsarchitektur priorisiert Klarheit vor visueller Komplexität.
- REQ-A-001: Die Struktur bleibt komponentenbasiert und erweiterbar.
- REQ-DOC-001: Inhalte, offene Annahmen und spätere Erweiterungen werden dokumentiert.

## Akzeptanzkriterien
- Hero beantwortet: Für wen? Welches Problem? Welcher nächste Schritt?
- Jede Leistungssektion enthält Nutzen, Ergebnis und Beispiel.
- Mindestens drei Nicht-Ziele verhindern Scope-Creep.
```

### GoalForge-Beispiel

```markdown
GF total=1880/3999 body=1785/3600
Goal: PRD-lite und Website-Slice für KI-Beratungswebsite

Ziel. Erzeuge die erste umsetzbare Version einer vertrauensbildenden KI-Beratungswebsite für B2B-Besucher. Das Ergebnis soll Zielgruppe, Nutzen, Angebotsstruktur und primären CTA so klären, dass ein Coding- oder Design-Agent ohne verdeckte Annahmen starten kann.

Scope. Branch default: `feat/ki-consulting-website-slice`. Betroffen sind Konzept, Informationsarchitektur, Content-Skelett und technische Frontend-Struktur. Umsetzung beschränkt sich auf den ersten Website-Slice: Hero, Problem, Leistungen, Prozess, Vertrauen, CTA.

Bedingungen (hart).
- Keine Programmierung ohne bestätigte Umsetzungsfreigabe.
- Keine neuen Runtime-Dependencies ohne Begründung.
- Unbekannte Zielgruppen-, Angebots- und Tech-Details als ASSUMPTION/MISSING markieren.
- TDD oder prüfbare Review-Kriterien vor Umsetzung definieren.
- Keine Secrets, Tracking-Keys oder Produktionszugriffe verwenden.

Akzeptanzkriterien.
- PAD/PRD-lite enthält Zielbild, Scope, Requirements, AC, Risiken und offene Punkte.
- Informationsarchitektur enthält alle Must-have-Sektionen des ersten Slices.
- Mindestens drei Out-of-scope-Punkte sind dokumentiert.
- Test-/Reviewplan nennt konkrete Prüfpfade für Content, UX, Responsiveness und Performance-Baseline.

Explizit out-of-scope.
- Kundenportal oder Login.
- Vollständiger Blog/Content-Hub.
- CRM-/Payment-/Analytics-Integration.
- Redesign einer bestehenden Marke ohne Brandmaterial.

Done-Definition. Fertig ist ein prüfbares Projektpaket mit PAD/PRD-lite, Sprintplan, Teststrategie und Claude-Project-Systemprompt.

Reference-Doc: docs/plans/ki-beratungswebsite.md
END
```

### Iterativer Plan

```markdown
## Iterativer Plan

### Sprint 0: Zielklärung & Baseline
- Ziel: Zielgruppe, CTA, Angebotskern und Nicht-Ziele bestätigen.
- Ergebnis: PAD/PRD-lite v0.1.
- Tests/Checks: Review gegen Hero-Fragen: Für wen? Welches Problem? Welcher nächste Schritt?

### Sprint 1: Minimaler Website-Wert-Slice
- Ziel: Informationsarchitektur und Content-Skelett für Hero → CTA.
- TDD: Vorab Akzeptanzkriterien pro Sektion definieren.
- Akzeptanz: Jede Sektion hat Zweck, Nutzerfrage, Kernbotschaft und CTA-Bezug.

### Sprint 2: Design-/Frontend-Vorbereitung
- Ziel: Komponentenstruktur, visuelle Richtung und technische Annahmen festlegen.
- TDD: Review-Checkliste für Responsiveness, Accessibility, Performance.
- Akzeptanz: Coding-Agent kann ohne weitere Grundsatzfragen starten.

### Sprint 3: Handoff
- Ziel: Claude-Project-Systemprompt und Umsetzungsbrief finalisieren.
- Tests: Prompt erfüllt Plan-vor-Aktion, Annahmenlogik und Reibungsmodus.
- Übergabe: Projektwissen + Prompt + Plan.
```

### Claude-Project-Systemprompt-Auszug

```text
Du bist der proaktive Claude-Cowork-Projektmanager für die KI-Beratungswebsite.

Deine Aufgabe ist es, aus einer vagen Website-Idee ein fokussiertes, umsetzbares digitales Produkt zu machen. Arbeite nutzerwertgetrieben: B2B-Besucher müssen schnell verstehen, für wen die Beratung ist, welches Problem gelöst wird, welche Ergebnisse realistisch sind und wie sie ein Erstgespräch starten.

Arbeitsregeln:
- Trenne Fakten, Annahmen, offene Fragen und Blocker.
- Stelle höchstens die Fragen, die die nächste Entscheidung blockieren.
- Programmiere erst nach explizitem Umsetzungsauftrag.
- Plane jede Änderung an Inhalt, Code, Architektur oder UX vorab.
- Nutze kleine Slices: zuerst Hero → Problem → Angebot → CTA.
- Widersprich konstruktiv, wenn Ideen zu breit, zu generisch oder zu hype-lastig werden.
- Erlaube kreative Differenzierung, wenn sie Vertrauen, Klarheit oder Conversion verbessert.
```

## Beispiel 2: Automations-Tool für Research-to-Video

### User sagt

> Ich will ein Tool, das aus Quellen automatisch ein YouTube-Video-Briefing macht.

### Semantische Einordnung

```markdown
- Werk/Produkt: Research-to-Video-Briefing-Automation
- Bedeutung: Reduziert Recherche- und Strukturierungsaufwand für Creator.
- Problemraum: Quellenqualität, Faktenprüfung, Dramaturgie und Zitationsdisziplin.
- Zielgruppe: YouTube-Creator, Researcher, Redakteure.
- Nutzerwert: Schnellere Recherche, nachvollziehbare Quellen, bessere Skriptgrundlage.
- Systemgrenze: Briefing-Generator; kein vollautomatisches Video-Rendering in Version 1.
- Designthese: Quellenvertrauen ist wichtiger als maximale Automatisierung.
```

### Reibung

```markdown
Ich würde hier bewusst bremsen: "automatisch ein YouTube-Video" klingt attraktiv, aber die riskante Stelle ist nicht das Schreiben, sondern Quellenqualität und Falschbehauptungen. Version 1 sollte daher ein überprüfbares Briefing erzeugen, nicht direkt ein finales Skript ohne menschliches Review.
```

### Architekturidee

```markdown
- Input: Thema, Zielgruppe, gewünschte Tiefe, Quellenpräferenzen.
- Research: Web/Dateien/Paper je nach Auftrag.
- Source Ledger: Titel, Autor, Datum, Relevanz, Zuverlässigkeit.
- Synthesis: These, Gegenpositionen, Narrative Struktur.
- Output: Briefing, Gliederung, Zitationsliste, offene Unsicherheiten.
- Später: Skriptgenerator, Thumbnail-Briefing, Remotion-Video-Prompt.
```


---

## Beispiel 3: Extrem vage Idee, trotzdem Prompt-Garantie

### User sagt

> Ich will eine Website bauen.

### Semantische Einordnung

```markdown
## Semantische Einordnung
- Werk/Produkt: Noch unbestimmtes Website-Projekt
- Bedeutung: Digitale Präsenz, Angebotserklärung oder Conversion-Fläche; noch nicht entscheidbar.
- Problemraum: Zielgruppe, Wirkung und primäre Handlung fehlen.
- Primäre Zielgruppe: MISSING
- Nutzerwert: MISSING
- Systemgrenze: Website ja; Umfang, Stack und Inhalte offen.
- Designthese: Erst Wirkung klären, dann Design.
- Explizite Nicht-Ziele: Keine Programmierung ohne Zielbild; kein Tech-Stack ohne Scope.
- Konfidenz: niedrig
```

### Maximal drei Rückfragen

```markdown
1. Für wen soll die Website wertvoll sein?
2. Was soll ein Besucher danach tun oder verstanden haben?
3. Was darf auf keinen Fall passieren: generisch wirken, zu teuer werden, zu technisch sein oder zu lange dauern?
```

### PAD/PRD-lite-Auszug

```markdown
# PAD/PRD-lite: Website-Projekt im Discovery-Modus

## Zielbild
Eine Website soll geplant werden. Zielgruppe, Wirkung, Umfang und primäre Handlung sind noch offen und müssen vor Umsetzung geklärt werden.

## Scope
### In
- Zielklärung
- Zielgruppe und Nutzerwert
- erste Informationsarchitektur
- Nicht-Ziele
- Claude-Discovery-Systemprompt

### Out
- Programmierung
- finaler Tech-Stack
- Designsystem
- CMS-/API-/Tracking-Entscheidungen

## Requirements
- REQ-DISC-001: Zielgruppe, gewünschte Wirkung und primäre Handlung werden vor Umsetzung geklärt.
- REQ-DISC-002: Vage Begriffe wie "modern" werden in konkrete Nutzerwirkung übersetzt.
- REQ-DOC-001: Alle Annahmen, Missing und Blocker werden dokumentiert.

## Akzeptanzkriterien
- Der nächste Klärungsschritt ist eindeutig.
- Keine Umsetzung wird ohne bestätigtes Zielbild gestartet.
- Claude erhält einen Prompt, der die Discovery-Phase zuverlässig führt.
```

### Claude-Project-Systemprompt im Discovery-Modus

```text
# Rolle
Du bist der proaktive Claude-Cowork-Projektmanager für ein noch vages Website-Projekt.

# Projektziel
Hilf dem User, aus der Rohidee "Ich will eine Website bauen" ein klares, nutzerwertgetriebenes Website-Zielbild zu entwickeln. Starte im Discovery-Modus. Keine Programmierung, kein finaler Tech-Stack und keine Architekturentscheidung, bis Zielgruppe, gewünschte Wirkung, primäre Handlung und grober Scope bestätigt sind.

# Kontext und Artefakte
Bestätigte Fakten:
- Der User möchte eine Website bauen.

Annahmen:
- Es geht wahrscheinlich um digitale Präsenz, Angebotserklärung, Vertrauen oder Conversion.
- Die erste Version sollte klein und entscheidbar bleiben.

Missing / offene Fragen:
- Zielgruppe
- gewünschte Besucherhandlung
- Inhaltstyp und Umfang
- vorhandene Marke/Inhalte
- technische Constraints

Blocker:
- Umsetzung ist blockiert, bis Zielgruppe, Wirkung und primäre Handlung geklärt sind.

# Arbeitsmodus
- Stelle maximal drei Fragen pro Runde.
- Trenne Fakten, Annahmen, offene Fragen und Blocker.
- Übersetze vage Wünsche wie "modern" in konkrete Wirkung.
- Erzeuge erst nach ausreichender Klärung PAD/PRD-lite, GoalForge-Ziel und Sprint-/TDD-Plan.
- Keine Datei-, Code-, Daten-, UX- oder Architekturänderung ohne expliziten Auftrag.

# Kreativer Freiraum
Schlage mutige Richtungen vor, wenn sie Nutzerwert, Differenzierung oder Klarheit verbessern.

# Reibungsmodus
Spiegele Unklarheit respektvoll: "Website bauen" ist noch kein Ziel; ein Ziel beschreibt Nutzer, Wirkung und Handlung.

# Nächster Schritt
Frage zuerst: Für wen ist die Website, was soll der Besucher tun, und was darf auf keinen Fall passieren?
```

---

## Beispiel 4: Skill-Review und Reparatur

### User sagt

> Durchdenke den Skill nochmals kritisch und mache ihn robuster. Er soll zuverlässig immer einen Claude-Cowork-Projekt-Systemprompt stellen.

### Semantische Einordnung

```markdown
## Semantische Einordnung
- Werk/Produkt: Skill-Orchestrator für Claude-Projektpakete
- Bedeutung: Der Skill soll nicht nur planen, sondern zuverlässig ein kopierbares Betriebsartefakt für Claude Projects erzeugen.
- Problemraum: Der Systemprompt kann durch unklare Inputs, Subskill-Fehler oder zu frühe Rückfragen verloren gehen.
- Nutzerwert: Stabiler Workflow, reproduzierbare Ausgaben, weniger manuelle Nacharbeit.
- Systemgrenze: Skill-Dateien, Output-Verträge, Validatoren, Beispiele; keine externe Plattformintegration.
- Designthese: Prompt-Garantie als oberste Invariante.
- Konfidenz: hoch
```

### Ultrathink-Prüfung

```markdown
## Plausibilitätscheck
- Triage: Tief
- Verb-Mandat: "durchdenke", "robuster machen", "überprüfe"
- Realer Engpass: Der Skill muss auch bei unvollständigen Inputs einen sicheren Systemprompt erzeugen, ohne falsche Sicherheit zu simulieren.
- Stärkster Gegenpunkt: Eine Prompt-Garantie könnte schlechte Prompts erzwingen.
- Antwort auf Gegenpunkt: Der Skill erzwingt nicht einen finalen Umsetzungs-Prompt, sondern erlaubt Discovery-/Review-Prompts mit klaren Blockern.
- Korrektur: Prompt-Modi, Validator und Recovery-Regeln ergänzen.
```

### Claude-Project-Systemprompt-Auszug

```text
# Rolle
Du bist der Claude-Cowork-Projektmanager für die Weiterentwicklung des Skills "claude-cowork-project-orchestrator".

# Projektziel
Führe den Skill so weiter, dass jede projektbezogene Ausführung zuverlässig mit einem Claude-Project-Systemprompt endet. Prüfe Skill-Dateien, Output-Verträge, Beispiele und Validatoren gegen diese Invariante.

# Arbeitsmodus
- Prüfe zuerst, ob die Prompt-Garantie in SKILL.md, References und Scripts verankert ist.
- Trenne bestätigte Skill-Regeln, Annahmen, Missing und Blocker.
- Wenn der Kontext unvollständig ist, erzeuge einen Discovery-Systemprompt statt die Ausgabe abzubrechen.
- Verändere Dateien nur nach Plan und explizitem Auftrag.
- Dokumentiere jede Vertragsänderung im Decision Log.
```
