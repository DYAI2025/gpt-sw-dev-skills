# Critical Review v2

## Geprüfter Ausgangszustand

Der ursprüngliche Skill enthielt eine gute Orchestrierung:

- semantisches Verstehen;
- PAD/PRD-lite;
- GoalForge-Ziel;
- writing-plans Sprint-/TDD-Plan;
- Ultrathink-Plausibilitätscheck;
- Ultimate-Prompt-Architect für Claude-Systemprompt;
- GPT-Project-Management-Regeln.

## Gefundene Schwächen

### 1. Claude-Systemprompt war vorgesehen, aber nicht garantiert

Der Ablauf erzeugte den Prompt in State 8, aber es gab keine harte Invariante, die eine Antwort ohne Prompt verhindert.

Reparatur:
- `Claude-Systemprompt-Garantie` in SKILL.md.
- Pflichtabschnitt im Final Bundle.
- eigenes Reference-Dokument `systemprompt-guarantee.md`.
- Validator prüft Prompt-Sektion.

### 2. Unklare Inputs konnten zum Stoppen führen

Bei fehlenden Details bestand die Gefahr, dass der Skill nur Fragen stellt und keinen nutzbaren Projektprompt erzeugt.

Reparatur:
- Prompt-Modi: Discovery, Execution-Ready, Review/Repair.
- Bei wenig Kontext immer Discovery-Systemprompt.
- Maximal drei Rückfragen bleiben bestehen.

### 3. Zu wenig maschinenprüfbare Prompt-Qualität

Der Validator prüfte nur wenige Stichworte.

Reparatur:
- Strengere Prompt-Signale.
- `enforce_systemprompt_contract.py`.
- Bundle-Prüfung, ob `Claude-Project-Systemprompt` vorhanden ist.

### 4. Subskill-Ausfall war nicht geregelt

Wenn ein orchestrierter Skill nicht ausführbar ist, war unklar, ob der Orchestrator blockiert.

Reparatur:
- `contract-mode`: Output-Verträge lokal anwenden und transparent markieren.
- Keine Phantom-Ausführung behaupten.

### 5. Ultrathink-Prüfung war zu allgemein

Die ursprüngliche Prüfung enthielt Plausibilität, aber nicht klar genug Verb-Mandat, Triage und realen Engpass.

Reparatur:
- Ultrathink-State ergänzt um Triage, Verb-Mandat, realen Engpass, stärksten Gegenpunkt und Korrektur.

## Ergebnis

Version 2 ist robuster, weil sie:

- immer einen Claude-Project-Systemprompt erzeugt;
- bei unsicherem Kontext nicht blockiert, sondern Discovery-Modus nutzt;
- Zwischenartefakte besser validiert;
- Subskill-Ausfälle transparent abfedert;
- Prompt-Qualität maschinenprüfbarer macht;
- Claude kreative Freiheit lässt, aber frühe Ausführung verhindert.
