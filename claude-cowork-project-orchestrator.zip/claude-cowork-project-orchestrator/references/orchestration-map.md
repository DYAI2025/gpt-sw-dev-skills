# Orchestration Map

Dieses Dokument beschreibt, welche vorhandenen Skills wann aktiviert werden und welche Artefakte entstehen.

## Wichtigste Invariante

Der Workflow endet bei projektbezogenen Aufgaben **nie ohne Claude-Project-Systemprompt**. Wenn Kontext fehlt, wird ein Discovery-Systemprompt erzeugt. Wenn Kontext klar ist, wird ein Execution-Ready-Systemprompt erzeugt. Wenn vorhandene Artefakte geprüft werden, wird ein Review-/Repair-Systemprompt erzeugt.

## Skill-Kette

| Schritt | Skill/Tool | Zweck | Output |
|---|---|---|---|
| 0 | Orchestrator Triage | Anfrage klassifizieren, Prompt-Garantie aktivieren, Output-Modus wählen | Triage-Block |
| 1 | `semantic-repository-wiki` | Semantische Einordnung von Rohidee, Bedeutung, Zielgruppe, Systemgrenze | Semantic Intent Map |
| 2 | `writing-plans` | Requirements, Akzeptanzkriterien, Annahmen-/MISSING-/BLOCKER-Logik, Planstruktur | PAD/PRD-lite + Sprintplan |
| 3 | `goal-forge` | Ein kompaktes, ausführbares Ziel unter 3999 Unicode-Zeichen | GoalForge-Block |
| 4 | `ultrathink-craftsmanship` | Plausibilitäts-, Overengineering-, Konfabulations- und Gegenargument-Check | Audit + Korrekturen |
| 5 | `ultimate-prompt-architect` | Claude-Systemprompt mit Guardrails, Rolle, Arbeitsmodus, Fehlerverhalten | Claude Project Systemprompt |
| 6 | `gpt-project-management` | PM-Schicht: Snapshot, Backloglogik, Decision Log, Risiken, DoD | Projektmanager-Verhalten im Prompt |
| 7 | Orchestrator Validator | Länge, Pflichtsignale und Prompt-Garantie prüfen | PASS/FAIL + Reparaturhinweise |

## Entscheidung: klein, mittel, groß

### Klein
- Wenige Seiten/Features.
- Kein vorhandenes Repo.
- Geringes Risiko.
- Output: PAD/PRD-lite, Goal, 2-Sprint-Plan, Claude-Systemprompt.

### Mittel
- Website/App/MVP mit mehreren Modulen.
- Daten, Auth, CMS oder Integrationen möglich.
- Output: PAD/PRD-lite, Goal, 3–4-Sprint-Plan, Claude-Systemprompt, Risiko-/Decision-Log.

### Groß
- Plattform, mehrere Stakeholder, mehrere Agenten/Teams.
- Hohe Unsicherheit oder irreversible Entscheidungen.
- Output: zusätzlich Story Mapping, Architektur-Seed, explizite Release-Slices, Claude-Systemprompt mit stärkerem PM-Modus.

## Prompt-Modus wählen

| Kontext | Modus | Was Claude tun soll |
|---|---|---|
| Vage Idee, wenig Kontext | Discovery-Systemprompt | Klären, spiegeln, Zielbild schaffen, keine Umsetzung |
| Genug Zielbild und Scope | Execution-Ready-Systemprompt | Projekt führen, planen, Umsetzung nach Freigabe begleiten |
| Vorhandener Skill/Plan/Repo | Review-/Repair-Systemprompt | Prüfen, reparieren, stabilisieren, Handoff erzeugen |

## Tokenökonomie

- Kein Voll-PRD, wenn PAD/PRD-lite reicht.
- Keine langen Requirements-Tabellen bei vagen Ideen.
- Maximal 12 Requirements im ersten Durchlauf.
- Architektur nur als Seed, nicht als Implementierungsdokument.
- Plan bleibt auf Sprint-/Slice-Level, bis Umsetzung startet.
- Claude-Systemprompt priorisiert dauerhaftes Verhalten; volatile Details gehören in Project Knowledge.
- Wenn der Systemprompt zu lang wird, zuerst Beispiele kürzen, nicht Guardrails entfernen.

## Artefakt-Reihenfolge

1. `triage.md`
2. `semantic-intent-map.md`
3. `pad-prd-lite.md`
4. `goalforge-goal.md`
5. `iterative-plan.md`
6. `craftsmanship-audit.md`
7. `claude-project-systemprompt.md`
8. `validation-report.md`

In Chat-Antworten können diese Artefakte zusammengefasst werden. In Dateiausgaben sollten sie separat speicherbar sein.

## Contract-Mode bei Subskill-Ausfall

Wenn ein Subskill nicht direkt ausführbar ist:

1. nicht behaupten, dass er ausgeführt wurde;
2. dessen Output-Vertrag lokal anwenden;
3. im Audit markieren: `source: contract-mode`;
4. trotzdem den Claude-Project-Systemprompt erzeugen.
