#!/usr/bin/env python3
"""
Enforce the Claude Project system prompt contract.

Usage:
  python scripts/enforce_systemprompt_contract.py claude-project-systemprompt.md --max 8000
"""

from __future__ import annotations
import argparse
import re
from pathlib import Path

REQUIRED_SECTIONS = [
    "Rolle",
    "Projektziel",
    "Kontext",
    "Arbeitsmodus",
    "Projektmanagement",
    "Kreativer Freiraum",
    "Reibungsmodus",
    "Umsetzung",
    "Stop",
]

REQUIRED_CONCEPTS = {
    "facts_assumptions_missing_blockers": r"Fakten|Annahmen|Missing|offene Fragen|Blocker",
    "plan_before_action": r"Plan.*vor.*Aktion|Plane.*vor|vor Umsetzung",
    "explicit_permission": r"explizite.*Freigabe|expliziter.*Auftrag|ohne.*Freigabe",
    "no_hidden_assumptions": r"keine.*verdeckten.*Annahmen|nicht.*erfinden|Fehlendes.*markiert",
    "tests": r"TDD|Testplan|Tests|Reviewpfad|Checks",
    "anti_sycophancy": r"Reibung|Anti-Sycophancy|widersprich|spiegele",
    "creative_space": r"kreativ|out of the box|mutige",
    "next_step": r"Nächster Schritt|nächste.*Schritt",
}

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("prompt", type=Path)
    parser.add_argument("--max", type=int, default=8000)
    parser.add_argument("--min", type=int, default=900)
    args = parser.parse_args()

    text = args.prompt.read_text(encoding="utf-8")
    errors: list[str] = []

    n = len(text)
    if n < args.min:
        errors.append(f"Prompt too short: {n}/{args.min}")
    if n > args.max:
        errors.append(f"Prompt too long: {n}/{args.max}")

    for section in REQUIRED_SECTIONS:
        if not re.search(section, text, re.I):
            errors.append(f"Missing section signal: {section}")

    for name, pattern in REQUIRED_CONCEPTS.items():
        if not re.search(pattern, text, re.I | re.S):
            errors.append(f"Missing concept: {name}")

    if errors:
        print("SYSTEMPROMPT CONTRACT FAILED")
        for e in errors:
            print(f"- {e}")
        return 1

    print("SYSTEMPROMPT CONTRACT OK")
    print(f"chars={n}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
