#!/usr/bin/env python3
"""
Count Unicode characters in a Claude Project system prompt.

Usage:
  python scripts/check_prompt_len.py claude-project-systemprompt.md --max 8000
"""

from __future__ import annotations
import argparse
from pathlib import Path

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("file", type=Path)
    parser.add_argument("--max", type=int, default=8000)
    args = parser.parse_args()

    text = args.file.read_text(encoding="utf-8")
    n = len(text)
    print(f"{args.file}: {n}/{args.max} Unicode characters")
    return 0 if n <= args.max else 1

if __name__ == "__main__":
    raise SystemExit(main())
