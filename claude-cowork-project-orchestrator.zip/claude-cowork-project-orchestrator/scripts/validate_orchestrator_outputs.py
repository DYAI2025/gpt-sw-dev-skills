#!/usr/bin/env python3
"""
Validate key textual outputs for claude-cowork-project-orchestrator.

Usage:
  python scripts/validate_orchestrator_outputs.py --goal goal.md --prompt claude-systemprompt.md
  python scripts/validate_orchestrator_outputs.py --bundle projektpaket.md --strict
"""

from __future__ import annotations
import argparse
import re
from pathlib import Path

REQUIRED_GOAL_SECTIONS = [
    "Goal:",
    "Ziel.",
    "Scope.",
    "Bedingungen (hart).",
    "Akzeptanzkriterien.",
    "Explizit out-of-scope.",
    "Done-Definition.",
    "Reference-Doc:",
]

REQUIRED_BUNDLE_SECTIONS = [
    "Zielbild",
    "PAD/PRD-lite",
    "GoalForge-Ziel",
    "Iterativer",
    "Plausibilitätscheck",
    "Claude-Project-Systemprompt",
    "Nächster sinnvoller Schritt",
]

REQUIRED_PROMPT_SIGNALS = [
    r"Claude.*Projektmanager|Claude-Cowork-Projektmanager|Claude.*Cowork",
    r"Projektziel",
    r"Fakten|Bestätigte Fakten",
    r"Annahmen|ASSUMPTION",
    r"Missing|offene Fragen|MISSING",
    r"Blocker|BLOCKER",
    r"Plan.*vor.*Aktion|plane.*vor|Plan-vor-Aktion",
    r"keine.*verdeckten.*Annahmen|Fehlendes.*nicht.*erfunden|nicht.*erfinden",
    r"explizit.*Auftrag|explizite.*Freigabe|ohne.*Freigabe",
    r"TDD|Testplan|Tests|Reviewpfad|Checks",
    r"Reibung|Anti-Sycophancy|konstruktiv",
    r"kreativ|out of the box|mutige",
    r"Stop-Bedingungen|Stoppe und frage|Stop",
    r"Nächster Schritt|nächste.*Schritt",
]

RISKY_PROMPT_PATTERNS = [
    r"programmiere sofort",
    r"ignoriere fehlende Informationen",
    r"immer zustimmen",
    r"nimm einfach an",
    r"ohne nachzufragen umsetzen",
    r"ändere dateien ohne freigabe",
]

def count_chars(text: str) -> int:
    return len(text)

def validate_goal_text(text: str) -> list[str]:
    errors: list[str] = []
    n = count_chars(text)
    if n > 3999:
        errors.append(f"Goal too long: {n}/3999 characters")
    for section in REQUIRED_GOAL_SECTIONS:
        if section not in text:
            errors.append(f"Missing goal section: {section}")
    out_scope = re.search(r"Explizit out-of-scope\.(.*?)(Done-Definition\.|Reference-Doc:|END)", text, re.S)
    if out_scope:
        bullets = re.findall(r"^\s*[-*]\s+", out_scope.group(1), re.M)
        if len(bullets) < 3:
            errors.append("Goal needs at least three out-of-scope bullets")
    else:
        errors.append("Cannot find out-of-scope section body")
    forbidden_softeners = ["vielleicht", "eventuell", "maybe", "possibly", "sollte", "könnte", "koennte"]
    found = [w for w in forbidden_softeners if re.search(rf"\b{re.escape(w)}\b", text, re.I)]
    if found:
        errors.append("Goal contains soft/open language: " + ", ".join(found))
    return errors

def validate_goal(path: Path) -> list[str]:
    return validate_goal_text(path.read_text(encoding="utf-8"))

def validate_prompt_text(text: str, max_chars: int, strict: bool = False) -> list[str]:
    errors: list[str] = []
    n = count_chars(text)
    if n == 0:
        errors.append("Prompt is empty")
    if n > max_chars:
        errors.append(f"Prompt too long: {n}/{max_chars} characters")
    if n < 900 and strict:
        errors.append(f"Prompt suspiciously short: {n} characters")
    for pattern in REQUIRED_PROMPT_SIGNALS:
        if not re.search(pattern, text, re.I | re.S):
            errors.append(f"Prompt may miss required signal: {pattern}")
    for pattern in RISKY_PROMPT_PATTERNS:
        if re.search(pattern, text, re.I):
            errors.append(f"Risky prompt phrase found: {pattern}")
    return errors

def validate_prompt(path: Path, max_chars: int, strict: bool = False) -> list[str]:
    return validate_prompt_text(path.read_text(encoding="utf-8"), max_chars, strict)

def extract_prompt_from_bundle(text: str) -> str:
    # Prefer fenced block following Claude-Project-Systemprompt.
    m = re.search(
        r"Claude-Project-Systemprompt.*?```(?:text|markdown)?\s*(.*?)```",
        text,
        re.I | re.S,
    )
    if m:
        return m.group(1).strip()
    # Fallback: take all text after heading.
    m = re.search(r"##\s*\d*\.?\s*Claude-Project-Systemprompt\s*(.*?)(?:\n##\s*\d|$)", text, re.I | re.S)
    return m.group(1).strip() if m else ""

def validate_bundle(path: Path, max_chars: int, strict: bool = False) -> list[str]:
    text = path.read_text(encoding="utf-8")
    errors: list[str] = []
    for section in REQUIRED_BUNDLE_SECTIONS:
        if not re.search(re.escape(section), text, re.I):
            errors.append(f"Bundle missing section/signal: {section}")
    prompt = extract_prompt_from_bundle(text)
    if not prompt:
        errors.append("Bundle missing extractable Claude-Project-Systemprompt")
    else:
        errors.extend(validate_prompt_text(prompt, max_chars, strict))
    return errors

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--goal", type=Path)
    parser.add_argument("--prompt", type=Path)
    parser.add_argument("--bundle", type=Path)
    parser.add_argument("--prompt-max", type=int, default=8000)
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()

    errors: list[str] = []
    if args.goal:
        errors.extend(validate_goal(args.goal))
    if args.prompt:
        errors.extend(validate_prompt(args.prompt, args.prompt_max, args.strict))
    if args.bundle:
        errors.extend(validate_bundle(args.bundle, args.prompt_max, args.strict))

    if errors:
        print("VALIDATION FAILED")
        for e in errors:
            print(f"- {e}")
        return 1

    print("VALIDATION OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
