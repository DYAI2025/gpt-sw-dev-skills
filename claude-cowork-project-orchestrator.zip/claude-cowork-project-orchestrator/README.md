# Claude Cowork Project Orchestrator

Ein orchestrierender Skill, der aus vagen Produktideen ein kompaktes Projektpaket macht:

- semantische Einordnung
- PAD/PRD-lite
- GoalForge-Ziel
- iterativer Sprint-/TDD-Plan
- Ultrathink-Plausibilitätscheck
- Claude-Project-Systemprompt

## Version 2: Prompt-Garantie

Die zentrale Verbesserung: Der Skill endet bei projektbezogenen Aufgaben **immer** mit einem Claude-Project-Systemprompt.

Wenn der Kontext noch unklar ist, wird kein falscher Umsetzungs-Prompt erzeugt, sondern ein **Discovery-Systemprompt**, der Claude als Projektmanager auf Zielklärung, Annahmentrennung und sichere nächste Schritte ausrichtet.

## Installation

Den Ordner `claude-cowork-project-orchestrator` als Skill-Paket einbinden.

## Wichtig

Der Skill ist bewusst tokenökonomisch. Er soll keine langen PRDs erzeugen, wenn ein gutes PAD/PRD-lite genügt.

## Standardausgabe

```markdown
# Projektpaket

## 1. Zielbild
## 2. PAD/PRD-lite
## 3. GoalForge-Ziel
## 4. Iterativer Sprint-/TDD-Plan
## 5. Plausibilitätscheck
## 6. Claude-Project-Systemprompt
## 7. Nächster sinnvoller Schritt
```

## Validierung

```bash
python scripts/validate_orchestrator_outputs.py --bundle projektpaket.md --strict
python scripts/enforce_systemprompt_contract.py claude-project-systemprompt.md
python scripts/check_prompt_len.py claude-project-systemprompt.md --max 8000
```

## Prompt-Modi

- `Discovery-Systemprompt`: bei vagen Ideen oder Blockern.
- `Execution-Ready-Systemprompt`: bei klarem Zielbild und Plan.
- `Review-/Repair-Systemprompt`: bei bestehenden Skills, Plänen oder Repos.
