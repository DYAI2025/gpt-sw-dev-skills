#!/usr/bin/env python3
"""Lightweight checker for Plumbline project-management markdown packets."""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

REQUIRED_HEADINGS = [
    "Source Findings",
    "Repository Current State",
    "Value Baseline",
    "Open Risks / Gaps",
    "Development Recommendations",
    "Next Sprint Slice",
    "Validation Checklist",
    "Next Verified Action",
]

CRITICAL_TERMS = [
    "FACT",
    "ASSUMPTION",
    "MISSING",
    "BLOCKER",
    "Evidence",
    "value",
    "Watcher",
    "Stop conditions",
]

FORBIDDEN_FRAMES = [
    "manage gpts",
    "gpt administration",
    "generic gpt management",
]


def read_text(path: str | None) -> str:
    if path and path != "-":
        return Path(path).read_text(encoding="utf-8")
    return sys.stdin.read()


def has_heading(text: str, heading: str) -> bool:
    pattern = rf"^#+\s+{re.escape(heading)}\s*$"
    return re.search(pattern, text, flags=re.MULTILINE | re.IGNORECASE) is not None


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a Plumbline PM packet markdown file.")
    parser.add_argument("path", nargs="?", default="-", help="markdown path, or '-' / omitted for stdin")
    parser.add_argument("--prompt-max", type=int, default=8000, help="warning threshold for fenced operating prompts")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    text = read_text(args.path)
    lower = text.lower()
    missing_headings = [h for h in REQUIRED_HEADINGS if not has_heading(text, h)]
    absent_terms = [t for t in CRITICAL_TERMS if t.lower() not in lower]
    forbidden_hits = [t for t in FORBIDDEN_FRAMES if t in lower]
    todos = re.findall(r"\bTODO\b|\bTBD\b", text, flags=re.IGNORECASE)

    fenced_prompts = re.findall(r"```(?:text|prompt)?\n(.*?)```", text, flags=re.DOTALL | re.IGNORECASE)
    prompt_lengths = [len(p) for p in fenced_prompts]
    too_long_prompts = [n for n in prompt_lengths if n > args.prompt_max]

    ok = not missing_headings and not too_long_prompts and not forbidden_hits
    result = {
        "ok": ok,
        "missing_headings": missing_headings,
        "absent_terms_warning": absent_terms,
        "forbidden_frame_hits": forbidden_hits,
        "todo_count_warning": len(todos),
        "fenced_prompt_lengths": prompt_lengths,
        "too_long_prompts": too_long_prompts,
    }

    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if ok else 2


if __name__ == "__main__":
    raise SystemExit(main())
