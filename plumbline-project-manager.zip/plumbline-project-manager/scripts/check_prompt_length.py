#!/usr/bin/env python3
"""Check a prompt file or stdin against a character limit."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def read_text(path: str | None) -> str:
    if path and path != "-":
        return Path(path).read_text(encoding="utf-8")
    return sys.stdin.read()


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate prompt character length.")
    parser.add_argument("path", nargs="?", default="-", help="prompt file path, or '-' / omitted for stdin")
    parser.add_argument("--max", type=int, default=8000, dest="max_chars", help="maximum allowed Unicode characters")
    parser.add_argument("--json", action="store_true", help="emit JSON only")
    args = parser.parse_args()

    text = read_text(args.path)
    chars = len(text)
    lines = text.count("\n") + (1 if text else 0)
    ok = chars <= args.max_chars
    result = {
        "ok": ok,
        "chars": chars,
        "max_chars": args.max_chars,
        "remaining": args.max_chars - chars,
        "lines": lines,
    }

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        status = "OK" if ok else "TOO_LONG"
        print(f"{status}: {chars}/{args.max_chars} characters ({args.max_chars - chars} remaining), {lines} lines")

    return 0 if ok else 2


if __name__ == "__main__":
    raise SystemExit(main())
