# Plumbline Current-State Snapshot

Snapshot basis: uploaded repository archive `Plumbline-main.zip`, inspected 2026-06-22. Treat this as a dated snapshot, not permanent truth. If a newer repo is supplied, re-inventory before using this as current.

## Verified repository facts from inspected files

| Area | Snapshot finding | Evidence file |
|---|---|---|
| Version | `0.22.2` | `VERSION`, `CHANGELOG.md` |
| Product identity | local Claude Code agent framework focused on proving work is actually done, not only apparently done | `README.md`, `CLAUDE.md` |
| README public claim | `86 subagents`, `16 vendored skills`, `11 slash commands`, `/agileteam`, `/concilium`, Runtime Integrity / Reality Layer | `README.md` |
| Vendored skills | 16 `config/claude/skills/*/SKILL.md` entries found | filesystem inventory |
| Slash commands | 11 markdown commands under `config/claude/commands/` found | filesystem inventory |
| Test harness | `bash config/claude/tests/run_all.sh` is documented as the full CI-equivalent suite | `CLAUDE.md` |
| Current open backlog | BL-004, BL-005, BL-006, BL-DM-001 remain open or future-oriented in `backlog.md` | `backlog.md` |
| Latest release note | v0.22.2 fixes update same-path / canonical-path fail-closed behavior | `CHANGELOG.md` |

## Product identity

Plumbline is not just an agent pack. It is a governed local Claude Code framework with:

1. Agent prompt library and Agent Explorer.
2. Vendored Claude workflow/tooling tree under `config/claude/`.
3. Empirical evidence layer: metrics, benchmarks, reality ledgers, traceability, and documented ceilings.

The central management question is: **does the next change strengthen fidelity to confirmed user value, or merely increase apparent completion?**

## Current core subsystems

| Subsystem | Repo evidence | Project-management implication |
|---|---|---|
| `/agileteam` | `config/claude/commands/agileteam.md`, agileteam agents, governance docs | Main governed delivery path; must preserve Canvas/Vision before execution. |
| Product Canvas / Vision / PRD | `docs/canvas/`, `docs/vision/`, `docs/prd/`, templates | Use as true-line anchors. Changes must propagate across all artifacts. |
| Runtime Integrity / Reality Layer | `config/claude/lib/plumbline_*.py`, `config/claude/bin/plumbline-*`, PRIL tests | Completion claims require evidence class and missing boundary. |
| PreToolUse / Stop hooks | `config/claude/hooks/`, tests | Runtime gates exist but have documented ceilings; do not overclaim enforcement. |
| `/concilium` / council | `config/claude/commands/concilium.md`, `config/claude/lib/council_*`, OpenRouter docs | Useful for decision friction; quality lift is not proven by reachability alone. |
| Update/install reliability | `config/claude/lib/plumbline_update.py`, `plumbline-update` command, update tests | Recent release focus; security and path-canonicalization lessons must carry forward. |
| Agent Explorer | `agent-explorer.html`, `explorer/`, `build-explorer.sh`, docs demo | Rebuild after agent frontmatter changes. |
| Metrics / benchmarks | `metrics/`, `docs/benchmarks/`, `docs/experiments/`, `docs/reality/` | Preserve RED/null results and evidence ceilings. |

## Recent shipped direction

From `CHANGELOG.md` and benchmark/docs inventory:

- v0.22.0: plumbline update reliability across install identity, release fetch, verify-or-revert, and opt-out update checks.
- v0.22.1: doctor/honest-status resolve identity from the install anchor.
- v0.22.2: same-path file-aware + canonical path fail-closed update fix.
- 2026-06-18 to 2026-06-20 benchmark/docs show OpenRouter/council boundary smokes, GUI live smoke, free-diversity probe, and runtime start governance evidence.

## Open backlog / next management attention

| ID | Status summary | Why it matters |
|---|---|---|
| BL-004 Runtime phase dashboard | open | Makes runtime phase/gate state visible; reduces hidden orchestration ambiguity. |
| BL-005 Bash-tool start-gate coverage | open boundary accepted for v1 | Potential bypass class: Bash-mediated writes under `VISION_MISSING` are not denied by current PreToolUse matcher. Needs false-positive analysis before widening. |
| BL-006 PRIL evidence-rank consistency | open | Evidence vocabulary mismatch can corrupt confidence ceilings. High-value consistency fix. |
| BL-DM-001 Model-resolution fallback cascade | future/open | Foreign-model council should resolve disclosed fallbacks without silent Claude substitution; budget and reachability must be explicit. |

## Known ceilings to preserve

- Runtime hooks can enforce some boundaries, but not every governance rule is mechanically enforced.
- A live `/agileteam` model self-halt transcript is not machine-asserted; the hook backstop carries the real guarantee where tested.
- Council reachability/invocation smokes do not prove decision-quality lift.
- Free-tier model reachability is intermittent; model IDs must be verified live or resolved dynamically.
- macOS CI can expose shell/path/loopback differences; do not treat local/Linux-green as sufficient for portability-sensitive tests.
- User-facing demo/fake fallbacks violate Plumbline if they make a dead real path look alive.

## Recommended near-term roadmap

1. **Fix evidence-rank consistency (BL-006).** Small, high-value, directly protects evidence honesty.
2. **Analyze Bash-tool start-gate coverage (BL-005).** Start with a RED test and false-positive matrix; do not widen gating blindly.
3. **Define runtime phase dashboard slice (BL-004).** First slice should expose current gate/phase state from real artifacts, not cosmetic UI.
4. **Design disclosed model fallback cascade (BL-DM-001).** No silent substitution; live-catalog verification or dynamic resolution.
5. **Institutionalize update-reliability lessons.** Any new secret on an existing override seam requires a fresh threat model; path tests must canonicalize expected values exactly like production.

## Project-manager warning

Do not present this snapshot as live repo state after new files are supplied. Always refresh `VERSION`, `CHANGELOG.md`, `backlog.md`, `CLAUDE.md`, relevant docs, and tests before making current-state claims.
