# Output Contracts

## Plumbline Project Management Packet

```markdown
# Plumbline Project Management Packet

## 1. Source Findings
| Source | Finding | Evidence | Limit |
|---|---|---|---|

## 2. Repository Current State
- Version / date evidence:
- Recent shipped direction:
- Open backlog:
- Runtime/test evidence inspected:
- Known ceilings:

## 3. Value Baseline
- Target user/customer:
- Real problem:
- Desired change:
- Core value promise:
- Success signal:
- Non-goals:
- Required evidence:
- Status:

## 4. Open Risks / Gaps
| Gap | Type | Impact on Plumbline value | Evidence | Next check |
|---|---|---|---|---|

## 5. Development Recommendations
| Rank | Recommendation | User value | Repo evidence | Slice size | Risk |
|---:|---|---|---|---|---|

## 6. Next Sprint Slice
Goal:
Scope in:
Scope out:
Files likely affected:
First failing test/check:
Implementation sketch:
Evidence target:
Watcher question:
Stop conditions:
Done means:

## 7. Tooling & Method Policy
- Available:
- Missing:
- Needs approval:
- Security/privacy limits:

## 8. Watcher / Council Notes
Watcher verdict: pass | review-required | pause | blocked
Council needed: yes/no
Reason:

## 9. Validation Checklist
- [ ] Facts/assumptions split
- [ ] Current repo/files inspected
- [ ] Value baseline explicit
- [ ] Evidence classes visible
- [ ] Tool/runtime claims grounded
- [ ] Stop conditions present
- [ ] Next slice small and reversible

## 10. Next Verified Action
```

## Repository status card

```markdown
## Befund
- FACT:
- ASSUMPTION:
- MISSING:
- BLOCKER:

## Vorschlag

## Risiko

## Nächster prüfbarer Schritt
```

## Gap matrix

```markdown
| ID | Target | Actual | Evidence | Gap type | Value risk | Remediation slice | Test/check |
|---|---|---|---|---|---|---|---|
```

## Development recommendation

```markdown
## Development Recommendation: <title>
- Problem / gap:
- User value protected or created:
- Repo evidence:
- Proposed slice:
- Files likely affected:
- Tests/checks:
- Evidence target:
- Risks:
- Stop conditions:
```

## Plumbline Agent Handoff

```markdown
# Plumbline Agent Handoff
Goal:
Confirmed facts:
Assumptions:
Out of scope:
Files likely affected:
Allowed change scope:
First failing test/check:
Implementation steps:
Reality/evidence checks:
Watcher question:
Stop conditions:
Done means:
```

## Decision note

```markdown
# Decision Note: <title>

Date:
Status: proposed | accepted | rejected | superseded
Decision owner:

## Context

## Options
| Option | Upside | Downside | Evidence | Risk |
|---|---|---|---|---|

## Decision

## Rationale

## Reversal trigger

## Follow-up checks
```

## Evidence ledger row

```markdown
| Claim ID | Claim | Evidence | Class | Confidence ceiling | Missing boundary | Falsifier / next check |
|---|---|---|---|---|---|---|
```

Evidence classes:

```text
statement-only < document-supported < unit-fake < integration-fake < integration-real < real-boundary-smoke < production-observed
```

## Watcher verdict

```markdown
Watcher verdict: pass | review-required | pause | blocked
True-line status: aligned | value-risk | contradiction | blocked
Reason:
Evidence:
Evidence class:
Missing boundary:
Required user decision:
```

## Retrospective learning proposal

```markdown
# Retro Learning Proposal

Observed pattern:
Impact on Plumbline value/evidence:
Proposed rule/change:
Why this strengthens Plumbline:
Risk of overfitting:
Diff preview / affected prompt or repo section:
Test/check to validate:
Approval required: yes
```
