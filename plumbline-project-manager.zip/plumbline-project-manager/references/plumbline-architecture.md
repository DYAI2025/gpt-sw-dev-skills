# Plumbline Architecture Reference

Use this when the user asks for architecture, process, subsystem impact, or next-slice planning for the Plumbline project.

## Source basis

Derived from inspected repository files including `README.md`, `CLAUDE.md`, `SETUP.md`, `DEPENDENCIES.md`, `backlog.md`, `config/claude/commands/*`, `config/claude/lib/*`, `config/claude/hooks/*`, `config/claude/tests/*`, agileteam agents, concilium agents, governance docs, benchmark docs, and reality ledgers.

Do not treat this reference as runtime proof. It is an architecture and process map.

## Repository identity

Plumbline is a local Claude Code framework for agentic software delivery where the expensive failure is not a red test but a green artifact that does not solve the confirmed user problem.

It is three coupled systems:

1. **Agent library**: markdown agent prompts and explorer.
2. **Workflow/tooling layer**: vendored commands, skills, hooks, libraries, CLIs, tests under `config/claude/`.
3. **Evidence system**: metrics, benchmarks, experiments, traceability, reality ledgers, changelog, backlog.

## True-line delivery flow

```mermaid
flowchart TD
  U[User intent / problem] --> C[Product Canvas]
  C --> V[Product Vision]
  V --> P[PRD / Requirements / REQ IDs]
  P --> T[Traceability]
  T --> G[Goal / Sprint slice]
  G --> TD[TDD first failing check]
  TD --> Impl[Implementation]
  Impl --> QA[Tester / independent review]
  QA --> Sec[Security + dependency review]
  Sec --> R[Reality Ledger / evidence class]
  R --> W[Plumbline Watcher]
  W -->|pass| A[Human acceptance]
  W -->|review-required / pause / blocked| D[Decision / re-scope / repair]
  A --> Retro[Retro learning proposal]
  Retro -->|explicit approval + diff + tests| Rules[Rule / skill / CLAUDE.md update]

  C -. consequential decision .-> Council[/concilium]
  Council -. friction .-> P
```

## Main project-management control objects

| Object | Role | PM check |
|---|---|---|
| Product Canvas | problem, user, value promise, success signal, non-goals, risks | Is it confirmed or inferred? |
| Product Vision | semantic anchor | Is the planned change still true to it? |
| PRD / REQ IDs | testable scope | Are requirements linked to Canvas/Vision? |
| Traceability | artifact consistency | Did a re-scope update all linked docs? |
| Reality Ledger | evidence class and missing boundary | Is the claim ceiling honest? |
| Watcher verdict | true-line gate | Could this be green-but-useless? |
| Council report | decision friction | Is it evidence-bearing or theater? |
| Backlog | open work and next slices | Is priority based on value/evidence risk? |
| Changelog / docs | public truth contract | Does README overclaim relative to evidence? |
| Tests / CI | mechanical verifier | Do tests cover the actual boundary claimed? |

## Runtime/tooling layers

```mermaid
flowchart LR
  Repo[Plumbline repo] --> Install[install.sh / local Claude config]
  Install --> Cmds[slash commands]
  Cmds --> Agile[/agileteam]
  Cmds --> Concilium[/concilium]
  Cmds --> Update[/plumbline-update]
  Cmds --> Status[/honest-status]

  Agile --> Hooks[PreToolUse + Stop hooks]
  Hooks --> Libs[plumbline_* libraries]
  Libs --> Checks[reality/scope/context/redact/run-ledger checks]
  Checks --> Tests[config/claude/tests/run_all.sh]

  Concilium --> OR[OpenRouter council backend]
  OR --> Evidence[benchmark + reality evidence]
  Update --> Verify[verify-or-revert / doctor / session update check]
```

## Impact map for changes

When planning a change, inspect likely impact across:

| Change type | Areas to check |
|---|---|
| Agent prompt/frontmatter | agent file, unique `name`, explorer rebuild, frontmatter validator, docs if public count changes |
| `/agileteam` governance | command file, agileteam agents, Product Canvas/Vision/PRD templates, true-line tests, watcher docs |
| Runtime gate/hook | hook script, library, bin wrapper, settings/install wiring, fail-open/fail-closed semantics, test module |
| Evidence vocabulary | `plumbline_reality.py`, crosswalk docs, reality ledgers, tests, README wording |
| Council/OpenRouter | backend, inference, presets, budget gate, live catalog checks, redaction, benchmark claims |
| Update/install | install anchor, release fetch, token destination gate, verify-or-revert, doctor/honest-status, macOS path parity |
| GUI/live boundary | proxy/server, static UI, live-only vs offline behavior, no demo fallback, security tests |
| Docs/status | README, CHANGELOG, backlog, benchmark write-up, plan/canvas/prd/vision/reality/trace matrix consistency |

## Plumbline project-manager architecture

```mermaid
flowchart TD
  PM[Plumbline Project Manager] --> SI[Source Inventory]
  PM --> RS[Repository Current State]
  PM --> VB[Value Baseline]
  PM --> GM[Gap Matrix]
  PM --> Road[Roadmap / Backlog Priority]
  PM --> Slice[Next Sprint Slice]
  PM --> HO[Agent/Coder Handoff]
  PM --> EV[Evidence Ledger]
  PM --> W[Watcher Gate]
  PM --> C[Council Decision Friction]
  PM --> Retro[Retro Proposal]

  RS --> GM
  VB --> Road
  GM --> Slice
  Slice --> HO
  HO --> EV
  EV --> W
  C --> Road
  W -->|pause/block| PM
```

## Practical operating loop

1. Inventory current repo evidence.
2. Restate Plumbline value baseline.
3. Identify gaps: target vs actual vs evidence vs user value.
4. Rank gaps by value risk, evidence inconsistency, and reversibility.
5. Define one small next slice.
6. Define first failing test/check.
7. Define allowed change scope.
8. Run/require relevant checks.
9. Write honest status and update linked artifacts.
10. Run Watcher before Done.
11. Propose, not persist, retro learning.

## Standing risk notes

- A skill package cannot enforce runtime hooks. It can instruct, validate, and generate handoffs.
- A project manager cannot claim latest repo state unless it inspected the latest files.
- A model-simulated council has correlated blind spots; real foreign-model paths need live evidence and budget/credential handling.
- CI green is not enough if the test did not cross the claimed boundary.
- Any demo/sample/fake path that makes a user-facing dead path look alive violates the Plumbline philosophy.
