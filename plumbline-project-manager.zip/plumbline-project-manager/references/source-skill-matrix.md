# Tool and Method Matrix for Managing Plumbline

## Selection principle

Pick tools and methods by the Plumbline management job-to-be-done. Do not build a GPT-management ceremony around the work. The managed object is the Plumbline repository/product.

## Always-on project-management methods

| Method | Use | Failure it prevents |
|---|---|---|
| Source inventory | Inspect repo/docs/backlog/tests before advising | Phantom repo state |
| Product Canvas / Vision check | Keep work true to the confirmed user problem | Feature drift |
| FACT / ASSUMPTION / MISSING / BLOCKER split | Keep uncertainty visible | Scheinpräzision |
| Gap matrix | Compare target vs actual vs evidence | Green-but-incomplete status |
| GoalForge-style next objective | Bound one slice tightly | Scope creep |
| Sprint/TDD plan | Define first failing check and review path | Implementation without falsifier |
| Reality Ledger | Classify evidence and confidence ceiling | Evidence laundering |
| Watcher verdict | Pause if value/evidence contradicts Done | Test-green but value-red |
| Council friction | Stress-test consequential choices | Single-model overconfidence |
| Decision log | Preserve why a path was chosen | Future amnesia |
| Retro proposal | Learn only with approval and validation | Silent self-modification |

## Useful ChatGPT skills / internal methods

| Skill / method | Use for Plumbline project management | Use when | Avoid |
|---|---|---|---|
| codebase-architecture-audit-researcher | Repo map, architecture risks, subsystem inventory | Large repo or unknown codebase | Do not infer runtime without running checks |
| software-gap-analysis-agent | Target-vs-actual vs evidence matrix | Backlog, PRD, implementation drift | Do not treat documents as implementation proof |
| writing-plans | Implementation plan, acceptance criteria, test strategy | Preparing a slice or handoff | Do not produce task volume before value is clear |
| goal-forge | Compact objective / Done definition | Coding-agent or sprint target | Do not exceed character/scope contract |
| ultrathink-craftsmanship | Strongest counterpoint and overengineering audit | Non-trivial architecture/product decisions | Do not use as theatrical depth |
| der-pruefer | Strict critique of claims, risk, evidence, contradictions | Watcher/council-style quality pressure | Do not turn critique into cynicism |
| mcp-builder | External APIs, MCP, connector design | OpenRouter/tool integrations or future MCP work | Do not assume installed servers or credentials |
| middleware-api-architect / api-developer-builder | API contracts, auth, rate limits, observability | Council backend, update fetch, external services | Do not skip secret destination threat model |
| omni-architecture-brief-engine | Architecture visualization and dev brief | Multi-component change | Do not overvisualize a simple fix |
| skill-creator | Only if Plumbline needs a reusable skill package | Creating/updating actual Skills | Not the default PM object |
| ultimate-prompt-architect | Compact operating prompts / guardrails | A project prompt is explicitly requested | Do not let prompt work replace repo progress |
| gpt-project-management | Cockpit, status, risk/decision/backlog formats | PM dashboard artifacts | Do not manage GPTs instead of Plumbline |

## Repository-native tools and commands to account for

| Repo tool / file | PM use | Evidence caution |
|---|---|---|
| `bash config/claude/tests/run_all.sh` | Full CI-equivalent local suite | Only claim green if actually run and output inspected |
| `./build-explorer.sh` | Rebuild Agent Explorer after agent frontmatter changes | Requires dependencies; run before claiming explorer updated |
| `config/claude/bin/plumbline-reality-check` | Evidence-class checks | Boundary depends on inputs/artifacts |
| `config/claude/bin/plumbline-scope-check` | Scope containment | Allowed scope must be machine-parseable |
| `config/claude/bin/plumbline-context-check` | Context artifact checks | Does not prove value by itself |
| `config/claude/bin/plumbline-redact` | Secret/private-data redaction | Verify secret paths when adding credentials |
| `config/claude/bin/plumbline-run-ledger` | Run ledger support | Ledger is evidence only if populated honestly |
| `/agileteam` | Governed delivery workflow | Prose obedience is not full runtime proof |
| `/concilium` | Council friction and foreign-model paths | Reachability/inference smoke is not quality proof |
| `/plumbline-update` | Update/install reliability | Must preserve token host-gate and verify-or-revert |
| `/honest-status` | Status disclosure | Must resolve install identity correctly |

## Conditional routing by project situation

| Situation | Recommended route |
|---|---|
| User asks “where are we?” | Inspect `VERSION`, `CHANGELOG.md`, `backlog.md`, `README.md`, `CLAUDE.md`, relevant docs; output current-state packet. |
| User asks “what next?” | Current-state snapshot → value baseline → gap rank → one next slice. |
| Open backlog item | Turn item into Goal + TDD slice + affected files + tests + evidence target. |
| Runtime/hook change | Threat model, fail-open/fail-closed decision, hook tests, install/settings wiring, macOS/Linux portability. |
| Evidence vocabulary change | Align code + docs + tests + ledgers; avoid rank mismatch. |
| OpenRouter/council work | Live catalog verification, budget gate, token handling, no silent Claude fallback, classified failures. |
| Update/install work | Anchor/cwd tests, release fetch, secret destination gate, verify-or-revert, doctor/honest-status, canonical paths. |
| GUI/live boundary | No demo fallback; live-only path or classified actionable error; security and macOS socket test policy. |
| Agent prompt changes | Unique `name`, frontmatter validator, explorer rebuild, docs count consistency. |

## Recommendation priority heuristic

Score each candidate 1-5:

1. Protects core value / true-line fidelity.
2. Reduces evidence inconsistency or overclaim risk.
3. Closes a real runtime boundary gap.
4. Is small and reversible.
5. Has a clear falsifier/test.

Prefer the highest total. Break ties by lower blast radius.
