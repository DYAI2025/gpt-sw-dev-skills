---
name: api-developer-builder
description: professional api development, api analysis, endpoint testing, schema validation, root-cause analysis, documentation, and b2b api platform architecture. use when working with openapi, graphql, grpc, asyncapi, postman, har, curl, logs, sdk code, api gateways, azure apim, b2b api products, quotas, subscriptions, policies, partner onboarding, developer portals, api errors, contract drift, auth failures, rate limits, idempotency, pagination, webhooks, websockets, or api observability.
---

# API Developer and Builder

## Purpose

Use this skill to analyze, design, test, document, and troubleshoot APIs with contract-first discipline. It supports REST, GraphQL, gRPC, AsyncAPI, webhooks, WebSockets, Server-Sent Events, event-driven APIs, API gateways, and B2B API platform models.

Keep recommendations evidence-bound. If contracts, logs, schemas, gateway configuration, runtime access, repository context, or credentials are missing, mark the gap as `MISSING` and continue with the safest useful analysis. Never invent endpoints, logs, schemas, provider features, credentials, or test results.

## Workflow Decision Tree

1. If the user provides errors, logs, traces, HAR, cURL, gateway responses, or failing endpoint behavior, follow **Root Cause Analysis** and load `references/analysis-and-rca.md`.
2. If the user provides OpenAPI, JSON Schema, GraphQL SDL, Protobuf, AsyncAPI, Postman, SDK code, or schema diffs, follow **Schema and Contract Validation** and load `references/testing-and-validation.md`.
3. If the user asks to design or build an API, API product, gateway policy plan, partner platform, or developer portal, follow **Builder Mode** and load `references/design-and-platform-architecture.md`.
4. If the user asks for documentation, migration guidance, endpoint references, changelogs, SDK examples, or troubleshooting guides, follow **Documentation Mode** and load `references/output-templates-and-examples.md`.
5. If the user asks about Azure API Management, APIM products, subscriptions, named values, policies, users, gateways, or management-plane SDKs, load `references/azure-apim-notes.md`.

## Core Principles

- Start from the API contract, not from implementation guesses.
- Separate symptom, evidence, hypothesis, test, root cause, fix, and prevention.
- Prefer small reproducible requests over broad speculation.
- Treat authentication, authorization, input validation, error semantics, rate limits, idempotency, versioning, and observability as first-class API design elements.
- Distinguish general API patterns from provider-specific implementation details.
- For protected APIs, never finalize a design without an auth strategy, error model, test plan, and documentation plan.
- For public or partner-facing APIs, include versioning, deprecation, changelog, onboarding, quotas, and support paths.
- Avoid offensive security guidance unless the user clearly frames the task as defensive and authorized.

## Inputs to Inventory

When available, inventory these inputs before analysis:

| Input | What to extract |
|---|---|
| OpenAPI / JSON Schema | paths, operations, parameters, security, responses, examples, nullable/optional semantics, enum values |
| GraphQL SDL | types, resolvers, auth boundaries, pagination pattern, N+1 risk, deprecations |
| gRPC Protobuf | service methods, message fields, field numbers, streaming mode, backward compatibility |
| AsyncAPI / events | channels, messages, schemas, delivery guarantees, retries, ordering, DLQ handling |
| Postman / cURL / HAR | request method, URL, headers, auth, body, status, latency, response shape |
| Logs / traces | correlation IDs, gateway vs service errors, dependency calls, timeout boundaries |
| SDK code | generated vs manual code, serialization assumptions, retry behavior, auth injection |
| Gateway policy | routing, rate limits, subscriptions, header transforms, backend selection, named values |
| Business context | consumers, producer, SLA/SLO, compliance, PII, tenant model, partner onboarding |

## API Analysis Workflow

1. **Scope the request**: identify API style, environment, consumers, producer, business use case, and current failure or design goal.
2. **Review the contract**: map endpoints/operations/types/messages, inputs, outputs, security, error semantics, pagination, filtering, sorting, and idempotency.
3. **Map runtime path**: client -> DNS/CDN/WAF -> gateway -> auth/policy -> backend service -> dependency -> database or event system.
4. **Classify findings**:
   - contract/schema mismatch;
   - authn/authz or subscription problem;
   - routing/gateway/policy problem;
   - backend/service problem;
   - data/serialization/validation problem;
   - rate limit/performance problem;
   - versioning/deprecation/breaking-change problem.
5. **Select tests**: propose concrete smoke, contract, negative, auth, rate-limit, idempotency, pagination, backward-compatibility, performance, and resilience checks.
6. **Deliver with evidence**: cite the exact provided artifact, line, snippet, endpoint, trace field, header, status code, schema path, or log fragment when available.
7. **State missing facts**: use `MISSING` for unavailable evidence and avoid presenting assumptions as verified.

## Root Cause Analysis Workflow

For endpoint failures, produce a hypothesis table before recommending fixes. Use the matrix in `references/analysis-and-rca.md`.

Minimum RCA sequence:

1. Reconstruct the request and timeline.
2. Identify exact failing boundary: client, gateway, auth provider, policy, service, dependency, serializer, database, event consumer, or external partner.
3. List competing hypotheses with evidence, risk, likelihood, and testability.
4. Run or propose the smallest safe test that distinguishes hypotheses.
5. Separate direct cause from contributing cause and systemic prevention.
6. Produce fixes with blast radius, rollback, and verification checks.

Never claim a root cause from a single symptom unless the evidence is conclusive.

## Endpoint Testing Workflow

Use `references/testing-and-validation.md` for detailed test matrices. Always include at least these test classes when relevant:

- smoke tests for availability and expected success path;
- contract tests against OpenAPI/GraphQL/Protobuf/AsyncAPI;
- schema validation for request and response examples;
- negative tests for invalid input, missing auth, forbidden scopes, malformed IDs, and unsupported enum values;
- auth tests for no token, expired token, wrong audience, wrong scope, wrong tenant, invalid subscription key, and mTLS failure where relevant;
- rate-limit and quota tests with expected `429` semantics and retry headers;
- idempotency tests for `POST`/mutation operations that create or charge resources;
- pagination, filtering, sorting, and cursor stability tests;
- backward-compatibility and schema-diff tests;
- timeout, retry, circuit-breaker, and graceful-degradation tests.

For local OpenAPI linting, the bundled script can be used as a lightweight first pass:

```bash
python scripts/openapi_contract_lint.py path/to/openapi.json
```

If YAML support is needed and PyYAML is unavailable, convert the schema to JSON first or install PyYAML in the local environment.

## Schema Validation Workflow

1. Identify schema dialect and version: OpenAPI 3.x, JSON Schema, GraphQL SDL, Protobuf, AsyncAPI, or provider-specific schema.
2. Check request and response examples against declared schemas.
3. Detect enum drift, nullable vs optional mismatch, undocumented required fields, loose `additionalProperties`, ambiguous IDs, missing formats, inconsistent date/time handling, and error model gaps.
4. Classify changes as breaking, conditionally breaking, or non-breaking.
5. Prefer additive evolution: add optional fields, add enum values only with consumer tolerance, deprecate before removal, preserve field numbers in Protobuf, and version when behavior changes.
6. Recommend consumer-driven contract tests for partner and B2B APIs.

## Builder Mode

When asked to create an API design, produce only artifacts that are justified by user context. Typical deliverables:

- OpenAPI skeleton or GraphQL SDL / Protobuf / AsyncAPI outline;
- endpoint/resource model or type/message model;
- authentication and authorization flow;
- error model and error code catalog;
- pagination/filtering/sorting/idempotency rules;
- API product model with plans, subscriptions, quotas, policies, partner onboarding, and support paths;
- gateway policy plan for routing, auth enforcement, throttling, header transforms, named values/secrets, backend abstraction, and observability;
- test plan and contract validation strategy;
- documentation structure and developer portal content;
- Mermaid architecture diagram.

When runtime, repository, credentials, or provider access are missing, mark implementation limits explicitly and provide pasteable templates rather than claiming execution.

## Security and Compliance Guardrails

- Do not request or expose production secrets, tokens, subscription keys, private certificates, passwords, or real customer data.
- Use placeholders such as `EXAMPLE_TOKEN`, `SUBSCRIPTION_KEY_PLACEHOLDER`, and `tenant-id-placeholder` in examples.
- Recommend OAuth2/OIDC/JWT, API keys, mTLS, RBAC/ABAC, scopes, claims, secret storage, and audit logs based on risk and consumer type.
- For PII or regulated data, require data minimization, retention rules, access logs, encryption in transit, secure storage, and GDPR/DSGVO review where applicable.
- Use OWASP API Security Top 10 as a defensive review frame; do not provide exploit playbooks against third-party systems.
- Sanitize error responses: expose stable problem details to clients, log detailed internals server-side only.

## Documentation Workflow

Use `references/output-templates-and-examples.md` to produce structured outputs. Good API documentation contains:

- quickstart with authentication and first successful request;
- endpoint or operation reference;
- request/response examples;
- error examples and remediation;
- auth guide with scopes, claims, token lifetimes, key rotation, and subscription flow;
- pagination/filtering/sorting/idempotency rules;
- SDK examples and version compatibility;
- changelog, migration guide, deprecation policy;
- troubleshooting guide and support escalation path;
- ADRs for consequential design decisions;
- runbooks for operational failure modes.

## Quality Gates

Before finalizing, score 1-5 and fix any score below 4 unless blocked by missing inputs:

| Gate | Check |
|---|---|
| Clarity | consumer, producer, scope, and output are unambiguous |
| Contract correctness | schemas, examples, errors, versioning, and compatibility are addressed |
| Security | auth, authorization, secrets, PII, and least privilege are addressed |
| Testability | concrete tests and expected results are defined |
| Observability | logs, metrics, traces, correlation IDs, SLO/SLI, and alerts are considered |
| Documentation quality | quickstart, reference, examples, errors, changelog, and migration are covered |
| Maintainability | design is evolvable, simple, and operationally supportable |

Reject or revise outputs that contain: no input validation, no auth strategy for protected APIs, no error semantics, no tests, no versioning strategy for public APIs, no documentation, invented facts, unsafe secret handling, or claims of executed tests without evidence.

## Output Formats

Use these formats as appropriate. Keep outputs concise unless the user requests full artifacts.

### API Analysis Report

```xml
<api_analysis_report>
  <summary></summary>
  <inputs_reviewed></inputs_reviewed>
  <assumptions></assumptions>
  <endpoint_inventory></endpoint_inventory>
  <contract_findings></contract_findings>
  <security_findings></security_findings>
  <testing_findings></testing_findings>
  <root_cause_hypotheses></root_cause_hypotheses>
  <recommended_actions></recommended_actions>
  <quality_score></quality_score>
</api_analysis_report>
```

### Root Cause Matrix

| Symptom | Evidence | Hypothesis | Test | Root Cause | Fix | Prevention |
|---|---|---|---|---|---|---|

### API Test Plan

| Test Type | Endpoint | Scenario | Expected Result | Tool/Method | Priority |
|---|---|---|---|---|---|

### Schema Validation Report

| Schema Area | Finding | Breaking? | Evidence | Recommendation |
|---|---|---|---|---|

### B2B API Architecture Brief

```xml
<b2b_api_architecture_brief>
  <business_model></business_model>
  <api_products></api_products>
  <consumer_onboarding></consumer_onboarding>
  <auth_strategy></auth_strategy>
  <gateway_policies></gateway_policies>
  <rate_limits_and_quotas></rate_limits_and_quotas>
  <observability></observability>
  <documentation_portal></documentation_portal>
  <risks_and_tradeoffs></risks_and_tradeoffs>
</b2b_api_architecture_brief>
```

## Examples

For richer examples, load `references/output-templates-and-examples.md`.

### Example: REST endpoint failure

Input: `GET /orders/{id}` returns `500` for one partner.

Output: produce an RCA matrix covering contract mismatch, auth/subscription, gateway policy, backend dependency, serialization, timeout, and versioning hypotheses. Include tests such as replaying with a known-good order ID, validating path parameter format, checking correlation ID across gateway and service logs, verifying partner subscription policy, and comparing response schema against contract.

### Example: OpenAPI schema drift

Input: response field changed from optional to required, or enum value disappeared.

Output: classify as breaking or conditionally breaking, identify affected consumers, provide corrected schema fragment, and recommend contract tests plus deprecation/migration notes.

### Example: B2B API platform

Input: partners need API products with quotas and subscriptions.

Output: define product tiers, auth strategy, gateway policies, onboarding flow, developer portal content, observability, support model, and risks/trade-offs.

## GPT and Claude Compatibility

- Do not assume a specific tool is available. If tools are unavailable, provide manual steps, pseudo-commands, or templates.
- Keep reasoning summaries short and auditable: assumptions, evidence, decision, and next verification step.
- Do not expose private chain-of-thought. Provide structured rationale instead.
- Use Markdown tables, XML templates, Mermaid diagrams, and code blocks that can be copied into common developer workflows.
