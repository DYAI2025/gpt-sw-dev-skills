#!/usr/bin/env python3
"""Lightweight OpenAPI contract lint for api-developer-builder.

This script performs a conservative first-pass review. It does not replace a
full OpenAPI validator. It flags common issues that matter for API analysis:
missing operation IDs, missing responses, absent error responses, path parameter
problems, weak examples, and missing security declarations.

Usage:
  python scripts/openapi_contract_lint.py openapi.json
  python scripts/openapi_contract_lint.py openapi.yaml --format markdown

YAML support requires PyYAML. JSON works with the Python standard library.
"""

from __future__ import annotations

import argparse
import json
import pathlib
import sys
from typing import Any

HTTP_METHODS = {"get", "put", "post", "delete", "patch", "options", "head", "trace"}
SEVERITY_ORDER = {"error": 0, "warn": 1, "info": 2}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("spec", help="Path to an OpenAPI JSON or YAML file")
    parser.add_argument(
        "--format",
        choices=["text", "json", "markdown"],
        default="text",
        help="Output format (default: text)",
    )
    return parser.parse_args()


def load_spec(path: pathlib.Path) -> dict[str, Any]:
    raw = path.read_text(encoding="utf-8")
    if path.suffix.lower() in {".yaml", ".yml"}:
        try:
            import yaml  # type: ignore
        except Exception as exc:  # noqa: BLE001
            raise SystemExit(
                "YAML input requires PyYAML. Convert to JSON or install PyYAML."
            ) from exc
        payload = yaml.safe_load(raw)
    else:
        payload = json.loads(raw)
    if not isinstance(payload, dict):
        raise SystemExit("Spec root must be a JSON/YAML object.")
    return payload


def add(findings: list[dict[str, str]], severity: str, location: str, message: str) -> None:
    findings.append({"severity": severity, "location": location, "message": message})


def has_example(media: dict[str, Any]) -> bool:
    if not isinstance(media, dict):
        return False
    if "example" in media or "examples" in media:
        return True
    schema = media.get("schema")
    return isinstance(schema, dict) and ("example" in schema or "examples" in schema)


def operation_security(operation: dict[str, Any], root_security: Any) -> bool:
    if "security" in operation:
        return bool(operation.get("security"))
    return bool(root_security)


def lint(spec: dict[str, Any]) -> list[dict[str, str]]:
    findings: list[dict[str, str]] = []

    if not spec.get("openapi"):
        add(findings, "error", "$", "Missing 'openapi' version field.")
    if not isinstance(spec.get("info"), dict):
        add(findings, "error", "$.info", "Missing or invalid info object.")
    else:
        if not spec["info"].get("title"):
            add(findings, "warn", "$.info.title", "Missing API title.")
        if not spec["info"].get("version"):
            add(findings, "warn", "$.info.version", "Missing API version.")

    paths = spec.get("paths")
    if not isinstance(paths, dict) or not paths:
        add(findings, "error", "$.paths", "Missing or empty paths object.")
        return findings

    root_security = spec.get("security")

    for path_name, path_item in paths.items():
        if not isinstance(path_item, dict):
            add(findings, "error", f"$.paths.{path_name}", "Path item must be an object.")
            continue

        path_params = {
            p.get("name")
            for p in path_item.get("parameters", [])
            if isinstance(p, dict) and p.get("in") == "path"
        }

        for method, operation in path_item.items():
            if method.lower() not in HTTP_METHODS:
                continue
            loc = f"{method.upper()} {path_name}"
            if not isinstance(operation, dict):
                add(findings, "error", loc, "Operation must be an object.")
                continue

            if not operation.get("operationId"):
                add(findings, "warn", loc, "Missing operationId.")
            if not (operation.get("summary") or operation.get("description")):
                add(findings, "info", loc, "Missing summary/description.")
            if not operation_security(operation, root_security):
                add(findings, "info", loc, "No security declared globally or on operation.")

            responses = operation.get("responses")
            if not isinstance(responses, dict) or not responses:
                add(findings, "error", loc, "Missing responses object.")
                continue

            if not any(str(code).startswith("2") for code in responses):
                add(findings, "warn", loc, "No documented 2xx success response.")
            if not any(str(code).startswith("4") for code in responses):
                add(findings, "warn", loc, "No documented 4xx client error response.")
            if not any(str(code).startswith("5") for code in responses):
                add(findings, "info", loc, "No documented 5xx server error response.")

            for status, response in responses.items():
                if not isinstance(response, dict):
                    continue
                content = response.get("content")
                if not isinstance(content, dict):
                    continue
                if content and not any(has_example(media) for media in content.values()):
                    add(findings, "info", f"{loc} response {status}", "Response schema has no example.")

            declared_params = set(path_params)
            for param in operation.get("parameters", []):
                if not isinstance(param, dict):
                    continue
                if param.get("in") == "path":
                    name = param.get("name")
                    declared_params.add(name)
                    if param.get("required") is not True:
                        add(findings, "error", f"{loc} parameter {name}", "Path parameter must be required: true.")
                    if not isinstance(param.get("schema"), dict):
                        add(findings, "warn", f"{loc} parameter {name}", "Path parameter missing schema.")

            for token in [part[1:-1] for part in path_name.split("/") if part.startswith("{") and part.endswith("}")]:
                if token not in declared_params:
                    add(findings, "error", loc, f"Path token '{{{token}}}' has no declared path parameter.")

            request_body = operation.get("requestBody")
            if isinstance(request_body, dict):
                content = request_body.get("content")
                if not isinstance(content, dict) or not content:
                    add(findings, "warn", loc, "requestBody missing content map.")
                elif not any(has_example(media) for media in content.values()):
                    add(findings, "info", loc, "requestBody has no example.")

    return sorted(findings, key=lambda item: (SEVERITY_ORDER[item["severity"]], item["location"]))


def emit_text(findings: list[dict[str, str]]) -> None:
    if not findings:
        print("No findings from lightweight lint.")
        return
    for item in findings:
        print(f"[{item['severity'].upper()}] {item['location']}: {item['message']}")


def emit_markdown(findings: list[dict[str, str]]) -> None:
    print("| Severity | Location | Finding |")
    print("|---|---|---|")
    for item in findings:
        print(f"| {item['severity']} | `{item['location']}` | {item['message']} |")


def main() -> int:
    args = parse_args()
    spec_path = pathlib.Path(args.spec)
    if not spec_path.exists():
        raise SystemExit(f"Spec file not found: {spec_path}")
    spec = load_spec(spec_path)
    findings = lint(spec)

    if args.format == "json":
        print(json.dumps({"findings": findings}, indent=2))
    elif args.format == "markdown":
        emit_markdown(findings)
    else:
        emit_text(findings)

    return 1 if any(item["severity"] == "error" for item in findings) else 0


if __name__ == "__main__":
    raise SystemExit(main())
