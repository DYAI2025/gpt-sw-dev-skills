# Azure API Management Notes

Use this reference only for Azure API Management (APIM) management-plane design, SDK usage planning, or gateway policy architecture. Distinguish APIM management-plane operations from calls to the data-plane gateway endpoints.

## Management Plane vs Data Plane

| Plane | Purpose | Examples |
|---|---|---|
| Management plane | create and configure APIM resources | APIM service, APIs, products, subscriptions, users, named values, policies, backends, gateways |
| Data plane | call business APIs through the APIM gateway | partner calls `https://gateway.example.com/orders` |

Do not mix ARM/SDK resource configuration with runtime API invocation. A management SDK creates or configures products, APIs, policies, and subscriptions; it does not prove that the backend endpoint behaves correctly.

## Common APIM Resource Concepts

- APIM service instance.
- API and API operations.
- API policy, product policy, operation policy, and global policy.
- Product as a bundle of APIs with subscription and approval rules.
- Subscription and subscription keys.
- Named values for configuration and secrets.
- Backend resources for backend abstraction.
- Users, groups, certificates, gateways, loggers, diagnostics.

## Design Checklist for APIM B2B Platforms

- Define products around consumer value, not internal microservice boundaries.
- Use subscriptions for partner access where API-key style product access is appropriate.
- Use OAuth2/OIDC or mTLS where identity, non-repudiation, or fine-grained authorization is required.
- Store secrets in named values or external secret stores; do not hardcode secrets in policies.
- Apply policies at the narrowest useful scope: global, product, API, or operation.
- Include correlation IDs and diagnostics so gateway logs can be joined with backend traces.
- Use separate products/environments for sandbox and production.
- Document approval flow, quota, key rotation, subscription lifecycle, and support process.

## Provider-Specific Caution

Only emit runnable Azure SDK code when the language, SDK version, Azure resource model, and auth context are known. Otherwise, provide a provider-neutral policy plan or pseudocode. Use placeholders for tenant IDs, subscription IDs, and credentials.

## Safe Example Placeholders

```text
AZURE_SUBSCRIPTION_ID=subscription-id-placeholder
AZURE_TENANT_ID=tenant-id-placeholder
APIM_SERVICE_NAME=apim-service-placeholder
RESOURCE_GROUP=resource-group-placeholder
```

## APIM Output Template

```markdown
## Azure APIM plan
- APIM service/environment:
- APIs to import or expose:
- Products:
- Subscriptions and approval:
- Auth strategy:
- Policies:
- Named values/secrets:
- Backends:
- Diagnostics/logging:
- Quotas/rate limits:
- Developer portal/onboarding:
- Rollout:
- Open questions / MISSING:
```
