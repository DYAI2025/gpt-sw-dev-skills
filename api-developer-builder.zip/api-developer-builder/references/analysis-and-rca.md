# API Analysis and Root Cause Analysis Reference

Use this reference when diagnosing API failures, unexplained endpoint behavior, gateway errors, schema mismatches, partner integration failures, rate-limit incidents, or production API regressions.

## RCA Operating Rules

- Do not collapse symptom and root cause.
- Do not infer server defects from `500` alone; determine which boundary failed.
- Do not infer auth defects from `401` or `403` alone; inspect token, scope, audience, tenant, subscription, gateway policy, and backend authorization separately.
- Do not claim provider-specific behavior unless the user supplied provider documentation, configuration, or logs.
- Mark unavailable evidence as `MISSING`.

## Failure Class Matrix

| Failure class | Common symptoms | Evidence to request | Distinguishing tests | Typical fixes | Prevention |
|---|---|---|---|---|---|
| Client/contract 4xx | `400`, `404`, validation error, malformed ID | cURL/HAR, OpenAPI path, request schema, response body | replay with valid and invalid examples; validate against schema | fix client payload, examples, validation message, docs | contract tests, generated clients, request examples |
| Authentication | `401`, invalid token, missing credentials | auth header shape, token claims, issuer, audience, expiry | no token vs expired token vs wrong audience | correct auth flow, token audience, key rotation | auth quickstart, token diagnostics, integration tests |
| Authorization | `403`, scope denied, tenant denied | scopes, roles, claims, tenant mapping, subscription | same token with different scope; known allowed principal | fix RBAC/ABAC/scopes/product subscription | policy tests, least-privilege review |
| Gateway/proxy/policy | gateway-specific `4xx/5xx`, transformed headers, backend unreachable | gateway logs, policy config, route table, backend ID | bypass gateway in safe lower env; compare gateway vs backend logs | route, policy, named value, backend config correction | policy-as-code, staged rollout, synthetic checks |
| Serialization/validation | `500` or `422`, enum parsing, nullable crash | payload, schema, serializer logs, stack trace | send minimal body; vary nullable/missing/unknown enum | schema correction, tolerant parser, better error mapping | schema diffing, consumer contract tests |
| Dependency/backend | `502`, `503`, `504`, dependency timeout | traces, dependency status, circuit breaker state | isolate dependency; check latency and failure rate | timeout budget, retries with jitter, fallback | SLOs, dependency dashboards, bulkheads |
| Rate limit/quota | `429`, quota exceeded, throttling | headers, product plan, subscription, time window | controlled request burst; inspect retry headers | tune quota, return standard retry semantics | quota docs, dashboards, partner alerts |
| Versioning/deprecation | one consumer fails after release | changelog, deploy timeline, schema diff, SDK version | replay against old and new versions | restore compatibility, version endpoint, migration | deprecation policy, canary, compatibility tests |
| Pagination/filtering | missing records, duplicates, unstable pages | query params, cursor, sort key, response metadata | repeat same cursor; mutate dataset in test env | stable ordering, cursor design, deterministic filters | pagination contract tests |
| Idempotency | duplicate charge/order/event | idempotency key, retry logs, request IDs | retry same key and compare resource ID | enforce idempotency store and replay response | idempotency docs, retry-safe SDKs |
| Webhook delivery | duplicate events, missing delivery, signature failure | delivery logs, event ID, signature header, retry schedule | replay same event ID; verify signature base string | idempotency, signature docs, DLQ/replay | webhook test harness, event catalog |

## RCA Template

```markdown
## Summary
- Symptom:
- Affected consumer(s):
- Affected endpoint/event:
- First seen:
- Current impact:

## Inputs reviewed
- Contract:
- Request sample:
- Response/error:
- Logs/traces:
- Gateway/policy:
- Missing evidence:

## Hypothesis matrix
| Hypothesis | Evidence For | Evidence Against | Likelihood | Risk | Test |
|---|---|---|---:|---:|---|
| Contract/schema mismatch | | | | | |
| Auth/subscription problem | | | | | |
| Gateway/policy/routing problem | | | | | |
| Backend/dependency problem | | | | | |
| Serialization/data problem | | | | | |
| Rate limit/performance problem | | | | | |
| Versioning/breaking change | | | | | |

## Root cause
- Symptom:
- Direct cause:
- Contributing causes:
- Systemic cause:
- Confidence:

## Fix plan
1. Immediate mitigation:
2. Permanent fix:
3. Rollback path:
4. Verification:
5. Prevention:
```

## Request/Response Trace Checklist

- Method, path, query string, and normalized route.
- Host, gateway, backend route, and selected API version.
- Auth scheme, token type, issuer, audience, expiry, scopes, roles, tenant, subscription/product.
- Request ID and correlation ID across client, gateway, service, and dependency logs.
- Payload size, content type, encoding, compression, and body hash when sensitive content cannot be displayed.
- Status code at each boundary, not only final client status.
- Latency split: gateway, backend, dependency, database, event publishing.
- Retry count, retry reason, idempotency key, circuit breaker state, timeout budget.

## Five-Why Prompts for APIs

1. Why did the client observe this status/body/latency?
2. Why did that boundary produce it instead of the documented response?
3. Why did validation/auth/routing/serialization/dependency behavior differ from the contract?
4. Why did tests, gateway policy review, or monitoring not catch it earlier?
5. What control prevents this class of failure for the next endpoint, consumer, or release?
