# API Testing and Schema Validation Reference

Use this reference for endpoint test plans, contract testing, schema validation, compatibility analysis, and API release gates.

## Test Plan Matrix

| Test Type | Purpose | Examples | Expected result |
|---|---|---|---|
| Smoke | prove endpoint is reachable and core success path works | `GET /health`, `GET /orders/{knownId}` | documented success status and schema |
| Contract | prove implementation matches OpenAPI/GraphQL/Protobuf/AsyncAPI | validate response examples against schema | no schema violations |
| Negative | prove invalid input fails predictably | malformed ID, missing required field, unknown enum | documented `4xx` with stable error body |
| AuthN | prove identity enforcement | missing token, expired token, wrong audience | `401` or provider-specific equivalent |
| AuthZ | prove permission enforcement | insufficient scope, wrong tenant, inactive subscription | `403` or documented denial |
| Rate limit | prove quota behavior | burst above quota | `429`, retry metadata, no data mutation |
| Idempotency | prove safe retries | same idempotency key on create/payment/order | same resource/result, no duplicate side effect |
| Pagination | prove stable traversal | first page, next cursor, invalid cursor | stable order, no duplicates, clear cursor errors |
| Filtering/sorting | prove deterministic query semantics | filter by status/date, sort asc/desc | expected subset and order |
| Compatibility | prove consumers survive change | old SDK against new API; schema diff | no breaking behavior without versioning |
| Performance | probe latency and saturation | representative load, p95/p99 checks | within SLO or documented limit |
| Resilience | prove controlled failure | timeout, dependency down, retry storm | fallback/degraded response or clear error |
| Webhook | prove delivery semantics | duplicate event, signature failure, retry | idempotent processing, clear DLQ/replay |

## OpenAPI / JSON Schema Checks

Check these areas:

- `openapi`, `info`, and `paths` exist.
- Every operation has `operationId`, summary or description, response map, and examples for important statuses.
- Protected operations declare security or inherit global security.
- Path parameters are declared as `required: true` and have schemas.
- Request bodies specify content type and schema.
- Response bodies specify schema for `2xx` and documented error responses.
- Error model is consistent, preferably based on stable fields such as `code`, `message`, `details`, `correlationId`, or RFC 7807 problem details.
- Dates and times use explicit formats and timezone semantics.
- IDs are typed and examples reflect actual format.
- `nullable` and optional are not confused:
  - optional means the field may be absent;
  - nullable means the field may be present with `null`.
- Enums are evaluated for consumer tolerance before adding or removing values.

## Breaking Change Classification

| Change | Classification | Notes |
|---|---|---|
| remove endpoint/operation | breaking | version or deprecate first |
| remove response field used by consumers | breaking | especially for generated clients |
| make optional request field required | breaking | old clients fail |
| make nullable response field non-null without data guarantee | conditionally breaking | generated clients may depend on nullability |
| remove enum value | breaking | old stored values or clients may fail |
| add enum value | conditionally breaking | tolerant clients OK; exhaustive switch clients may fail |
| add optional response field | usually non-breaking | document and test serialization |
| add optional request field | usually non-breaking | safe if default behavior is stable |
| change field type or format | breaking | version required |
| change pagination cursor semantics | breaking for traversing clients | migration guide required |
| change auth scope/audience | breaking for clients | rollout and partner communication required |
| reserve but do not reuse Protobuf field numbers | non-breaking hygiene | never reuse old field numbers |

## GraphQL Validation Checks

- Check N+1 risk in resolvers and require DataLoader/batching for nested entity fetches.
- Use connection-style pagination for large lists when client traversal matters.
- Treat removing fields, changing field nullability from nullable to non-null, changing argument requirements, or narrowing enum values as breaking.
- Prefer field deprecation with reason before removal.
- Validate authorization at resolver or data-access boundary, not only at UI layer.
- Add query complexity/depth limits for public GraphQL APIs.

## gRPC / Protobuf Validation Checks

- Never reuse field numbers.
- Do not change field meaning while preserving field name/number.
- Add fields with new numbers for compatible evolution.
- Avoid changing scalar type in a way that breaks binary compatibility.
- Define deadline/timeout behavior and retry policy outside business semantics.
- Document streaming mode: unary, server streaming, client streaming, bidirectional.

## AsyncAPI / Event Validation Checks

- Document channel/topic names, message schema, event ID, timestamp, producer, and consumer expectations.
- Define ordering, delivery guarantees, retry schedule, deduplication key, and DLQ behavior.
- Treat removal or semantic change of event fields as breaking for consumers.
- Include replay and backfill strategy for B2B integrations.

## Example Test Cases

```markdown
| Test Type | Endpoint | Scenario | Expected Result | Tool/Method | Priority |
|---|---|---|---|---|---|
| Smoke | GET /orders/{id} | known accessible order | 200 with Order schema | curl + schema validator | P0 |
| Negative | GET /orders/{id} | malformed UUID | 400 with documented error code | curl | P0 |
| AuthZ | GET /orders/{id} | valid token, wrong tenant | 403 with no resource leakage | integration test | P0 |
| Idempotency | POST /orders | same idempotency key retried | same order ID, no duplicate | integration test | P0 |
| Rate limit | GET /orders | exceed partner quota | 429 with Retry-After | controlled burst | P1 |
```
