# API Design and B2B Platform Architecture Reference

Use this reference when designing APIs, API products, partner platforms, gateway policy plans, developer portals, or multi-tenant API architectures.

## Style Selection

| Style | Use when | Avoid when | Key design risks |
|---|---|---|---|
| REST | resource-oriented CRUD/workflow APIs, broad compatibility, gateway-friendly B2B APIs | highly graph-shaped client-specific data or real-time streams | inconsistent resources, weak error model, ad hoc filtering |
| GraphQL | clients need flexible graph reads, multiple frontends, schema-driven DX | simple public partner APIs with strict quotas or heavy caching needs | N+1, overfetch through nested queries, auth at field level |
| gRPC | low-latency service-to-service calls, strongly typed internal APIs, streaming | browser-first public APIs without gateway translation | compatibility mistakes, weaker human inspectability |
| AsyncAPI/events | asynchronous workflows, fan-out, integration events, eventual consistency | immediate request/response semantics | ordering, retries, idempotency, schema evolution |
| Webhooks | outbound partner notifications | partners cannot expose stable receivers | duplicate delivery, signatures, retries, DLQ/replay |
| WebSockets/SSE | real-time updates, notifications, collaboration | simple request/response data retrieval | connection lifecycle, scaling, backpressure |
| BFF | different client experiences need tailored aggregation | API surface can stay uniform | logic duplication across BFFs |

## REST Design Checklist

- Model nouns/resources before URLs.
- Use HTTP methods consistently: `GET`, `POST`, `PUT`, `PATCH`, `DELETE`.
- Use path parameters for identity and query parameters for filtering, sorting, pagination, and sparse fieldsets.
- Define status codes and error body consistently.
- Use idempotency keys for retryable create/payment/order operations.
- Use optimistic concurrency (`ETag`, version field, or precondition headers) where overwrite risk exists.
- Define pagination with stable order. Prefer cursor pagination for mutable large collections.
- Version public APIs intentionally: URL, header, or media type; document deprecation.

## GraphQL Design Checklist

- Define schema around domain concepts, not database tables.
- Use resolver batching/DataLoader for nested relations.
- Enforce auth at resolver/data boundary and consider field-level authorization.
- Add query complexity and depth limits.
- Use deprecation metadata before removing fields.
- Provide persisted queries for high-volume clients if needed.

## Webhook Design Checklist

- Include `event_id`, `event_type`, `created_at`, producer identity, and resource reference.
- Sign payloads with a documented signature base string and timestamp tolerance.
- Require idempotent consumer handling based on `event_id` or resource version.
- Define retry schedule, terminal failure behavior, and DLQ/replay process.
- Provide local testing tools or sample receiver code.

## B2B API Product Model

A B2B API platform normally needs these layers:

| Layer | Decisions |
|---|---|
| Business model | free trial, sandbox, partner tier, paid product, internal product, regulatory product |
| Consumer identity | organization, application, environment, user/developer, tenant |
| API products | bundles of APIs with usage plans, subscription requirement, approval flow |
| Auth | OAuth2 client credentials, OIDC, API key, mTLS, signed requests, partner certificates |
| Authorization | scopes, roles, claims, tenant mapping, product access, resource-level checks |
| Gateway policies | routing, auth validation, subscription checks, quotas, rate limits, transforms, CORS where relevant |
| Quotas | requests per second/minute/day/month, burst, concurrent requests, payload size, webhook retries |
| Developer portal | catalog, quickstart, credentials, sandbox, SDKs, changelog, support, status page |
| Observability | per-partner metrics, correlation IDs, audit logs, anomaly detection, quota dashboards |
| Operations | onboarding, key rotation, incident handling, deprecation notices, SLA reports |

## API Gateway Policy Plan

```markdown
## Gateway policy plan
- Gateway/product:
- API/backend route:
- Consumer identity source:
- Authentication enforcement:
- Authorization/subscription check:
- Rate limit/quota:
- Request transformations:
- Response transformations:
- Header policy:
- Backend selection:
- Caching:
- Observability:
- Error mapping:
- Secrets/named values:
- Rollout and rollback:
```

## Multi-Tenant API Guardrails

- Tenant identity must be explicit in token claims, subscription metadata, or trusted routing context.
- Never rely only on client-supplied tenant IDs for authorization.
- Tenant filters must exist in repository/query boundary, not only in controllers.
- Cross-tenant access tests are P0.
- Audit logs should include actor, tenant, application, operation, resource, result, and correlation ID.

## Mermaid Architecture Template

```mermaid
flowchart LR
  PartnerApp[Partner application] -->|OAuth2 / API key / mTLS| Gateway[API gateway]
  Gateway -->|policy: auth, quota, route| API[API service]
  API --> AuthZ[authorization service]
  API --> DB[(tenant data store)]
  API --> Events[(event bus)]
  Gateway --> Obs[logs metrics traces]
  API --> Obs
  Events --> Webhook[webhook delivery worker]
  Webhook --> PartnerReceiver[partner webhook receiver]
```

## ADR Template for API Decisions

```markdown
# ADR: <decision title>

## Status
Proposed | Accepted | Deprecated | Replaced

## Context
- Consumers:
- Constraints:
- Non-functional requirements:
- Existing contracts:

## Decision

## Alternatives considered
| Alternative | Pros | Cons | Reason rejected/accepted |
|---|---|---|---|

## Consequences
- Compatibility:
- Security:
- Observability:
- Operations:
- Documentation:
```
