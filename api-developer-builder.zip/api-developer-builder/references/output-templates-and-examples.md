# Output Templates and Examples

Use this reference when the user asks for structured reports, API documentation, platform briefs, test plans, examples, or reusable output formats.

## API Analysis Report Template

```xml
<api_analysis_report>
  <summary></summary>
  <inputs_reviewed></inputs_reviewed>
  <assumptions></assumptions>
  <endpoint_inventory></endpoint_inventory>
  <contract_findings></contract_findings>
  <security_findings></security_findings>
  <testing_findings></testing_findings>
  <root_cause_hypotheses></root_cause_hypotheses>
  <recommended_actions></recommended_actions>
  <quality_score></quality_score>
</api_analysis_report>
```

## Endpoint Documentation Template

```markdown
# <METHOD> <PATH>

## Purpose

## Authentication and authorization
- Auth method:
- Required scopes/roles/product:
- Tenant behavior:

## Request
### Path parameters
| Name | Type | Required | Description | Example |
|---|---|---:|---|---|

### Query parameters
| Name | Type | Required | Description | Example |
|---|---|---:|---|---|

### Headers
| Name | Required | Description | Example |
|---|---:|---|---|

### Body
```json
{}
```

## Responses
### 200 / 201 success
```json
{}
```

### Errors
| Status | Code | Meaning | Client action |
|---:|---|---|---|

## Pagination, filtering, sorting

## Idempotency

## Rate limits and quotas

## Examples
### cURL
```bash
curl -X GET "https://api.example.com/resource" \
  -H "Authorization: Bearer EXAMPLE_TOKEN"
```

## Changelog
```

## Example 1: REST API RCA

**Input:** `GET /orders/{id}` returns `500`.

**Output pattern:**

```markdown
## Summary
`GET /orders/{id}` returns `500`. Current evidence is insufficient to assert root cause. Highest-probability hypotheses are serialization/data mismatch, backend dependency failure, or gateway/backend mapping error.

## Root cause matrix
| Symptom | Evidence | Hypothesis | Test | Root Cause | Fix | Prevention |
|---|---|---|---|---|---|---|
| 500 for GET /orders/{id} | MISSING: exact body, correlation ID, logs | backend throws on specific order data | replay same ID and known-good ID; inspect service logs by correlation ID | MISSING | harden serializer or data mapping if confirmed | contract tests with edge-case order fixtures |
| 500 through gateway only | MISSING: gateway/backend status split | APIM/gateway policy or route transform issue | compare direct backend call in safe env with gateway call | MISSING | fix route/policy/header transform if confirmed | policy tests and staged rollout |
| 500 for one partner | MISSING: partner token/subscription | product policy or tenant mapping failure | same resource with admin/partner token; inspect claims/product | MISSING | correct subscription/tenant mapping | partner auth regression tests |

## Immediate tests
1. Capture full response body, headers, and correlation ID.
2. Search gateway logs and backend logs by correlation ID.
3. Replay with one known-good order ID and the failing ID.
4. Validate response/error against OpenAPI error schema.
5. Compare failing partner token claims and subscription to a known-good partner.
```

## Example 2: OpenAPI Schema Validation

**Input:** `status` enum changed from `['created', 'paid', 'shipped']` to `['created', 'paid']`, or a response field changed from optional to required.

**Output pattern:**

```markdown
## Schema validation report
| Schema Area | Finding | Breaking? | Evidence | Recommendation |
|---|---|---|---|---|
| Order.status enum | `shipped` removed | Yes | previous enum included `shipped`; new enum omits it | restore enum value or introduce new API version with migration guide |
| Order.deliveryDate | field changed optional -> required | Yes for old clients if response/request validation depends on it | required list now includes `deliveryDate` | keep optional until all consumers migrate |

## Corrected schema fragment
```json
{
  "Order": {
    "type": "object",
    "required": ["id", "status"],
    "properties": {
      "id": { "type": "string" },
      "status": {
        "type": "string",
        "enum": ["created", "paid", "shipped"]
      },
      "deliveryDate": {
        "type": "string",
        "format": "date-time",
        "nullable": true
      }
    }
  }
}
```
```

## Example 3: B2B API Platform

**Input:** partners should consume API products with quotas and subscriptions.

**Output pattern:**

```markdown
## B2B API architecture brief
### Business model
Partner-facing API platform with sandbox and production access.

### API products
| Product | APIs | Consumer | Quota | Approval |
|---|---|---|---|---|
| Sandbox | test APIs | prospective partners | low daily quota | self-service |
| Standard | core APIs | approved partners | contractual quota | approval required |
| Premium | core + bulk APIs | strategic partners | higher quota + SLA | manual approval |

### Auth strategy
OAuth2 client credentials for application identity; optional mTLS for high-trust partners; subscription/product binding at gateway.

### Gateway policies
Validate token, check product subscription, enforce quota, inject correlation ID, route to backend, normalize errors, log partner/app/product.

### Onboarding flow
Register organization -> create app -> accept terms -> sandbox credentials -> integration tests -> production approval -> key/cert rotation schedule.
```

## Example 4: GraphQL N+1

**Input:** GraphQL order query is slow when fetching `orders { customer { name } items { sku } }`.

**Output pattern:**

```markdown
## Diagnosis
Likely N+1 resolver behavior if each order resolves customer and items with separate database calls. Evidence required: resolver traces or query count per request.

## Recommendation
- Add DataLoader/batching for customer and items by ID.
- Add query complexity/depth limits.
- Add resolver-level auth and tenant checks.
- Add integration test that asserts bounded query count for 1, 10, and 100 orders.

## Test plan
| Test Type | Scenario | Expected Result |
|---|---|---|
| Performance | 100 orders with nested customers/items | query count remains bounded by batches, not O(n) |
| AuthZ | order from another tenant | field denied or filtered without leakage |
| Compatibility | deprecated field still available | field works and includes deprecation metadata |
```

## Example 5: Webhook Delivery

**Input:** partner receives duplicate events and some failed deliveries.

**Output pattern:**

```markdown
## Webhook reliability plan
- Include `event_id` and require consumers to deduplicate by `event_id`.
- Sign payload with timestamped HMAC or equivalent provider-approved mechanism.
- Define retry schedule: immediate, 1 min, 5 min, 30 min, 2 h, then DLQ.
- Store delivery attempts with status, response code, latency, and next retry.
- Provide replay from DLQ after partner fix.
- Document idempotent receiver behavior and signature verification base string.
```

## Example 6: API Documentation Improvement

**Input:** endpoint documentation only says `POST /payments creates payment`.

**Output pattern:**

```markdown
# POST /payments

## Purpose
Create a payment authorization or charge depending on configured payment mode.

## Authentication
Requires OAuth2 client credentials with `payments:create` scope and active product subscription.

## Idempotency
Required. Send `Idempotency-Key` for retry-safe creation. Reusing the same key returns the original payment result.

## Request example
```json
{
  "amount": { "currency": "EUR", "value": "49.00" },
  "merchantReference": "order-123"
}
```

## Success response
```json
{
  "id": "pay_example_123",
  "status": "authorized",
  "createdAt": "2026-05-29T10:00:00Z"
}
```

## Error examples
| Status | Code | Meaning | Client action |
|---:|---|---|---|
| 400 | invalid_amount | amount format invalid | correct request |
| 401 | invalid_token | auth failed | request new token |
| 403 | insufficient_scope | missing `payments:create` | update app permissions |
| 409 | idempotency_conflict | key reused with different payload | use original payload or new key |
| 429 | quota_exceeded | product quota exceeded | wait and retry after header |
```
