# Repo Integration Patterns for MCP Builder

## Zweck

Diese Referenz uebersetzt die Repo-Evaluation in konkrete, wiederverwendbare Erweiterungsmodule fuer den `mcp-builder` Skill. Verwende diese Patterns, wenn ein Nutzer Repos, API-Code, OpenAPI-Spezifikationen oder Generator-Prototypen als Input fuer eine MCP-Creator-Weiterentwicklung liefert.

## Modul 1: Contract-first API to MCP Specification

**Quelle:** primaer `fastapi_mcp-main`.

### Ziel

Aus FastAPI-, OpenAPI-, REST-, GraphQL- oder aehnlichen API-Kontrakten eine sichere MCP Tool-Spezifikation erzeugen, ohne Endpunkte blind zu spiegeln.

### Algorithmus

1. Lade API-Kontrakt oder App-Introspection nur aus bereitgestellten/erlaubten Quellen.
2. Erzeuge `capability_inventory`:
   - resource;
   - operation id;
   - method/query/mutation;
   - read/write/destructive/admin;
   - auth scope;
   - pagination;
   - idempotency.
3. Filtere Operationen:
   - `include_operations`/`exclude_operations`;
   - `include_tags`/`exclude_tags`;
   - Security-Blocklist fuer delete/admin/export_sensitive.
4. Normalisiere Toolnamen zu `service_action_object`.
5. Mape Parameter, Request Body und Response Schema in MCP Input/Output-Schema.
6. Setze Annotationen:
   - GET/search/list/get: meist readOnly=true, destructive=false, idempotent=true;
   - POST/PATCH/PUT: write und meistens ask;
   - DELETE/publish/send/revoke/charge: destructive=true und deny/ask.
7. Erzeuge Tool Specification Table und MCP Builder IR.
8. Markiere ungepruefte SDK-Felder als `MISSING_VERIFICATION`.

### Output

```yaml
capability_inventory:
  service: target-service
  source_contract: openapi | fastapi | graphql | manual
  operations:
    - operation_id: listItems
      method: GET
      path: /items
      action_class: read
      tool_name: target_list_items
      permission: allow
      annotations:
        readOnlyHint: true
        destructiveHint: false
        idempotentHint: true
        openWorldHint: true
```

### Gates

- Kein Tool ohne Input-Schema.
- Kein List/Search-Tool ohne `limit` und Pagination-Strategie.
- Kein Write-Tool ohne Permission `ask` oder hoeher.
- Kein Delete/Admin-Tool ohne explizite Nutzeranforderung.
- Kein Token Forwarding ausser ueber Allowlist und dokumentierte Policy.

## Modul 2: Safe MCP Server Intermediate Representation

**Quelle:** `MCP-Server-Creator-main`, gehaertet durch mcp-builder Security Policy.

### Ziel

Eine deklarative IR schaffen, aus der TypeScript- oder Python-MCP-Server generiert werden koennen, ohne freie Code-Strings oder ungepruefte Pfade zu akzeptieren.

### IR-Pflichtfelder

```yaml
mcp_server_ir:
  name: target-service-mcp
  version: 0.1.0
  runtime: typescript | python
  transport: stdio | streamable_http | secure_tunnel
  auth:
    inbound: bearer | jwt | oauth | mtls | none_for_stdio_only
    downstream: token_exchange | scoped_service_token | api_key | oauth_client_credentials
    token_passthrough_default: false
  tools:
    - name: target_list_items
      description: Listet Items mit Pagination und optionalem Filter.
      source_operation: GET /items
      input_schema: {}
      output_schema: {}
      annotations:
        readOnlyHint: true
        destructiveHint: false
        idempotentHint: true
        openWorldHint: true
      permission: allow
      implementation_strategy: api_client_call
      pagination: cursor
      errors: [400, 401, 403, 404, 409, 429, 5xx]
  resources: []
  prompts: []
  tests:
    unit: true
    integration: mock_or_sandbox
    smoke: list_tools_and_one_read_call
  evaluation:
    required_qa_pairs: 10
    read_only_only: true
  activation:
    local_stdio: true
    remote_http: false
```

### Verbotene Defaults

- `implementation: raw_code_string`.
- `save_path` ausserhalb eines expliziten Output-Verzeichnisses.
- `auth: none` fuer Remote-HTTP.
- unbounded response.
- `permission: allow` fuer destructive Tools.

## Modul 3: Generated Server Verifier

**Quellen:** `mcp-use-main`, `playwright-mcp-main`, bestehender Evaluation Guide.

### Ziel

Jeder generierte MCP-Server muss nachweisbar mindestens starten, Tools listen und einen read-only Tool Call ausfuehren koennen, bevor er als nutzbar gilt.

### Ablauf

1. Build/Typecheck/Syntaxcheck ausfuehren.
2. Server mit gewaehltem Transport starten:
   - `stdio`: Prozess durch Verifier starten;
   - `streamable_http`: Server separat starten, Healthcheck pruefen;
   - `legacy_sse`: nur Kompatibilitaetsmodus.
3. MCP Client verbinden.
4. `ping` oder aehnliche Verbindung pruefen, falls vom SDK/Client unterstuetzt.
5. `list_tools` ausfuehren.
6. Toolliste gegen erwartete Tool-Spezifikation vergleichen.
7. Schemata und Annotationen pruefen.
8. Einen garantiert read-only Tool Call mit Mock/Sandbox-Daten ausfuehren.
9. Evaluation XML mit exakt 10 Aufgaben pruefen.
10. Report mit Pass/Fail, Tool-Feedback und MISSING-Feldern ausgeben.

### Golden Tool List

Nutze eine Snapshot-Datei:

```json
{
  "server": "target-service-mcp",
  "tools": [
    {
      "name": "target_list_items",
      "readOnlyHint": true,
      "destructiveHint": false,
      "permission": "allow"
    }
  ]
}
```

Golden Tool Lists pruefen Regressionen, ersetzen aber keine semantischen Evaluations.

## Modul 4: Activation Bundle Generator

**Quellen:** `mcp-server-guide-main`, `playwright-mcp-main`, vorhandener `activation-guide.md`.

### Ziel

Generierte MCP-Server werden nicht nur als Code, sondern als aktivierbares Paket ausgegeben.

### Pflichtartefakte

```text
generated-mcp-server/
├── README.md
├── .env.example
├── Dockerfile
├── evaluation.xml
├── inspector-checklist.md
├── mcp-local-stdio.json
├── mcp-remote-http.json
├── permissions.json
├── server.json
└── troubleshooting.md
```

### Server Manifest Regel

`server.json` darf nur Felder enthalten, die fuer die Zielplattform verifiziert sind. Bei Unsicherheit:

```json
{
  "name": "MISSING_VERIFICATION",
  "remotes": [
    {
      "type": "streamable-http",
      "url": "MISSING_DEPLOYMENT_URL"
    }
  ]
}
```

## Modul 5: Tool Budget and Category Compression

**Quellen:** `playwright-mcp-main`, `cocos-mcp-server-main`, `everything-claude-code-main`.

### Ziel

Grosse APIs duerfen nicht unkontrolliert als riesige Tool-Schemata geladen werden. Der Creator muss Tool-Budget, Kategorien und progressive Tool-Exposure planen.

### Regeln

- Wenn mehr als 25 Tools entstehen, erstelle Toolgruppen nach Domain und Persona.
- Wenn mehr als 75 Tools entstehen, erzwinge Kategorie-Enablement oder High-Level-Workflow-Tools.
- Wenn ein Tool sehr grosse Response-Schemata hat, erzeuge compact/list und detail/get getrennt.
- Wenn eine CLI fuer Coding-Agenten token-effizienter ist als MCP, dokumentiere CLI/Skill als Alternative.
- Default: nur read/search/get Tools auto-allow; write/destructive nur `ask` oder `deny`.

### Kategorieformat

```yaml
tool_categories:
  read_core:
    enabled_by_default: true
    permission: allow
  write_standard:
    enabled_by_default: false
    permission: ask
  destructive_admin:
    enabled_by_default: false
    permission: deny
```

## Modul 6: Agent Harness Governance

**Quelle:** `everything-claude-code-main` als Pattern-Mine.

### Ziel

MCP Builder soll langfristig nicht nur Generator sein, sondern ein kontrollierter Entwicklungsprozess mit Inventory, Decision Log, Security Gates und Release Checks.

### Minimaler Governance-Kern

```yaml
governance:
  evidence_ledger: true
  source_map: true
  decision_log: true
  missing_dependencies_register: true
  security_gate: true
  validation_gate: true
  release_gate: true
```

### Gates

- Kein Release ohne `missing_dependencies` Review.
- Kein Remote-Deployment ohne Auth/Rate Limit/Timeout/Log-Redaction.
- Kein Write-Tool ohne Permission- und Approval-Modell.
- Kein grosses Toolset ohne Tool-Budget-Review.

## Modul 7: Missing Submodule Gate

**Quelle:** `minds-main`.

### Ziel

Repo-Snapshots mit fehlenden Submodulen duerfen nicht als vollstaendige Implementierungen bewertet werden.

### Regel

Wenn `.gitmodules` Submodule nennt und die Zielpfade fehlen oder leer sind:

```yaml
repo_completeness: incomplete
confidence_cap: 2
allowed_use: deployment_topology_only
blocked_use:
  - code_generation_pattern
  - api_contract_claim
  - runtime_claim
```

## Integrationsprinzip

Extrahiere Muster, nicht Monolithen. Uebernimm nur Code, wenn Lizenz, Runtime-Kompatibilitaet, Security und Testbarkeit geklaert sind. Andernfalls nutze das Repo als `reference_pattern` und erzeuge eigene, saubere Templates im MCP Builder.
