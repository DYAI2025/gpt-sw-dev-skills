# Repo Extension Roadmap for MCP Builder

## Zielbild

Der MCP Builder wird von einem promptbasierten Server-Design-Skill zu einem repo-gestuetzten MCP Creator erweitert, der API-Kontrakte analysiert, eine sichere IR erzeugt, Code generiert, Smoke Tests ausfuehrt, Evaluationen vorbereitet und Activation Bundles ausgibt.

## Sprint 0: Repo Evidence Baseline

**Ziel:** Bewertbare Evidenz statt Bauchgefuehl.

Tasks:

1. Repo-Inventar erzeugen: Dateien, LOC, Manifeste, Tests, CI, Lizenz, MCP-Bezug.
2. Source Map mit Confidence erstellen.
3. Risiken und MISSING-Felder erfassen.
4. Direkte Codeuebernahme blockieren, bis Lizenz und Runtime geklaert sind.

Acceptance Criteria:

- `repo-extension-source-map.md` existiert.
- Jedes Repo hat Typ, Nutzen, Grenzen und Confidence.
- Repos ohne Lizenz oder mit fehlenden Submodulen sind begrenzt.

## Sprint 1: Safe MCP Server IR

**Primaere Quelle:** `MCP-Server-Creator-main`.

Tasks:

1. `mcp_server_ir` definieren.
2. Tool, Resource, Prompt, Auth, Transport, Permission, Test, Evaluation und Activation abbilden.
3. Arbitrary code strings verbieten.
4. Exportpfade sandboxen.
5. IR gegen JSON Schema validieren.

Acceptance Criteria:

- IR ist ohne SDK-Versionen nutzbar.
- Jedes Tool hat Annotationen und Permission.
- Write/Destructive Tools sind nicht auto-allow.
- Validation Script erkennt fehlende Pflichtfelder.

## Sprint 2: OpenAPI/FastAPI to MCP Spec

**Primaere Quelle:** `fastapi_mcp-main`.

Tasks:

1. API-Kontrakt laden.
2. Operation Inventory erzeugen.
3. Include/Exclude nach Operations und Tags unterstuetzen.
4. Parameters/Body/Responses in Input/Output-Schemata mappen.
5. Toolnamen normalisieren.
6. Permission/Annotation heuristisch ableiten.

Acceptance Criteria:

- Aus einer Beispiel-OpenAPI entsteht eine Tool Specification Table.
- Alle List/Search-Tools haben Pagination.
- Delete/Admin/Export werden denied oder ask.
- Unbekannte Auth-Scopes bleiben `MISSING_AUTH_SCOPE`.

## Sprint 3: Generated Server Verifier

**Primaere Quellen:** `mcp-use-main`, `playwright-mcp-main`.

Tasks:

1. Verifier-Spezifikation implementieren.
2. stdio Smoke Test modellieren.
3. streamable_http Smoke Test modellieren.
4. Golden Tool List erzeugen.
5. read-only Tool Call gegen Mock/Sandbox ausfuehren.
6. Evaluation XML auf exakt 10 QA-Paare pruefen.

Acceptance Criteria:

- Verifier Report unterscheidet `PASSED`, `FAILED`, `MISSING_VERIFICATION`.
- Ein generierter Server darf ohne Tool Listing nicht als aktiviert gelten.
- Eval-Antworten ohne read-only Verifikation bleiben markiert.

## Sprint 4: Activation Bundle Generator

**Primaere Quellen:** `mcp-server-guide-main`, `playwright-mcp-main`.

Tasks:

1. `mcp-local-stdio.json` erzeugen.
2. `mcp-remote-http.json` erzeugen.
3. `permissions.json` erzeugen.
4. `server.json` nur mit verifizierten Feldern erzeugen.
5. Dockerfile und Reverse-Proxy-Hinweise erzeugen.
6. README und Troubleshooting erzeugen.

Acceptance Criteria:

- Keine Produktionssecrets in Artefakten.
- Remote-Konfig enthaelt Auth-Hinweis.
- Permission-Regeln folgen `deny > ask > allow`.
- Unsichere Felder sind `MISSING_VERIFICATION`.

## Sprint 5: Tool Budget and Governance

**Primaere Quellen:** `everything-claude-code-main`, `cocos-mcp-server-main`, `playwright-mcp-main`.

Tasks:

1. Tool-Budget-Grenzen definieren.
2. Kategorie-Enablement fuer grosse APIs einfuehren.
3. Context-Budget Report erzeugen.
4. Security Gate und Release Gate definieren.
5. MCP Inventory fuer mehrere Server einbauen.

Acceptance Criteria:

- Mehr als 25 Tools loest Tool-Budget-Review aus.
- Mehr als 75 Tools erfordert Kategorie-Enablement oder Workflow-Tool-Design.
- Jeder Release hat Evidence Ledger, Missing Register und Security Gate.

## Backlog fuer spaetere Iterationen

| Item | Nutzen | Voraussetzung |
|---|---|---|
| GraphQL SDL→MCP Konverter | erweitert Contract-first Reichweite | GraphQL-Beispielschemas |
| AsyncAPI/Webhook→MCP Resource/Prompt Design | Event-getriebene Systeme | AsyncAPI-Spezifikationen |
| Evaluation Runner Integration | misst reale Agentenfaehigkeit | lauffaehiger MCP Client und Modellzugang |
| Multi-runtime Codegen | TypeScript/Python parallel | aktuelle SDK-Verifikation |
| Secure Tunnel Activation | private/on-prem Server | aktuelle Plattformdokumentation |
