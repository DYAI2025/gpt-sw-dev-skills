# Implementation Templates

Use these templates as project scaffolds. They intentionally avoid final SDK import claims until official documentation or installed packages are verified.

## 1. TypeScript Project Structure Template

Copy from `assets/typescript-project-structure.txt`.

Recommended modules:

| File | Purpose |
|---|---|
| `src/config.ts` | parse env vars, validate required configuration |
| `src/api/client.ts` | downstream API wrapper with auth, timeout, retry and rate-limit handling |
| `src/api/errors.ts` | error mapper from downstream errors to MCP-facing errors |
| `src/mcp/server.ts` | MCP server initialization after SDK verification |
| `src/mcp/tools/*.ts` | tool definitions grouped by domain |
| `src/mcp/registry.ts` | explicit tool registration |
| `src/mcp/format.ts` | response formatter and structured output helpers |
| `src/security/*.ts` | auth middleware, permission checks, rate limiter |
| `src/pagination.ts` | cursor/limit helpers |
| `tests/*.test.ts` | unit and integration tests |

### TypeScript `package.json` template

```json
{
  "name": "mcp-target-service",
  "version": "0.1.0",
  "type": "module",
  "private": true,
  "scripts": {
    "build": "tsc -p tsconfig.json",
    "typecheck": "tsc -p tsconfig.json --noEmit",
    "lint": "eslint .",
    "test": "vitest run",
    "start": "node dist/index.js",
    "inspect": "npx @modelcontextprotocol/inspector"
  },
  "dependencies": {
    "@modelcontextprotocol/sdk": "MISSING_VERIFICATION",
    "zod": "MISSING_VERIFICATION"
  },
  "devDependencies": {
    "@types/node": "MISSING_VERIFICATION",
    "typescript": "MISSING_VERIFICATION",
    "vitest": "MISSING_VERIFICATION",
    "eslint": "MISSING_VERIFICATION"
  }
}
```

### TypeScript `tsconfig.json` template

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "lib": ["ES2022"],
    "outDir": "dist",
    "rootDir": "src",
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "exactOptionalPropertyTypes": true,
    "esModuleInterop": true,
    "forceConsistentCasingInFileNames": true,
    "skipLibCheck": true
  },
  "include": ["src/**/*.ts", "tests/**/*.ts"]
}
```

### TypeScript server skeleton

```ts
// MISSING_VERIFICATION: replace imports with current official MCP TypeScript SDK imports.
// import { McpServer } from "MISSING_VERIFIED_MCP_TYPESCRIPT_SDK";
// import { StdioServerTransport } from "MISSING_VERIFIED_MCP_TYPESCRIPT_SDK";
// import { StreamableHttpTransport } from "MISSING_VERIFIED_MCP_TYPESCRIPT_SDK";
// import { z } from "zod";

import { createApiClient } from "./api/client.js";
import { mapError } from "./api/errors.js";
import { loadConfig } from "./config.js";

export async function createServer() {
  const config = loadConfig();
  const api = createApiClient(config);

  // const server = new McpServer({ name: config.serverName, version: config.serverVersion });

  // server.registerTool("service_list_items", {
  //   description: "Listet Items mit Pagination und optionalem Filter.",
  //   inputSchema: z.object({
  //     limit: z.number().int().min(1).max(50).default(20),
  //     cursor: z.string().optional(),
  //     query: z.string().max(200).optional()
  //   }),
  //   annotations: {
  //     readOnlyHint: true,
  //     destructiveHint: false,
  //     idempotentHint: true,
  //     openWorldHint: true
  //   }
  // }, async (input) => {
  //   try {
  //     const result = await api.listItems(input);
  //     return {
  //       content: [{ type: "text", text: `Gefunden: ${result.items.length}` }],
  //       structuredContent: result
  //     };
  //   } catch (error) {
  //     return mapError(error, "limit reduzieren, Auth prüfen oder später erneut versuchen");
  //   }
  // });

  // return server;
  return { config, api, status: "MISSING_VERIFICATION: instantiate MCP server after SDK docs are checked" };
}
```

## 2. Python Project Structure Template

Copy from `assets/python-project-structure.txt`.

Recommended modules:

| File | Purpose |
|---|---|
| `src/config.py` | environment configuration and validation |
| `src/api_client.py` | async API client with auth, timeout and retry |
| `src/errors.py` | exception to MCP error mapping |
| `src/pagination.py` | bounded pagination helpers |
| `src/security.py` | auth, rate limit, approval boundaries |
| `src/server.py` | MCP server initialization after SDK verification |
| `src/tools/*.py` | grouped tool functions |
| `tests/test_*.py` | pytest suite |

### Python `pyproject.toml` template

```toml
[project]
name = "mcp-target-service"
version = "0.1.0"
requires-python = ">=3.11"
dependencies = [
  "mcp==MISSING_VERIFICATION",
  "pydantic==MISSING_VERIFICATION",
  "httpx==MISSING_VERIFICATION"
]

[project.optional-dependencies]
dev = [
  "pytest==MISSING_VERIFICATION",
  "pytest-asyncio==MISSING_VERIFICATION",
  "ruff==MISSING_VERIFICATION",
  "mypy==MISSING_VERIFICATION"
]

[tool.ruff]
line-length = 100

[tool.mypy]
strict = true
```

### Python server skeleton

```py
# MISSING_VERIFICATION: replace imports with current official Python SDK or FastMCP imports.
# from mcp.server.fastmcp import FastMCP
# from pydantic import BaseModel, Field

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Config:
    server_name: str
    api_base_url: str
    auth_token_env: str


def load_config() -> Config:
    return Config(
        server_name="mcp-target-service",
        api_base_url="MISSING_TARGET_API_BASE_URL",
        auth_token_env="TARGET_API_TOKEN",
    )


def map_error(exc: Exception, next_step: str) -> dict[str, Any]:
    return {
        "isError": True,
        "content": [{"type": "text", "text": f"Fehler: {exc}. Nächster Schritt: {next_step}"}],
        "structuredContent": {"code": "DOWNSTREAM_ERROR", "retryable": False},
    }


def create_server() -> object:
    config = load_config()
    # mcp = FastMCP(config.server_name)
    # @mcp.tool(...)
    # async def service_list_items(limit: int = 20, cursor: str | None = None) -> dict[str, Any]:
    #     ...
    return {"status": "MISSING_VERIFICATION: instantiate MCP server after SDK docs are checked", "config": config}
```

## 3. API Client Rules

Every API client must implement:

- base URL allowlist;
- auth header injection without logging tokens;
- timeout per request;
- bounded retry policy for retryable statuses;
- rate-limit handling with `retry_after` when available;
- request correlation IDs where safe;
- response size limit and JSON parsing guard;
- explicit mapping for 400, 401, 403, 404, 409, 429 and 5xx.

## 4. Test Matrix

| Test | Type | Required assertions |
|---|---|---|
| config validation | unit | missing env fails safely |
| schema validation | unit | invalid inputs rejected |
| error mapper | unit | actionable messages, no secrets |
| pagination | unit | max limit enforced, cursor propagated |
| tool list | smoke | MCP Inspector or SDK client can list tools |
| read tool call | smoke | at least one read-only tool works |
| write guard | integration | write/destructive tools require ask/approval |
| auth failure | integration | 401/403 returned without token leak |
| rate limit | integration | 429 maps to retryable error |
| evaluation | agentic | exactly 10 stable read-only QA tasks |
