# Missing Dependencies and Verification Register

Use this file whenever the builder cannot verify current external details from user-provided or official documentation.

## Always verify before final code claims

| Dependency | Status | Required verification |
|---|---|---|
| TypeScript MCP SDK package name | MISSING_VERIFICATION | official SDK README or installed package |
| TypeScript MCP SDK version | MISSING_VERIFICATION | package registry, lockfile or official docs |
| TypeScript import paths | MISSING_VERIFICATION | official docs or local TypeScript compile |
| TypeScript transport class names | MISSING_VERIFICATION | official docs or local compile |
| TypeScript tool registration API | MISSING_VERIFICATION | official docs or SDK types |
| TypeScript structured output fields | MISSING_VERIFICATION | official docs or SDK types |
| Python MCP SDK or FastMCP package name | MISSING_VERIFICATION | official SDK README or installed package |
| Python SDK/FastMCP version | MISSING_VERIFICATION | package registry, lockfile or official docs |
| Python import paths | MISSING_VERIFICATION | official docs or local import test |
| Python transport configuration | MISSING_VERIFICATION | official docs or running smoke test |
| MCP specification version | MISSING_VERIFICATION | official modelcontextprotocol.io docs |
| Streamable HTTP exact semantics | MISSING_VERIFICATION | official MCP transport spec |
| SSE support requirements | MISSING_VERIFICATION | target client compatibility docs |
| MCP Inspector commands | MISSING_VERIFICATION | installed inspector help or official docs |
| Secure MCP Tunnel command syntax | MISSING_VERIFICATION | official tunnel docs and installed client help |
| Target API auth flow | MISSING_TARGET_API_DOCS | target API official docs |
| Target API rate limits | MISSING_TARGET_API_DOCS | target API official docs |
| Target API pagination | MISSING_TARGET_API_DOCS | target API official docs |
| Deployment platform constraints | MISSING_DEPLOYMENT_TARGET | platform docs or operator input |
| Production secret manager | MISSING_SECRET_POLICY | operator input |
| Evaluation stable dataset | MISSING_EVALUATION_DATASET | sandbox or historical data |

## Required source policy

Allowed sources:

1. user-provided MCP-builder material;
2. attached skill-design and prompt-engineering documents;
3. user-provided target API documentation;
4. official MCP and SDK documentation only when web access or local documentation is allowed.

Forbidden behavior:

- inventing current package versions;
- inventing import paths;
- inventing endpoint schemas;
- implying a build or Inspector run succeeded when not executed;
- using examples with real-looking secrets;
- converting `MISSING_VERIFICATION` into certainty without evidence.
