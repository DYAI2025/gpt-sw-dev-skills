# Repo Extension Risk Register

## Zweck

Dieses Register verhindert, dass Muster aus Nutzer-Repositories ungeprueft als sichere MCP-Builder-Regeln oder produktive Codepfade uebernommen werden.

## Risikomatrix

| Risiko | Betroffene Repos | Schwere | Wahrscheinlichkeit | Gate | Sichere Behandlung |
|---|---|---:|---:|---|---|
| Unverifizierte SDK-Versionen und Imports | alle MCP-Repos | hoch | hoch | SDK Verification Gate | `MISSING_VERIFICATION` bis offizielle Docs oder lokaler Build vorliegen |
| Fehlende Lizenzdatei im ZIP | `cocos-mcp-server-main`, `mcp-server-guide-main` | hoch | sicher | License Gate | keine Code-/Textuebernahme; nur Pattern-Beschreibung |
| Arbitrary Code Generation | `MCP-Server-Creator-main` | hoch | mittel | Generator Safety Gate | deklarative IR, keine freien Code-Strings als Default |
| Unsichere Dateipfade beim Export | `MCP-Server-Creator-main` | hoch | mittel | Sandbox Gate | Output nur in erlaubtem Verzeichnis, Pfadnormalisierung |
| Token Passthrough als falscher Default | `fastapi_mcp-main` Beispiele/Auth-Muster moeglich | hoch | mittel | Auth Boundary Gate | Token Exchange/scoped Credentials bevorzugen; Forwarding nur Allowlist |
| Legacy SSE als Default | mehrere Repos enthalten SSE | mittel | hoch | Transport Gate | SSE nur Legacy, Streamable HTTP fuer Remote Default nach Verifikation |
| Telemetrie/Observability nicht opt-in | `mcp-use-main`, `everything-claude-code-main` | mittel | mittel | Privacy Gate | Telemetrie deaktivieren oder opt-in dokumentieren |
| Custom-Protokoll statt MCP-SDK-Naehe | `cocos-mcp-server-main` | hoch | hoch | Protocol Gate | nicht als Server-Vorlage verwenden |
| Fehlende Submodule | `minds-main` | mittel | sicher | Completeness Gate | Confidence maximal 2, nur Deployment-Topologie |
| Grosse Toolsets ueberlasten Kontext | `cocos`, `everything`, API-Konverter | hoch | hoch | Tool Budget Gate | Kategorien, Enablement, compact/list vs detail/get |
| CORS/Auth-Schwachstellen | custom HTTP-Server und Guides | hoch | mittel | Remote Security Gate | kein Wildcard-CORS/Authless Remote in Production |
| Ungepruefte Eval-Antworten | alle generierten Server | mittel | hoch | Evaluation Verification Gate | `MISSING_EVALUATION_VERIFICATION` bis read-only geloest |

## Blocking Rules

Ein Pattern darf nicht in den MCP Builder als verbindliche Regel aufgenommen werden, wenn eines zutrifft:

- Lizenz unklar und Inhalt wuerde direkt kopiert.
- SDK/API-Version nicht verifiziert und als aktuell behauptet.
- Pattern setzt unauthentifizierten Remote-Zugriff voraus.
- Pattern erlaubt beliebige Dateipfade oder beliebige URL-Fetches.
- Pattern erzeugt Tools ohne Annotationen und Permission.
- Pattern fuehrt Write/Destructive Operationen ohne Human Approval aus.
- Pattern benoetigt fehlende Submodule oder nicht gelieferte Dateien.

## Risk-specific Handling

### License Gate

- MIT/Apache-Lizenzdateien im Snapshot erlauben Pattern- und ggf. Codeuebernahme nach Projektpolicy.
- Fehlende Lizenz blockiert direkte Uebernahme.
- README-Badges oder pyproject-Kommentare ersetzen keine Lizenzpruefung.

### Generator Safety Gate

- Der Creator darf Implementierungscode generieren, aber nicht ungeprueft aus Nutzerstrings ausfuehren.
- Code-Templates muessen aus verifizierten Quellen oder eigenen Templates stammen.
- Nutzerimplementierungen als Text werden als `untrusted_user_code` markiert.

### Transport Gate

- `stdio` fuer lokal.
- `streamable_http` fuer remote, nach aktueller Spec-Verifikation.
- SSE nur Legacy-Kompatibilitaet.
- WebSocket nur, wenn Zielclient dies explizit fordert und verifiziert ist.

### Tool Budget Gate

- 0-25 Tools: normal.
- 26-75 Tools: Kategorie-Review.
- >75 Tools: Kategorie-Enablement oder Workflow-Tool-Design Pflicht.
- Jedes Tool muss bounded output liefern.

### Privacy and Telemetry Gate

- Observability ja, Telemetrie nur opt-in.
- Logs muessen Tokens, Headers, Secrets und sensible Payloads redaktieren.
- Evaluation Reports duerfen keine Secrets enthalten.

## Residual Risks

- Ohne Internet/Upstream-Pruefung bleiben Versions- und Spec-Details unbestaetigt.
- Ohne Dependency-Installation bleibt Build-/Runtime-Kompatibilitaet offen.
- Ohne Ziel-API-Dokumente kann nur eine generische Pipeline, kein finaler API-spezifischer Server erzeugt werden.
