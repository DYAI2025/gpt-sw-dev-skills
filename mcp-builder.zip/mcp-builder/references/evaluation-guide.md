# Evaluation Guide

## Purpose

Evaluate whether an LLM can use the generated MCP server to answer realistic, difficult questions using only the server's tools.

Quality is measured by agent task success, not by the number of implemented endpoints.

## Hard requirements

Create exactly 10 QA pairs.

Each question must be:

- read-only;
- independent;
- non-destructive;
- idempotent;
- realistic;
- complex enough to require multiple tool calls or deep exploration;
- answerable by a single verifiable value;
- stable over time.

Each answer must be:

- a single string;
- directly comparable;
- not a list unless the question mandates one exact stable string;
- preferably human-readable;
- verified by the builder using read-only tools, or marked `MISSING_EVALUATION_VERIFICATION`.

## Process

1. Inspect target API documentation.
2. Inspect MCP tool names, schemas and descriptions without reading implementation internals.
3. Explore stable content using only read-only tools with small `limit` values.
4. Draft 10 questions using fixed historical windows or stable records.
5. Solve every question yourself using the MCP server read-only tools.
6. Remove any question that requires write/destructive operations.
7. Replace uncertain answers with verified answers.
8. Save as `evaluation.xml`.

## XML format

```xml
<evaluation>
  <qa_pair>
    <question>Find the project completed in 2024 Q2 that had the longest cycle time. What was the project name?</question>
    <answer>Billing Migration</answer>
  </qa_pair>
</evaluation>
```

## Good patterns

- Superlative over fixed historical data: highest, earliest, longest, first, last within a closed window.
- Multi-hop lookup: find entity by indirect clue, inspect details, derive single answer.
- Aggregation over stable closed records.
- Ambiguous wording with one verifiable answer after exploration.

## Bad patterns

- Current counts, open issue totals, live reaction counts or mutable values.
- Exact keyword search for a title included in the question.
- Questions requiring writes, deletes, updates or admin changes.
- Answers that are lists, paragraphs or complex objects.
- Questions with unverified expected answers.

## Running evaluations

If using a provided evaluation harness, choose transport carefully:

```bash
# stdio: harness starts server process
python scripts/evaluation.py -t stdio -c node -a dist/index.js evaluation.xml

# http: server must already be running
python scripts/evaluation.py -t http -u https://mcp.example.invalid/mcp -H "Authorization: Bearer token" evaluation.xml
```

If the exact harness, flags or model are not present in the target project, mark as `MISSING_VERIFICATION` and adapt to the local evaluation runner.
