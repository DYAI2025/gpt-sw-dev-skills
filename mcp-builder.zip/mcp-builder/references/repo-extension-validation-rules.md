# Repo Extension Validation Rules

## Zweck

Diese Regeln pruefen, ob repo-basierte Erweiterungen des MCP Builders sicher, evidenzbasiert und integrationsfaehig sind.

## Validation Gates

### 1. Source Inventory Gate

Bestehen nur wenn:

- jedes Repo einen Typ (`user_provided`, `primary`, `secondary`, `derived`, `uncertain`) hat;
- jedes Repo einen Zweck im Skill hat;
- jedes Repo Grenzen und Confidence enthaelt;
- fehlende Lizenzen und Submodule markiert sind.

Fail wenn:

- ein Repo als primaere SDK-Quelle behandelt wird, obwohl es nur ein Nutzer-Snapshot ist;
- eine fehlende Lizenz ignoriert wird;
- dynamische Versionsclaims ohne Verifikation gemacht werden.

### 2. Pattern Extraction Gate

Bestehen nur wenn:

- jedes uebernommene Pattern einem konkreten Modul zugeordnet ist;
- das Pattern eine klare Grenze hat: `copy`, `adapt`, `reference_only`, `blocked`;
- Security-, Lizenz- und Runtime-Risiken geprueft sind.

Fail wenn:

- ein Monolith-Repo direkt absorbiert wird;
- grosse Toolsets ohne Tool-Budget-Regel uebernommen werden;
- custom HTTP/MCP-Protokoll als Standard gesetzt wird.

### 3. MCP IR Gate

Bestehen nur wenn jede generierte IR enthaelt:

- Servername und Runtime;
- Transport;
- Inbound- und Downstream-Auth;
- Toolliste mit Input-Schema, Annotationen und Permission;
- Tests und Evaluation;
- Activation-Ziel;
- Missing Dependencies.

Fail wenn:

- ein Tool keine Permission hat;
- ein Write/Destructive Tool `allow` als Default hat;
- Remote-HTTP ohne Auth geplant wird.

### 4. Generated Server Verifier Gate

Bestehen nur wenn der Report mindestens dokumentiert:

- Build/Typecheck/Syntaxcheck Status;
- Serverstart Status;
- Tool Listing Status;
- Schema/Annotation Status;
- ein read-only Tool Call Status;
- Evaluation XML Status;
- MISSING-Verifikationen.

Fail wenn:

- der Skill behauptet, Tests seien bestanden, obwohl sie nicht ausgefuehrt wurden;
- Evaluation XML nicht genau 10 QA-Paare hat;
- Evaluations write/destructive Tools erfordern.

### 5. Activation Bundle Gate

Bestehen nur wenn:

- lokale stdio-Konfiguration keine Secrets enthaelt;
- Remote-Konfiguration Auth und Permissions enthaelt;
- Dockerfile keine Secrets einbaut;
- `permissions.json` `deny > ask > allow` dokumentiert;
- `server.json` nur verifizierte Felder oder MISSING-Marker enthaelt.

Fail wenn:

- Production Token in Beispielkonfig steht;
- Remote MCP unauthentifiziert ist;
- destructive Tools nicht `ask` oder `deny` sind.

## Offline Validation Commands

Fuer die Skill-Erweiterungsartefakte:

```bash
python scripts/validate_repo_extension.py .
```

Fuer erzeugte MCP-Projekte:

```bash
python scripts/validate_mcp_builder_outputs.py path/to/generated-mcp-project
```

## Required Outputs for Repo-backed MCP Creator Work

Wenn der Nutzer Repos als Erweiterung einbauen will, liefere:

1. Source Map.
2. Nutzen-/Aufwand-Matrix.
3. Pattern Library.
4. Risk Register.
5. Roadmap.
6. Maschinenlesbare Modul-Spezifikation.
7. Validierungsstatus.
8. MISSING/SOURCE_NEEDED-Liste.

## Anti-hallucination Checks

- Repo-Fakten muessen aus statischer Analyse oder Nutzerdateien stammen.
- Runtime-Erfolge duerfen nur behauptet werden, wenn Build/Test/Inspector wirklich ausgefuehrt wurde.
- Aktuelle MCP-/SDK-Details muessen official-doc-verifiziert sein oder `MISSING_VERIFICATION` bleiben.
- Live-Zahlen, Stars, PyPI-/npm-Versionen und Marktstatus nicht aus Repo-Snapshots ableiten.
