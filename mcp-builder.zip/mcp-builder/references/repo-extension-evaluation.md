# Repo Extension Evaluation for MCP Builder

## Zweck

Diese Datei bewertet die vom Nutzer bereitgestellten Repositories als Erweiterungsquellen fuer den `mcp-builder` Skill. Die Bewertung priorisiert nicht Popularitaet, sondern konkreten Nutzen fuer einen MCP Creator: API-Analyse, MCP-Spezifikation, Codegenerierung, Sicherheit, Validierung, Evaluation und Aktivierung.

## Bewertungsmodell

Bewerte jedes Repo mit diesen Dimensionen:

| Dimension | Bedeutung | Skala |
|---|---|---|
| Integrationsaufwand | Aufwand fuer sichere Uebernahme; niedriger ist besser | 1 niedrig bis 5 hoch |
| Direkter Nutzen | Sofort spuerbare Verbesserung des MCP Creators | 1 bis 10 |
| Langfristiger Nutzen | strategischer Wert fuer Generator, Tests, Governance, Aktivierung | 1 bis 10 |
| Multiplikator | Hebel auf viele kuenftige MCP-Server statt nur Einzelfall | 1 bis 10 |
| Vollstaendigkeit | Repo-Reife: Docs, Tests, Lizenz, CI, klare Struktur | 1 bis 10 |
| Kompatibilitaet | Passung zu `mcp-builder` Architektur, Security und Anti-Halluzination | 1 bis 10 |
| Risikoabschlag | Lizenz-, Security-, Scope-, Telemetrie-, Runtime- oder Kopplungsrisiko | 0 bis 5 |

Empfohlene ROI-Formel fuer interne Priorisierung:

```text
benefit = 0.25*direkter_nutzen + 0.20*langfristiger_nutzen + 0.20*multiplikator + 0.15*vollstaendigkeit + 0.20*kompatibilitaet
roi = benefit - 0.55*integrationsaufwand - 0.35*risikoabschlag
```

## Gesamtmatrix

| Rang | Repo | Aufwand | Direkt | Langfristig | Multiplikator | Vollstaendig | Kompatibel | Risiko | ROI | Entscheidung |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| 1 | `fastapi_mcp-main` | 2.5 | 9.0 | 8.0 | 9.0 | 8.5 | 9.0 | 1.5 | 7.0 | Prioritaet 1: API/OpenAPI→MCP-Konverter |
| 2 | `MCP-Server-Creator-main` | 2.0 | 8.0 | 7.0 | 8.0 | 4.5 | 9.0 | 2.5 | 6.0 | Prioritaet 2: sicheren Generator-IR ableiten |
| 3 | `mcp-use-main` | 3.5 | 6.5 | 8.5 | 8.5 | 8.0 | 7.5 | 2.0 | 5.6 | Prioritaet 3: Verifier-/Eval-Harness Patterns |
| 4 | `playwright-mcp-main` | 2.5 | 6.5 | 7.5 | 8.0 | 7.5 | 7.0 | 1.5 | 5.6 | Test-/Packaging-Muster extrahieren |
| 5 | `mcp-server-guide-main` | 2.0 | 5.5 | 7.5 | 7.5 | 6.5 | 6.5 | 3.0 | 5.0 | Activation Bundle Patterns, keine Codeuebernahme |
| 6 | `everything-claude-code-main` | 5.0 | 4.5 | 9.0 | 9.5 | 8.5 | 5.5 | 3.0 | 4.6 | Selektive Governance-/Context-Budget-Extraktion |
| 7 | `cocos-mcp-server-main` | 3.5 | 4.5 | 5.5 | 6.0 | 6.0 | 4.0 | 4.0 | 2.8 | Nur Tool-Manager-Pattern und Anti-Patterns |
| 8 | `minds-main` | 4.0 | 2.5 | 5.0 | 5.0 | 2.0 | 2.5 | 3.0 | 1.5 | Zurueckstellen bis Submodule vorliegen |

## Entscheidungslogik je Repo

### 1. `fastapi_mcp-main`

**Entscheidung:** priorisiert integrieren.

**Warum:** Das Repo liefert den direktesten Hebel fuer einen MCP Creator: aus FastAPI/OpenAPI-Strukturen MCP-Tools ableiten. Es enthaelt Testabdeckung, MIT-Lizenz, eine klare Python-Struktur, OpenAPI-Konvertierung, Auth-/Header-Handling und Transportmodule. Die statische Analyse zeigt eine hohe Passung zur bestehenden `mcp-builder` Forderung nach Contract-first Tool-Spezifikation.

**Einzubauen als:**

- `openapi_to_mcp_spec` Modul.
- Operation-/Tag-Filter als Standardoption.
- Header-Forwarding nur ueber Allowlist.
- Schema-Mapping in die deklarative MCP Builder IR.
- Testmuster fuer einfache und komplexe API-Apps.

**Nicht direkt uebernehmen:**

- FastAPI als einzige Quelle erzwingen.
- SSE als Default.
- konkrete SDK-Versionen ohne aktuelle Verifikation.
- Token-Passthrough als Default.

### 2. `MCP-Server-Creator-main`

**Entscheidung:** Generator-Prototyp haerten und als IR-Vorbild nutzen.

**Warum:** Das Repo modelliert bereits einen MCP-Server, der andere MCP-Server erzeugt. Das passt semantisch exakt zum MCP Creator. Der Nutzen liegt im stufenweisen Server/Tool/Resource-Flow, nicht in ungepruefter Codeuebernahme.

**Einzubauen als:**

- `mcp_server_ir` mit Server, Tools, Resources, Prompts, Auth, Transport, Tests, Evaluation, Activation.
- Dialog-/Workflow-Muster: create server → add tool → add resource → generate → save.
- Speicher- und Exportmodell nur sandboxed.

**Blockierende Anpassungen:**

- Keine freien Implementation-Strings als Default.
- Pfad-Sandbox und Dateiname-Normalisierung.
- Tool-Annotations und Permission-Matrix als Pflichtfelder.
- Human Approval fuer Write/Destructive Tools.

### 3. `mcp-use-main`

**Entscheidung:** als Verifier-/Client-Schicht referenzieren.

**Warum:** Der MCP Creator muss generierte Server pruefen. `mcp-use` liefert Multi-Transport-, Client-, Session-, Server-Manager- und Tool-Restriction-Patterns. Diese sind als Validierungsschicht wertvoller als als Generator-Code.

**Einzubauen als:**

- `generated_server_verifier` Spezifikation.
- Multi-Transport Smoke Test: stdio, streamable_http, legacy_sse optional.
- Tool-Restrictions fuer Evaluations: nur read-only Tools erlauben.
- Session-/Server-Manager Pattern fuer mehrere generierte Server.

**Nicht direkt uebernehmen:**

- Telemetrie ohne Opt-in.
- LangChain als Pflichtabhaengigkeit.
- WebSocket/SSE als Default fuer neue Remote-Server.

### 4. `playwright-mcp-main`

**Entscheidung:** Test- und Packaging-Muster extrahieren.

**Warum:** Das Repo zeigt, wie ein produktisierter MCP-Server mit CLI, Docker, Server Manifest und stdio-Clienttests strukturiert sein kann. Der eigentliche Browser-Use-Case ist nicht allgemein uebertragbar, die Testform schon.

**Einzubauen als:**

- Golden Tool List Regression.
- `connect`, `ping`, `list_tools`, `call_tool` Smoke Test.
- Docker-/CLI-/server.json Packaging Pattern.
- Tool-Budget-Hinweis: CLI/Skills koennen token-effizienter sein als grosse MCP-Schemata.

### 5. `mcp-server-guide-main`

**Entscheidung:** Activation Bundle Pattern nutzen, direkte Uebernahme blockieren.

**Warum:** Das Repo enthaelt `.mcp.json`, `server.json` und Plugin-Manifest-Muster. Das verbessert die Aktivierbarkeit generierter MCP-Server. Wegen fehlender Lizenzdatei im ZIP und starker Figma-Domainbindung ist es keine Codequelle.

**Einzubauen als:**

- Activation Bundle Generator: `.mcp.json`, `server.json`, host-spezifische Metadata, Tooltitel, Icons optional.
- Remote Manifest mit `streamable-http` als Formatbeispiel nach Verifikation.

### 6. `everything-claude-code-main`

**Entscheidung:** nur selektive Pattern-Mine.

**Warum:** Das Repo ist zu gross fuer direkte Integration, aber sehr wertvoll fuer Langzeit-Governance: Command Registry, Security Checks, Harness Audits, MCP-Inventory, Plugin-Systeme, Context-Budget-Disziplin.

**Einzubauen als:**

- `mcp_inventory` Schema fuer viele Server und Tools.
- Context-Budget-Regeln fuer Toolauswahl.
- Security-/Release-Gates.
- Skill-/Command-Registry-Validierung.

**Nicht einbauen:** Monolith, komplette Commands, unkuratiertes Plugin-System, grosse Docs.

### 7. `cocos-mcp-server-main`

**Entscheidung:** Design- und Anti-Pattern-Quelle.

**Warum:** Das Repo zeigt ein grosses Domain-Toolset mit Kategorien und Tool-Enablement. Gleichzeitig bestehen Lizenz-, Security- und Protokollrisiken.

**Einzubauen als:**

- Tool-Kategorien und Enable/Disable-Listen.
- Tool-Kompression: grosse API in wenige Kategorien und kontrollierte Toolgruppen.
- Anti-Pattern-Regeln fuer Custom-Protokoll, CORS, fehlende Auth, destruktive Tools.

### 8. `minds-main`

**Entscheidung:** zurueckstellen.

**Warum:** Das ZIP enthaelt im Wesentlichen Umbrella-/Deployment-Dateien und verweist per `.gitmodules` auf fehlende Submodule. Ohne Submodule ist der MCP-Creator-Nutzen gering.

**Einzubauen als:**

- schwaches Deployment-/Compose-/Proxy-Topologiebeispiel.
- MISSING-Gate: Repos mit fehlenden Submodulen duerfen nicht als vollstaendig bewertet werden.

## Integrationsempfehlung

Wenn nur ein Repo genutzt wird: `fastapi_mcp-main`.

Wenn zwei Repos genutzt werden: `fastapi_mcp-main` + `MCP-Server-Creator-main`.

Wenn drei Repos genutzt werden: zusaetzlich `mcp-use-main`.

Wenn der MCP Creator als installierbares Produkt paketiert werden soll: `playwright-mcp-main` und `mcp-server-guide-main` als Packaging-Referenzen hinzunehmen.

Wenn der MCP Creator langfristig zum Agent-Harness wachsen soll: selektive Patterns aus `everything-claude-code-main` extrahieren, aber nie als Monolith absorbieren.
