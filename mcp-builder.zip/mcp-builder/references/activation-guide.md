# Activation Guide

## 1. Skill installation in a skill-enabled GPT or agent

Install the `mcp-builder/` folder as one skill package.

Required files:

```text
mcp-builder/
  SKILL.md
  LICENSE.txt
  agents/openai.yaml
  references/
  assets/
  scripts/
```

The entrypoint is `SKILL.md`. Reference files are loaded only when the active MCP-building task needs them.

## 2. Inputs the agent must request for each MCP server

At minimum collect:

```yaml
target_service: MISSING_TARGET_SERVICE
target_api_docs: MISSING_TARGET_API_DOCS
auth_model: MISSING_AUTH_MODEL
runtime: typescript | python
transport: stdio | streamable_http | secure_tunnel | legacy_sse
deployment_target: local | docker | vm | kubernetes | serverless | other
tool_scope: read_only | write | destructive | admin
secret_policy: env | secret_manager | vault | platform_connector
evaluation_dataset: sandbox | stable_historical_data | missing
```

If the user cannot provide details, continue with safe templates and mark missing fields.

## 3. Local activation over stdio

Use local stdio for local desktop, CLI or development contexts.

Example configuration shape:

```json
{
  "mcpServers": {
    "target-service": {
      "command": "node",
      "args": ["/absolute/path/to/dist/index.js"],
      "env": {
        "TARGET_API_BASE_URL": "https://api.example.invalid",
        "TARGET_API_TOKEN": "set-in-host-secret-store"
      }
    }
  }
}
```

For Python:

```json
{
  "mcpServers": {
    "target-service": {
      "command": "python",
      "args": ["/absolute/path/to/src/server.py"],
      "env": {
        "TARGET_API_BASE_URL": "https://api.example.invalid",
        "TARGET_API_TOKEN": "set-in-host-secret-store"
      }
    }
  }
}
```

Never paste real production secrets into config examples.

## 4. Remote activation over Streamable HTTP

Use remote Streamable HTTP when the server is hosted for one or more clients.

Required remote properties:

| Item | Rule |
|---|---|
| Endpoint | HTTPS URL, normally `/mcp` or documented equivalent |
| Auth | Bearer/JWT/OAuth/mTLS or connector-managed auth |
| Permissions | deny/ask/allow documented per tool |
| Approval | destructive/high-impact tools require ask/human approval |
| Timeouts | long enough for expected tool latency, bounded |
| Rate limits | per token/user/IP/workspace where possible |
| Logs | no secrets, no full tokens, redacted payloads |
| Health | `/healthz` and readiness if supported by runtime |

Example activation shape:

```json
{
  "mcpServers": {
    "target-service": {
      "url": "https://mcp.example.invalid/mcp",
      "headers": {
        "Authorization": "Bearer ${MCP_SERVER_AUTH_TOKEN}"
      },
      "permissions": {
        "deny": ["mcp__target-service__*_delete_*"],
        "ask": ["mcp__target-service__*_create_*", "mcp__target-service__*_update_*"],
        "allow": ["mcp__target-service__*_list_*", "mcp__target-service__*_get_*", "mcp__target-service__*_search_*"]
      }
    }
  }
}
```

## 5. Secure MCP Tunnel activation

Use a secure tunnel when the MCP server is private, on-premises, behind a firewall or should not expose public inbound ports.

Operational model:

1. Create or select a tunnel endpoint in the supported platform.
2. Run the tunnel client inside the network that can reach the private MCP server.
3. Configure the tunnel identity, runtime key and private MCP server address.
4. The supported product calls the hosted tunnel endpoint; the tunnel client forwards requests to the private MCP server.

Required checks:

- tunnel is associated with the correct organization or workspace;
- operator has read/use permission;
- runtime API key is stored in secret manager or env var;
- tunnel client can reach MCP server over local stdio or private HTTP;
- health/readiness checks pass before activation testing.

Mark exact tunnel commands as `MISSING_VERIFICATION` unless current official tunnel documentation is present.

## 6. Dockerfile template

Use `assets/dockerfile-template.Dockerfile` and adapt runtime commands after SDK verification.

Required container hardening:

- multi-stage build where practical;
- non-root runtime user;
- production dependencies only in runtime image;
- no secrets baked into image;
- `NODE_ENV=production` or Python equivalent;
- healthcheck where supported;
- explicit port only for remote transport.

## 7. Reverse proxy notes

For Streamable HTTP or long-running MCP requests:

- disable response buffering when streaming or long polling requires immediate forwarding;
- set bounded but sufficient read/send timeouts;
- pass `Host`, `X-Forwarded-For`, `X-Forwarded-Proto`;
- terminate TLS at proxy or upstream according to platform policy;
- do not open unauthenticated public routes;
- apply request body limits.

Use `assets/reverse-proxy-nginx-template.conf` as a starting point.

## 8. Build, test and inspect commands

### TypeScript

```bash
npm install
npm run typecheck
npm run lint
npm test
npm run build
npx @modelcontextprotocol/inspector
```

### Python

```bash
python -m py_compile src/server.py
python -m pytest
python -m mcp dev src/server.py
```

Commands involving MCP SDK CLIs are `MISSING_VERIFICATION` unless verified against the installed/current SDK.

## 9. Troubleshooting table

| Symptom | Likely cause | Check | Fix |
|---|---|---|---|
| tool list empty | server did not register tools | Inspector tool list | verify registry and SDK registration |
| connection refused | wrong command, port or URL | process logs, healthcheck | correct activation config |
| 401 | missing/expired auth | header/env presence | refresh token or configure auth |
| 403 | insufficient scope | auth server/scopes | request scoped permission |
| 429 | rate limit | response headers | reduce limit, respect retry-after |
| large context failures | unbounded tool output | response size | add pagination/filters |
| destructive call auto-runs | bad permission/annotation | permission config | set `destructiveHint=true`, `ask` |
| tunnel unavailable | client not running or workspace mismatch | tunnel health and association | start client, fix workspace permissions |
| proxy timeout | buffering or short timeout | reverse proxy logs | disable buffering, increase bounded timeout |
| eval answers unstable | dynamic question | evaluation review | use historical/fixed-window questions |
