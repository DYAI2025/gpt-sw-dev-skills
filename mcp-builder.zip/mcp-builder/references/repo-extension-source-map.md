# Repo Extension Source Map

## Zweck

Diese Referenz inventarisiert die vom Nutzer bereitgestellten Repository-ZIP-Snapshots als Quellen fuer eine Erweiterung des `mcp-builder` Skills. Sie dient nicht als Lizenz- oder Runtime-Bestaetigung. Sie trennt beobachtete Repo-Fakten von Ableitungen und markiert ungesicherte externe Versionen als `MISSING_VERIFICATION`.

## Quellenpolitik

Alle acht Repositories sind `user_provided` Snapshot-Quellen. Sie koennen starke Hinweise auf wiederverwendbare Patterns liefern, sind aber ohne Web-, Upstream- und Runtime-Pruefung keine aktuellen Primaerquellen fuer SDK-Versionen, Transportklassen oder Plattformfeatures.

| Confidence | Bedeutung fuer diese Analyse | Auslieferungsregel |
|---:|---|---|
| 5 | Direkt im Repo-Snapshot beobachtet und durch statische Pruefung plausibilisiert | Als Repo-Fakt verwendbar |
| 4 | Direkt beobachtet, aber ohne Runtime-Ausfuehrung | Als Repo-Fakt mit Hinweis verwendbar |
| 3 | Plausible Ableitung aus mehreren Dateien | Als Annahme kennzeichnen |
| 2 | Indirekt, unvollstaendig oder lizenz-/securitykritisch | Nicht als Regel uebernehmen |
| 1 | Spekulativ oder nicht belegt | Blockieren oder `SOURCE_NEEDED` |

## Inventaruebersicht

Statische Analyse: ZIP entpackt, Dateibaum, Manifeste, README, Lizenz, Tests, Workflows und zentrale Code-Dateien inspiziert. Python-Repos wurden mit `py_compile` syntaxgeprueft; keine Dependencies installiert, keine Testsuite ausgefuehrt, keine MCP-Server gestartet.

| Repo | Typ | Dateien | Code-Dateien | Tests | CI/Workflows | Lizenzdatei | Syntax-/Runtime-Status | Primaerer Nutzen fuer MCP Builder | Confidence |
|---|---|---:|---:|---:|---:|---|---|---|---:|
| `fastapi_mcp-main` | user_provided Python MCP/API-Konverter | 84 | 44 | 17 | 4 | MIT vorhanden | Python-Syntax OK; Runtime nicht ausgefuehrt | FastAPI/OpenAPI→MCP Tool-Spezifikation und Server-Mounting | 5 |
| `MCP-Server-Creator-main` | user_provided Python Meta-MCP-Generator | 14 | 4 | 1 | 0 | MIT vorhanden | Python-Syntax OK; Runtime nicht ausgefuehrt | Deklarativer MCP-Generator-Flow und Server/Tool/Resource-Datenmodell | 4 |
| `mcp-use-main` | user_provided Python MCP Client/Agent Framework | 159 | 84 | 27 | 7 | MIT vorhanden | Python-Syntax OK; Runtime nicht ausgefuehrt | Multi-Transport-Verifier, Client-/Session-Management, Tool Restrictions | 4 |
| `playwright-mcp-main` | user_provided TypeScript/Node produktisierter MCP-Server | 33 | 14 | 10 | 2 | Apache-2.0 vorhanden | Manifeste inspiziert; Build nicht ausgefuehrt | Golden Tool Listing, stdio Client Tests, Docker/CLI/Server Manifest | 4 |
| `mcp-server-guide-main` | user_provided MCP Activation/Plugin Guide | 104 | 10 | 0 | 0 | keine Lizenzdatei im ZIP | statisch inspiziert | Host-Konfiguration, `server.json`, Plugin-/Skill-Bundling | 3 |
| `everything-claude-code-main` | user_provided grosser Agent-Harness | 3244 | 502 | 256 | 13 | MIT vorhanden | statisch inspiziert; nicht gebaut | Governance-, Command-, Skill-, Security- und MCP-Inventory-Patterns | 3 |
| `cocos-mcp-server-main` | user_provided Domain-MCP fuer Cocos Creator | 76 | 57 | 9 | 0 | keine Lizenzdatei im ZIP | statisch inspiziert; nicht gebaut | Tool-Manager, Kategorien, grosse Domain-Toolsets, Anti-Patterns | 2 |
| `minds-main` | user_provided Umbrella-/Deployment-Repo | 34 | 0 | 0 | 7 | MIT vorhanden | wesentliche Submodule fehlen | Deployment-/Compose-/Proxy-Topologie als schwaches Pattern | 2 |

## Repo-spezifische Quellenkarten

### fastapi_mcp-main

- Typ: `user_provided`, technische Implementierungsquelle.
- Beobachtete Artefakte: `pyproject.toml`, `README.md`, `fastapi_mcp/server.py`, `fastapi_mcp/openapi/convert.py`, Transportmodule, 17 Testdateien.
- Beobachtete Faehigkeiten: FastAPI-App wird in MCP-Tools uebersetzt; Operation-/Tag-Filter; Header-Forwarding-Allowlist; Auth-Konfiguration; HTTP/SSE-Transportmodule; OpenAPI-Konvertierung.
- Skill-Verwendung: Primaerquelle fuer ein `openapi_to_mcp_spec` Modul und fuer Contract-first API→MCP-Pipeline.
- Grenzen: FastAPI-spezifisch; SSE-Kompatibilitaet ist nicht Default fuer neue Remote-Server; konkrete `mcp` Paketversion aus Snapshot nicht als aktuell behaupten.
- Confidence: 5 fuer beobachtete Dateien und Patterns, 2 fuer aktuelle SDK-Kompatibilitaet.

### MCP-Server-Creator-main

- Typ: `user_provided`, Meta-Generator-Prototyp.
- Beobachtete Artefakte: `mcp_server_creator/mcp_server_creator.py`, `pyproject.toml`, `test_mcp_creator.py`, README, Quick Reference.
- Beobachtete Faehigkeiten: `create_server`, `add_tool`, `add_resource`, `generate_server_code`, `save_server`, `list_servers`, `get_server_details`; In-Memory Server-Konfiguration; FastMCP-Abhaengigkeit.
- Skill-Verwendung: Vorlage fuer ein sicheres `mcp_server_ir` Datenmodell und einen stufenweisen Generator-Dialog.
- Grenzen: Tool-/Resource-Implementierungen koennen als freie Code-Strings modelliert sein; `save_server` muss sandboxed werden; keine ausreichende Security-/Permission-Matrix fuer produktive Generatoren.
- Confidence: 4 fuer Generator-Flow, 2 fuer sichere Direktuebernahme.

### mcp-use-main

- Typ: `user_provided`, Client-/Agent-/Session-Framework.
- Beobachtete Artefakte: `mcp_use/client.py`, Connectors fuer stdio/http/sse/websocket/sandbox, Session- und Server-Manager, Observability/Telemetry-Module, 27 Testdateien.
- Beobachtete Faehigkeiten: Multi-Server-Konfiguration, erlaubte Server, Sandbox-Optionen, Connector-Abstraktion, LangChain-Adapter, Tool-Search und Dynamic Server Management.
- Skill-Verwendung: Vorlage fuer `generated_server_verifier`: Server starten, Tools listen, Schemata inspizieren, read-only Tool Call ausfuehren, Eval-Lauf vorbereiten.
- Grenzen: LangChain-Kopplung nicht als Pflicht in MCP Builder aufnehmen; Telemetrie nur opt-in; keine ungeprueften Runtime-Erfolgsaussagen.
- Confidence: 4 fuer Architekturpattern, 3 fuer direkte Integrationskompatibilitaet.

### playwright-mcp-main

- Typ: `user_provided`, produktisierter MCP-Server und Testreferenz.
- Beobachtete Artefakte: `package.json`, `server.json`, `Dockerfile`, `tests/fixtures.ts`, `tests/core.spec.ts`, CLI-Dateien.
- Beobachtete Faehigkeiten: MCP-SDK-Clienttests ueber stdio, Ping/Connect, Tool Calls, Docker- und CLI-Packaging.
- Skill-Verwendung: Vorlage fuer Golden Tool List, stdio Smoke Test, Docker/CLI-Verpackung und Server Manifest.
- Grenzen: browser-/Playwright-spezifisch; nicht als allgemeine MCP-Creator-Abhaengigkeit uebernehmen.
- Confidence: 4 fuer Test-/Packaging-Muster.

### mcp-server-guide-main

- Typ: `user_provided`, Aktivierungs-/Plugin-Guide.
- Beobachtete Artefakte: `.mcp.json`, `server.json`, `.claude-plugin/plugin.json`, `.cursor-plugin/plugin.json`, Figma-spezifische Skill-/Power-Dateien.
- Beobachtete Faehigkeiten: Remote `streamable-http` Server Manifest, Host-Konfiguration, IDE-/Plugin-Metadaten und Tooltitel.
- Skill-Verwendung: Vorlage fuer Activation Bundle Generator: `.mcp.json`, `server.json`, Pluginmanifest, host-spezifische Hinweise.
- Grenzen: keine Lizenzdatei im ZIP; stark Figma-spezifisch; externe Versionen/Server-URLs nicht als aktuell oder allgemein gueltig behaupten.
- Confidence: 3 fuer Packaging-Patterns, 1 fuer Code-/Textuebernahme.

### everything-claude-code-main

- Typ: `user_provided`, grosser Agent-Harness und Skill-/Command-Korpus.
- Beobachtete Artefakte: `.mcp.json`, `.claude-plugin`, `.codex-plugin`, commands, hooks, skills, security scripts, Test-/CI-Struktur, mehrsprachige Docs.
- Beobachtete Faehigkeiten: Command Registry, Harness-Audit, Security-Scans, MCP-Inventory, Plugin/Skill-Bundles, Observability- und Release-Gates.
- Skill-Verwendung: Langfristiges Pattern-Reservoir fuer Governance, Context-Budget, Inventory, Skill-/Command-Validierung und Release-Gates.
- Grenzen: zu gross fuer direkte Aufnahme; hohe Kopplungs- und Kontextkosten; nur selektive Pattern-Extraktion.
- Confidence: 3 fuer Pattern-Nutzen, 1 fuer Direktintegration.

### cocos-mcp-server-main

- Typ: `user_provided`, grosser Domain-spezifischer Editor-MCP.
- Beobachtete Artefakte: `source/mcp-server.ts`, Tool-Kategorien, dist-Builds, README/Feature Guides, package.json.
- Beobachtete Faehigkeiten: Tool-Kategorien, Tool-Enablement, grosse Domain-Toolsets, Editor-spezifische Steuerung.
- Skill-Verwendung: Pattern fuer Tool-Kompression, Kategorien, Enable/Disable-Listen und Anti-Pattern-Analyse grosser Toolsets.
- Grenzen: keine Lizenzdatei im ZIP; eigenes HTTP-/MCP-aehnliches Servermuster; hohe Zahl destruktiver/editorveraendernder Aktionen; Auth/CORS/Protocol-Details nicht als Vorbild uebernehmen.
- Confidence: 2.

### minds-main

- Typ: `user_provided`, Umbrella-/Deployment-Repo mit Submodulen.
- Beobachtete Artefakte: `.gitmodules`, Docker-/Compose-/Nginx-Dateien, README, Security, Workflows.
- Beobachtete Faehigkeiten: Plattformtopologie, Proxy/Health/Compose-Struktur.
- Skill-Verwendung: schwaches Deployment-Pattern und Beispiel fuer fehlende Submodule als MISSING-Gate.
- Grenzen: Kerncode fehlt wegen nicht enthaltenen Submodulen; kein direkter MCP-Creator-Baustein.
- Confidence: 2.

## Offene Verifikation

- `MISSING_VERIFICATION`: aktuelle MCP-Spezifikation, TypeScript-/Python-SDK-APIs, Inspector-Kommandos und Transportklassen.
- `MISSING_LICENSE`: Code-/Textuebernahme aus `cocos-mcp-server-main` und `mcp-server-guide-main`, weil im ZIP keine Lizenzdatei gefunden wurde.
- `MISSING_RUNTIME_EVIDENCE`: Build-/Test-/Inspector-Erfolg fuer alle Repos.
- `MISSING_SUBMODULES`: `minds-main` enthaelt Verweise auf externe Submodule, die im ZIP nicht enthalten sind.
