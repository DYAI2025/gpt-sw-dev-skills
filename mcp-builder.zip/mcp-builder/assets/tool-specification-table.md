# Tool Specification Table

| Tool name | User intent | API mapping | Input schema | Output schema | Pagination/filtering | Annotation | Permission | Error cases | Security notes |
|---|---|---|---|---|---|---|---|---|---|
| service_list_items | List items for exploration | GET /items | limit, cursor, query | items[], next_cursor, has_more | limit<=50, cursor | readOnly=true, destructive=false, idempotent=true, openWorld=true | allow | 401, 403, 429, 5xx | no secrets; bounded output |
| service_get_item | Inspect one item by ID | GET /items/{id} | id | item | none | readOnly=true, destructive=false, idempotent=true, openWorld=true | allow | 404, 403 | validate ID tenant/workspace |
| service_create_item | Create item | POST /items | fields, idempotency_key | item | none | readOnly=false, destructive=false, idempotent=false unless key used, openWorld=true | ask | 400, 401, 403, 409, 429 | human approval; no token passthrough |
| service_update_item | Update item fields | PATCH /items/{id} | id, fields, version | item | none | readOnly=false, destructive=true if overwrites important state, idempotent=false, openWorld=true | ask | 400, 403, 404, 409 | confirmation for high-impact fields |
| service_delete_item | Delete item | DELETE /items/{id} | id, confirmation | result | none | readOnly=false, destructive=true, idempotent=false, openWorld=true | deny by default | 403, 404, 409 | enable only with explicit user requirement |
