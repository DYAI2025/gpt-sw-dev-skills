# SKILL.md repo extension insertion block

## Reference list entries

Add these entries to the `Lade bei Bedarf diese Referenzen:` list in `mcp-builder/SKILL.md`:

```markdown
- `references/repo-extension-source-map.md` für inventarisierte Nutzer-Repo-Snapshots und Confidence-Einstufungen.
- `references/repo-extension-evaluation.md` für Nutzen-/Aufwandsbewertung externer MCP-Repos als Erweiterungsquellen.
- `references/repo-integration-patterns.md` für wiederverwendbare Integrationsmodule aus den analysierten Repos.
- `references/repo-extension-roadmap.md` für priorisierte Umsetzungssprints zur Weiterentwicklung des MCP Creators.
- `references/repo-extension-risk-register.md` für Lizenz-, Security-, Telemetrie-, Transport- und Kopplungsrisiken.
- `references/repo-extension-validation-rules.md` für zusätzliche Gates bei repo-basierter MCP-Creator-Erweiterung.
- `assets/mcp-creator-extension-modules.yaml` für maschinenlesbare Erweiterungsmodule.
- `assets/openapi-to-mcp-ir.schema.json` für die deklarative Zwischenrepräsentation API→MCP.
- `assets/generated-server-verifier-spec.yaml` für Smoke-/Inspector-/Evaluation-Prüfung generierter MCP-Server.
- `scripts/validate_repo_extension.py` für Offline-Prüfungen der Erweiterungsartefakte.
```

## Workflow section

Add this section before `## Security policy`:

```markdown
## Repo-backed extension workflow

Wenn der Nutzer Repositories, ZIPs oder Codebasen als Erweiterungsquelle für diesen MCP Builder bereitstellt:

1. Inventarisiere jedes Repo statisch: Manifeste, Sprache, LOC, Tests, CI, Lizenz, MCP-Bezug, Transport, Auth, Tool-Design und Risiken.
2. Klassifiziere jede Quelle als `user_provided` und trenne beobachtete Repo-Fakten von Ableitungen. Nutze `references/repo-extension-source-map.md` als Struktur.
3. Bewerte Integrationsnutzen mit den Dimensionen aus `references/repo-extension-evaluation.md`: Integrationsaufwand, direkter Nutzen, Langzeitnutzen, Multiplikator, Vollständigkeit, Kompatibilität, Sicherheits-/Lizenzrisiko.
4. Überführe nur robuste Muster in den MCP Creator. Keine unkuratierte Code-Übernahme, keine ungeprüften SDK-Versionen, keine Telemetrie oder unsicheren Auth-Muster.
5. Nutze `references/repo-integration-patterns.md`, um aus Repo-Mustern konkrete Module zu erzeugen: API→MCP-Konverter, sichere IR, Verifier Harness, Activation Bundle, Tool-Budget-Policy und Governance-Gates.
6. Vor der Integration müssen `references/repo-extension-validation-rules.md` und `scripts/validate_repo_extension.py` bestanden sein.
```
