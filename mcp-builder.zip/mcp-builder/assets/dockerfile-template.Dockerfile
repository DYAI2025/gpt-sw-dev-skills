# TypeScript/Node multi-stage template. Verify runtime and package manager for the target project.
FROM node:20-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY tsconfig.json ./
COPY src ./src
RUN npm run build

FROM node:20-alpine AS runtime
WORKDIR /app
ENV NODE_ENV=production
COPY package*.json ./
RUN npm ci --omit=dev
COPY --from=build /app/dist ./dist
USER node
EXPOSE 8000
CMD ["node", "dist/index.js"]

# Python alternative after SDK verification:
# FROM python:3.12-slim AS runtime
# WORKDIR /app
# ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
# COPY pyproject.toml ./
# RUN pip install --no-cache-dir .
# COPY src ./src
# RUN useradd -r -u 10001 appuser
# USER appuser
# CMD ["python", "-m", "src.server"]
