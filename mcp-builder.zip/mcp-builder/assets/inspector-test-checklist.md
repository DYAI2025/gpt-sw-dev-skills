# MCP Inspector Test Checklist

## Before Inspector

- [ ] Dependencies installed.
- [ ] Build/typecheck passes or compile command succeeds.
- [ ] Env vars set through shell, host config or secret manager.
- [ ] Target API uses sandbox or mock environment for tests.
- [ ] No real production secret appears in command history or logs.

## Tool listing

- [ ] Server starts without uncaught exception.
- [ ] Inspector can list tools.
- [ ] Every expected tool appears once.
- [ ] Tool descriptions are concise and distinct.
- [ ] Schemas show constraints and defaults.
- [ ] Tool annotations match intended behavior.

## Read-only call

- [ ] At least one read-only call succeeds.
- [ ] Response is bounded and paginated when applicable.
- [ ] Response includes stable IDs for follow-up.
- [ ] No secret or raw token appears.

## Error path

- [ ] Invalid input returns actionable validation error.
- [ ] Missing auth returns 401-style actionable error.
- [ ] Permission failure returns 403-style actionable error.
- [ ] Rate limit returns retry guidance.

## Write/destructive guard

- [ ] Write tools are not auto-allowed.
- [ ] Destructive tools use `destructiveHint=true`.
- [ ] Client permission config requires ask or deny.

## Post-test

- [ ] Record exact commands run.
- [ ] Record SDK/package versions observed.
- [ ] Store Inspector notes without secrets.
- [ ] Update `missing_dependencies` if anything remains unverified.
