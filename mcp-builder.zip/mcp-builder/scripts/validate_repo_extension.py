#!/usr/bin/env python3
"""Offline validator for repo-backed mcp-builder extension artifacts.

The script validates bundled YAML/JSON/CSV presence and high-level safety rules.
It does not verify external SDK versions, runtime behavior, or licenses beyond files
explicitly represented in the extension docs.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

try:
    import yaml  # type: ignore
except Exception:  # pragma: no cover
    yaml = None

REQUIRED_FILES = [
    "references/repo-extension-source-map.md",
    "references/repo-extension-evaluation.md",
    "references/repo-integration-patterns.md",
    "references/repo-extension-roadmap.md",
    "references/repo-extension-risk-register.md",
    "references/repo-extension-validation-rules.md",
    "references/repo-extension-evaluation-plan.md",
    "assets/repo-extension-scoring-matrix.csv",
    "assets/mcp-creator-extension-modules.yaml",
    "assets/generated-server-verifier-spec.yaml",
    "assets/openapi-to-mcp-ir.schema.json",
    "assets/skill-md-repo-extension-block.md",
]


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def read_yaml(path: Path) -> dict:
    if yaml is None:
        # Lightweight fallback for environments without PyYAML: presence check only.
        text = path.read_text(encoding="utf-8")
        if "modules:" not in text and "required_reports:" not in text:
            fail(f"YAML-like file missing expected keys: {path}")
        return {}
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        fail(f"YAML root must be mapping: {path}")
    return data


def validate_required_files(root: Path) -> None:
    for rel in REQUIRED_FILES:
        path = root / rel
        if not path.exists():
            fail(f"missing required extension file: {rel}")
        if path.stat().st_size == 0:
            fail(f"empty extension file: {rel}")


def validate_scoring_csv(path: Path) -> None:
    rows = list(csv.DictReader(path.open(encoding="utf-8")))
    if len(rows) != 8:
        fail(f"scoring matrix must contain 8 repos, found {len(rows)}")
    for row in rows:
        for key in ["integration_effort", "direct_benefit", "long_term_benefit", "multiplier", "completeness", "compatibility", "risk_penalty", "roi"]:
            try:
                float(row[key])
            except Exception as exc:
                fail(f"invalid numeric value in {path}: {row.get('repo')} {key}: {exc}")


def validate_modules(path: Path) -> None:
    data = read_yaml(path)
    if not data:
        return
    modules = data.get("modules")
    if not isinstance(modules, list) or len(modules) < 5:
        fail("mcp-creator-extension-modules.yaml must define at least 5 modules")
    ids = {m.get("id") for m in modules if isinstance(m, dict)}
    required = {"openapi_to_mcp_spec", "safe_mcp_server_ir", "generated_server_verifier", "activation_bundle_generator"}
    missing = sorted(required - ids)
    if missing:
        fail(f"missing required module ids: {', '.join(missing)}")


def validate_ir_schema(path: Path) -> None:
    data = json.loads(path.read_text(encoding="utf-8"))
    required = set(data.get("required", []))
    for key in ["name", "runtime", "transport", "auth", "tools"]:
        if key not in required:
            fail(f"IR schema missing required field: {key}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path, help="mcp-builder skill root")
    args = parser.parse_args()
    root = args.root
    if not root.exists() or not root.is_dir():
        fail(f"root directory not found: {root}")
    validate_required_files(root)
    validate_scoring_csv(root / "assets/repo-extension-scoring-matrix.csv")
    validate_modules(root / "assets/mcp-creator-extension-modules.yaml")
    read_yaml(root / "assets/generated-server-verifier-spec.yaml")
    validate_ir_schema(root / "assets/openapi-to-mcp-ir.schema.json")
    print("repo-backed mcp-builder extension artifacts passed offline validation")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
