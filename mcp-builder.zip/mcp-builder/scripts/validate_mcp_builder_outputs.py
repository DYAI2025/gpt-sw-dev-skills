#!/usr/bin/env python3
"""Validate selected artifacts produced by an mcp-builder workflow.

This script performs offline checks only. It does not prove SDK compatibility or
MCP protocol conformance. Use it before build, Inspector and integration tests.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

SECRET_PATTERNS = [
    re.compile(r"sk-[A-Za-z0-9_-]{20,}"),
    re.compile(r"ghp_[A-Za-z0-9_]{20,}"),
    re.compile(r"xox[baprs]-[A-Za-z0-9-]{20,}"),
    re.compile(r"(?i)(api[_-]?key|token|secret)\s*=\s*['\"][^'\"]{12,}['\"]"),
]


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def validate_evaluation_xml(path: Path) -> None:
    if not path.exists():
        fail(f"evaluation XML not found: {path}")
    try:
        root = ET.fromstring(path.read_text(encoding="utf-8"))
    except ET.ParseError as exc:
        fail(f"invalid XML in {path}: {exc}")
    if root.tag != "evaluation":
        fail("root element must be <evaluation>")
    pairs = root.findall("qa_pair")
    if len(pairs) != 10:
        fail(f"evaluation must contain exactly 10 qa_pair elements, found {len(pairs)}")
    for idx, pair in enumerate(pairs, start=1):
        question = pair.findtext("question", default="").strip()
        answer = pair.findtext("answer", default="").strip()
        if not question:
            fail(f"qa_pair {idx} has empty question")
        if not answer:
            fail(f"qa_pair {idx} has empty answer")
        if len(answer.splitlines()) > 1:
            fail(f"qa_pair {idx} answer must be a single-line verifiable value")


def scan_for_secret_patterns(project: Path) -> None:
    for path in project.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() in {".png", ".jpg", ".jpeg", ".gif", ".zip", ".pdf"}:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        for pattern in SECRET_PATTERNS:
            if pattern.search(text):
                fail(f"possible hardcoded secret in {path}")


def validate_permissions(path: Path) -> None:
    if not path.exists():
        return
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        fail(f"invalid permissions JSON {path}: {exc}")
    permissions = payload.get("permissions", {})
    for key in ["deny", "ask", "allow"]:
        if key not in permissions or not isinstance(permissions[key], list):
            fail(f"permissions JSON must contain permissions.{key} as list")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path, help="Generated MCP project directory")
    parser.add_argument("--evaluation", type=Path, help="Path to evaluation.xml")
    parser.add_argument("--permissions", type=Path, help="Path to permissions JSON")
    args = parser.parse_args()

    if not args.project.exists() or not args.project.is_dir():
        fail(f"project directory not found: {args.project}")

    scan_for_secret_patterns(args.project)

    evaluation = args.evaluation or args.project / "evaluation.xml"
    if evaluation.exists():
        validate_evaluation_xml(evaluation)
    else:
        print(f"WARN: no evaluation.xml found at {evaluation}")

    if args.permissions:
        validate_permissions(args.permissions)

    print("mcp-builder offline artifact checks passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
