#!/usr/bin/env python3
"""Check a generated Markdown documentation package for expected headings.

This script does not prove documentation quality. It catches obvious structural gaps
so the model or maintainer can fix them before handoff.

Usage:
  python scripts/check_documentation_package.py /path/to/docs --profile software-active

Profiles:
  software-idea, software-active, finished-app, game, enterprise-arc42, rescue
"""

from __future__ import annotations

import argparse
import json
import pathlib
import re
import sys
from dataclasses import dataclass


HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$", re.MULTILINE)


@dataclass(frozen=True)
class Profile:
    required_terms: tuple[str, ...]
    recommended_terms: tuple[str, ...]


PROFILES: dict[str, Profile] = {
    "software-idea": Profile(
        required_terms=(
            "executive summary",
            "product objective",
            "problem statement",
            "target users",
            "user stories",
            "mvp",
            "non-goals",
            "metrics",
            "assumptions",
            "open questions",
        ),
        recommended_terms=("validation", "roadmap", "technical description", "risks"),
    ),
    "software-active": Profile(
        required_terms=(
            "requirements",
            "acceptance criteria",
            "architecture",
            "context",
            "building block",
            "runtime",
            "quality",
            "adr",
            "risks",
            "technical debt",
            "glossary",
        ),
        recommended_terms=("deployment", "observability", "security", "traceability", "agents"),
    ),
    "finished-app": Profile(
        required_terms=(
            "handover",
            "system overview",
            "user guide",
            "admin",
            "architecture",
            "deployment",
            "configuration",
            "runbook",
            "known issues",
            "maintenance",
            "support",
        ),
        recommended_terms=("backup", "restore", "monitoring", "security", "release notes"),
    ),
    "game": Profile(
        required_terms=(
            "game design document",
            "technical design document",
            "game vision",
            "core gameplay loop",
            "mechanics",
            "progression",
            "ui",
            "controls",
            "art",
            "audio",
            "performance",
            "production roadmap",
        ),
        recommended_terms=("economy", "level", "narrative", "engine", "feature-to-system"),
    ),
    "enterprise-arc42": Profile(
        required_terms=(
            "introduction and goals",
            "architecture constraints",
            "context and scope",
            "solution strategy",
            "building block view",
            "runtime view",
            "deployment view",
            "cross-cutting concepts",
            "architecture decisions",
            "quality requirements",
            "risks",
            "glossary",
        ),
        recommended_terms=("traceability", "security", "compliance", "sla", "adr"),
    ),
    "rescue": Profile(
        required_terms=(
            "observable behavior",
            "black-box",
            "integration test",
            "architecture snapshot",
            "technical debt",
            "modularization",
            "adr",
            "unknowns",
            "risks",
        ),
        recommended_terms=("entrypoints", "routes", "data flows", "seams", "stabilization"),
    ),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("docs_path", help="Directory containing Markdown documentation files")
    parser.add_argument(
        "--profile",
        required=True,
        choices=sorted(PROFILES),
        help="Documentation profile to validate",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print JSON only",
    )
    return parser.parse_args()


def read_markdown_tree(path: pathlib.Path) -> tuple[str, list[str]]:
    if not path.exists():
        raise SystemExit(f"Path does not exist: {path}")
    if path.is_file():
        files = [path]
    else:
        files = sorted(path.rglob("*.md"))
    if not files:
        raise SystemExit(f"No Markdown files found under: {path}")

    parts: list[str] = []
    rels: list[str] = []
    base = path if path.is_dir() else path.parent
    for file in files:
        rels.append(str(file.relative_to(base)))
        parts.append(file.read_text(encoding="utf-8", errors="replace"))
    return "\n".join(parts), rels


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower())


def find_headings(text: str) -> list[str]:
    return [match.group(2).strip() for match in HEADING_RE.finditer(text)]


def evaluate(text: str, profile: Profile) -> dict[str, object]:
    haystack = normalize(text)
    required = {term: (term.lower() in haystack) for term in profile.required_terms}
    recommended = {term: (term.lower() in haystack) for term in profile.recommended_terms}
    missing_required = [term for term, present in required.items() if not present]
    missing_recommended = [term for term, present in recommended.items() if not present]
    return {
        "required": required,
        "recommended": recommended,
        "missing_required": missing_required,
        "missing_recommended": missing_recommended,
        "required_score": len(profile.required_terms) - len(missing_required),
        "required_total": len(profile.required_terms),
        "recommended_score": len(profile.recommended_terms) - len(missing_recommended),
        "recommended_total": len(profile.recommended_terms),
        "passed": not missing_required,
        "headings": find_headings(text)[:100],
    }


def main() -> int:
    args = parse_args()
    docs_path = pathlib.Path(args.docs_path)
    text, files = read_markdown_tree(docs_path)
    result = evaluate(text, PROFILES[args.profile])
    result["profile"] = args.profile
    result["files"] = files

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"Profile: {args.profile}")
        print(f"Files: {len(files)}")
        print(
            "Required headings/terms: "
            f"{result['required_score']} / {result['required_total']}"
        )
        print(
            "Recommended headings/terms: "
            f"{result['recommended_score']} / {result['recommended_total']}"
        )
        if result["missing_required"]:
            print("Missing required:")
            for term in result["missing_required"]:
                print(f"- {term}")
        if result["missing_recommended"]:
            print("Missing recommended:")
            for term in result["missing_recommended"]:
                print(f"- {term}")
        print("PASS" if result["passed"] else "FAIL")

    return 0 if result["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
