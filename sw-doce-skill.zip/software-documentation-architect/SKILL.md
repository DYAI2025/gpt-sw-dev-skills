---
name: software-documentation-architect
description: creates reliable, detailed, standards-aligned documentation packages for software, games, apps, product ideas, running projects, finished applications, ai-generated codebases, handovers, architecture descriptions, prds, srs, sdds, gdds, tdds, arc42 docs, adr logs, runbooks, docs-as-code repositories, and audit-ready technical documentation.
---

# Software Documentation Architect

## Core principle

Create documentation that is useful, traceable, and honest. Prefer a complete, structured, standards-aligned documentation package over a polished but fictional document. Never invent project facts, metrics, architecture, compliance status, implementation details, stakeholder decisions, or test results.

Use the bundled references as needed:
- `references/standard-selection-guide.md` for choosing the right documentation family.
- `references/documentation-templates.md` for Markdown structures and section templates.
- `references/quality-rubric.md` for final review, completeness scoring, and anti-hallucination checks.
- `scripts/check_documentation_package.py` for deterministic heading checks on generated Markdown files.

## When to use

Use this skill when asked to create, improve, audit, or standardize documentation for:

- software ideas, app ideas, game ideas, SaaS concepts, MVPs, prototypes, or product visions;
- running projects that need PRD, SRS, SDD, arc42, ADRs, technical handover, implementation briefs, or coding-agent-ready docs;
- finished applications that need end-user documentation, operator docs, deployment notes, architecture docs, changelog, release notes, runbook, or maintenance documentation;
- games or interactive media that need a Game Design Document, Technical Design Document, feature bible, mechanics specification, economy design, level-design notes, or engine architecture notes;
- AI-generated or vibe-coded codebases that need reconstruction of requirements, tests, architecture decisions, risks, technical debt, and stabilization plans.

Do not use this skill for purely promotional copy, one-off blog posts, or casual summaries unless they are part of a documentation package.

## Workflow

### 1. Classify the project and maturity stage

Determine these dimensions before drafting:

1. **Product type**
   - software or SaaS;
   - mobile or desktop app;
   - game or interactive media;
   - internal tool or enterprise system;
   - AI-assisted or reconstructed codebase.
2. **Maturity stage**
   - idea or discovery;
   - planned MVP;
   - active implementation;
   - production system;
   - finished application or handover;
   - legacy, refactor, or rescue case.
3. **Risk level**
   - low risk: small internal tool or prototype;
   - medium risk: customer-facing product;
   - high risk: payments, health, legal, finance, safety, regulated data, security-sensitive systems, multiplayer economies, or enterprise integrations.
4. **Audience**
   - founders, sponsors, product managers, designers, developers, QA, operations, support, auditors, publishers, players, end users, or coding agents.

If information is missing, proceed with explicit assumptions unless the missing information would change the document family or create safety/compliance risk. Ask at most three targeted questions only when required.

### 2. Select the documentation stack

Use this decision model:

| Situation | Primary documentation | Add when needed |
|---|---|---|
| Early software or app idea | PDD or PRD-lite | MRD, BRD, validation plan |
| MVP or SaaS planning | PDD plus PRD | SRS, release plan, metrics plan |
| Active software project | PRD plus SDD | arc42-lite, ADR log, API spec, test strategy |
| Enterprise or complex system | arc42 | SRS, SDD, ADRs, runbook, security concept |
| Regulated or audit-heavy project | BRD, MRD, PRD, SRS, SDD | traceability matrix, risk register, compliance appendix |
| Game idea | GDD | market note, production roadmap |
| Game in development | GDD plus TDD | economy model, level-design spec, performance budgets |
| Finished app | product overview plus architecture plus runbook | user guide, admin guide, deployment guide, support guide |
| AI-generated or undocumented codebase | reconstruction dossier | black-box test plan, technical debt register, modularization plan |

Do not force every project into every document. Use the smallest stack that prevents expensive misunderstanding. This is the “minimal but honest” rule.

### 3. Establish factual boundaries

Before writing detailed claims, separate inputs into four buckets:

1. **Provided facts**: explicitly supplied by the user, files, repository, screenshots, tickets, or prior documents.
2. **Derived conclusions**: logically inferred from provided facts.
3. **Assumptions**: plausible but not confirmed.
4. **Open questions**: facts needed before implementation, audit, launch, or handover.

Every major document must include an `Assumptions and open questions` section unless the user explicitly supplied all required facts. Do not hide uncertainty in confident prose. Humanity already tried that with status reports. It went exactly as expected.

### 4. Build the documentation package

Create a package rather than a single shapeless wall of text. Use these defaults:

#### For ideas and planned products

- `00-executive-summary.md`
- `01-product-design-document.md`
- `02-requirements.md`
- `03-user-flows-and-ux.md`
- `04-architecture-lite.md`
- `05-validation-and-metrics.md`
- `06-roadmap-and-open-questions.md`

#### For active software projects

- `00-documentation-index.md`
- `01-product-context.md`
- `02-requirements-prd-srs.md`
- `03-architecture-arc42-lite.md`
- `04-runtime-and-user-flows.md`
- `05-api-and-data-contracts.md`
- `06-adrs.md`
- `07-quality-test-and-release.md`
- `08-risks-and-technical-debt.md`
- `09-glossary.md`
- `AGENTS.md` when coding agents should use the docs as source of truth.

#### For finished applications

- `00-handover-index.md`
- `01-system-overview.md`
- `02-user-guide.md`
- `03-admin-and-operations-guide.md`
- `04-architecture-and-deployment.md`
- `05-runbook-observability-support.md`
- `06-security-privacy-compliance-notes.md`
- `07-release-notes-and-known-issues.md`
- `08-maintenance-roadmap.md`

#### For games

- `00-game-documentation-index.md`
- `01-game-design-document.md`
- `02-technical-design-document.md`
- `03-content-and-level-design.md`
- `04-economy-progression-and-balancing.md`
- `05-art-audio-ui-direction.md`
- `06-production-roadmap.md`
- `07-risk-performance-and-release.md`

### 5. Write each document with traceability

For every feature, mechanic, module, or capability, capture:

- identifier;
- purpose;
- user or player value;
- requirement or design statement;
- acceptance criteria;
- dependencies;
- non-functional requirements;
- risks;
- test approach;
- implementation or documentation status;
- source confidence: `provided`, `derived`, `assumed`, or `unknown`.

For architecture, include:

- context and system boundary;
- building-block view;
- runtime scenarios;
- deployment view;
- cross-cutting concepts;
- ADRs;
- quality scenarios;
- risks and technical debt;
- glossary.

For games, maintain a hard bridge between GDD and TDD: every technical mechanism in the TDD should reference the GDD feature, mechanic, content system, control scheme, or player-facing rule it implements.

### 6. Include docs-as-code guidance

When the target is a repository or agentic development workflow, include:

- recommended `/docs` folder structure;
- Mermaid or PlantUML diagram placeholders where diagrams are useful;
- ADR file naming such as `docs/adrs/0001-title.md`;
- PR review rule: documentation changes are part of Definition of Done for architecture-impacting changes;
- `AGENTS.md` rules instructing coding agents to read docs before changing code and to stop when architecture constraints are violated.

### 7. Review before finalizing

Apply the quality rubric:

1. Does the selected documentation stack match project type, stage, risk, and audience?
2. Are facts, assumptions, unknowns, and derived claims clearly separated?
3. Are requirements testable?
4. Are quality attributes measurable?
5. Are architecture decisions explicit and reversible decisions marked?
6. Are risks and technical debt concrete, owned, and actionable?
7. Does the document avoid fake certainty, generic filler, and ungrounded industry claims?
8. Is the result detailed enough for the next actor to act without asking the same basic questions again?

If the generated package is available as Markdown files, run:

```bash
python scripts/check_documentation_package.py /path/to/docs --profile software-active
```

Supported profiles are `software-idea`, `software-active`, `finished-app`, `game`, `enterprise-arc42`, and `rescue`.

## Output format

When producing documentation, respond in this structure unless the user asks for a different deliverable:

1. **Documentation stack selected**
   - project classification;
   - selected standard or standards;
   - why this stack fits;
   - what was intentionally omitted.
2. **Assumptions and evidence boundaries**
   - provided facts;
   - derived conclusions;
   - assumptions;
   - open questions.
3. **Documentation package**
   - file tree;
   - full Markdown contents, or a prioritized subset if the package is too large for one response;
   - traceability matrix where useful.
4. **Quality and risk review**
   - completeness score;
   - missing inputs;
   - risks and technical debt;
   - next documentation actions.
5. **Docs-as-code handoff** when relevant
   - repository placement;
   - ADR naming;
   - AGENTS.md instructions;
   - validation command.

When the user asks for a single document, still include a short preface explaining the chosen document type and assumptions, then provide the document.

## Common mistakes

- Treating “industry standard” as one universal template. There is no universal template. Select by product type, maturity, risk, and audience.
- Writing a giant PRD when the user needs a GDD plus TDD.
- Writing an SDD before requirements are stable enough to design against.
- Claiming ISO, GDPR, SOC 2, HIPAA, PCI, or platform compliance without evidence.
- Inventing APIs, schemas, services, stakeholders, metrics, or architecture because the document “looks empty otherwise.” Empty truth beats decorative nonsense.
- Mixing confirmed facts and assumptions in the same paragraph.
- Omitting non-functional requirements, quality scenarios, risks, technical debt, and acceptance criteria.
- Forgetting operations and maintenance documentation for finished systems.
- Producing diagrams without explaining boundaries, data flows, and failure cases.

## Examples

### Example 1: app idea

Request: “Dokumentiere meine App-Idee für eine lokale Nachbarschaftshilfe-Plattform.”

Expected behavior:
- classify as early app idea;
- select PDD plus PRD-lite;
- include personas, problem statement, user flows, MVP scope, success metrics, risks, validation plan, and architecture-lite;
- mark unconfirmed market claims as assumptions.

### Example 2: running SaaS project

Request: “Erstelle eine ausführliche Dokumentation für unser laufendes B2B-SaaS-Projekt inklusive Architektur und Agenten-Handoff.”

Expected behavior:
- classify as active software project;
- select PRD plus SDD plus arc42-lite plus ADRs plus AGENTS.md;
- create docs-as-code file tree;
- include quality scenarios, runtime flows, deployment notes, API contracts, risks, and Definition-of-Done documentation rules.

### Example 3: game project

Request: “Baue eine vollständige Dokumentation für mein Roguelite-Spiel.”

Expected behavior:
- classify as game;
- create GDD plus TDD;
- separate player-facing design from implementation architecture;
- connect each technical system to GDD features;
- include controls, mechanics, progression, content structure, art/audio direction, performance budgets, build and release notes.

### Example 4: finished application

Request: “Dokumentiere eine fertige interne Anwendung so, dass ein neues Team sie übernehmen kann.”

Expected behavior:
- classify as finished application and handover;
- create overview, user guide, admin guide, architecture/deployment, runbook, known issues, release notes, maintenance roadmap, and support procedures;
- distinguish confirmed behavior from inferred behavior.
