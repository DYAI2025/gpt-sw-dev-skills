# Documentation templates

Use these templates as adaptable structures. Preserve headings when possible so generated packages are easy to validate and maintain.

## Universal front matter for every document

```markdown
---
title: "Document title"
status: draft | reviewed | approved | deprecated
owner: "name or role"
last_reviewed: "YYYY-MM-DD or unknown"
source_confidence: provided | derived | assumed | mixed
---

# Document title

## Purpose

## Scope

## Sources and evidence

| Claim area | Source | Confidence | Notes |
|---|---|---|---|

## Assumptions and open questions

### Assumptions

### Open questions
```

## PDD or product spec template

```markdown
# Product Design Document

## 1. Executive summary

## 2. Product objective

## 3. Problem statement

## 4. Target users and personas

## 5. Current alternatives and market context

## 6. User stories

| ID | User story | Priority | Acceptance criteria | Confidence |
|---|---|---:|---|---|

## 7. User flows and UX notes

## 8. Functional scope

### MVP scope

### Later scope

### Explicit non-goals

## 9. Technical description

## 10. Metrics and validation

## 11. Roadmap

## 12. Risks, dependencies, and open questions
```

## PRD plus SRS template

```markdown
# Requirements Specification

## 1. Purpose and product context

## 2. Stakeholders and audiences

## 3. Scope and non-goals

## 4. Functional requirements

| ID | Requirement | Priority | Acceptance criteria | Status | Source confidence |
|---|---|---:|---|---|---|

## 5. Non-functional requirements

| ID | Quality attribute | Scenario | Target | Verification |
|---|---|---|---|---|

## 6. User stories and use cases

## 7. Data requirements

## 8. Interface and integration requirements

## 9. Error states and edge cases

## 10. Release criteria

## 11. Traceability matrix

| Requirement | Feature | Design element | Test | Status |
|---|---|---|---|---|
```

## SDD or arc42-lite template

```markdown
# Software Design and Architecture Document

## 1. Introduction and goals

### Requirements overview

### Quality goals

### Stakeholders

## 2. Architecture constraints

## 3. Context and scope

### Business context

### Technical context

## 4. Solution strategy

## 5. Building block view

### Level 1: system white box

### Level 2: key components

## 6. Runtime view

### Scenario: critical user or system flow

## 7. Deployment view

## 8. Cross-cutting concepts

### Security

### Resilience

### Observability

### Data and domain model

## 9. Architecture decisions

| ADR | Decision | Status | Consequence |
|---|---|---|---|

## 10. Quality requirements

| Scenario | Stimulus | Response | Target | Measurement |
|---|---|---|---|---|

## 11. Risks and technical debt

| ID | Type | Description | Impact | Probability | Owner | Mitigation |
|---|---|---|---|---|---|---|

## 12. Glossary
```

## ADR template

```markdown
# ADR-0001: Decision title

## Status

proposed | accepted | deprecated | superseded by ADR-XXXX

## Context

## Decision

## Alternatives considered

| Alternative | Pros | Cons | Reason not chosen |
|---|---|---|---|

## Consequences

## Review trigger
```

## GDD template

```markdown
# Game Design Document

## 1. Game vision

## 2. Design pillars

## 3. Target player and platform

## 4. Core gameplay loop

## 5. Mechanics

| ID | Mechanic | Player-facing rule | Progression impact | TDD reference |
|---|---|---|---|---|

## 6. Narrative, world, and characters

## 7. Progression, economy, and balancing

## 8. Levels, missions, and content structure

## 9. UI, controls, and accessibility

## 10. Art direction

## 11. Audio direction

## 12. Monetization and live operations, if relevant

## 13. Production roadmap

## 14. Scope control and non-goals

## 15. Risks and open questions
```

## Game TDD template

```markdown
# Game Technical Design Document

## 1. Technical goals and platforms

## 2. Engine and middleware

## 3. Feature-to-system mapping

| GDD feature | Technical system | Main module | Data model | Test approach |
|---|---|---|---|---|

## 4. Architecture overview

## 5. Gameplay systems

## 6. Physics, collision, AI, and simulation

## 7. Save, persistence, and progression data

## 8. Networking and multiplayer, if relevant

## 9. Rendering and performance budgets

| Budget | Target | Measurement |
|---|---|---|

## 10. Build, branching, and release process

## 11. Tooling and content pipeline

## 12. Technical risks and mitigations
```

## Finished application handover template

```markdown
# Application Handover Documentation

## 1. Handover summary

## 2. System overview

## 3. User guide

## 4. Admin guide

## 5. Architecture and deployment

## 6. Configuration and secrets inventory

| Name | Purpose | Environment | Owner | Rotation note |
|---|---|---|---|---|

## 7. Data stores and integrations

## 8. Runbook

### Startup and shutdown

### Monitoring and alerts

### Backup and restore

### Incident procedures

## 9. Security, privacy, and compliance notes

## 10. Release notes and changelog

## 11. Known issues

## 12. Maintenance roadmap

## 13. Support boundaries and owners
```

## AGENTS.md template

```markdown
# AGENTS.md

## Source of truth

Before changing code, read the relevant files in `/docs`:

- product and requirements docs for behavior;
- architecture docs for boundaries and constraints;
- ADRs for decisions;
- runbook for operational constraints.

## Stop conditions

Stop and ask for a new ADR or human decision when:

- a change violates an accepted ADR;
- a new dependency or external service is introduced;
- a data model or public API changes;
- security, privacy, or compliance assumptions change;
- requirements and implementation conflict.

## Definition of Done

A code change is incomplete until affected docs, ADRs, tests, and release notes are updated.
```
