# Standard selection guide

Use this guide to choose documentation standards for software, games, apps, product ideas, running projects, finished applications, and reconstructed codebases.

## Selection dimensions

Choose by four dimensions, not by template nostalgia:

1. **Product type**: software, app, game, internal tool, enterprise platform, AI-generated codebase.
2. **Maturity**: idea, MVP planning, active development, production, finished handover, legacy rescue.
3. **Risk**: business risk, user harm, data sensitivity, security exposure, operational complexity, regulatory pressure.
4. **Audience**: sponsors, users, product, design, engineering, QA, operations, support, auditors, publishers, coding agents.

## Common document families

| Document | Use when | Do not use when | Must contain |
|---|---|---|---|
| BRD | business case, funding, portfolio decision, strategic alignment | no business decision is being made | business goals, success criteria, ROI logic, constraints, risks |
| MRD | market positioning, customer segments, competitive landscape | product scope is already fixed and market context is irrelevant | personas, market problem, customer journeys, alternatives |
| PRD | product capabilities from user perspective | implementation details dominate | features, user stories, acceptance criteria, scope, release assumptions |
| PDD or product spec | agile product idea or MVP needs one integrated product document | regulated traceability requires separate formal docs | objective, personas, user flows, technical notes, metrics, roadmap |
| SRS | detailed system behavior must be testable and traceable | concept is too vague | functional requirements, NFRs, interfaces, data, validation rules |
| FRS | step-by-step functional interactions must be specified | broad architecture is the concern | use cases, I/O tables, flows, edge cases |
| SDD | engineering design and implementation structure are needed | no technical implementation exists or is planned | components, architecture, UI/UX handoff, conventions, glossary |
| arc42 | complex, enterprise, long-lived, or architecture-heavy systems | a small idea only needs lightweight planning | 12-section architecture description, ADRs, quality scenarios |
| GDD | game or interactive media needs player-facing design | implementation detail is the primary concern | vision, mechanics, loop, narrative, art, audio, UI, controls, levels |
| TDD for games | game implementation architecture must be documented | no playable or technical design is needed | engine architecture, algorithms, networking, performance budgets, build rules |
| ADR log | architecture decisions need history | decisions are trivial or temporary | context, decision, alternatives, consequences, status |
| Runbook | production operation or handover is required | system will not be operated | alerts, procedures, backup, incident response, recovery |
| AGENTS.md | coding agents should modify the codebase safely | no agentic development workflow exists | docs source-of-truth rules, constraints, stop conditions, ADR triggers |

## Recommended stacks

### Software or app idea

Use this when the user has an idea but little implementation evidence.

Recommended stack:
- PDD or PRD-lite;
- validation plan;
- lightweight architecture note;
- roadmap and open questions.

Include:
- problem statement;
- target users;
- jobs-to-be-done or core user stories;
- MVP and non-goals;
- assumptions;
- validation interviews or experiment plan;
- core flows;
- measurable success indicators.

Avoid:
- pretending implementation choices are final;
- overbuilding enterprise architecture before product-market clarity exists.

### Running software project

Use this when code, backlog, prototypes, APIs, or decisions already exist.

Recommended stack:
- PRD plus SRS sections;
- SDD or arc42-lite;
- ADR log;
- test and release strategy;
- risk and technical debt register;
- docs-as-code structure.

Include:
- current scope and known non-goals;
- implemented vs planned capabilities;
- system boundaries;
- components and runtime flows;
- deployment and environment notes;
- quality scenarios;
- known risks;
- source confidence for each major claim.

### Enterprise or regulated system

Use this when auditability, formal traceability, security, or compliance pressure matters.

Recommended stack:
- BRD, MRD if market-facing, PRD, SRS, SDD;
- arc42;
- ADRs;
- traceability matrix;
- risk register;
- compliance appendix.

Include:
- source references;
- requirement identifiers;
- acceptance criteria;
- owner and status;
- measurable quality scenarios;
- explicit evidence gaps.

Never claim formal compliance unless evidence is provided. Use wording such as “supports documentation for GDPR assessment” rather than “is GDPR compliant.”

### Game idea or game project

Use this when the product is a game or interactive media.

Recommended stack:
- GDD for player-facing design;
- TDD for implementation;
- production roadmap;
- balancing and content appendix;
- performance and platform notes.

GDD should include:
- game vision and pillars;
- core loop;
- mechanics;
- progression;
- narrative and world;
- level/content structure;
- UI and controls;
- art and audio direction;
- monetization if relevant;
- scope and non-goals.

TDD should include:
- engine and platform assumptions;
- architecture;
- feature-to-system mapping;
- algorithms and data structures;
- physics, AI, networking, save systems;
- performance budgets;
- build, branching, and release policy.

Maintain a `GDD feature reference` column or field in the TDD.

### Finished application or handover

Use this when a system exists and another team, client, maintainer, or operator must understand it.

Recommended stack:
- handover index;
- user guide;
- admin guide;
- architecture and deployment doc;
- runbook;
- release notes and known issues;
- maintenance roadmap;
- support guide.

Include:
- actual behavior, not aspirational behavior;
- setup instructions;
- environment variables;
- dependencies;
- data stores;
- backup and restore;
- monitoring;
- common incidents;
- upgrade procedure;
- ownership and support boundaries.

### AI-generated or undocumented rescue case

Use this when the user has generated a codebase without prior documentation, tests, or architecture.

Recommended stack:
- reconstruction dossier;
- black-box behavior inventory;
- integration test plan;
- architecture snapshot;
- technical debt register;
- modularization plan;
- ADR backfill.

Order of work:
1. document observable behavior;
2. create black-box integration tests before refactoring;
3. map entrypoints, routes, screens, jobs, and data flows;
4. identify seams for modular extraction;
5. capture recovered decisions as ADRs with status `reconstructed`;
6. mark unknowns clearly.

Do not pretend reconstructed decisions were intentional unless evidence supports that claim.

## Minimal but honest package

When speed matters, use a minimal package:

- goals and non-goals;
- constraints;
- context and system boundary;
- building-block view level 1;
- one critical runtime scenario;
- ADR log;
- quality scenarios;
- risks and technical debt;
- glossary.

Add deeper sections only when complexity, risk, or audience demands it.
