# Quality rubric

Use this rubric before delivering documentation. It is intentionally strict because vague docs metastasize into meetings, and meetings are where clarity goes to become a calendar invite.

## Scoring

Score each dimension from 0 to 3.

| Score | Meaning |
|---:|---|
| 0 | missing or misleading |
| 1 | present but vague |
| 2 | usable with minor gaps |
| 3 | specific, actionable, traceable |

## Dimensions

| Dimension | Check |
|---|---|
| Fit | Document stack matches product type, maturity, risk, and audience. |
| Evidence honesty | Facts, derived claims, assumptions, and unknowns are separated. |
| Requirements quality | Functional requirements are testable and have acceptance criteria. |
| Scope control | Goals, non-goals, MVP, later scope, and exclusions are explicit. |
| Architecture clarity | Context, boundaries, components, runtime, deployment, and cross-cutting concepts are clear. |
| Quality attributes | Performance, reliability, security, usability, maintainability, or other NFRs are measurable. |
| Traceability | Features, requirements, architecture decisions, and tests can be linked. |
| Risk visibility | Risks and technical debt have impact, probability, owner or mitigation. |
| Operations readiness | Finished or production systems include runbook, monitoring, backup, support, and release notes. |
| Game dual-track fit | Games keep GDD player-facing design separate from TDD implementation and cross-reference both. |
| Docs-as-code readiness | Repository structure, ADR naming, diagrams-as-code, and review rules are described when relevant. |
| Anti-hallucination | No invented compliance, metrics, architecture, APIs, services, owners, or test results. |

## Rating bands

| Total | Interpretation |
|---:|---|
| 0-12 | Not reliable. Needs reconstruction before use. |
| 13-24 | Draft. Useful for discussion, unsafe as implementation source of truth. |
| 25-31 | Solid. Good enough for team use with tracked gaps. |
| 32-36 | Strong. Implementation or handover ready, assuming facts are accurate. |

## Mandatory anti-hallucination checks

Before finalizing, verify:

- Every metric is either provided, calculated from supplied data, or clearly marked as target or assumption.
- Every named system, API, database, queue, library, or cloud service is supplied by evidence or marked as assumed.
- Every compliance claim is framed as documentation support unless formal evidence is supplied.
- Every architecture diagram has a stated boundary and does not imply unseen infrastructure.
- Every risk has a plausible mitigation or an explicit owner-needed note.
- Every finished-system guide distinguishes actual behavior from desired future behavior.

## Completeness statement template

Use this at the end of large documentation packages:

```markdown
## Documentation quality review

| Dimension | Score | Notes |
|---|---:|---|
| Fit |  |  |
| Evidence honesty |  |  |
| Requirements quality |  |  |
| Scope control |  |  |
| Architecture clarity |  |  |
| Quality attributes |  |  |
| Traceability |  |  |
| Risk visibility |  |  |
| Operations readiness |  |  |
| Docs-as-code readiness |  |  |
| Anti-hallucination |  |  |

**Total:** X / 33

**Safe to use for:** discussion | planning | implementation | handover | audit preparation

**Not yet safe for:** list concrete missing uses
```

For game projects, add `Game dual-track fit` and score out of 36.
