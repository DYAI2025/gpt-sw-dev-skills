from __future__ import annotations

import os
import unittest

from scripts.confluence_client import RestConfluenceClient
from tests.support import make_client, make_writer, payload


class ConcurrencyAndCapabilityTests(unittest.TestCase):
    def test_25_version_conflict_rebases_successfully(self):
        client = make_client()
        client.simulate_version_conflicts = 1
        result = make_writer(client=client).execute(payload(dry_run=False, content="Rebased append"))
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["operation_performed"], "append_to_existing")
        self.assertEqual(len([item for item in client.mutations if item["operation"] == "update_page"]), 1)

    def test_26_version_conflict_stops_after_retry_limit(self):
        client = make_client()
        client.simulate_version_conflicts = 3
        result = make_writer(client=client).execute(payload(dry_run=False, content="Conflict"))
        self.assertEqual(result["error_code"], "version_conflict")

    def test_27_permission_denied_is_not_retried(self):
        calls = []

        def transport(method, url, headers, data, timeout):
            calls.append((method, url))
            return 403, {}, b'{}'

        old = os.environ.get("CONFLUENCE_TOKEN")
        os.environ["CONFLUENCE_TOKEN"] = "test-value-not-a-real-secret"
        try:
            client = RestConfluenceClient(
                {
                    "confluence_base_url":"https://example.atlassian.net",
                    "auth_mode":"bearer",
                    "host_allowlist":["example.atlassian.net"],
                    "max_retries":2
                },
                transport=transport,
                sleep_fn=lambda _: None,
            )
            with self.assertRaises(Exception) as caught:
                client.resolve_space("EYT")
            self.assertEqual(getattr(caught.exception, "code", None), "permission_denied")
            self.assertEqual(len(calls), 1)
        finally:
            if old is None:
                os.environ.pop("CONFLUENCE_TOKEN", None)
            else:
                os.environ["CONFLUENCE_TOKEN"] = old

    def test_28_rate_limit_uses_bounded_backoff(self):
        calls = []
        sleeps = []

        def transport(method, url, headers, data, timeout):
            calls.append((method, url))
            if len(calls) < 3:
                return 429, {"Retry-After":"0.1"}, b'{}'
            return 200, {}, b'{"results":[{"id":"100","key":"EYT","status":"current"}]}'

        old = os.environ.get("CONFLUENCE_TOKEN")
        os.environ["CONFLUENCE_TOKEN"] = "test-value-not-a-real-secret"
        try:
            client = RestConfluenceClient(
                {
                    "confluence_base_url":"https://example.atlassian.net",
                    "auth_mode":"bearer",
                    "host_allowlist":["example.atlassian.net"],
                    "max_retries":2
                },
                transport=transport,
                sleep_fn=sleeps.append,
            )
            result = client.resolve_space("EYT")
            self.assertEqual(result[0]["id"], "100")
            self.assertEqual(len(calls), 3)
            self.assertEqual(sleeps, [0.1, 0.1])
        finally:
            if old is None:
                os.environ.pop("CONFLUENCE_TOKEN", None)
            else:
                os.environ["CONFLUENCE_TOKEN"] = old

    def test_29_labels_are_applied_when_capability_exists(self):
        client = make_client(labels_write=True)
        result = make_writer(client=client).execute(payload(page_title="Labeled", operation="create_child", dry_run=False, labels=["alpha", "beta"]))
        self.assertEqual(result["status"], "success")
        self.assertEqual(set(result["labels_applied"]), {"alpha", "beta"})
        self.assertTrue(result["validation"]["labels_verified"])

    def test_30_labels_warn_when_capability_missing(self):
        client = make_client(labels_write=False)
        result = make_writer(client=client).execute(payload(page_title="Unlabeled", operation="create_child", dry_run=False, labels=["alpha"], strict_labels=False))
        self.assertEqual(result["status"], "success")
        self.assertIn("labels_not_applied", result["warnings"])


if __name__ == "__main__":
    unittest.main()
