from __future__ import annotations

import unittest

from scripts.errors import WriterError
from scripts.project_resolver import ProjectResolver
from tests.support import make_writer, payload, registry


class ProjectResolutionTests(unittest.TestCase):
    def setUp(self):
        self.resolver = ProjectResolver(registry())

    def test_01_exact_key_match_eyt(self):
        result = self.resolver.resolve(project_hint="EYT", content="x", page_title="x", parent_hint=None)
        self.assertEqual(result["project_key"], "EYT")

    def test_02_exact_project_name_match_easytree(self):
        result = self.resolver.resolve(project_hint="EasyTree", content="x", page_title="x", parent_hint=None)
        self.assertEqual(result["project_key"], "EYT")

    def test_03_semantic_context_over_threshold(self):
        result = self.resolver.resolve(project_hint=None, content="EasyTree weather adapter documentation", page_title="API", parent_hint=None)
        self.assertEqual(result["project_key"], "EYT")

    def test_04_semantic_context_under_threshold(self):
        with self.assertRaises(WriterError) as caught:
            self.resolver.resolve(project_hint=None, content="generic integration notes", page_title="API", parent_hint=None)
        self.assertEqual(caught.exception.code, "ambiguous_project")

    def test_05_insufficient_margin_between_candidates(self):
        custom = {
            "projects": [
                {"project_key":"AAA","project_name":"Alpha Product","space_key":"AAA","root_page_id":"1","aliases":["Alpha Product"],"forbidden_aliases":[],"status":"active"},
                {"project_key":"AAB","project_name":"Alpha Platform","space_key":"AAB","root_page_id":"2","aliases":["Alpha Platform"],"forbidden_aliases":[],"status":"active"}
            ]
        }
        resolver = ProjectResolver(custom)
        with self.assertRaises(WriterError) as caught:
            resolver.resolve(project_hint=None, content="Alpha Product and Alpha Platform migration", page_title="Plan", parent_hint=None)
        self.assertEqual(caught.exception.code, "ambiguous_project")
        self.assertEqual(len(caught.exception.project_candidates), 2)

    def test_06_bazodiac_relationship_never_routes_to_baz_or_fuf(self):
        with self.assertRaises(WriterError) as caught:
            self.resolver.resolve(project_hint="Bazodiac Relationship", content="matching", page_title="Logic", parent_hint=None)
        self.assertEqual(caught.exception.code, "unknown_project")


    def test_06b_unregistered_forbidden_product_blocks_contextual_cross_route(self):
        with self.assertRaises(WriterError) as caught:
            self.resolver.resolve(project_hint=None, content="Bazodiac Relationship uses the FuFire API", page_title="Integration", parent_hint=None)
        self.assertEqual(caught.exception.code, "ambiguous_project")

    def test_07_wor_requires_initialization(self):
        result = make_writer().execute(payload(project_hint="WOR", page_title="New", operation="create_child"))
        self.assertEqual(result["error_code"], "initialization_required")

    def test_08_zsh_requires_initialization(self):
        result = make_writer().execute(payload(project_hint="ZSH", page_title="New", operation="create_child"))
        self.assertEqual(result["error_code"], "initialization_required")

    def test_09_bzg_is_blocked(self):
        result = make_writer().execute(payload(project_hint="BZG", page_title="New", operation="create_child"))
        self.assertEqual(result["error_code"], "project_not_active")
        self.assertIn("canonical_project_name", result["missing_fields"])


if __name__ == "__main__":
    unittest.main()
