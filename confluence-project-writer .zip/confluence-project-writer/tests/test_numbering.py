from __future__ import annotations

import unittest

from scripts.hierarchy_resolver import HierarchyResolver


class NumberingTests(unittest.TestCase):
    def setUp(self):
        self.resolver = HierarchyResolver()

    def test_17_numbered_subtree_uses_next_max_number(self):
        siblings = [{"title":"09 – A","type":"page"},{"title":"12 - B","type":"page"}]
        title, warnings = self.resolver.apply_numbering("New Entry", siblings)
        self.assertEqual(title, "13 – New Entry")
        self.assertEqual(warnings, [])

    def test_18_unnumbered_subtree_leaves_title_unchanged(self):
        title, warnings = self.resolver.apply_numbering("New Entry", [{"title":"Alpha","type":"page"}])
        self.assertEqual(title, "New Entry")
        self.assertEqual(warnings, [])

    def test_19_mixed_numbering_emits_warning(self):
        siblings = [{"title":"01 – A","type":"page"},{"title":"B","type":"page"},{"title":"C","type":"page"}]
        title, warnings = self.resolver.apply_numbering("New Entry", siblings)
        self.assertEqual(title, "New Entry")
        self.assertIn("mixed_numbering_convention", warnings)

    def test_20_pre_numbered_title_is_not_double_numbered(self):
        title, warnings = self.resolver.apply_numbering("22 – New Entry", [{"title":"01 – A","type":"page"}])
        self.assertEqual(title, "22 – New Entry")
        self.assertEqual(warnings, [])


if __name__ == "__main__":
    unittest.main()
