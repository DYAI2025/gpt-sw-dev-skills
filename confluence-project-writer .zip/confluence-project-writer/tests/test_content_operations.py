from __future__ import annotations

import unittest

from scripts.content_transformer import ContentTransformer
from scripts.errors import WriterError


class ContentOperationTests(unittest.TestCase):
    def setUp(self):
        self.transformer = ContentTransformer()

    def test_21_append_is_idempotent(self):
        existing = "<p>Existing</p><p>New</p>"
        merged, changed = self.transformer.append_storage(existing, "<p>New</p>")
        self.assertFalse(changed)
        self.assertEqual(merged, existing)

    def test_22_replace_exactly_one_section(self):
        existing = "<h2>Overview</h2><p>Old</p><h3>Detail</h3><p>Old detail</p><h2>Next</h2><p>Keep</p>"
        updated = self.transformer.replace_section(existing, "Overview", "<p>New</p>")
        self.assertIn("<p>New</p>", updated)
        self.assertNotIn("Old detail", updated)
        self.assertIn("<h2>Next</h2><p>Keep</p>", updated)

    def test_23_missing_section_returns_error(self):
        with self.assertRaises(WriterError) as caught:
            self.transformer.replace_section("<h2>Other</h2><p>x</p>", "Overview", "<p>New</p>")
        self.assertEqual(caught.exception.code, "section_not_found")

    def test_24_duplicate_section_returns_error(self):
        with self.assertRaises(WriterError) as caught:
            self.transformer.replace_section("<h2>Overview</h2><p>x</p><h2>Overview</h2><p>y</p>", "Overview", "<p>New</p>")
        self.assertEqual(caught.exception.code, "section_ambiguous")

    def test_markdown_converter_supports_required_common_constructs(self):
        markdown = "# Head\n\n- A\n- B\n\n| X | Y |\n|---|---|\n| 1 | 2 |\n\n[link](https://example.com)\n\n```python\nprint('x')\n```"
        storage = self.transformer.markdown_to_storage(markdown)
        self.assertIn("<h1>Head</h1>", storage)
        self.assertIn("<ul>", storage)
        self.assertIn("<table>", storage)
        self.assertIn('href="https://example.com"', storage)
        self.assertIn("structured-macro", storage)


if __name__ == "__main__":
    unittest.main()
