from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

from scripts.confluence_client import MockConfluenceClient
from scripts.confluence_project_write import ConfluenceProjectWriter
from scripts.project_resolver import load_registry

ROOT = Path(__file__).resolve().parents[1]
REGISTRY_PATH = ROOT / "references" / "project_registry.yaml"
FIXTURE_PATH = ROOT / "tests" / "fixtures" / "sample_pages.json"


def registry():
    return load_registry(REGISTRY_PATH)


def sample_pages():
    return json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))


def make_client(*, pages=None, page_size=100, labels_write=True):
    return MockConfluenceClient(
        spaces=[{"id": "100", "key": "EYT", "status": "current", "name": "EasyTree"}],
        pages=deepcopy(pages or sample_pages()),
        page_size=page_size,
        labels_write=labels_write,
    )


def make_writer(*, client=None, max_content_chars=1_000_000):
    return ConfluenceProjectWriter(
        registry=registry(),
        client=client or make_client(),
        max_content_chars=max_content_chars,
    )


def payload(**overrides):
    value = {
        "content": "New content",
        "project_hint": "EYT",
        "page_title": "Existing Page",
        "parent_hint": "root",
        "operation": "auto",
        "content_format": "markdown",
        "dry_run": True,
    }
    value.update(overrides)
    return value
