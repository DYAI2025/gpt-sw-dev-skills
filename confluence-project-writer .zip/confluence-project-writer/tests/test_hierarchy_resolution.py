from __future__ import annotations

import unittest

from scripts.errors import WriterError
from scripts.hierarchy_resolver import HierarchyResolver
from tests.support import make_client, make_writer, payload, sample_pages


class HierarchyResolutionTests(unittest.TestCase):
    def test_10_root_page_wrong_space_is_registry_error(self):
        pages = sample_pages()
        pages["5505026"]["spaceId"] = "999"
        result = make_writer(client=make_client(pages=pages)).execute(payload())
        self.assertEqual(result["error_code"], "registry_integrity_error")

    def test_11_children_pagination_across_multiple_cursors(self):
        pages = sample_pages()
        for index in range(3):
            pages[str(300 + index)] = {
                "id": str(300 + index), "type": "page", "status": "current", "title": f"Child {index}",
                "spaceId": "100", "parentId": "5505026", "position": index + 2, "version": {"number": 1},
                "body": {"storage": {"value": "<p>x</p>"}}, "_links": {}
            }
        client = make_client(pages=pages, page_size=1)
        children = HierarchyResolver().list_all_direct_child_pages(client, "5505026")
        self.assertEqual(len(children), 4)

    def test_12_exact_parent_match(self):
        pages = sample_pages()
        pages["250"] = {
            "id":"250","type":"page","status":"current","title":"Documentation","spaceId":"100","parentId":"5505026",
            "position":2,"version":{"number":1},"body":{"storage":{"value":"<p>x</p>"}},"_links":{}
        }
        client = make_client(pages=pages)
        parent = HierarchyResolver().resolve_parent(client, root_page_id="5505026", space_id="100", parent_hint="Documentation")
        self.assertEqual(parent["id"], "250")

    def test_13_ambiguous_parent_match(self):
        pages = sample_pages()
        for page_id in ["250", "251"]:
            pages[page_id] = {
                "id":page_id,"type":"page","status":"current","title":"Documentation","spaceId":"100","parentId":"5505026",
                "position":2,"version":{"number":1},"body":{"storage":{"value":"<p>x</p>"}},"_links":{}
            }
        with self.assertRaises(WriterError) as caught:
            HierarchyResolver().resolve_parent(make_client(pages=pages), root_page_id="5505026", space_id="100", parent_hint="Documentation")
        self.assertEqual(caught.exception.code, "ambiguous_parent")

    def test_14_auto_existing_target_plans_append(self):
        result = make_writer().execute(payload())
        self.assertEqual(result["operation_performed"], "append_to_existing")
        self.assertFalse(result["write_performed"])

    def test_15_auto_missing_target_plans_create(self):
        result = make_writer().execute(payload(page_title="Brand New"))
        self.assertEqual(result["operation_performed"], "create_child")

    def test_16_create_child_existing_title_is_duplicate(self):
        result = make_writer().execute(payload(operation="create_child"))
        self.assertEqual(result["error_code"], "duplicate_title")


if __name__ == "__main__":
    unittest.main()
