# Missing Dependencies and Runtime Configuration

## Laufzeitabhängigkeiten

- `MISSING`: konkrete Confluence-Basis-URL.
- `MISSING`: Authentifizierungsmodus der Zielumgebung.
- `MISSING`: tatsächlich gebundenes Atlassian-Connector-, HTTP-MCP- oder Tool-Schema.
- `MISSING`: bestätigte Label-Schreibfähigkeit der Zielumgebung.
- `MISSING`: explizit freigegebene Live-Testseite und Live-Testautorisierung.

## Registry-Abhängigkeiten

- `WOR`: kanonische Root-Page-ID fehlt; Status bleibt `initialization_required`.
- `ZSH`: kanonische Root-Page-ID fehlt; Status bleibt `initialization_required`.
- `BZG/BG`: kanonischer Projektname, Root-Page-ID und bestätigte Beziehung zwischen BZG und BG fehlen; Status bleibt blockiert.

## Deployment-Auswirkung

Diese Punkte blockieren keine Paketvalidierung oder Mock-Tests. Sie blockieren reale Confluence-Mutationen und rechtfertigen ausschließlich `READY_WITH_RUNTIME_CONFIGURATION`, nicht `READY`.
