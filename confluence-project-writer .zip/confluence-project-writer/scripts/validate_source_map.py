from __future__ import annotations

import argparse
from pathlib import Path


def validate(skill_dir: Path) -> list[str]:
    path = skill_dir / "references" / "source-map.md"
    if not path.exists():
        return ["references/source-map.md is missing"]
    text = path.read_text(encoding="utf-8")
    errors = []
    for required in ["user_provided", "primary", "derived", "Confidence", "Atlassian"]:
        if required.casefold() not in text.casefold():
            errors.append(f"source map missing required concept: {required}")
    if "https://developer.atlassian.com/" not in text:
        errors.append("source map has no official Atlassian primary-source location")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("skill_dir", nargs="?", default=str(Path(__file__).resolve().parents[1]))
    args = parser.parse_args()
    errors = validate(Path(args.skill_dir).resolve())
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        return 1
    print("source-map: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
