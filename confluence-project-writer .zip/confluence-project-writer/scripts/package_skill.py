from __future__ import annotations

import argparse
import subprocess
import sys
import zipfile
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("skill_dir")
    parser.add_argument("output_dir", nargs="?", default="./dist")
    args = parser.parse_args()
    skill_dir = Path(args.skill_dir).resolve()
    output_dir = Path(args.output_dir).resolve()
    validator = skill_dir / "scripts" / "quick_validate.py"
    completed = subprocess.run([sys.executable, str(validator), str(skill_dir), "--with-tests"], check=False)
    if completed.returncode != 0:
        print("Packaging blocked because validation failed.", file=sys.stderr)
        return completed.returncode
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = output_dir / "skill.zip"
    if archive.exists():
        archive.unlink()
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as handle:
        for path in sorted(skill_dir.rglob("*")):
            if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
                continue
            arcname = Path(skill_dir.name) / path.relative_to(skill_dir)
            handle.write(path, arcname.as_posix())
    print(archive)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
