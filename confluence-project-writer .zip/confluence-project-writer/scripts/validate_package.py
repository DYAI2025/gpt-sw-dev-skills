from __future__ import annotations

import argparse
import json
import py_compile
import re
import xml.etree.ElementTree as ET
from pathlib import Path

REQUIRED_PATHS = [
    "SKILL.md",
    "README.md",
    "MISSING_DEPENDENCIES.md",
    "CONFLICTS.md",
    "config.example.yaml",
    "agents/openai.yaml",
    "references/project_registry.yaml",
    "references/routing_rules.md",
    "references/confluence_api_contract.md",
    "references/storage_format_rules.md",
    "references/error_contract.md",
    "references/runtime_binding.md",
    "references/security-and-tools.md",
    "references/source-policy.md",
    "references/source-map.md",
    "references/eval-design.md",
    "references/agent-agnostic-compatibility.md",
    "schemas/project_registry.schema.json",
    "schemas/confluence_project_write.input.schema.json",
    "schemas/confluence_project_write.success.schema.json",
    "schemas/confluence_project_write.error.schema.json",
    "scripts/project_resolver.py",
    "scripts/hierarchy_resolver.py",
    "scripts/content_transformer.py",
    "scripts/confluence_client.py",
    "scripts/confluence_project_write.py",
    "scripts/validate_registry.py",
    "scripts/validate_package.py",
    "scripts/quick_validate.py",
    "scripts/package_skill.py",
    "tests/test_project_resolution.py",
    "tests/test_hierarchy_resolution.py",
    "tests/test_numbering.py",
    "tests/test_content_operations.py",
    "tests/test_concurrency.py",
    "tests/test_security.py",
    "evals/eval_cases.jsonl",
    "evals/eval_rubric.md",
    "evals/expected_failures.json",
    "reports/release-gate-report.json",
    "reports/installability-report.json",
    "reports/test-report.json",
    "reports/security-report.json",
]

SECRET_PATTERNS = [
    re.compile(r"ghp_[A-Za-z0-9]{20,}"),
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(r"ATATT[A-Za-z0-9_-]{20,}"),
]


def parse_frontmatter(text: str) -> tuple[dict[str, str], list[str]]:
    errors: list[str] = []
    if not text.startswith("---\n"):
        return {}, ["SKILL.md must start with YAML frontmatter"]
    try:
        _, frontmatter, _ = text.split("---", 2)
    except ValueError:
        return {}, ["SKILL.md frontmatter is not closed"]
    data: dict[str, str] = {}
    for line in frontmatter.strip().splitlines():
        if not line.strip():
            continue
        if ":" not in line:
            errors.append(f"invalid frontmatter line: {line}")
            continue
        key, value = line.split(":", 1)
        data[key.strip()] = value.strip().strip('"').strip("'")
    return data, errors


def validate(skill_dir: Path) -> list[str]:
    errors: list[str] = []
    for relative in REQUIRED_PATHS:
        path = skill_dir / relative
        if not path.exists():
            errors.append(f"missing required path: {relative}")
        elif path.is_file() and path.stat().st_size == 0:
            errors.append(f"empty required file: {relative}")

    skill_path = skill_dir / "SKILL.md"
    if skill_path.exists():
        frontmatter, frontmatter_errors = parse_frontmatter(skill_path.read_text(encoding="utf-8"))
        errors.extend(frontmatter_errors)
        name = frontmatter.get("name", "")
        description = frontmatter.get("description", "")
        if name != skill_dir.name:
            errors.append("frontmatter name must match the skill folder")
        if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name):
            errors.append("frontmatter name is invalid")
        if not description or "<" in description or ">" in description:
            errors.append("frontmatter description is missing or contains angle brackets")
        if set(frontmatter) != {"name", "description"}:
            errors.append("frontmatter may contain only name and description")

    for path in skill_dir.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(skill_dir).as_posix()
        if path.suffix in {".json", ".yaml"}:
            try:
                json.loads(path.read_text(encoding="utf-8"))
            except json.JSONDecodeError as exc:
                if relative == "agents/openai.yaml":
                    text = path.read_text(encoding="utf-8")
                    if "display_name:" not in text or "short_description:" not in text:
                        errors.append(f"invalid minimal YAML metadata: {relative}")
                else:
                    errors.append(f"invalid JSON-compatible YAML/JSON in {relative}: {exc}")
        if path.suffix == ".py":
            try:
                py_compile.compile(str(path), doraise=True)
            except py_compile.PyCompileError as exc:
                errors.append(f"python compile failed for {relative}: {exc.msg}")
        if path.suffix == ".xml":
            try:
                ET.fromstring(path.read_text(encoding="utf-8"))
            except ET.ParseError as exc:
                errors.append(f"invalid XML in {relative}: {exc}")
        if path.suffix in {".md", ".py", ".json", ".yaml", ".xml", ".dot"}:
            text = path.read_text(encoding="utf-8", errors="replace")
            if re.search(r"\{\{[^}]+\}\}", text) or re.search(r"\bTODO\b", text):
                errors.append(f"placeholder marker found in {relative}")
            for pattern in SECRET_PATTERNS:
                if pattern.search(text):
                    errors.append(f"possible secret material found in {relative}")

    implementation = (skill_dir / "scripts" / "confluence_client.py").read_text(encoding="utf-8")
    for destructive in ['method="DELETE"', "def delete_page", "def purge", "def move_page", "def create_space"]:
        if destructive in implementation:
            errors.append(f"destructive client capability found: {destructive}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("skill_dir", nargs="?", default=str(Path(__file__).resolve().parents[1]))
    args = parser.parse_args()
    errors = validate(Path(args.skill_dir).resolve())
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        return 1
    print("package-structure: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
