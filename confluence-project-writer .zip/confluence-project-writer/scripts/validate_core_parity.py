from __future__ import annotations

import argparse
import json
from pathlib import Path

REQUIRED_CORE = {
    "exact and confidence-gated project resolution",
    "space and root verification",
    "parent and target resolution",
    "create_child",
    "append_to_existing",
    "replace_section",
    "numbering",
    "version conflict handling",
    "post-write validation",
    "machine-readable success and error contracts",
}


def validate(skill_dir: Path) -> list[str]:
    path = skill_dir / "reports" / "core-functionality-preservation.json"
    if not path.exists():
        return ["core-functionality preservation report missing"]
    report = json.loads(path.read_text(encoding="utf-8"))
    preserved = set(report.get("preserved_core_functions", []))
    errors = [f"missing preserved core function: {item}" for item in sorted(REQUIRED_CORE - preserved)]
    if report.get("unintentional_changes"):
        errors.append("unintentional core changes are present")
    if report.get("status") != "PASS":
        errors.append("core parity status is not PASS")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("skill_dir", nargs="?", default=str(Path(__file__).resolve().parents[1]))
    args = parser.parse_args()
    errors = validate(Path(args.skill_dir).resolve())
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        return 1
    print("core-parity: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
