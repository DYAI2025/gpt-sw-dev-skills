from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class WriterError(Exception):
    code: str
    message: str
    retryable: bool = False
    project_candidates: list[dict[str, Any]] = field(default_factory=list)
    missing_fields: list[str] = field(default_factory=list)
    details: dict[str, Any] = field(default_factory=dict)
    safe_next_action: str = "Review the error details and correct the request."
    write_performed: bool = False

    def __str__(self) -> str:
        return f"{self.code}: {self.message}"

    def as_result(self, idempotency_key: str | None = None) -> dict[str, Any]:
        return {
            "status": "error",
            "error_code": self.code,
            "message": self.message,
            "retryable": self.retryable,
            "project_candidates": self.project_candidates,
            "missing_fields": self.missing_fields,
            "details": self.details,
            "safe_next_action": self.safe_next_action,
            "write_performed": self.write_performed,
            "idempotency_key": idempotency_key,
        }


class ClientError(Exception):
    def __init__(
        self,
        code: str,
        message: str,
        *,
        status: int | None = None,
        retryable: bool = False,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status
        self.retryable = retryable
        self.details = details or {}
