from __future__ import annotations

import re
import unicodedata
from difflib import SequenceMatcher
from typing import Any

from .errors import WriterError

NUMBERED_TITLE_RE = re.compile(r"^\s*(\d{2,})\s*[–-]\s+(.+)$")


def normalize_title(value: str) -> str:
    value = unicodedata.normalize("NFKC", value)
    value = value.replace("—", "-").replace("–", "-")
    value = re.sub(r"\s+", " ", value).strip().casefold()
    return value


def split_numbered_title(value: str) -> tuple[int | None, str]:
    match = NUMBERED_TITLE_RE.match(value)
    if not match:
        return None, value.strip()
    return int(match.group(1)), match.group(2).strip()


def title_matches(existing: str, requested: str) -> bool:
    if normalize_title(existing) == normalize_title(requested):
        return True
    _, existing_base = split_numbered_title(existing)
    _, requested_base = split_numbered_title(requested)
    return normalize_title(existing_base) == normalize_title(requested_base)


class HierarchyResolver:
    def list_all_direct_child_pages(self, client: Any, parent_id: str) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        cursor: str | None = None
        seen_cursors: set[str] = set()
        while True:
            page = client.list_direct_children(parent_id, cursor=cursor)
            for child in page.get("results", []):
                if child.get("type", "page") == "page":
                    results.append(child)
            cursor = page.get("next_cursor")
            if not cursor:
                break
            if cursor in seen_cursors:
                raise WriterError(
                    "upstream_api_error",
                    "Cursor pagination loop detected.",
                    details={"cursor": cursor},
                    safe_next_action="Inspect the connector pagination implementation.",
                )
            seen_cursors.add(cursor)
        return results

    def resolve_parent(
        self,
        client: Any,
        *,
        root_page_id: str,
        space_id: str,
        parent_hint: str | None,
    ) -> dict[str, Any]:
        if parent_hint is None or normalize_title(parent_hint) == "root":
            return client.get_page(root_page_id)

        parent_hint = parent_hint.strip()
        if parent_hint.isdigit():
            page = client.get_page(parent_hint)
            if str(page.get("spaceId")) != str(space_id):
                raise WriterError(
                    "parent_not_found",
                    "Numeric parent_hint is outside the resolved space.",
                    details={"parent_hint": parent_hint},
                    safe_next_action="Use a parent page inside the canonical project tree.",
                )
            if not self._belongs_to_tree(client, page, root_page_id):
                raise WriterError(
                    "parent_not_found",
                    "Numeric parent_hint is not inside the canonical project tree.",
                    details={"parent_hint": parent_hint, "root_page_id": root_page_id},
                    safe_next_action="Use the canonical root or a descendant of it.",
                )
            return page

        children = self.list_all_direct_child_pages(client, root_page_id)
        matches = [child for child in children if normalize_title(child.get("title", "")) == normalize_title(parent_hint)]
        if len(matches) == 1:
            return client.get_page(str(matches[0]["id"]))
        if len(matches) > 1:
            raise WriterError(
                "ambiguous_parent",
                "More than one direct root child matches parent_hint.",
                details={"matches": [str(item["id"]) for item in matches]},
                safe_next_action="Provide the numeric parent page ID.",
            )
        candidates = sorted(
            (
                {
                    "id": str(child.get("id")),
                    "title": child.get("title", ""),
                    "similarity": round(
                        SequenceMatcher(
                            None,
                            normalize_title(parent_hint),
                            normalize_title(child.get("title", "")),
                        ).ratio(),
                        3,
                    ),
                }
                for child in children
            ),
            key=lambda item: item["similarity"],
            reverse=True,
        )[:5]
        raise WriterError(
            "parent_not_found",
            "No exact direct child of the project root matches parent_hint.",
            details={"candidates": candidates},
            safe_next_action="Provide an exact direct-child title or numeric page ID.",
        )

    def _belongs_to_tree(self, client: Any, page: dict[str, Any], root_page_id: str) -> bool:
        current = page
        visited: set[str] = set()
        for _ in range(100):
            current_id = str(current.get("id"))
            if current_id == str(root_page_id):
                return True
            if current_id in visited:
                return False
            visited.add(current_id)
            parent_id = current.get("parentId")
            if not parent_id:
                return False
            current = client.get_page(str(parent_id))
        return False

    def resolve_target(self, children: list[dict[str, Any]], page_title: str) -> dict[str, Any] | None:
        matches = [child for child in children if title_matches(child.get("title", ""), page_title)]
        if len(matches) > 1:
            raise WriterError(
                "duplicate_title",
                "More than one target page matches the requested title under the same parent.",
                details={"matches": [str(item.get("id")) for item in matches]},
                safe_next_action="Resolve duplicate sibling titles before writing.",
            )
        return matches[0] if matches else None

    def resolve_operation(self, requested: str, target: dict[str, Any] | None) -> str:
        if requested == "auto":
            return "append_to_existing" if target else "create_child"
        if requested == "create_child" and target:
            raise WriterError(
                "duplicate_title",
                "A page with the same normalized title already exists under the parent.",
                safe_next_action="Choose append_to_existing or a different page_title.",
            )
        if requested in {"append_to_existing", "replace_section"} and not target:
            raise WriterError(
                "target_not_found",
                "The requested existing target page was not found under the resolved parent.",
                safe_next_action="Use an exact page_title or create the page first.",
            )
        return requested

    def apply_numbering(self, page_title: str, siblings: list[dict[str, Any]]) -> tuple[str, list[str]]:
        incoming_number, incoming_base = split_numbered_title(page_title)
        if incoming_number is not None:
            return page_title.strip(), []

        page_siblings = [item for item in siblings if item.get("type", "page") == "page"]
        numbered = []
        for sibling in page_siblings:
            number, _ = split_numbered_title(str(sibling.get("title", "")))
            if number is not None:
                numbered.append(number)

        total = len(page_siblings)
        if total == 0 or not numbered:
            return page_title.strip(), []
        all_numbered = len(numbered) == total
        ratio = len(numbered) / total
        clear = all_numbered or (len(numbered) >= 2 and ratio >= 0.60)
        if clear:
            next_number = max(numbered) + 1
            return f"{next_number:02d} – {incoming_base}", []
        return page_title.strip(), ["mixed_numbering_convention"]
