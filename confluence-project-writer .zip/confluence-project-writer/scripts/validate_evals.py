from __future__ import annotations

import argparse
import json
from pathlib import Path


def validate(skill_dir: Path) -> list[str]:
    errors: list[str] = []
    eval_dir = skill_dir / "evals"
    required = ["trigger_queries.json", "output_evals.json", "eval_cases.jsonl", "expected_failures.json", "eval_rubric.md"]
    for name in required:
        if not (eval_dir / name).exists():
            errors.append(f"missing eval file: {name}")
    if errors:
        return errors
    try:
        triggers = json.loads((eval_dir / "trigger_queries.json").read_text(encoding="utf-8"))
        if len(triggers.get("should_trigger", [])) < 8 or len(triggers.get("should_not_trigger", [])) < 8:
            errors.append("trigger evals require at least 8 positive and 8 negative queries")
        outputs = json.loads((eval_dir / "output_evals.json").read_text(encoding="utf-8"))
        if len(outputs.get("cases", [])) < 3:
            errors.append("output evals require at least 3 cases")
        json.loads((eval_dir / "expected_failures.json").read_text(encoding="utf-8"))
        lines = [line for line in (eval_dir / "eval_cases.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
        if len(lines) < 10:
            errors.append("eval_cases.jsonl requires at least 10 stable cases")
        for line_number, line in enumerate(lines, start=1):
            item = json.loads(line)
            if not item.get("question") or not isinstance(item.get("answer"), (str, int, float, bool)):
                errors.append(f"invalid JSONL case at line {line_number}")
    except (json.JSONDecodeError, OSError) as exc:
        errors.append(f"eval parsing failed: {exc}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("skill_dir", nargs="?", default=str(Path(__file__).resolve().parents[1]))
    args = parser.parse_args()
    errors = validate(Path(args.skill_dir).resolve())
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        return 1
    print("evals: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
