from __future__ import annotations

import argparse
import sys
from pathlib import Path

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from scripts.project_resolver import load_registry, validate_registry_data
else:
    from .project_resolver import load_registry, validate_registry_data


def validate(skill_dir: Path) -> list[str]:
    registry = load_registry(skill_dir / "references" / "project_registry.yaml")
    errors = validate_registry_data(registry)
    projects = {project["project_key"]: project for project in registry["projects"]}
    if projects.get("EIH", {}).get("root_page_id") != "12451841":
        errors.append("EIH root_page_id must be 12451841")
    for key in ["WOR", "ZSH"]:
        project = projects.get(key, {})
        if project.get("status") != "initialization_required" or project.get("root_page_id") is not None:
            errors.append(f"{key} must remain initialization_required with null root_page_id")
    bzg = projects.get("BZG", {})
    if bzg.get("status") == "active" or bzg.get("root_page_id") is not None:
        errors.append("BZG must remain blocked until registry conflict is resolved")
    baz = projects.get("BAZ", {})
    if "Bazodiac Relationship" not in baz.get("forbidden_aliases", []):
        errors.append("BAZ must explicitly forbid Bazodiac Relationship")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("skill_dir", nargs="?", default=str(Path(__file__).resolve().parents[1]))
    args = parser.parse_args()
    errors = validate(Path(args.skill_dir).resolve())
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        return 1
    print("registry: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
