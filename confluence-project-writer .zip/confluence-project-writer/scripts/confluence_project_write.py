from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from scripts.confluence_client import ConfluenceClient, RestConfluenceClient
    from scripts.content_transformer import ContentTransformer
    from scripts.errors import ClientError, WriterError
    from scripts.hierarchy_resolver import HierarchyResolver
    from scripts.project_resolver import ProjectResolver, load_registry
else:
    from .confluence_client import ConfluenceClient, RestConfluenceClient
    from .content_transformer import ContentTransformer
    from .errors import ClientError, WriterError
    from .hierarchy_resolver import HierarchyResolver
    from .project_resolver import ProjectResolver, load_registry

ALLOWED_FIELDS = {
    "content",
    "project_hint",
    "page_title",
    "parent_hint",
    "operation",
    "section_heading",
    "labels",
    "content_format",
    "dry_run",
    "strict_labels",
    "allow_initialization",
    "allow_split",
    "idempotency_key",
    "expected_version",
}

DEFAULTS = {
    "project_hint": None,
    "page_title": None,
    "parent_hint": None,
    "operation": "auto",
    "section_heading": None,
    "labels": [],
    "content_format": "markdown",
    "dry_run": True,
    "strict_labels": False,
    "allow_initialization": False,
    "allow_split": False,
    "idempotency_key": None,
    "expected_version": None,
}


class ConfluenceProjectWriter:
    def __init__(
        self,
        *,
        registry: dict[str, Any],
        client: ConfluenceClient,
        max_content_chars: int = 1_000_000,
    ) -> None:
        self.project_resolver = ProjectResolver(registry)
        self.hierarchy = HierarchyResolver()
        self.transformer = ContentTransformer()
        self.client = client
        self.max_content_chars = max(1, int(max_content_chars))
        self._idempotency_cache: dict[str, dict[str, Any]] = {}

    def execute(self, raw_payload: dict[str, Any]) -> dict[str, Any]:
        idempotency_key = raw_payload.get("idempotency_key") if isinstance(raw_payload, dict) else None
        try:
            payload = self._validate_input(raw_payload)
            idempotency_key = payload["idempotency_key"]
            if idempotency_key and idempotency_key in self._idempotency_cache:
                cached = dict(self._idempotency_cache[idempotency_key])
                cached["warnings"] = list(cached.get("warnings", [])) + ["idempotency_cache_hit"]
                return cached

            result = self._execute_validated(payload)
            if idempotency_key and result.get("status") == "success":
                self._idempotency_cache[idempotency_key] = dict(result)
            return result
        except WriterError as exc:
            return exc.as_result(idempotency_key)
        except ClientError as exc:
            return self._map_client_error(exc).as_result(idempotency_key)
        except Exception as exc:  # defensive boundary
            return WriterError(
                "upstream_api_error",
                "An unexpected non-secret runtime error occurred.",
                details={"exception_type": type(exc).__name__},
                safe_next_action="Inspect local logs and rerun in dry_run mode.",
            ).as_result(idempotency_key)

    def _validate_input(self, raw: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(raw, dict):
            raise WriterError(
                "invalid_input",
                "Input must be a JSON object.",
                safe_next_action="Provide an object matching the input schema.",
            )
        unknown = sorted(set(raw) - ALLOWED_FIELDS)
        if unknown:
            raise WriterError(
                "invalid_input",
                "Unknown input fields are not accepted.",
                details={"unknown_fields": unknown},
                safe_next_action="Remove unknown fields or update the explicit schema first.",
            )
        payload = dict(DEFAULTS)
        payload.update(raw)
        content = payload.get("content")
        if not isinstance(content, str) or not content.strip():
            raise WriterError(
                "invalid_input",
                "content is required and must not be empty.",
                missing_fields=["content"],
                safe_next_action="Provide non-empty content.",
            )
        operation = payload.get("operation")
        if operation not in {"auto", "create_child", "append_to_existing", "replace_section"}:
            raise WriterError("invalid_input", "operation is invalid.")
        if payload.get("content_format") not in {"markdown", "storage"}:
            raise WriterError("invalid_input", "content_format must be markdown or storage.")
        for field in ["dry_run", "strict_labels", "allow_initialization", "allow_split"]:
            if not isinstance(payload[field], bool):
                raise WriterError("invalid_input", f"{field} must be boolean.")
        if not isinstance(payload.get("labels"), list) or not all(isinstance(item, str) and item.strip() for item in payload["labels"]):
            raise WriterError("invalid_input", "labels must be an array of non-empty strings.")
        payload["labels"] = list(dict.fromkeys(item.strip() for item in payload["labels"]))
        page_title = payload.get("page_title")
        if operation in {"auto", "create_child", "append_to_existing", "replace_section"} and (
            not isinstance(page_title, str) or not page_title.strip()
        ):
            raise WriterError(
                "invalid_input",
                "page_title is required for deterministic target resolution.",
                missing_fields=["page_title"],
                safe_next_action="Provide the exact page title or intended new child title.",
            )
        payload["page_title"] = page_title.strip()
        if operation == "replace_section" and (
            not isinstance(payload.get("section_heading"), str) or not payload["section_heading"].strip()
        ):
            raise WriterError(
                "invalid_input",
                "section_heading is required for replace_section.",
                missing_fields=["section_heading"],
                safe_next_action="Provide the exact visible section heading.",
            )
        expected_version = payload.get("expected_version")
        if expected_version is not None and (not isinstance(expected_version, int) or expected_version < 1):
            raise WriterError("invalid_input", "expected_version must be a positive integer or null.")
        return payload

    def _execute_validated(self, payload: dict[str, Any]) -> dict[str, Any]:
        project = self.project_resolver.resolve(
            project_hint=payload["project_hint"],
            content=payload["content"],
            page_title=payload["page_title"],
            parent_hint=payload["parent_hint"],
        )
        self._validate_project_status(project, payload)
        root_page_id = project.get("root_page_id")
        if not root_page_id:
            raise WriterError(
                "root_not_found",
                "The project has no canonical root page ID.",
                safe_next_action="Complete the registry entry before writing.",
            )

        spaces = self.client.resolve_space(project["space_key"])
        if not spaces:
            raise WriterError(
                "space_not_found",
                "The canonical Confluence space was not found or is not visible.",
                details={"space_key": project["space_key"]},
                safe_next_action="Verify the base URL, permissions, and canonical space_key.",
            )
        if len(spaces) != 1:
            raise WriterError(
                "registry_integrity_error",
                "Space resolution did not return exactly one current space.",
                details={"space_key": project["space_key"], "match_count": len(spaces)},
                safe_next_action="Resolve the space ambiguity before writing.",
            )
        space_id = str(spaces[0]["id"])
        try:
            root_page = self.client.get_page(str(root_page_id))
        except ClientError as exc:
            if exc.status == 404:
                raise WriterError(
                    "root_not_found",
                    "The canonical root page was not found or is not visible.",
                    details={"root_page_id": str(root_page_id)},
                    safe_next_action="Verify the registry root_page_id and permissions.",
                ) from exc
            raise
        if str(root_page.get("spaceId")) != space_id:
            raise WriterError(
                "registry_integrity_error",
                "The canonical root page belongs to a different space than the resolved space.",
                details={
                    "root_page_id": str(root_page_id),
                    "root_space_id": str(root_page.get("spaceId")),
                    "resolved_space_id": space_id,
                },
                safe_next_action="Correct the registry; do not write until space/root consistency is restored.",
            )

        parent = self.hierarchy.resolve_parent(
            self.client,
            root_page_id=str(root_page_id),
            space_id=space_id,
            parent_hint=payload["parent_hint"],
        )
        parent_id = str(parent["id"])
        siblings = self.hierarchy.list_all_direct_child_pages(self.client, parent_id)
        target = self.hierarchy.resolve_target(siblings, payload["page_title"])
        operation = self.hierarchy.resolve_operation(payload["operation"], target)

        warnings: list[str] = []
        resolved_title = payload["page_title"]
        if operation == "create_child":
            resolved_title, numbering_warnings = self.hierarchy.apply_numbering(resolved_title, siblings)
            warnings.extend(numbering_warnings)

        if len(payload["content"]) > self.max_content_chars:
            if not payload["allow_split"]:
                raise WriterError(
                    "content_too_large",
                    "Content exceeds the configured deterministic client-side size guard.",
                    details={"content_chars": len(payload["content"]), "max_content_chars": self.max_content_chars},
                    safe_next_action="Reduce content or request a visible split plan with allow_split=true.",
                )
            return self._split_plan_result(payload, project, space_id, parent_id, resolved_title, warnings)

        labels_supported = bool(self.client.capabilities.get("labels_write"))
        if payload["labels"] and payload["strict_labels"] and not labels_supported:
            raise WriterError(
                "labels_not_supported",
                "The bound adapter does not expose a verified label-write capability.",
                safe_next_action="Bind a verified label-capable adapter or set strict_labels=false.",
            )
        if payload["labels"] and not labels_supported:
            warnings.append("labels_not_applied")

        storage = self.transformer.convert(payload["content"], payload["content_format"])

        if payload["dry_run"]:
            mutation_plan = {
                "project_key": project["project_key"],
                "space_id": space_id,
                "parent_page_id": parent_id,
                "target_page_id": str(target["id"]) if target else None,
                "resolved_title": resolved_title,
                "operation": operation,
                "content_format": "storage",
                "content_chars": len(storage),
                "labels": payload["labels"],
                "write_authorized": False,
            }
            return self._success_result(
                payload=payload,
                project=project,
                space_id=space_id,
                parent_id=parent_id,
                operation_performed=operation,
                page=target,
                resolved_title=resolved_title,
                warnings=warnings,
                labels_applied=[],
                validation=self._empty_validation(),
                write_performed=False,
                dry_run=True,
                mutation_plan=mutation_plan,
            )

        if operation == "create_child":
            page = self.client.create_page(
                space_id=space_id,
                parent_id=parent_id,
                title=resolved_title,
                body=storage,
            )
            changed = True
            intended_title = resolved_title
            intended_version = 1
        else:
            page_id = str(target["id"])
            intended_title = str(target.get("title"))
            page, changed, intended_version = self._update_with_rebase(
                page_id=page_id,
                operation=operation,
                new_fragment=storage,
                section_heading=payload["section_heading"],
                expected_version=payload["expected_version"],
            )
            if not changed:
                warnings.append("idempotent_noop")

        labels_applied: list[str] = []
        if payload["labels"] and labels_supported:
            labels_applied = self.client.apply_labels(str(page["id"]), payload["labels"])

        readback = self.client.get_page(str(page["id"]))
        validation = self._post_write_validate(
            readback=readback,
            expected_space_id=space_id,
            expected_parent_id=parent_id,
            expected_title=intended_title,
            expected_version=intended_version,
            expected_fragment=storage,
            labels_requested=payload["labels"] if labels_supported else [],
        )
        if not all(validation[key] for key in ["title_verified", "parent_verified", "space_verified", "version_verified", "content_verified"]):
            raise WriterError(
                "post_write_validation_failed",
                "The post-write readback did not match the intended mutation.",
                details={"validation": validation, "page_id": str(page["id"])},
                safe_next_action="Stop further writes and inspect the page state manually.",
                write_performed=changed,
            )
        if payload["labels"] and labels_supported and not validation.get("labels_verified", False):
            raise WriterError(
                "post_write_validation_failed",
                "Page content was written, but requested labels were not verified.",
                details={"validation": validation, "page_id": str(page["id"])},
                safe_next_action="Inspect label permissions and page state before retrying.",
                write_performed=changed,
            )

        return self._success_result(
            payload=payload,
            project=project,
            space_id=space_id,
            parent_id=parent_id,
            operation_performed=operation if changed else "noop",
            page=readback,
            resolved_title=str(readback.get("title")),
            warnings=warnings,
            labels_applied=labels_applied,
            validation=validation,
            write_performed=changed,
            dry_run=False,
            mutation_plan=None,
        )

    def _validate_project_status(self, project: dict[str, Any], payload: dict[str, Any]) -> None:
        status = project.get("status")
        if status == "active":
            return
        if status == "initialization_required":
            raise WriterError(
                "initialization_required",
                "The project requires a separately authorized initialization capability.",
                details={"project_key": project["project_key"], "allow_initialization": payload["allow_initialization"]},
                safe_next_action="Configure the canonical root page through a separately authorized initialization workflow.",
            )
        raise WriterError(
            "project_not_active",
            "The project is blocked by incomplete or conflicting registry data.",
            missing_fields=list(project.get("missing", [])),
            details={"project_key": project["project_key"], "status": status},
            safe_next_action="Resolve the registry conflict before any write.",
        )

    def _update_with_rebase(
        self,
        *,
        page_id: str,
        operation: str,
        new_fragment: str,
        section_heading: str | None,
        expected_version: int | None,
    ) -> tuple[dict[str, Any], bool, int]:
        rebase_attempts = 0
        while True:
            current = self.client.get_page(page_id)
            current_version = int(current.get("version", {}).get("number", 0))
            if expected_version is not None and rebase_attempts == 0 and current_version != expected_version:
                raise WriterError(
                    "version_conflict",
                    "The page version does not match expected_version.",
                    details={"expected_version": expected_version, "current_version": current_version},
                    safe_next_action="Read the current page and submit an updated expected_version.",
                )
            body = self._page_body(current)
            if operation == "append_to_existing":
                updated_body, changed = self.transformer.append_storage(body, new_fragment)
            else:
                updated_body = self.transformer.replace_section(body, str(section_heading), new_fragment)
                changed = updated_body != body
            if not changed:
                return current, False, current_version
            try:
                updated = self.client.update_page(
                    page_id=page_id,
                    status=str(current.get("status", "current")),
                    title=str(current.get("title")),
                    body=updated_body,
                    version_number=current_version + 1,
                    space_id=str(current.get("spaceId")) if current.get("spaceId") is not None else None,
                    parent_id=str(current.get("parentId")) if current.get("parentId") is not None else None,
                )
                return updated, True, current_version + 1
            except ClientError as exc:
                if exc.code != "version_conflict":
                    raise
                if rebase_attempts >= 2:
                    raise WriterError(
                        "version_conflict",
                        "Version conflict persisted after two safe rebase attempts.",
                        retryable=True,
                        safe_next_action="Pause automated updates and review concurrent edits.",
                    ) from exc
                rebase_attempts += 1

    def _post_write_validate(
        self,
        *,
        readback: dict[str, Any],
        expected_space_id: str,
        expected_parent_id: str,
        expected_title: str,
        expected_version: int,
        expected_fragment: str,
        labels_requested: list[str],
    ) -> dict[str, bool]:
        actual_labels = self.client.get_labels(str(readback["id"])) if labels_requested else []
        return {
            "title_verified": str(readback.get("title")) == str(expected_title),
            "parent_verified": str(readback.get("parentId")) == str(expected_parent_id),
            "space_verified": str(readback.get("spaceId")) == str(expected_space_id),
            "version_verified": int(readback.get("version", {}).get("number", 0)) == int(expected_version),
            "content_verified": self.transformer.contains_fragment(self._page_body(readback), expected_fragment),
            "labels_verified": all(label in actual_labels for label in labels_requested),
        }

    @staticmethod
    def _page_body(page: dict[str, Any]) -> str:
        body = page.get("body", {})
        storage = body.get("storage", {}) if isinstance(body, dict) else {}
        value = storage.get("value") if isinstance(storage, dict) else None
        if not isinstance(value, str):
            raise WriterError(
                "upstream_api_error",
                "Page response does not contain a storage body.",
                safe_next_action="Bind a connector that returns body.storage.value.",
            )
        return value

    def _split_plan_result(
        self,
        payload: dict[str, Any],
        project: dict[str, Any],
        space_id: str,
        parent_id: str,
        title: str,
        warnings: list[str],
    ) -> dict[str, Any]:
        chunk_size = self.max_content_chars
        parts = [payload["content"][index : index + chunk_size] for index in range(0, len(payload["content"]), chunk_size)]
        split_plan = {
            "index_page_title": title,
            "child_pages": [
                {"title": f"{title} – Part {index:02d}", "content_chars": len(part)}
                for index, part in enumerate(parts, start=1)
            ],
            "requires_explicit_write_authorization": True,
        }
        return self._success_result(
            payload=payload,
            project=project,
            space_id=space_id,
            parent_id=parent_id,
            operation_performed="split_plan",
            page=None,
            resolved_title=title,
            warnings=warnings + ["split_plan_only_no_mutation"],
            labels_applied=[],
            validation=self._empty_validation(),
            write_performed=False,
            dry_run=True,
            mutation_plan=split_plan,
        )

    @staticmethod
    def _empty_validation() -> dict[str, bool]:
        return {
            "title_verified": False,
            "parent_verified": False,
            "space_verified": False,
            "version_verified": False,
            "content_verified": False,
            "labels_verified": False,
        }

    def _success_result(
        self,
        *,
        payload: dict[str, Any],
        project: dict[str, Any],
        space_id: str,
        parent_id: str,
        operation_performed: str,
        page: dict[str, Any] | None,
        resolved_title: str,
        warnings: list[str],
        labels_applied: list[str],
        validation: dict[str, bool],
        write_performed: bool,
        dry_run: bool,
        mutation_plan: dict[str, Any] | None,
    ) -> dict[str, Any]:
        page_id = str(page.get("id")) if page and page.get("id") is not None else None
        page_url = self._page_url(page) if page else None
        version = int(page.get("version", {}).get("number", 0)) if page else None
        return {
            "status": "success",
            "project": project.get("project_name"),
            "project_key": project["project_key"],
            "space_key": project["space_key"],
            "space_id": space_id,
            "page_id": page_id,
            "page_title": resolved_title,
            "page_url": page_url,
            "parent_page_id": parent_id,
            "operation_requested": payload["operation"],
            "operation_performed": operation_performed,
            "version": version,
            "labels_applied": labels_applied,
            "warnings": warnings,
            "validation": validation,
            "write_performed": write_performed,
            "dry_run": dry_run,
            "idempotency_key": payload["idempotency_key"],
            "mutation_plan": mutation_plan,
        }

    @staticmethod
    def _page_url(page: dict[str, Any] | None) -> str | None:
        if not page:
            return None
        links = page.get("_links", {})
        base = str(links.get("base") or "").rstrip("/")
        webui = str(links.get("webui") or "")
        if base and webui:
            return base + "/" + webui.lstrip("/")
        return None

    @staticmethod
    def _map_client_error(exc: ClientError) -> WriterError:
        allowed = {
            "permission_denied",
            "authentication_failed",
            "labels_not_supported",
            "version_conflict",
            "rate_limited",
            "content_too_large",
            "tool_unavailable",
            "upstream_api_error",
        }
        code = exc.code if exc.code in allowed else "upstream_api_error"
        actions = {
            "permission_denied": "Grant only the required page/space permission, then retry.",
            "authentication_failed": "Repair runtime authentication without embedding secrets in the skill package.",
            "labels_not_supported": "Disable strict_labels or bind a verified label-write capability.",
            "version_conflict": "Read the latest page version and retry after reviewing concurrent edits.",
            "rate_limited": "Retry later; do not increase retry frequency.",
            "content_too_large": "Reduce content or request a split plan.",
            "tool_unavailable": "Configure a compatible connector or REST adapter.",
            "upstream_api_error": "Inspect the upstream response and retry only if the operation is known to be safe.",
        }
        return WriterError(
            code,
            exc.message,
            retryable=exc.retryable,
            details=exc.details,
            safe_next_action=actions[code],
        )


def load_json_compatible_yaml(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def main() -> int:
    parser = argparse.ArgumentParser(description="Execute confluence_project_write using the REST adapter.")
    parser.add_argument("--input", required=True, help="Path to JSON input payload")
    parser.add_argument("--config", required=True, help="Path to JSON-compatible YAML runtime config")
    parser.add_argument("--registry", default=str(Path(__file__).resolve().parents[1] / "references" / "project_registry.yaml"))
    parser.add_argument("--allow-live-mutation", action="store_true", help="Required in addition to dry_run=false")
    args = parser.parse_args()

    payload = load_json_compatible_yaml(args.input)
    config = load_json_compatible_yaml(args.config)
    if payload.get("dry_run", True) is False and not args.allow_live_mutation:
        result = WriterError(
            "invalid_input",
            "Live mutation requires the explicit --allow-live-mutation CLI flag.",
            safe_next_action="Run dry_run first, then explicitly authorize the live CLI invocation.",
        ).as_result(payload.get("idempotency_key"))
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 2

    client = RestConfluenceClient(config)
    writer = ConfluenceProjectWriter(
        registry=load_registry(args.registry),
        client=client,
        max_content_chars=int(config.get("max_content_chars", 1_000_000)),
    )
    result = writer.execute(payload)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("status") == "success" else 1


if __name__ == "__main__":
    raise SystemExit(main())
