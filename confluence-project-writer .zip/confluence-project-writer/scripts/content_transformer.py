from __future__ import annotations

import copy
import html
import re
import xml.etree.ElementTree as ET
from typing import Iterable

from .errors import WriterError

AC_NS = "http://atlassian.com/content"
RI_NS = "http://atlassian.com/resource/identifier"
ET.register_namespace("ac", AC_NS)
ET.register_namespace("ri", RI_NS)

WRAPPER_OPEN = f'<root xmlns:ac="{AC_NS}" xmlns:ri="{RI_NS}">'
WRAPPER_CLOSE = "</root>"


def _safe_fragment(fragment: str) -> str:
    return fragment.replace("&nbsp;", "&#160;")


def _parse_fragment(fragment: str) -> ET.Element:
    try:
        return ET.fromstring(WRAPPER_OPEN + _safe_fragment(fragment) + WRAPPER_CLOSE)
    except ET.ParseError as exc:
        raise WriterError(
            "malformed_storage_content",
            "Confluence storage content is not a well-formed XML fragment.",
            details={"parser_error": str(exc)},
            safe_next_action="Provide valid Confluence storage-format XML or use content_format=markdown.",
        ) from exc


def _serialize_children(root: ET.Element) -> str:
    return "".join(ET.tostring(child, encoding="unicode", short_empty_elements=True) for child in list(root))


def normalize_storage(fragment: str) -> str:
    fragment = re.sub(r">\s+<", "><", fragment.strip())
    fragment = re.sub(r"\s+", " ", fragment)
    return fragment.strip()


def _inline_markdown(text: str) -> str:
    escaped = html.escape(text, quote=False)
    code_tokens: list[str] = []

    def stash_code(match: re.Match[str]) -> str:
        code_tokens.append(f"<code>{html.escape(match.group(1), quote=False)}</code>")
        return f"@@CODE{len(code_tokens)-1}@@"

    escaped = re.sub(r"`([^`]+)`", stash_code, escaped)

    def link_replace(match: re.Match[str]) -> str:
        label = match.group(1)
        href = html.unescape(match.group(2)).strip()
        if re.match(r"(?i)^(javascript|data|vbscript):", href):
            return label
        return f'<a href="{html.escape(href, quote=True)}">{label}</a>'

    escaped = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", link_replace, escaped)
    escaped = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", escaped)
    escaped = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<em>\1</em>", escaped)
    for index, token in enumerate(code_tokens):
        escaped = escaped.replace(f"@@CODE{index}@@", token)
    return escaped


class ContentTransformer:
    def markdown_to_storage(self, markdown: str) -> str:
        lines = markdown.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        out: list[str] = []
        paragraph: list[str] = []
        in_code = False
        code_language = ""
        code_lines: list[str] = []
        list_type: str | None = None
        list_items: list[str] = []
        index = 0

        def flush_paragraph() -> None:
            nonlocal paragraph
            if paragraph:
                value = " ".join(part.strip() for part in paragraph if part.strip())
                if value:
                    out.append(f"<p>{_inline_markdown(value)}</p>")
                paragraph = []

        def flush_list() -> None:
            nonlocal list_type, list_items
            if list_type and list_items:
                tag = "ul" if list_type == "ul" else "ol"
                out.append(f"<{tag}>" + "".join(f"<li>{_inline_markdown(item)}</li>" for item in list_items) + f"</{tag}>")
            list_type = None
            list_items = []

        while index < len(lines):
            line = lines[index]
            if line.startswith("```"):
                if in_code:
                    code_value = html.escape("\n".join(code_lines), quote=False)
                    language_param = ""
                    if code_language:
                        language_param = (
                            f'<ac:parameter ac:name="language">{html.escape(code_language)}</ac:parameter>'
                        )
                    out.append(
                        '<ac:structured-macro ac:name="code">'
                        + language_param
                        + f"<ac:plain-text-body><![CDATA[{code_value}]]></ac:plain-text-body>"
                        + "</ac:structured-macro>"
                    )
                    in_code = False
                    code_language = ""
                    code_lines = []
                else:
                    flush_paragraph()
                    flush_list()
                    in_code = True
                    code_language = line[3:].strip()
                index += 1
                continue
            if in_code:
                code_lines.append(line)
                index += 1
                continue

            if line.strip().startswith("|") and index + 1 < len(lines):
                separator = lines[index + 1].strip()
                if re.fullmatch(r"\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?", separator):
                    flush_paragraph()
                    flush_list()
                    headers = [cell.strip() for cell in line.strip().strip("|").split("|")]
                    index += 2
                    rows: list[list[str]] = []
                    while index < len(lines) and lines[index].strip().startswith("|"):
                        rows.append([cell.strip() for cell in lines[index].strip().strip("|").split("|")])
                        index += 1
                    table = ["<table><tbody><tr>"]
                    table.extend(f"<th>{_inline_markdown(cell)}</th>" for cell in headers)
                    table.append("</tr>")
                    for row in rows:
                        table.append("<tr>")
                        table.extend(f"<td>{_inline_markdown(cell)}</td>" for cell in row)
                        table.append("</tr>")
                    table.append("</tbody></table>")
                    out.append("".join(table))
                    continue

            heading = re.match(r"^(#{1,6})\s+(.+)$", line)
            if heading:
                flush_paragraph()
                flush_list()
                level = len(heading.group(1))
                out.append(f"<h{level}>{_inline_markdown(heading.group(2).strip())}</h{level}>")
                index += 1
                continue

            unordered = re.match(r"^\s*[-*+]\s+(.+)$", line)
            ordered = re.match(r"^\s*\d+[.)]\s+(.+)$", line)
            if unordered or ordered:
                flush_paragraph()
                current_type = "ul" if unordered else "ol"
                if list_type and current_type != list_type:
                    flush_list()
                list_type = current_type
                list_items.append((unordered or ordered).group(1).strip())
                index += 1
                continue

            if not line.strip():
                flush_paragraph()
                flush_list()
                index += 1
                continue

            if list_type:
                flush_list()
            paragraph.append(line)
            index += 1

        if in_code:
            raise WriterError(
                "conversion_failed",
                "Markdown code fence is not closed.",
                safe_next_action="Close the fenced code block and retry.",
            )
        flush_paragraph()
        flush_list()
        result = "".join(out)
        self.validate_storage(result)
        return result

    def validate_storage(self, fragment: str) -> str:
        lowered = fragment.casefold()
        if "<script" in lowered or "javascript:" in lowered:
            raise WriterError(
                "malformed_storage_content",
                "Unsafe script content is not allowed in Confluence storage fragments.",
                safe_next_action="Remove scripts, event handlers, and unsafe URL schemes.",
            )
        root = _parse_fragment(fragment)
        for element in root.iter():
            for attr_name, attr_value in element.attrib.items():
                local_name = attr_name.rsplit("}", 1)[-1].casefold()
                if local_name.startswith("on") or re.match(r"(?i)^(javascript|data|vbscript):", attr_value.strip()):
                    raise WriterError(
                        "malformed_storage_content",
                        "Unsafe event handler or URL scheme is not allowed.",
                        safe_next_action="Remove executable attributes and unsafe links.",
                    )
        return _serialize_children(root)

    def convert(self, content: str, content_format: str) -> str:
        if content_format == "markdown":
            return self.markdown_to_storage(content)
        if content_format == "storage":
            return self.validate_storage(content)
        raise WriterError(
            "conversion_unavailable",
            "Unsupported content_format.",
            details={"content_format": content_format},
            safe_next_action="Use markdown or storage.",
        )

    def append_storage(self, existing: str, new_fragment: str) -> tuple[str, bool]:
        existing_valid = self.validate_storage(existing)
        new_valid = self.validate_storage(new_fragment)
        if normalize_storage(existing_valid).endswith(normalize_storage(new_valid)):
            return existing_valid, False
        separator = '<hr/><p data-confluence-project-writer="append-separator"></p>'
        merged = existing_valid.rstrip() + separator + new_valid
        return self.validate_storage(merged), True

    def replace_section(self, existing: str, heading_text: str, new_fragment: str) -> str:
        root = _parse_fragment(self.validate_storage(existing))
        replacement_root = _parse_fragment(self.validate_storage(new_fragment))
        children = list(root)
        normalized_heading = self._normalize_plain_text(heading_text)
        matches: list[tuple[int, int]] = []
        for index, child in enumerate(children):
            tag = child.tag.rsplit("}", 1)[-1].casefold()
            match = re.fullmatch(r"h([1-6])", tag)
            if match and self._normalize_plain_text("".join(child.itertext())) == normalized_heading:
                matches.append((index, int(match.group(1))))

        if not matches:
            raise WriterError(
                "section_not_found",
                "The requested section heading was not found.",
                details={"section_heading": heading_text},
                safe_next_action="Provide the exact visible heading text.",
            )
        if len(matches) > 1:
            raise WriterError(
                "section_ambiguous",
                "The requested section heading occurs more than once.",
                details={"section_heading": heading_text, "match_count": len(matches)},
                safe_next_action="Use a unique section heading before replacing content.",
            )

        start, level = matches[0]
        end = len(children)
        for index in range(start + 1, len(children)):
            tag = children[index].tag.rsplit("}", 1)[-1].casefold()
            next_heading = re.fullmatch(r"h([1-6])", tag)
            if next_heading and int(next_heading.group(1)) <= level:
                end = index
                break

        for child in children[start + 1 : end]:
            root.remove(child)
        insert_at = start + 1
        for replacement in list(replacement_root):
            root.insert(insert_at, copy.deepcopy(replacement))
            insert_at += 1
        return self.validate_storage(_serialize_children(root))

    def contains_fragment(self, body: str, expected_fragment: str) -> bool:
        return normalize_storage(self.validate_storage(expected_fragment)) in normalize_storage(self.validate_storage(body))

    @staticmethod
    def _normalize_plain_text(value: str) -> str:
        return re.sub(r"\s+", " ", unicodedata_normalize(value)).strip().casefold()


def unicodedata_normalize(value: str) -> str:
    import unicodedata

    return unicodedata.normalize("NFKC", value)
