from __future__ import annotations

import argparse
import json
from pathlib import Path


def validate(skill_dir: Path) -> list[str]:
    errors = []
    reference = skill_dir / "references" / "agent-agnostic-compatibility.md"
    report_path = skill_dir / "reports" / "agent-compatibility-report.json"
    if not reference.exists():
        errors.append("agent compatibility reference missing")
    if not report_path.exists():
        errors.append("agent compatibility report missing")
        return errors
    report = json.loads(report_path.read_text(encoding="utf-8"))
    if report.get("agent_agnostic_ready") is not True:
        errors.append("agent_agnostic_ready is not true")
    if not report.get("not_guaranteed"):
        errors.append("runtime limitations are not documented")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("skill_dir", nargs="?", default=str(Path(__file__).resolve().parents[1]))
    args = parser.parse_args()
    errors = validate(Path(args.skill_dir).resolve())
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        return 1
    print("agent-agnostic: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
