from __future__ import annotations

import base64
import json
import os
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
from abc import ABC, abstractmethod
from copy import deepcopy
from typing import Any, Callable

from .errors import ClientError

Transport = Callable[[str, str, dict[str, str], bytes | None, float], tuple[int, dict[str, str], bytes]]


class ConfluenceClient(ABC):
    capabilities: dict[str, bool]

    @abstractmethod
    def resolve_space(self, space_key: str) -> list[dict[str, Any]]: ...

    @abstractmethod
    def get_page(self, page_id: str) -> dict[str, Any]: ...

    @abstractmethod
    def list_direct_children(self, page_id: str, cursor: str | None = None) -> dict[str, Any]: ...

    @abstractmethod
    def create_page(self, *, space_id: str, parent_id: str, title: str, body: str) -> dict[str, Any]: ...

    @abstractmethod
    def update_page(
        self,
        *,
        page_id: str,
        status: str,
        title: str,
        body: str,
        version_number: int,
        space_id: str | None = None,
        parent_id: str | None = None,
    ) -> dict[str, Any]: ...

    @abstractmethod
    def get_labels(self, page_id: str) -> list[str]: ...

    @abstractmethod
    def apply_labels(self, page_id: str, labels: list[str]) -> list[str]: ...


class RestConfluenceClient(ConfluenceClient):
    def __init__(
        self,
        config: dict[str, Any],
        *,
        transport: Transport | None = None,
        sleep_fn: Callable[[float], None] = time.sleep,
    ) -> None:
        base_url = str(config.get("confluence_base_url") or "").rstrip("/")
        if not base_url or base_url == "MISSING":
            raise ClientError("tool_unavailable", "CONFLUENCE_BASE_URL is not configured.")
        parsed = urllib.parse.urlparse(base_url)
        if parsed.scheme != "https":
            raise ClientError("tool_unavailable", "Confluence base URL must use HTTPS.")
        allowlist = {str(item).casefold() for item in config.get("host_allowlist", [])}
        if not parsed.hostname or parsed.hostname.casefold() not in allowlist:
            raise ClientError(
                "tool_unavailable",
                "Confluence host is not present in the configured host allowlist.",
                details={"host": parsed.hostname},
            )

        self.base_url = base_url
        self.timeout = float(config.get("timeout_seconds", 15))
        self.max_retries = min(max(int(config.get("max_retries", 2)), 0), 2)
        self.auth_mode = str(config.get("auth_mode") or "MISSING")
        self.token_env = str(config.get("token_env") or "CONFLUENCE_TOKEN")
        self.username_env = str(config.get("username_env") or "CONFLUENCE_USER_EMAIL")
        self.label_write_mode = str(config.get("label_write_mode") or "disabled")
        self.transport = transport or self._urllib_transport
        self.sleep_fn = sleep_fn
        self.capabilities = {"labels_read": True, "labels_write": self.label_write_mode == "v1"}

    def _headers(self) -> dict[str, str]:
        token = os.environ.get(self.token_env)
        if not token:
            raise ClientError("authentication_failed", f"Credential environment variable {self.token_env} is missing.")
        headers = {"Accept": "application/json", "Content-Type": "application/json", "User-Agent": "confluence-project-writer/0.1"}
        if self.auth_mode == "bearer":
            headers["Authorization"] = f"Bearer {token}"
        elif self.auth_mode in {"basic", "api_token"}:
            username = os.environ.get(self.username_env)
            if not username:
                raise ClientError("authentication_failed", f"Username environment variable {self.username_env} is missing.")
            value = base64.b64encode(f"{username}:{token}".encode("utf-8")).decode("ascii")
            headers["Authorization"] = f"Basic {value}"
        else:
            raise ClientError("authentication_failed", "auth_mode must be bearer, basic, or api_token.")
        return headers

    @staticmethod
    def _urllib_transport(
        method: str, url: str, headers: dict[str, str], data: bytes | None, timeout: float
    ) -> tuple[int, dict[str, str], bytes]:
        request = urllib.request.Request(url, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                return response.status, dict(response.headers.items()), response.read()
        except urllib.error.HTTPError as exc:
            return exc.code, dict(exc.headers.items()), exc.read()
        except (urllib.error.URLError, socket.timeout, TimeoutError) as exc:
            raise ClientError(
                "upstream_api_error",
                "Confluence request failed before a reliable response was received.",
                retryable=False,
                details={"error": str(exc), "unknown_write_state": method in {"POST", "PUT"}},
            ) from exc

    def _request(self, method: str, path_or_url: str, payload: dict[str, Any] | list[Any] | None = None) -> dict[str, Any]:
        if path_or_url.startswith("http://") or path_or_url.startswith("https://"):
            url = path_or_url
        else:
            url = urllib.parse.urljoin(self.base_url + "/", path_or_url.lstrip("/"))
        parsed = urllib.parse.urlparse(url)
        base_host = urllib.parse.urlparse(self.base_url).hostname
        if parsed.hostname != base_host:
            raise ClientError("tool_unavailable", "Pagination or API URL escaped the configured Confluence host.")
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        attempts = 0
        while True:
            status, response_headers, body = self.transport(method, url, self._headers(), data, self.timeout)
            if 200 <= status < 300:
                if not body:
                    return {}
                try:
                    result = json.loads(body.decode("utf-8"))
                except json.JSONDecodeError as exc:
                    raise ClientError("upstream_api_error", "Confluence returned invalid JSON.") from exc
                if isinstance(result, dict):
                    result["__response_headers"] = response_headers
                return result
            if status == 401:
                raise ClientError("authentication_failed", "Confluence authentication failed.", status=status)
            if status == 403:
                raise ClientError("permission_denied", "Confluence denied the requested operation.", status=status)
            if status == 404:
                raise ClientError("upstream_api_error", "Confluence resource was not found.", status=status)
            if status == 409:
                raise ClientError("version_conflict", "Confluence rejected the update because of a version conflict.", status=status, retryable=True)
            if status == 413:
                raise ClientError("content_too_large", "Confluence rejected content as too large.", status=status)
            if status == 429 or 500 <= status < 600:
                if attempts >= self.max_retries:
                    code = "rate_limited" if status == 429 else "upstream_api_error"
                    raise ClientError(code, "Confluence transient retry limit was reached.", status=status, retryable=True)
                retry_after = response_headers.get("Retry-After") or response_headers.get("retry-after")
                delay = min(float(retry_after), 5.0) if retry_after and retry_after.replace(".", "", 1).isdigit() else min(0.25 * (2**attempts), 2.0)
                attempts += 1
                self.sleep_fn(delay)
                continue
            raise ClientError("upstream_api_error", f"Confluence returned HTTP {status}.", status=status)

    @staticmethod
    def _next_cursor(payload: dict[str, Any]) -> str | None:
        next_link = payload.get("_links", {}).get("next")
        if not next_link:
            return None
        query = urllib.parse.parse_qs(urllib.parse.urlparse(next_link).query)
        values = query.get("cursor")
        return values[0] if values else None

    def resolve_space(self, space_key: str) -> list[dict[str, Any]]:
        query = urllib.parse.urlencode({"keys": space_key, "status": "current", "limit": 25})
        payload = self._request("GET", f"/wiki/api/v2/spaces?{query}")
        return list(payload.get("results", []))

    def get_page(self, page_id: str) -> dict[str, Any]:
        query = urllib.parse.urlencode({"body-format": "storage", "include-version": "true"})
        return self._request("GET", f"/wiki/api/v2/pages/{urllib.parse.quote(str(page_id))}?{query}")

    def list_direct_children(self, page_id: str, cursor: str | None = None) -> dict[str, Any]:
        params = {"limit": 100}
        if cursor:
            params["cursor"] = cursor
        query = urllib.parse.urlencode(params)
        payload = self._request("GET", f"/wiki/api/v2/pages/{urllib.parse.quote(str(page_id))}/direct-children?{query}")
        return {"results": payload.get("results", []), "next_cursor": self._next_cursor(payload)}

    def create_page(self, *, space_id: str, parent_id: str, title: str, body: str) -> dict[str, Any]:
        payload = {
            "spaceId": str(space_id),
            "status": "current",
            "title": title,
            "parentId": str(parent_id),
            "body": {"representation": "storage", "value": body},
        }
        return self._request("POST", "/wiki/api/v2/pages", payload)

    def update_page(
        self,
        *,
        page_id: str,
        status: str,
        title: str,
        body: str,
        version_number: int,
        space_id: str | None = None,
        parent_id: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "id": str(page_id),
            "status": status,
            "title": title,
            "body": {"representation": "storage", "value": body},
            "version": {"number": int(version_number), "message": "confluence-project-writer update"},
        }
        if space_id is not None:
            payload["spaceId"] = str(space_id)
        if parent_id is not None:
            payload["parentId"] = str(parent_id)
        return self._request("PUT", f"/wiki/api/v2/pages/{urllib.parse.quote(str(page_id))}", payload)

    def get_labels(self, page_id: str) -> list[str]:
        payload = self._request("GET", f"/wiki/api/v2/pages/{urllib.parse.quote(str(page_id))}/labels?limit=100")
        return [str(item.get("name")) for item in payload.get("results", []) if item.get("name")]

    def apply_labels(self, page_id: str, labels: list[str]) -> list[str]:
        if not self.capabilities.get("labels_write"):
            raise ClientError("labels_not_supported", "Label writing is not enabled for this adapter.")
        payload = [{"prefix": "global", "name": label} for label in labels]
        result = self._request("POST", f"/wiki/rest/api/content/{urllib.parse.quote(str(page_id))}/label", payload)
        return [str(item.get("name")) for item in result.get("results", []) if item.get("name")]


class MockConfluenceClient(ConfluenceClient):
    def __init__(
        self,
        *,
        spaces: list[dict[str, Any]] | None = None,
        pages: dict[str, dict[str, Any]] | None = None,
        page_size: int = 100,
        labels_write: bool = True,
    ) -> None:
        self.spaces = deepcopy(spaces or [])
        self.pages = {str(key): deepcopy(value) for key, value in (pages or {}).items()}
        self.page_size = page_size
        self.capabilities = {"labels_read": True, "labels_write": labels_write}
        self.labels: dict[str, list[str]] = {}
        self.mutations: list[dict[str, Any]] = []
        self.next_id = 9000000
        self.simulate_version_conflicts = 0
        self.simulate_permission_denied = False
        self.post_write_corrupt_parent = False
        self.post_write_drop_content = False

    def resolve_space(self, space_key: str) -> list[dict[str, Any]]:
        return [deepcopy(space) for space in self.spaces if space.get("key") == space_key and space.get("status", "current") == "current"]

    def get_page(self, page_id: str) -> dict[str, Any]:
        page_id = str(page_id)
        if page_id not in self.pages:
            raise ClientError("upstream_api_error", "Mock page not found.", status=404)
        return deepcopy(self.pages[page_id])

    def list_direct_children(self, page_id: str, cursor: str | None = None) -> dict[str, Any]:
        page_id = str(page_id)
        children = [
            deepcopy(page)
            for page in self.pages.values()
            if str(page.get("parentId")) == page_id
        ]
        children.sort(key=lambda item: (int(item.get("position", 0)), str(item.get("id"))))
        offset = int(cursor or 0)
        page = children[offset : offset + self.page_size]
        next_offset = offset + self.page_size
        return {"results": page, "next_cursor": str(next_offset) if next_offset < len(children) else None}

    def create_page(self, *, space_id: str, parent_id: str, title: str, body: str) -> dict[str, Any]:
        if self.simulate_permission_denied:
            raise ClientError("permission_denied", "Mock permission denied.", status=403)
        page_id = str(self.next_id)
        self.next_id += 1
        page = {
            "id": page_id,
            "type": "page",
            "status": "current",
            "title": title,
            "spaceId": str(space_id),
            "parentId": str(parent_id),
            "position": len(self.pages),
            "version": {"number": 1},
            "body": {"storage": {"representation": "storage", "value": body}},
            "_links": {"base": "https://example.atlassian.net/wiki", "webui": f"/spaces/X/pages/{page_id}"},
        }
        self.pages[page_id] = page
        self.mutations.append({"operation": "create_page", "page_id": page_id})
        return deepcopy(page)

    def update_page(
        self,
        *,
        page_id: str,
        status: str,
        title: str,
        body: str,
        version_number: int,
        space_id: str | None = None,
        parent_id: str | None = None,
    ) -> dict[str, Any]:
        page_id = str(page_id)
        if self.simulate_permission_denied:
            raise ClientError("permission_denied", "Mock permission denied.", status=403)
        if self.simulate_version_conflicts > 0:
            self.simulate_version_conflicts -= 1
            current = self.pages[page_id]
            current["version"]["number"] += 1
            raise ClientError("version_conflict", "Mock version conflict.", status=409, retryable=True)
        page = self.pages[page_id]
        expected = int(page.get("version", {}).get("number", 0)) + 1
        if int(version_number) != expected:
            raise ClientError("version_conflict", "Mock version conflict.", status=409, retryable=True)
        page["status"] = status
        page["title"] = title
        if space_id is not None:
            page["spaceId"] = str(space_id)
        if parent_id is not None:
            page["parentId"] = str(parent_id)
        page["version"] = {"number": int(version_number)}
        page["body"] = {"storage": {"representation": "storage", "value": body}}
        if self.post_write_corrupt_parent:
            page["parentId"] = "999999"
        if self.post_write_drop_content:
            page["body"]["storage"]["value"] = "<p>corrupted</p>"
        self.mutations.append({"operation": "update_page", "page_id": page_id, "version": version_number})
        return deepcopy(page)

    def get_labels(self, page_id: str) -> list[str]:
        return list(self.labels.get(str(page_id), []))

    def apply_labels(self, page_id: str, labels: list[str]) -> list[str]:
        if not self.capabilities.get("labels_write"):
            raise ClientError("labels_not_supported", "Mock labels unsupported.")
        current = self.labels.setdefault(str(page_id), [])
        for label in labels:
            if label not in current:
                current.append(label)
        self.mutations.append({"operation": "apply_labels", "page_id": str(page_id), "labels": list(labels)})
        return list(current)
