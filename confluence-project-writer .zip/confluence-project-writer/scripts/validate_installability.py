from __future__ import annotations

import argparse
import json
from pathlib import Path


def validate(skill_dir: Path) -> list[str]:
    errors = []
    if not (skill_dir / "SKILL.md").exists():
        errors.append("SKILL.md missing")
    if not (skill_dir / "agents" / "openai.yaml").exists():
        errors.append("agents/openai.yaml missing")
    path = skill_dir / "reports" / "installability-report.json"
    if not path.exists():
        errors.append("installability report missing")
        return errors
    report = json.loads(path.read_text(encoding="utf-8"))
    if report.get("artifact_name") != "skill.zip":
        errors.append("primary artifact must be named skill.zip")
    if report.get("frontend_install_suggestion_status") == "guaranteed":
        errors.append("frontend installation may not be guaranteed")
    if report.get("blocking_issues"):
        errors.append("installability report contains blocking issues")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("skill_dir", nargs="?", default=str(Path(__file__).resolve().parents[1]))
    args = parser.parse_args()
    errors = validate(Path(args.skill_dir).resolve())
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        return 1
    print("installability: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
