from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

VALIDATORS = [
    "validate_package.py",
    "validate_registry.py",
    "validate_source_map.py",
    "validate_evals.py",
    "validate_release_gate.py",
    "validate_installability.py",
    "validate_agent_agnostic.py",
    "validate_core_parity.py",
]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("skill_dir", nargs="?", default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument("--with-tests", action="store_true")
    args = parser.parse_args()
    skill_dir = Path(args.skill_dir).resolve()
    scripts_dir = Path(__file__).resolve().parent
    failures = 0
    for validator in VALIDATORS:
        completed = subprocess.run(
            [sys.executable, str(scripts_dir / validator), str(skill_dir)],
            text=True,
            capture_output=True,
            check=False,
        )
        print(completed.stdout, end="")
        if completed.stderr:
            print(completed.stderr, end="", file=sys.stderr)
        if completed.returncode != 0:
            failures += 1
    if args.with_tests:
        completed = subprocess.run(
            [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
            cwd=skill_dir,
            text=True,
            capture_output=True,
            check=False,
        )
        print(completed.stdout, end="")
        if completed.stderr:
            print(completed.stderr, end="", file=sys.stderr)
        if completed.returncode != 0:
            failures += 1
    if failures:
        print(f"quick-validate: FAIL ({failures} failing stage(s))")
        return 1
    print("quick-validate: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
