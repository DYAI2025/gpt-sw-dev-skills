from __future__ import annotations

import argparse
import json
from pathlib import Path


def validate(skill_dir: Path) -> list[str]:
    path = skill_dir / "reports" / "release-gate-report.json"
    if not path.exists():
        return ["release-gate report missing"]
    report = json.loads(path.read_text(encoding="utf-8"))
    errors = []
    if report.get("release_gate", {}).get("status") != "PASS":
        errors.append("release_gate.status is not PASS")
    if report.get("release_gate", {}).get("allowed_to_package") is not True:
        errors.append("allowed_to_package is not true")
    if report.get("craftsmanship_gate", {}).get("status") != "PASS":
        errors.append("craftsmanship gate failed")
    anti = report.get("anti_confabulation_gate", {})
    if anti.get("status") != "PASS" or anti.get("blocked_claims"):
        errors.append("anti-confabulation gate failed")
    syc = report.get("anti_sycophancy", {})
    if syc.get("score", 99) >= syc.get("threshold", 3):
        errors.append("anti-sycophancy threshold failed")
    if report.get("bias_gate", {}).get("status") == "BLOCKED":
        errors.append("bias gate blocked")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("skill_dir", nargs="?", default=str(Path(__file__).resolve().parents[1]))
    args = parser.parse_args()
    errors = validate(Path(args.skill_dir).resolve())
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        return 1
    print("release-gate: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
