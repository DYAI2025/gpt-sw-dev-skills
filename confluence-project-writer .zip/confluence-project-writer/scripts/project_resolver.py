from __future__ import annotations

import json
import re
import unicodedata
from pathlib import Path
from typing import Any

from .errors import WriterError


def normalize_text(value: str | None) -> str:
    if value is None:
        return ""
    normalized = unicodedata.normalize("NFKC", value)
    normalized = re.sub(r"\s+", " ", normalized).strip().casefold()
    return normalized


def load_registry(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def validate_registry_data(registry: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    projects = registry.get("projects")
    if not isinstance(projects, list) or not projects:
        return ["projects must be a non-empty list"]

    seen: set[str] = set()
    for index, project in enumerate(projects):
        prefix = f"projects[{index}]"
        key = project.get("project_key")
        if not isinstance(key, str) or not re.fullmatch(r"[A-Z0-9]+", key):
            errors.append(f"{prefix}.project_key is invalid")
            continue
        if key in seen:
            errors.append(f"duplicate project_key: {key}")
        seen.add(key)
        status = project.get("status")
        if status == "active" and not project.get("root_page_id"):
            errors.append(f"active project {key} has no root_page_id")
        if status == "active" and not project.get("project_name"):
            errors.append(f"active project {key} has no project_name")
        if not project.get("space_key"):
            errors.append(f"project {key} has no space_key")
    return errors


class ProjectResolver:
    def __init__(self, registry: dict[str, Any]) -> None:
        errors = validate_registry_data(registry)
        if errors:
            raise WriterError(
                "registry_integrity_error",
                "Project registry is invalid.",
                details={"errors": errors},
                safe_next_action="Repair the registry before attempting any write.",
            )
        self.registry = registry

    @property
    def projects(self) -> list[dict[str, Any]]:
        return self.registry["projects"]

    def resolve(
        self,
        *,
        project_hint: str | None,
        content: str,
        page_title: str | None,
        parent_hint: str | None,
    ) -> dict[str, Any]:
        if project_hint and normalize_text(project_hint):
            return self._resolve_exact(project_hint)
        return self._resolve_context(content, page_title, parent_hint)

    def _resolve_exact(self, hint: str) -> dict[str, Any]:
        normalized = normalize_text(hint)
        forbidden_matches: list[str] = []
        for project in self.projects:
            for forbidden in project.get("forbidden_aliases", []):
                if normalized == normalize_text(forbidden):
                    forbidden_matches.append(project["project_key"])
        if forbidden_matches:
            raise WriterError(
                "unknown_project",
                "The supplied project hint is explicitly forbidden for the matching registry entries.",
                details={"forbidden_for": forbidden_matches, "project_hint": hint},
                safe_next_action="Provide the exact canonical project key for the intended product.",
            )

        matches: list[dict[str, Any]] = []
        for project in self.projects:
            values = [project.get("project_key"), project.get("project_name")]
            values.extend(project.get("aliases", []))
            if any(normalized == normalize_text(value) for value in values if value):
                matches.append(project)

        if not matches:
            raise WriterError(
                "unknown_project",
                "Project could not be resolved from the supplied project_hint.",
                details={"project_hint": hint},
                safe_next_action="Provide an exact project_key, project_name, or registered alias.",
            )
        if len(matches) > 1:
            raise WriterError(
                "ambiguous_project",
                "Project hint matches more than one registry entry.",
                project_candidates=[
                    {"project_key": project["project_key"], "confidence": 1.0}
                    for project in matches
                ],
                safe_next_action="Provide the exact project_key.",
            )
        return matches[0]

    def _resolve_context(
        self, content: str, page_title: str | None, parent_hint: str | None
    ) -> dict[str, Any]:
        combined = normalize_text(" ".join(part for part in [content, page_title or "", parent_hint or ""] if part))
        combined_tokens = set(re.findall(r"[\w-]+", combined))
        global_forbidden = sorted({
            normalize_text(value)
            for project in self.projects
            for value in project.get("forbidden_aliases", [])
            if value
        })
        matched_forbidden = [value for value in global_forbidden if value and value in combined]
        if matched_forbidden:
            raise WriterError(
                "ambiguous_project",
                "Content names a product that is explicitly excluded from automatic registry routing.",
                details={"matched_forbidden_aliases": matched_forbidden},
                safe_next_action="Provide the exact registered project_hint for the intended destination or add a confirmed registry entry.",
            )
        candidates: list[dict[str, Any]] = []

        for project in self.projects:
            forbidden = [normalize_text(value) for value in project.get("forbidden_aliases", [])]
            if any(value and value in combined for value in forbidden):
                continue

            phrases = [project.get("project_name"), *project.get("aliases", [])]
            normalized_phrases = [normalize_text(value) for value in phrases if value]
            key = normalize_text(project.get("project_key"))

            score = 0.0
            if any(phrase and phrase in combined for phrase in normalized_phrases):
                score = 0.95
            elif key and re.search(rf"(?<!\w){re.escape(key)}(?!\w)", combined):
                score = 0.92
            else:
                phrase_tokens: set[str] = set()
                for phrase in normalized_phrases:
                    phrase_tokens.update(re.findall(r"[\w-]+", phrase))
                if phrase_tokens:
                    overlap = len(phrase_tokens & combined_tokens) / len(phrase_tokens)
                    if overlap:
                        score = min(0.88, 0.50 + 0.38 * overlap)

            if score > 0:
                candidates.append({"project": project, "confidence": round(score, 3)})

        candidates.sort(key=lambda item: item["confidence"], reverse=True)
        public_candidates = [
            {"project_key": item["project"]["project_key"], "confidence": item["confidence"]}
            for item in candidates[:5]
        ]
        if not candidates:
            raise WriterError(
                "ambiguous_project",
                "Project could not be classified with sufficient evidence.",
                project_candidates=[],
                safe_next_action="Provide an exact project_hint.",
            )

        top = candidates[0]
        second = candidates[1]["confidence"] if len(candidates) > 1 else 0.0
        if top["confidence"] < 0.80 or top["confidence"] - second < 0.15:
            raise WriterError(
                "ambiguous_project",
                "Project could not be uniquely classified above the confidence gates.",
                project_candidates=public_candidates,
                details={"required_confidence": 0.80, "required_margin": 0.15},
                safe_next_action="Provide an exact project_hint.",
            )
        return top["project"]
