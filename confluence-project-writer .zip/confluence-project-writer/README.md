# Confluence Project Writer

Produktionsnahes, agentenagnostisches Skill-Paket für kontrollierte Confluence-Projektmutationen.

## Status

- Paketstatus: validierbar und paketierbar
- Implementierungsstatus: Python-Referenzimplementierung vorhanden
- Mock-Teststatus: bestanden
- Live-Deploymentstatus: Laufzeitkonfiguration fehlt
- Live-Teststatus: nicht autorisiert und nicht ausgeführt
- Releaseentscheidung: `READY_WITH_RUNTIME_CONFIGURATION`

## Schnellstart

```bash
python scripts/quick_validate.py .
python -m unittest discover -s tests -v
python scripts/package_skill.py . ./dist
```

Die Dateien `config.example.yaml` und `references/project_registry.yaml` sind JSON-kompatibles YAML. Dadurch bleibt die Referenzimplementierung ohne externe YAML-Abhängigkeit ausführbar.

## Laufzeit

Für direkten REST-Zugriff:

1. `config.example.yaml` kopieren und Basis-URL, Auth-Modus und Host-Allowlist konfigurieren.
2. Secret ausschließlich über die benannte Umgebungsvariable bereitstellen.
3. Zuerst `dry_run=true` ausführen.
4. Eine reale CLI-Mutation benötigt zusätzlich `--allow-live-mutation`.

```bash
python scripts/confluence_project_write.py \
  --input request.json \
  --config runtime-config.yaml
```

Die Laufzeitbindung und Connector-Grenzen stehen in `references/runtime_binding.md`.
