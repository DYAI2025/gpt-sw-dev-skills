# Evaluation Rubric

A case passes only when the returned machine-readable field equals the expected stable value.

## Hard failures

- any mutation on ambiguous project, parent or target;
- cross-space or out-of-tree mutation;
- replace-section without exactly one heading match;
- append duplication after retry;
- missing version increment;
- success returned without post-write readback;
- live claim based only on mocks.

## Evidence classes

- Pure logic: deterministic function result.
- Dry run: read-only resolution and mutation planning.
- Mock readback: stateful adapter simulation, not live evidence.
- Report read: validation artifact generated from actual local commands.
