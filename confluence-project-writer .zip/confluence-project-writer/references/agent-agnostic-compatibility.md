# Agent-Agnostic Compatibility

The portable core consists of `SKILL.md`, the registry, JSON schemas, pure routing/transform logic, the adapter interface, tests and machine-readable results.

## ChatGPT

Use `agents/openai.yaml` for display metadata. Bind a compatible connector or execute the Python adapter in an allowed runtime.

## Claude Desktop / Claude Code

Use `SKILL.md` as the primary instruction document. Bind Confluence through a verified MCP/HTTP tool or run the Python reference implementation locally. Do not assume OpenAI-specific metadata is interpreted.

## Other frontier agents

Port `ConfluenceClient` and preserve invariants. Tool names, filesystem access, network access, installation UI and permission prompts are runtime-specific and not guaranteed.

## Not tested

No cross-runtime behavioral parity test was executed. This package claims workflow portability, not identical host capabilities.
