# Confluence API Contract

Verified against official Atlassian Confluence Cloud REST documentation on 2026-08-06.

## v2 operations used by the REST reference adapter

| Purpose | Method and path | Notes |
|---|---|---|
| Resolve space key | `GET /wiki/api/v2/spaces?keys=...&status=current` | Expect exactly one current result; use returned `id` as `spaceId`. |
| Read page | `GET /wiki/api/v2/pages/{id}?body-format=storage&include-version=true` | Runtime must expose title, spaceId, parentId, status, version, storage body and links. |
| Direct children | `GET /wiki/api/v2/pages/{id}/direct-children` | Current hierarchy endpoint; filter response to `type=page`; follow cursor pagination. |
| Create page | `POST /wiki/api/v2/pages` | Send `spaceId`, `parentId`, `status`, title and storage body. |
| Update page | `PUT /wiki/api/v2/pages/{id}` | Send id, status, title, body and incremented version; adapter also preserves spaceId/parentId when available. |
| Read labels | `GET /wiki/api/v2/pages/{id}/labels` | Read-only capability. |

Official references:

- https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-space/
- https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-page/
- https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-children/
- https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-label/

## Pagination

The v2 API uses cursor pagination. Continue until no `_links.next` cursor remains. Never assume the first result page contains every child.

## Labels

The v2 label group documents read operations. The official v1 API documents `POST /wiki/rest/api/content/{id}/label` for adding labels. The reference adapter therefore:

- defaults to no label-write capability;
- enables v1 label addition only when runtime configuration explicitly selects `label_write_mode: v1`;
- blocks before page mutation when `strict_labels=true` and write capability is absent.

Official v1 reference:

- https://developer.atlassian.com/cloud/confluence/rest/v1/api-group-content-labels/

## Authentication and permissions

Authentication is runtime configuration. The package never stores credentials. The adapter accepts only HTTPS, checks a host allowlist and reads credentials from environment variables. Required Confluence permissions remain tenant- and authentication-context dependent.

## Reliability mapping

- 401 -> `authentication_failed`, no blind retry.
- 403 -> `permission_denied`, no blind retry.
- 409 -> `version_conflict`, handled by read/merge/retry in the writer.
- 429 -> bounded backoff, maximum two retries.
- transient 5xx -> bounded backoff, maximum two retries.
- unknown write timeout -> no blind mutation retry; state inspection is required.
