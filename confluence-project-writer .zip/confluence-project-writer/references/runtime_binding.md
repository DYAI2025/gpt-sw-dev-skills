# Runtime Binding

## Direct REST

Use `RestConfluenceClient` when the runtime can make outbound HTTPS requests. Configure:

- `confluence_base_url`;
- exact `host_allowlist`;
- `auth_mode`;
- environment-variable names for credentials;
- optional `label_write_mode`;
- timeout and bounded retries.

The CLI blocks `dry_run=false` unless `--allow-live-mutation` is also present.

## Atlassian Connector

Create an adapter that implements `ConfluenceClient`. Map connector actions only after inspecting the actual action schema. Do not infer action names, pagination shapes, body representations or label support.

Required mapping evidence:

- space lookup by canonical key;
- page read including storage body, parent, space and version;
- current direct-children listing with complete pagination;
- create and update payload support;
- post-write page read;
- optional label read/write.

## HTTP-MCP

Treat MCP tools as transport bindings, not as business truth. The MCP tool schema must document inputs, outputs, permission boundary, pagination and error mapping. Keep project routing and mutation decisions in the pure Python/domain layer or equivalent host logic.

## Platform-native tools

If a host cannot run Python, port the interfaces and invariants, not merely the prose. Preserve schemas, registry, exact-match order, confidence gates, version checks, idempotent append and post-write readback.
