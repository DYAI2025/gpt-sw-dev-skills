# Source Policy

## Source classes

- `primary`: official Atlassian API documentation and package/runtime specifications.
- `user_provided`: the attached confluence-project-writer specification and project registry.
- `derived`: implementation decisions and test fixtures created from those sources.
- `uncertain`: runtime connector behavior, tenant settings and missing registry values.

## Hardening rule

User-provided business routing rules are authoritative for this package. Dynamic technical API claims must be checked against official Atlassian documentation or marked `SOURCE_NEEDED`. Runtime connector capabilities must be checked against the actual bound schema.

## Confidence

- 5: direct primary source or explicit fixed business rule.
- 4: strongly supported implementation rule.
- 3: design assumption; document it.
- 1-2: do not operationalize.

## Missing values

Use `MISSING` for absent deployment data. Never invent base URLs, credentials, root IDs or connector actions.
