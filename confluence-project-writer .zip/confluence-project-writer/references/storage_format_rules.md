# Storage Format Rules

## Accepted inputs

- `content_format=storage`: a well-formed Confluence storage XML fragment.
- `content_format=markdown`: converted by the deterministic reference converter.

## Markdown subset

The converter supports:

- headings `#` through `######`;
- paragraphs;
- unordered and ordered lists;
- inline emphasis, strong text and code;
- safe HTTP/HTTPS-style links;
- pipe tables with a separator row;
- fenced code blocks represented as a Confluence code macro.

Advanced macros, embedded apps, arbitrary HTML and vendor-specific extensions are intentionally outside the guaranteed subset. Use verified storage input when exact macro fidelity is required.

## Storage validation

The parser wraps fragments in a temporary namespace-aware XML root. It rejects:

- malformed XML;
- script elements;
- event-handler attributes;
- `javascript:`, `data:` or `vbscript:` URL schemes.

## Append

Append validates both fragments, checks whether the normalized new fragment already occurs at the end, and only then adds a stable separator. This makes retries idempotent for identical normalized append content.

## Section replacement

1. Parse the full fragment as XML.
2. Find heading elements `h1` through `h6` by exact normalized visible text.
3. Require exactly one match.
4. Remove following siblings until the next heading at the same or higher level.
5. Insert parsed replacement nodes.
6. Revalidate the serialized fragment.

Regex is not used as the sole parser for the full page body.
