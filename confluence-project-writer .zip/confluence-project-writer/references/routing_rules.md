# Routing Rules

## Project resolution order

1. Unicode NFKC normalization.
2. Trim and whitespace collapse.
3. Case-insensitive exact `project_key` match.
4. Exact `project_name` match.
5. Exact explicit alias match.
6. Never match `forbidden_aliases` positively.
7. Without a hint, score only projects already present in the registry.
8. Require confidence >= 0.80 and margin >= 0.15.

The reference classifier intentionally uses conservative registry phrase and token evidence. It is not a general-purpose embedding classifier and cannot create a new project mapping.

## Registry status

- `active`: regular operations allowed after space/root verification.
- `initialization_required`: regular writes blocked; `allow_initialization` is insufficient by itself.
- `blocked_missing_registry_data`: all writes blocked.

## Parent resolution

- Missing or `root`: canonical root page.
- Numeric ID: page must share the resolved `spaceId` and reach the canonical root through its parent chain.
- Text: exact normalized title among direct children of the root only.
- Fuzzy similarity is diagnostic output only.

## Target resolution

Search direct children of the resolved parent only. Normalize Unicode whitespace and typographic dashes. Compare the unnumbered title component separately. Multiple matches are a hard duplicate/ambiguity error.

## Operation routing

| Requested | Existing target | Result |
|---|---:|---|
| `auto` | yes | `append_to_existing` |
| `auto` | no | `create_child` |
| `create_child` | yes | `duplicate_title` |
| `append_to_existing` | no | `target_not_found` |
| `replace_section` | no | `target_not_found` |

`replace_section` is never inferred from `auto`.

## Numbering

Pattern: `^\s*(\d{2,})\s*[–-]\s+(.+)$`

A numbering convention is clear when all page siblings are numbered, or at least two are numbered and at least 60 percent match. Use `max + 1`; do not fill gaps. Preserve an already numbered incoming title. Mixed unclear trees retain the requested title and add `mixed_numbering_convention`.
