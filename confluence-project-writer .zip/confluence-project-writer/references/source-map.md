# Source Map

| ID | Source | Type | Purpose | Confidence | Limitations |
|---|---|---|---|---:|---|
| S1 | User-provided `Eingefügter Text.txt` | user_provided | Canonical registry, routing, schemas, tests, safety and release requirements | 5 for project business rules | Template fields for platform, runtime and integration were not filled |
| S2 | Atlassian Confluence Cloud REST API v2 - Space | primary | Resolve space key to spaceId | 5 | Runtime permissions and tenant data are not available |
| S3 | Atlassian Confluence Cloud REST API v2 - Page | primary | Read, create and update pages | 5 | No live tenant verification |
| S4 | Atlassian Confluence Cloud REST API v2 - Children | primary | Current direct-children endpoint and pagination | 5 | Connector mappings may differ |
| S5 | Atlassian Confluence Cloud REST API v2 - Label | primary | Page-label read capability | 5 | No v2 page-label write operation documented in inspected group |
| S6 | Atlassian Confluence Cloud REST API v1 - Content labels | primary | Optional explicit label-write adapter | 5 | Must be enabled deliberately and authorized |
| S7 | Enterprise Skill Creator policies | primary_internal | Package, release, installability and agent-handoff gates | 5 | Does not guarantee client UI behavior |
| S8 | Generated unit and mock fixtures | derived | Reproducible behavior verification | 4 | Mock tests are not live Confluence evidence |

Official technical locations:

- https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-space/
- https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-page/
- https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-children/
- https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-label/
- https://developer.atlassian.com/cloud/confluence/rest/v1/api-group-content-labels/
