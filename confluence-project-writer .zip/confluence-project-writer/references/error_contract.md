# Error Contract

Every failure returns `status=error`, a stable `error_code`, `retryable`, `write_performed`, diagnostic details and one safe next action.

| Code | Meaning | Mutation allowed before return |
|---|---|---|
| `invalid_input` | Schema or conditional input rule failed | no |
| `unknown_project` | Exact project hint is not registered or is forbidden | no |
| `ambiguous_project` | Confidence or margin gate failed | no |
| `project_not_active` | Registry entry is blocked | no |
| `initialization_required` | Separate root initialization is needed | no |
| `space_not_found` | Canonical space could not be uniquely resolved | no |
| `root_not_found` | Canonical root is unavailable | no |
| `registry_integrity_error` | Root/space or registry invariant failed | no |
| `ambiguous_parent` | More than one exact parent match | no |
| `parent_not_found` | Parent is outside tree or absent | no |
| `target_not_found` | Append/replace target absent | no |
| `duplicate_title` | Duplicate normalized sibling title | no |
| `mixed_numbering_convention` | Reserved error code; current implementation emits a warning and preserves title | no |
| `conversion_unavailable` | Unsupported conversion path | no |
| `conversion_failed` | Deterministic conversion failed | no |
| `malformed_storage_content` | Invalid or unsafe storage fragment | no |
| `section_not_found` | Exact section missing | no |
| `section_ambiguous` | Section heading duplicated | no |
| `permission_denied` | Upstream 403 | no new retry |
| `authentication_failed` | Upstream 401 or missing runtime credential | no |
| `labels_not_supported` | Strict labels requested without capability | no |
| `version_conflict` | Expected version or bounded rebase failed | no successful mutation claimed |
| `rate_limited` | Bounded 429 retry limit reached | no blind continuation |
| `content_too_large` | Guard or upstream size limit | no silent split |
| `tool_unavailable` | Adapter or runtime configuration missing | no |
| `upstream_api_error` | Classified upstream/runtime failure | depends on known state; default false |
| `post_write_validation_failed` | Readback differs after a real mutation | yes, explicitly reported |
