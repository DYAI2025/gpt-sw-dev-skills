# Evaluation Design

## Deterministic tests

The test suite covers the 36 mandatory scenarios plus schema, unsafe storage and strict-label preflight checks. It uses only standard-library `unittest` and a stateful mock adapter.

## Trigger evaluations

`evals/trigger_queries.json` contains should-trigger and should-not-trigger prompts. Trigger tests verify that the skill is selected for controlled Confluence project writes, not for generic writing or destructive administration.

## Output evaluations

`evals/output_evals.json` verifies stable output properties: exact error codes, no mutation on ambiguity, dry-run plans, correct operation routing and post-write validation failures.

## Read-only evaluation cases

`evals/eval_cases.jsonl` uses fixture analysis and dry-run behavior only. It does not require a live Confluence write. Each expected answer is a single stable value for direct comparison.

## Live tests

Live tests are excluded until all of the following are present:

- actual connector/REST schema;
- base URL and authentication configuration;
- explicit live-test authorization;
- approved test space and parent;
- permission for the specific create/update action.
