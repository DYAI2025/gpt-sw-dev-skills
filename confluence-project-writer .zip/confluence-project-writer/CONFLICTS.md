# Conflicts and Safe Resolutions

## Connector-Schema fehlt

Konflikt: Die Spezifikation priorisiert das tatsächlich gebundene Tool-Schema, aber kein Tool-Schema wurde geliefert.

Sichere Auflösung: Eine klare `ConfluenceClient`-Schnittstelle, ein Mock-Adapter und ein REST-v2-Referenzadapter wurden implementiert. Connector-spezifische Behauptungen bleiben Laufzeitkonfiguration.

## Label-Schreiben

Konflikt: Confluence REST API v2 dokumentiert das Lesen von Seitenlabels, aber keinen v2-Schreibendpunkt für Seitenlabels. Ein v1-Endpunkt zum Hinzufügen von Inhaltslabels ist offiziell dokumentiert.

Sichere Auflösung: Label-Schreiben ist standardmäßig deaktiviert. Der REST-Adapter aktiviert den v1-Endpunkt nur bei explizitem `label_write_mode: v1`. `strict_labels=true` blockiert vor der Seitenmutation, wenn diese Capability fehlt.

## Zielplattform und Runtime

Konflikt: Die Promptvorlage enthält ungefüllte Alternativen für Plattform und Runtime.

Sichere Auflösung: Das Paket ist agentenagnostisch formuliert und enthält eine Python-Standardbibliothek-Referenzimplementierung. `agents/openai.yaml` ergänzt ChatGPT-Metadaten, ist aber nicht die fachliche Laufzeitquelle.

## Live-Test

Konflikt: Keine autorisierte Testseite und keine Live-Testfreigabe liegen vor.

Sichere Auflösung: Keine Live-Mutation. Alle Laufzeitnachweise sind als Unit- oder Mock-Integrationstest gekennzeichnet.
