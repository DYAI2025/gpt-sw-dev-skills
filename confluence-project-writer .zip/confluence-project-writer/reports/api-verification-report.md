# API Verification Report

Date: 2026-08-06

## Verified official operations

- v2 `GET /spaces` supports filtering by space keys and returns space IDs.
- v2 `GET /pages/{id}` supports storage-body and page metadata retrieval.
- v2 `POST /pages` creates a page using `spaceId`, optional `parentId`, title and body.
- v2 `PUT /pages/{id}` requires id, status, title, body and version.
- v2 `GET /pages/{id}/direct-children` is the current direct-child hierarchy operation; the older child-pages operation is deprecated.
- v2 list operations use cursor pagination.
- v2 exposes page-label reads.
- v1 officially exposes adding labels to content.

## Runtime deviations

- No actual connector or MCP schema was supplied.
- No live tenant responses were inspected.
- Label writing is therefore opt-in and not assumed.

## Technical truth sources

Official Atlassian documentation listed in `references/source-map.md` and `references/confluence_api_contract.md`.
