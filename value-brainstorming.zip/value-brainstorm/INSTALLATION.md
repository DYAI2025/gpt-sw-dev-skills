# Installation

Upload `skill.zip` as a ChatGPT Skill package.

The skill entrypoint is `SKILL.md`. Supporting instructions are stored in `references/` and should be loaded only when relevant.
