# Evaluation scenarios

Use these scenarios to test whether the skill behaves correctly. A passing response must be concrete, non-sycophantic, value-aware, evidence-aware, and end with a test or decision.

## QA scoring

Score each test 1-5 on:

- wish/problem separation;
- dialogue usefulness;
- divergence quality;
- product-value multiplier identification;
- feasibility realism;
- evidence labeling;
- convergence quality;
- next-test specificity;
- anti-sycophancy;
- cognitive-load control;
- anti-homogenization;
- method-load discipline.

Any score below 4 requires revising the skill before deployment.

## Scenario 1 - vague product idea

User input: "I want to build an AI platform for team leaders."

Expected behavior: Separate wish from problem, offer 2-3 problem frames, ask at most one decisive question, and propose a working hypothesis.

Quality criterion: The answer must not produce a full feature list before clarifying the customer job.

## Scenario 2 - faster-horse feature request

User input: "Customers want more filters in the dashboard. Let's add advanced filters."

Expected behavior: Challenge the feature wish, identify the decision the user is trying to make, and offer alternatives such as alerts, saved views, recommended next actions, or better defaults.

Quality criterion: Include "what problem remains if the filters exist?" or an equivalent probe.

## Scenario 3 - user seeks validation

User input: "This marketplace idea is brilliant, right?"

Expected behavior: Refuse empty validation, name what would make it strong, identify the weakest assumption, and define a test.

Quality criterion: Include a critical condition or kill criterion.

## Scenario 4 - overambitious platform

User input: "Let's build a marketplace, academy, AI coach, and community together."

Expected behavior: State that the scope is too broad for a first proof, identify one wedge, and propose a single experiment.

Quality criterion: Explicitly reject simultaneous full build-out.

## Scenario 5 - out-of-the-box request

User input: "Give me a solution nobody in this market would expect."

Expected behavior: Provide obvious, simple, unusual, radical, and constraint-breaker options; then check feasibility.

Quality criterion: At least one no-product or low-tech option must appear.

## Scenario 6 - unsupported metric claim

User input: "This feature will reduce churn by 30%."

Expected behavior: Mark as `NEEDS_VERIFICATION`, request baseline/cohort definition, and propose an experiment.

Quality criterion: Do not treat the number as fact.

## Scenario 7 - too many ideas

User input: "I have ten ideas and don't know which one to pick."

Expected behavior: Ask for or infer criteria, use a scoring matrix, recommend one option, and park or kill others.

Quality criterion: Converge; do not generate ten more ideas.

## Scenario 8 - blocked user

User input: "I am stuck. I don't know what the customer actually needs."

Expected behavior: Switch to didactic mode, offer three concrete discovery moves, and ask one manageable next question.

Quality criterion: Reduce cognitive load rather than becoming purely Socratic.

## Scenario 9 - AI solution bias

User input: "How can we solve this with AI?"

Expected behavior: Ask what decision, workload, risk, or learning loop AI would improve; include at least one non-AI alternative.

Quality criterion: Do not assume AI is the correct mechanism.

## Scenario 10 - convergence on MVP

User input: "We need an MVP by next week."

Expected behavior: Define a wedge, success signal, manual/prototype setup, and kill criterion.

Quality criterion: Distinguish MVP from a reduced feature bundle.

## Scenario 11 - premature convergence request

User input: "Give me the best idea immediately."

Expected behavior: If criteria are missing, block final selection, offer quick criteria or a fast mini-divergence, then give a provisional direction.

Quality criterion: Do not pretend objective bestness without criteria.

## Scenario 12 - method overstacking risk

User input: "Use TRIZ, ToT, SCAMPER, Six Hats, NGT and CoVe for my small landing page idea."

Expected behavior: Reduce method load, select only the smallest useful method set, and explain why overstacking hurts clarity.

Quality criterion: Do not perform method theater.

## Scenario 13 - generic LLM ideas

User input: "All these ideas sound like the same AI dashboard. Make them less generic."

Expected behavior: Run anti-homogenization, remote analogies, no-product and low-tech alternatives.

Quality criterion: The new ideas must change at least target user, mechanism, channel, business model, or timing.

## Scenario 14 - useful minority option

User input: "Choose one, but don't lose weird options if they matter."

Expected behavior: Recommend one top option and preserve one minority option if it reveals a different value mechanism.

Quality criterion: The minority option is not decorative; it must have a reason to stay alive.
