# Creativity methods for deep ideation

Use only when the standard value-discovery workflow is not enough: explicit out-of-the-box request, generic ideas, hard contradiction, stakeholder conflict, or complex option tree.

## Anti-Homogenization Pass

Use when ideas feel like variants of the same pattern.

Check whether the ideas share:

- same user;
- same business model;
- same metaphor;
- same channel;
- same UI shape;
- same data dependency;
- same AI-first assumption;
- same promise language.

Then force at least one alternative from each category:

- no-product;
- low-tech/manual;
- process/default change;
- pricing/packaging change;
- trust/proof artifact;
- service wedge;
- opposite user or opposite timing;
- remote analogy.

## Remote Analogies

Generate mechanisms, not decorative metaphors.

Recommended domains:

- logistics/operations: routing, batching, handoff reduction, exception handling;
- games/learning: levels, feedback loops, quests, practice scaffolds;
- healthcare/safety: triage, prevention, monitoring, escalation;
- hospitality/service: concierge, anticipation, ritual, reassurance;
- finance/risk: hedging, portfolio, insurance, audit trail;
- craft/tools: jigs, templates, guided setup, repeatable patterns.

For each analogy, state:

- source domain;
- transferable mechanism;
- adapted idea;
- value multiplier;
- smallest test.

## SCAMPER

Use when improving a known idea.

Prompts:

- Substitute: What component, user, channel, or medium can be replaced?
- Combine: What adjacent job or artifact can merge with it?
- Adapt: What proven mechanism from another domain fits?
- Modify: What can be exaggerated, reduced, slowed, or made visible?
- Put to another use: Who else has the same hidden problem?
- Eliminate: What step, feature, decision, or onboarding can disappear?
- Reverse: What if the flow, responsibility, or timing is inverted?

Do not output all seven if three are enough.

## Geneplore

Use when the user wants genuinely new concept forms.

Generate:

- preinventive structures;
- metaphors;
- functional principles;
- tension axes;
- possible artifact forms;
- exploration prompts.

Keep output grounded by attaching each concept to a value multiplier and smallest test.

## TRIZ-style contradiction

Use when two desirable properties conflict.

Steps:

1. State the contradiction: "We want more X without more Y."
2. Classify: technical, physical, organizational, semantic.
3. Test separations:
   - time: complex at setup, simple in use;
   - space: expert back office, simple frontstage;
   - state: adaptive complexity only when needed;
   - system level: powerful system behind simple interface.
4. Convert into product, process, service, pricing, or default move.
5. Define smallest test.

## PTFA / Six-perspective check

Use for group, stakeholder, acceptance, or decision conflict.

- Facts: what is known?
- Feelings/acceptance: what fear, desire, or resistance matters?
- Risks: what can fail?
- Benefits: what becomes better if it works?
- Alternatives: what frame is missing?
- Process: what decision is needed now?

## Tree-of-options controller

Use for complex option spaces.

1. Generate 3-5 branches.
2. Mark each `promising`, `uncertain`, or `dead-end`.
3. Expand only promising/uncertain branches.
4. Stop when new branches stop changing the decision.
5. Synthesize strongest components into one target path.

Avoid pretending the tree is exhaustive.
