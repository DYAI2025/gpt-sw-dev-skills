# Value multiplier playbook

Use this reference when the task involves customer problems, product strategy, MVPs, value propositions, offers, adoption, pricing, retention, or feature prioritization.

## Faster-horse guardrail

A stated customer wish is input evidence, not a final solution. Convert it into a deeper problem before designing.

Ask:

1. What are they trying to get done?
2. What cost, delay, risk, confusion, embarrassment, or coordination pain is hidden in the request?
3. What would still be broken if we built exactly what they asked for?
4. What smaller intervention would change the outcome faster?
5. Is the request a symptom of bad defaults, unclear decision support, missing trust, or poor timing?

## Customer-problem map

| Dimension | Diagnostic question | Strong signal |
|---|---|---|
| Functional job | What task or progress is blocked? | user already spends time, money, or workarounds |
| Emotional job | What fear, stress, pride, or confidence issue matters? | user avoids action or seeks reassurance |
| Social job | How does the user need to appear to others? | approval, status, credibility, accountability |
| Timing | When does pain peak? | urgent moment, deadline, handoff, recurring cycle |
| Constraint | What prevents the obvious solution? | budget, skills, regulation, attention, politics |
| Current workaround | What do they do now? | spreadsheets, meetings, manual checks, hacks |

## Value multipliers

| Multiplier | What it changes | Example moves |
|---|---|---|
| Time compression | faster path to first useful outcome | defaults, pre-filled setup, concierge start |
| Risk reduction | lower fear of loss or failure | reversible trial, audit trail, guarantees, previews |
| Cognitive load reduction | fewer decisions and less interpretation | recommendations, ranking, summaries, single next action |
| Coordination reduction | fewer handoffs, meetings, approvals | shared state, decision packet, role-specific view |
| Trust creation | higher confidence in output or provider | evidence, provenance, transparent limits, examples |
| Switching-friction removal | easier move from current workaround | imports, migration-lite, compatibility, bridge workflow |
| Compounding reuse | one effort pays repeatedly | templates, saved views, learning memory, reusable assets |
| Visibility of progress | progress becomes tangible | scorecards, before-after snapshots, milestone proof |
| Distribution leverage | value spreads through channels or roles | shareable artifact, referral, embedded deliverable |
| Learning loop | use improves product or user behavior | feedback capture, analytics, adaptive recommendations |

## Wedge selection

A good first wedge is not the smallest feature. It is the smallest intervention that proves a meaningful value mechanism.

Use this filter:

- Who feels the pain most sharply?
- What moment concentrates the pain?
- What one outcome would make them believe?
- Can this be tested manually or with a thin prototype?
- What evidence would kill the idea quickly?

## Anti-patterns

- Building dashboards when the customer needs a decision.
- Building automation before understanding exception handling.
- Building a platform before proving one repeated transaction.
- Building personalization before proving baseline value.
- Adding AI where a checklist, default, template, or service would solve the job.
- Treating expressed willingness as payment evidence.
- Treating novelty as differentiation without switching reason.

## Product-value answer checklist

Include:

1. stated wish;
2. suspected real problem;
3. value multiplier opportunity;
4. one obvious solution;
5. one simpler solution;
6. one unconventional solution;
7. recommended wedge;
8. smallest test and kill criterion.
