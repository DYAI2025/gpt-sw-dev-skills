# Extraction map for Value Brainstorm v2

This file documents which parts were extracted from the second skill and why. It supports auditability and future maintenance.

## Baseline retained from the current value-discovery skill

| Part | Decision | Reason |
|---|---|---|
| Wish is not problem | retained as core | strongest protection against faster-horse feature traps |
| Customer job and problem framing | retained as core | keeps ideation tied to real user progress |
| Value multiplier playbook | retained as core | differentiates value creation from feature volume |
| MVP wedge selection | retained as core | prevents overbuilt first releases |
| Evidence labels | retained as core | reduces unsupported certainty |
| Existing portfolio scoring criteria | retained and extended | stronger than second skill scoring because it includes problem clarity and value multiplier |

## Extracted from the second skill

| Extracted part | Exact target in v2 | Why it improves the skill | Risk if overused |
|---|---|---|---|
| Phasenwächter | `references/phase-gates.md` and SKILL phase gates | prevents mixing intake, divergence, ranking, and final recommendation | can feel rigid if used for tiny questions |
| `PREMATURE_CONVERGENCE` gate | SKILL phase gates + eval scenario 11 | prevents fake best-answer selection before criteria/divergence | may slow urgent decisions unless provisional recommendation is allowed |
| `METHOD_OVERSTACKING` gate | SKILL principles + phase-gates + eval scenario 12 | prevents method theater and cognitive overload | may underuse methods if interpreted too strictly |
| `LLM_HOMOGENIZATION_RISK` gate | SKILL phase gates + creativity methods + eval scenario 13 | prevents generic AI-dashboard sameness | can overemphasize weirdness over value |
| `QUESTION_SPAM` gate | SKILL principles + phase-gates | keeps responses action-oriented | may miss a needed clarification in high-ambiguity cases |
| Minority option retention | SKILL convergence + templates + eval scenario 14 | preserves non-obvious search spaces during ranking | can keep weak ideas alive if not justified |
| Remote analogies | `references/creativity-methods.md` | creates genuinely different mechanisms | decorative metaphors if not tied to value multipliers |
| SCAMPER | `references/creativity-methods.md` | improves existing concepts without restarting discovery | can produce shallow variants |
| Geneplore | `references/creativity-methods.md` | useful for new metaphors and artifact forms | can become too abstract without smallest test |
| TRIZ-style contradiction | `references/creativity-methods.md` and routing | handles trade-offs like power vs simplicity | fake precision if treated as formal TRIZ certification |
| PTFA/Six-perspective check | `references/creativity-methods.md` and routing | useful for stakeholder and acceptance dynamics | too heavy for simple ideas |
| Tree-of-options controller | `references/creativity-methods.md` | disciplined search for complex option spaces | can imply exhaustiveness if not caveated |
| Idea card template | output templates | improves compact transfer of a concept | redundant if full response already used |
| Claim verification table | output templates | stronger handling of unsupported claims | can slow ideation if applied to every small claim |
| Added QA scenarios | evaluation scenarios 11-14 | tests the new add-ons directly | no automated runtime test unless separately scripted |

## Not extracted

| Part | Reason |
|---|---|
| Complete second skill as parallel skill | trigger overlap and routing collisions |
| Full 10+10+10 divergence engine as default | too much output for normal discovery turns |
| Second scoring script as-is | weaker semantic model; field meanings less clear for risk/effort |
| All output templates | redundant with value-discovery templates |
| Installation instructions from second skill | not relevant to runtime behavior |

## Expected delta toward 88/100

| Improvement area | Previous estimate | V2 expected | Added mechanism |
|---|---:|---:|---|
| Product-value focus | 9 | 9 | retained current core |
| Creative divergence | 7 | 8.5 | remote analogies, Geneplore, SCAMPER, anti-homogenization |
| Method discipline | 7 | 9 | method-overstacking gate |
| Anti-genericness | 6.5 | 8.5 | LLM homogenization gate |
| Convergence quality | 8.5 | 9 | minority option + expanded scoring |
| Cognitive-load control | 8 | 9 | phase gates + question-spam gate |
| Evidence hygiene | 8.5 | 9 | claim verification table |
| Runtime proof | unverified | unverified | no live GPT eval performed |

The 88/100 target is an architectural estimate, not a measured benchmark.
