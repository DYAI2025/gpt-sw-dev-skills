# Phase gates and failure controls

Use this reference when the conversation risks mixing intake, ideation, evaluation, and decision.

## Phasenwächter

| Phase | Erlaubt | Blockiert |
|---|---|---|
| INTAKE | Verstehen, spiegeln, fehlende Daten markieren | Ideenflut |
| FRAME | Challenge-Fragen, Scope, Constraints | finale Lösung |
| DIVERGE | Ideencluster, Analogien, Gegenideen | Ranking, Machbarkeitsmatrix |
| EXPAND | Varianten, Kombinationen, Widersprüche | endgültige Empfehlung |
| CONVERGE | Bewertung, Clustering, Auswahl | neue Ideenschwemme |
| VERIFY | Claims, Evidenzstatus, Risiken | rhetorische Glättung |
| PACKAGE | Testplan, Entscheidung, nächste Schritte | unbelegte Done-Claims |

## Failure gates

| Gate | Trigger | Required action |
|---|---|---|
| `PREMATURE_CONVERGENCE` | Ranking starts before meaningful divergence. | Return to DIVERGE and generate independent idea clusters. |
| `SOURCE_NEEDED` | Consequential factual claim lacks active evidence. | Mark `NEEDS_VERIFICATION`; ask for or perform source check if available. |
| `METHOD_OVERCLAIM` | Heuristic is presented as proven universal method. | Weaken claim; mark as practice heuristic or assumption. |
| `METHOD_OVERSTACKING` | Too many methods obscure the current decision. | Select the smallest method set that improves the next decision. |
| `LLM_HOMOGENIZATION_RISK` | Ideas share same business model, metaphor, target group, or implementation pattern. | Run anti-fixation and remote-analogy pass. |
| `USER_AUTONOMY_LOSS` | Agent decides values/context instead of the user. | Provide options and decision criteria; let user choose. |
| `FAKE_EVALUATION` | LLM scores ideas without criteria or countercheck. | Apply rubric, expose assumptions, and include a minority option. |
| `CONTEXT_OVERLOAD` | Too many ideas, methods, or sources obscure the goal. | Pin a compact context snapshot and restate the current decision. |
| `QUESTION_SPAM` | More than three questions without a concrete proposal. | Stop asking; make a provisional recommendation. |

## Bias countermeasures

| Bias | Countermeasure |
|---|---|
| Anchoring | Park the first idea and generate alternatives before evaluation. |
| Confirmation bias | Force a counterhypothesis and red-team pass. |
| Authority bias | Treat role voices as anonymous inputs before ranking. |
| Availability bias | Ask for examples from distant domains or current sources where needed. |
| LLM genericness | Run semantic redundancy and anti-cliche checks. |
| Overconfidence | Add confidence levels and `NEEDS_VERIFICATION`. |
| Completion pressure | Insert a phase gate before final recommendation. |

## Method load rule

When a user requests many methods, choose at most two primary methods plus one verification step. Explain that overstacking can make the answer look rigorous while reducing decision clarity.
