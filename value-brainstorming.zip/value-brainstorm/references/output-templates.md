# Output templates

Select the smallest template that advances the conversation. Do not use all templates at once.

## Full value-brainstorm response

```markdown
## Spiegelung
[2-4 sentences]

## Problem statt Wunsch
- Stated wish: ...
- Suspected real problem: ...
- Target user: ...
- Success signal: ...
- Evidence status: ...

## Drei Richtungen
| Richtung | Kernidee | Werthebel | Hauptrisiko |
|---|---|---|---|
| Obvious | ... | ... | ... |
| Simpler | ... | ... | ... |
| Unusual/Radical | ... | ... | ... |

## Realitätscheck
- Strongest assumption: ...
- Weakest point: ...
- Needs verification: ...

## Empfehlung
I recommend ..., because ...
Rejected alternative: ..., because ...
Geparkte Minderheitsoption: ...

## Kleinster Test
- Test: ...
- Sample: ...
- Setup: ...
- Success signal: ...
- Kill criterion: ...

## Offene Annahmen
- ...
```

## Wish-problem split

```markdown
## Wunsch
[what the user/customer asked for]

## Vermutetes eigentliches Problem
[underlying job/pain/risk]

## Was am Wunsch verdächtig ist
[why the requested feature may be a proxy]

## Alternativen
1. Build the wish: ...
2. Solve the job more directly: ...
3. Remove the need for the wish: ...

## Nächster Klärungstest
[one interview question, prototype, or data check]
```

## Idea card

```markdown
## Ideenkarte
- Idee:
- Zielnutzer:
- Problem:
- Nutzenversprechen:
- Werthebel:
- Ungewöhnlicher Kern:
- Hauptannahme:
- Risiko:
- Kleinster Test:
- Erfolgssignal:
- Kill-Kriterium:
- Evidenzstatus:
```

## Value multiplier map

```markdown
| Hebel | Relevanz 1-5 | Warum | Test |
|---|---:|---|---|
| Time compression | ... | ... | ... |
| Risk reduction | ... | ... | ... |
| Cognitive load | ... | ... | ... |
| Coordination | ... | ... | ... |
| Trust | ... | ... | ... |
| Reuse/compounding | ... | ... | ... |
```

## Feasibility and value matrix

```markdown
| Option | User value | Problem clarity | Feasibility | Testability | Effort | Risk | Differentiation | Value multiplier | Next-test readiness | Verdict |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| A | 1-5 | 1-5 | 1-5 | 1-5 | 1-5 | 1-5 | 1-5 | 1-5 | 1-5 | pursue / test_or_refine / park / kill |
```

## Claim verification table

```markdown
| Claim | Status | Prüffrage | Quelle nötig? | Risiko, wenn falsch | Confidence 1-5 |
|---|---|---|---|---|---:|
| ... | FACT_KNOWN / ASSUMPTION / NEEDS_VERIFICATION | ... | ja/nein | ... | ... |
```

## Test plan

```markdown
## Testplan
- Hypothese:
- Zielgruppe:
- Testformat:
- Aufwand:
- Erfolgssignal:
- Kill-Kriterium:
- Entscheidung nach Test:
```

## Decision note

```markdown
## Entscheidungsnotiz
- Entscheidung:
- Begründung:
- Akzeptierte Annahmen:
- Verworfene Optionen:
- Geparkte Minderheitsoption:
- Nächster überprüfbarer Schritt:
```
