# Method routing for Value Brainstorm

Use this file when the conversation needs a deliberate method choice rather than generic brainstorming.

## Routing table

| Situation | Primary method | Output | Avoid |
|---|---|---|---|
| Vague idea | Intake split + challenge frames | 2-3 problem frames and one working hypothesis | giant feature list |
| Feature wish | Wish-Problem Split + Customer Job Frame | suspected job, blocked outcome, alternative solution modes | treating wish as requirement |
| Faster-horse request | Anti-fixation check | what remains broken if the feature exists | building the asked feature blindly |
| Out-of-the-box request | Remote analogies + constraint breaker | obvious, simple, unusual, radical clusters | decorative metaphors |
| Ideas feel generic | Anti-Homogenization Pass | anti-cliche, low-tech, no-product, remote alternatives | more of the same |
| Overbuilt platform | No-Product Frame + MVP Wedge | smallest repeated value mechanism | full platform roadmap first |
| Too many ideas | Portfolio scoring + minority option | ranked options, parked ideas, next test | generating ten more ideas |
| Hard contradiction | TRIZ-style contradiction | conflict pair, separation strategy, smaller design move | fake TRIZ precision |
| Stakeholder/group context | PTFA/Six-perspective check | facts, acceptance, risks, benefits, alternatives, process decision | dominance simulation |
| Unsupported claim | Claim verification table | status, source need, risk if wrong, confidence | confident unsupported claims |
| User is blocked | Didactic mode | 3 direct moves, one next step | long Socratic interrogation |
| User asks for best idea too early | Criteria mini-gate + quick divergence | provisional recommendation with criteria | objective bestness without criteria |
| User requests many methods | Method load reduction | smallest useful method set | method theater |

## Core methods

### Wish-Problem Split

1. Paraphrase the stated wish.
2. Ask what job, pain, risk, or decision the wish is trying to improve.
3. Identify what would still be painful if the wish were fulfilled.
4. Generate at least two non-wish alternatives.

### Customer Job Frame

Use this syntax:

```text
Help [specific user] achieve [valuable outcome] despite [constraint], without [current pain or trade-off].
```

Add emotional and social jobs only when they plausibly affect adoption.

### Constraint Breaker

Apply one deliberate constraint:

- no app;
- no AI;
- no new user behavior;
- one-screen solution;
- one-day prototype;
- manual concierge first;
- no dashboard;
- no onboarding;
- no data migration.

Use the constraint to reveal simpler moves, not as a gimmick.

### CoVe-style claim check

Use for claim-heavy recommendations.

Output:

- extracted claim;
- evidence status;
- verification question;
- source need;
- confidence 1-5;
- risk if wrong.

### Experiment packager

Use after convergence.

Output:

- hypothesis;
- target user;
- test design;
- success signal;
- kill criterion;
- needed evidence;
- next decision.

## Failure gates

Stop and correct when:

- first solution dominates too early;
- user request is treated as requirement without problem discovery;
- value is described as "nice" rather than time, cost, risk, learning, trust, adoption, or coordination;
- current facts are asserted without verification;
- AI is treated as differentiation by itself;
- a platform is proposed before a wedge test exists;
- methods are stacked for appearance rather than decision quality.
