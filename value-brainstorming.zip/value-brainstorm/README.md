# Value Brainstorm

Value Brainstorm is a version-2 skill package that combines value-discovery convergence with selected deep-brainstorming methods.

Primary use: turn raw ideas, feature wishes, or vague product concepts into customer-value hypotheses, bold alternatives, reality checks, MVP wedges, and smallest tests.

Key additions over the prior value-discovery skill:

- phase gates;
- anti-homogenization;
- method-overstacking prevention;
- remote analogies, SCAMPER, Geneplore, TRIZ-style contradiction, PTFA, tree-of-options;
- minority-option retention;
- idea card and claim verification templates;
- evaluation scenarios for premature convergence, method theater, generic ideas, and minority options.
