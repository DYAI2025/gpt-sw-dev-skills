#!/usr/bin/env python3
"""Score a portfolio of ideas for value-brainstorm convergence.

Input JSON shape:
{
  "ideas": [
    {
      "name": "concierge onboarding",
      "user_value": 5,
      "problem_clarity": 4,
      "feasibility": 4,
      "testability": 5,
      "effort": 2,
      "risk": 2,
      "differentiation": 3,
      "value_multiplier": 5,
      "next_test_readiness": 5
    }
  ]
}

Scores are 1-5. For effort and risk, 5 means high/bad and is inverted.
`next_test_readiness` is optional; if omitted, it falls back to `testability`.
"""

from __future__ import annotations

import argparse
import json
import pathlib
import sys
from typing import Any

WEIGHTS = {
    "user_value": 1.6,
    "problem_clarity": 1.4,
    "feasibility": 1.2,
    "testability": 1.3,
    "effort_inverted": 1.0,
    "risk_inverted": 1.2,
    "differentiation": 1.0,
    "value_multiplier": 1.8,
    "next_test_readiness": 1.2,
}

REQUIRED = [
    "name",
    "user_value",
    "problem_clarity",
    "feasibility",
    "testability",
    "effort",
    "risk",
    "differentiation",
    "value_multiplier",
]

OPTIONAL_DEFAULTS = {
    "next_test_readiness": "testability",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", help="path to JSON file, or '-' for stdin")
    parser.add_argument("--top", type=int, default=0, help="return only top N ideas; 0 returns all")
    parser.add_argument("--pretty", action="store_true", help="pretty-print JSON output")
    return parser.parse_args()


def read_payload(path: str) -> dict[str, Any]:
    if path == "-":
        text = sys.stdin.read()
    else:
        text = pathlib.Path(path).read_text(encoding="utf-8")
    try:
        payload = json.loads(text)
    except json.JSONDecodeError as exc:
        raise SystemExit(f"Invalid JSON: {exc}") from exc
    if not isinstance(payload, dict) or not isinstance(payload.get("ideas"), list):
        raise SystemExit("Input must be an object with an 'ideas' list.")
    return payload


def score_value(value: Any, field: str, idea_name: str) -> float:
    if not isinstance(value, (int, float)):
        raise SystemExit(f"Idea '{idea_name}' field '{field}' must be numeric.")
    if value < 1 or value > 5:
        raise SystemExit(f"Idea '{idea_name}' field '{field}' must be between 1 and 5.")
    return float(value)


def get_metric(idea: dict[str, Any], field: str, idea_name: str) -> float:
    if field in idea:
        return score_value(idea[field], field, idea_name)
    fallback = OPTIONAL_DEFAULTS.get(field)
    if fallback and fallback in idea:
        return score_value(idea[fallback], field, idea_name)
    raise SystemExit(f"Idea '{idea_name}' missing field: {field}")


def score_idea(idea: dict[str, Any]) -> dict[str, Any]:
    missing = [field for field in REQUIRED if field not in idea]
    name = str(idea.get("name", "<unnamed>"))
    if missing:
        raise SystemExit(f"Idea '{name}' missing fields: {', '.join(missing)}")

    metrics = {field: score_value(idea[field], field, name) for field in REQUIRED if field != "name"}
    metrics["next_test_readiness"] = get_metric(idea, "next_test_readiness", name)
    metrics["effort_inverted"] = 6.0 - metrics.pop("effort")
    metrics["risk_inverted"] = 6.0 - metrics.pop("risk")

    weighted_sum = sum(metrics[field] * weight for field, weight in WEIGHTS.items())
    max_sum = sum(5.0 * weight for weight in WEIGHTS.values())
    score = round((weighted_sum / max_sum) * 100, 2)

    if score >= 82:
        verdict = "pursue"
    elif score >= 65:
        verdict = "test_or_refine"
    elif score >= 48:
        verdict = "park"
    else:
        verdict = "kill_or_reframe"

    return {
        "name": name,
        "score": score,
        "verdict": verdict,
        "metrics": metrics,
    }


def main() -> int:
    args = parse_args()
    payload = read_payload(args.input)
    results = [score_idea(idea) for idea in payload["ideas"]]
    results.sort(key=lambda item: item["score"], reverse=True)
    if args.top > 0:
        results = results[: args.top]
    output = {"results": results}
    print(json.dumps(output, ensure_ascii=False, indent=2 if args.pretty else None))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
