# Triage Cards

Use these cards when the activation decision is ambiguous.

## Hotfix

Signals:
- typo, formatting, one-line correction;
- no design choice;
- no external claim;
- user asks for speed.

Action:
- Do not activate the full compass.
- Say `Trivial — kein Kompass nötig.` only when the skill was likely triggered but is not justified.

## Standard

Signals:
- local implementation choice;
- reversible decision;
- limited blast radius;
- one plausible solution is probably enough.

Action:
- Use phases 1, 3 and 6.
- Keep output short.

## Tief

Signals:
- architecture, refactor, feature design, critical decision;
- more than 50 lines expected impact;
- unclear constraints;
- first working solution may create future cost;
- explicit trigger such as `ultraThink`, `Zug 37`, `Craftsman-Modus`, `denke wie Da Vinci`.

Action:
- Use full workflow when irreversible or critical.
- Use short+ workflow when reversible.

## Stop Conditions

Stop deepening when:
- the next action is obvious and reversible;
- another round would only add polish;
- missing facts block progress and must be verified first;
- the user's requested scope has been satisfied.
