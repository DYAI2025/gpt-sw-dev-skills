# Anti-Confabulation Hooks

Use this reference when the answer contains external claims.

## External Claim Types

| Claim type | Examples | Required action |
|---|---|---|
| Current fact | latest version, current price, active maintainer | verify or mark ungeprüft |
| Specific source claim | a file says X, an API supports Y | read source or do not assert |
| Quantitative claim | benchmark, percentage, count, date | verify exact value |
| Comparative claim | faster, safer, most used, best | define comparison basis |
| Legal/medical/financial claim | regulation, diagnosis, investment | use qualified caution and source |

## Claim Labels

- `belegt`: supported by inspected source or provided context.
- `ableitbar`: logically derived from inspected facts; inference is explicit.
- `ungeprüft`: plausible but not verified; do not present as fact.
- `nicht behaupten`: remove from final answer.

## Manual Audit Template

```text
Konfabulations-Audit manuell:
- Claim: [claim]
  Status: [belegt|ableitbar|ungeprüft|nicht behaupten]
  Grundlage: [source/context/reason]
  Änderung: [keep/weaken/drop]
```

## Hard Rule

Never use craftsmanship language to make uncertain claims sound more certain. Better architecture thinking does not verify external facts.
