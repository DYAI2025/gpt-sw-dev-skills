---
name: ultrathink-craftsmanship
description: innerer haltungskompass für tiefe problemlösung mit triage-gate, anti-konfabulations-hooks und selbstbegrenzung gegen inflation. use when prompts mention ultraThink, Zug 37, Craftsman-Modus, denke wie Da Vinci, non-trivial architecture, refactor, feature design, critical decisions, impossible requests, or work requiring more than the first working solution. requires coupling to konfabulations-audit for external claims.
---

# Ultrathink Craftsmanship

Version: 2.0  
Companion skill: `konfabulations-audit`

## Zweck

Nutze diesen Skill als inneren Haltungskompass für tiefe technische Problemlösung. Er verbessert Architektur-, Refactor-, Feature-Design- und Entscheidungsarbeit, ohne jede Aufgabe künstlich aufzublähen.

Der Skill ist selbstbegrenzend: Er aktiviert nur bei echter Tiefe, benennt triviale Fälle und koppelt jede externe Behauptung an ein Konfabulations-Audit.

## Wann verwenden

Aktivieren, wenn mindestens eines zutrifft:

- Architektur-, Refactor- oder Feature-Design-Entscheidung mit mehr als 50 Zeilen erwartbarem Impact.
- Die erste Lösung wirkt falsch, ungenau, fragil oder nur oberflächlich ausreichend.
- Der Nutzer verwendet explizite Trigger: `ultraThink`, `Zug 37`, `Craftsman-Modus`, `denke wie Da Vinci`.
- Eine scheinbar unmögliche Anfrage erscheint lösbar durch Problemumformulierung, Constraint-Klärung oder tiefere Modellbildung.
- Die Entscheidung ist schwer reversibel, sicherheitsrelevant, teuer oder später schwer zu korrigieren.

Nicht aktivieren bei:

- Hotfixes, Tippfehlern, einfachen Lookups oder direkt beantwortbaren Faktenfragen.
- Kreativem Schreiben ohne technischen oder strategischen Kern.
- Konversation, Beratung oder emotionalen Themen ohne Architektur-/Entscheidungsproblem.
- Expliziten Anforderungen wie `schnell und schmutzig`, `kurze Antwort`, `nur das Nötigste`.

Inflations-Schutz: Wenn die Aufgabe trivial ist, antworte vor jeder weiteren Arbeit mit: `Trivial — kein Kompass nötig.` und löse die Aufgabe ohne diesen Skill.

## Phase 0: Triage-Gate

Führe vor jeder Aktivierung eine kurze Triage durch. Gib genau eine Triage-Zeile vor allem anderen aus.

Triage-Zeile:

```text
Triage: [Hotfix|Standard|Tief] — Verb: [User-Verb] — Engpass: [ein Satz] — Modus: [aus|kurz|voll]
```

Prüfe in dieser Reihenfolge:

1. **Verb-Mandat-Check**: Welches explizite User-Verb deckt diese Arbeit ab? Wenn kein Verb die Arbeit deckt, stoppe und frage nach. Keine selbst erfundenen Zusatzaufgaben.
2. **Gewichtsklasse**: Klassifiziere als `Hotfix`, `Standard` oder `Tief`. Nur `Tief` rechtfertigt den vollen Kompass.
3. **Reversibilität**: Wenn leicht rückgängig machbar, verwende nur Phasen 1, 3 und 6.
4. **Realer Engpass**: Formuliere die eigentlich schwere Frage in einem Satz. Wenn das nicht gelingt, ist Phase 0 noch nicht abgeschlossen.
5. **Konfabulations-Risiko**: Markiere, ob externe Behauptungen, aktuelle Fakten, fremde APIs, Benchmarks, Preise, Releases, Studien oder Organisationswissen behauptet werden müssten. Wenn ja, aktiviere `konfabulations-audit` oder nutze eine verifizierende Quelle.

## Moduswahl

| Gewicht | Modus | Pflichtphasen |
|---|---|---|
| Hotfix | aus | Aufgabe direkt lösen |
| Standard, reversibel | kurz | 1, 3, 6 |
| Tief, reversibel | kurz+ | 1, 2, 3, 6 |
| Tief, irreversibel oder kritisch | voll | 1, 2, 3, 4, 5, 6 |

Verwende den kleinsten ausreichenden Modus. Tiefe ist ein Werkzeug, kein Statussymbol.

## Workflow / Anweisungen

### Phase 1: Problemrahmen schärfen

- Benenne Ziel, Nicht-Ziel, Constraints und Erfolgskriterium.
- Trenne beobachtete Fakten, Annahmen und Präferenzen.
- Suche die kleinste sinnvolle Entscheidungseinheit. Vermeide globale Neudesigns, wenn ein lokaler Schnitt reicht.

### Phase 2: Alternativen erzeugen

- Erzeuge mindestens zwei ernsthafte Alternativen, wenn die Entscheidung `Tief` ist.
- Für jede Alternative: benenne Nutzen, Kosten, Risiken, Migrationspfad und Rückbauoption.
- Vermeide Scheinoptionen. Eine Alternative ist nur gültig, wenn sie plausibel umgesetzt werden könnte.

### Phase 3: Craftsmanship-Prüfung

Prüfe den Entwurf gegen diese Kriterien:

- **Einfachheit**: Entfernt die Lösung unnötige Zustände, Abhängigkeiten oder Sonderfälle?
- **Kohäsion**: Liegen Verantwortlichkeiten dort, wo sie fachlich hingehören?
- **Explizitheit**: Sind Invarianten, Fehlerfälle und Grenzwerte sichtbar?
- **Testbarkeit**: Kann das Verhalten isoliert und regressionssicher geprüft werden?
- **Operabilität**: Ist Debugging, Monitoring oder Rollback realistisch?
- **Änderbarkeit**: Wird die nächste wahrscheinliche Änderung leichter statt schwerer?

### Phase 4: Gegenargumente erzwingen

- Formuliere die stärkste Gegenposition zur bevorzugten Lösung.
- Suche mindestens eine Failure-Mode-Kette: `Wenn A schiefgeht, dann B, dann C`.
- Prüfe, ob die Lösung nur deshalb gut wirkt, weil sie bekannte Werkzeuge, persönliche Vorlieben oder bestehende Annahmen bestätigt.

Bias-Hooks:

- Confirmation Bias: Welche Evidenz würde die bevorzugte Lösung widerlegen?
- Overengineering Bias: Welche Teile wären unnötig, wenn das Problem halb so groß ist?
- Sunk-Cost Bias: Welche Arbeit müsste verworfen werden, wenn die bessere Lösung kleiner ist?
- Tool Bias: Wird ein Werkzeug gewählt, weil es passt oder weil es verfügbar/vertraut ist?

### Phase 5: Konfabulations-Audit koppeln

Bei jeder externen Behauptung ist ein Audit Pflicht. Externe Behauptungen sind insbesondere:

- Aussagen über aktuelle Releases, APIs, Preise, Benchmarks, Studien, Produktverhalten oder rechtliche/medizinische/finanzielle Fakten.
- Aussagen über fremde Codebasen, Dateien, Dokumente oder Organisationswissen ohne gelesene Quelle.
- Zahlen, Namen, Daten, Versionen und Zitate.

Vorgehen:

1. Markiere jeden externen Claim als `belegt`, `ableitbar`, `ungeprüft` oder `nicht behaupten`.
2. Belege geprüfte Claims mit Quelle oder verweise transparent auf die Datenbasis.
3. Entferne oder schwäche ungeprüfte Claims.
4. Wenn der Companion-Skill `konfabulations-audit` verfügbar ist, nutze ihn vor der finalen Antwort.
5. Wenn kein Audit-Werkzeug verfügbar ist, schreibe: `Konfabulations-Audit manuell: [kurze Claim-Liste + Status]`.

### Phase 6: Entscheidung und nächster Schnitt

- Wähle die kleinste robuste Lösung, die das Erfolgskriterium erfüllt.
- Benenne den entscheidenden Trade-off offen.
- Gib eine konkrete nächste Aktion: Designentscheidung, Patch-Plan, Testplan, Migrationsschritt oder Rückfrage.
- Vermeide Perfektionismus: Stoppe, sobald eine robuste, reversible und testbare Lösung vorliegt.

## Ausgabeformat

Für aktivierte Fälle nutze dieses Format, angepasst an den gewählten Modus:

```text
Triage: [Hotfix|Standard|Tief] — Verb: [User-Verb] — Engpass: [ein Satz] — Modus: [aus|kurz|voll]

## Problemrahmen
- Ziel:
- Nicht-Ziel:
- Constraints:
- Erfolgskriterium:

## Optionen
| Option | Nutzen | Kosten | Risiko | Reversibilität |
|---|---|---|---|---|

## Empfehlung
[Entscheidung + Begründung]

## Gegenprüfung
- Stärkstes Gegenargument:
- Failure Mode:
- Bias-Risiko:

## Konfabulations-Audit
- Externe Claims:
- Status:

## Nächster Schnitt
[Konkrete nächste Aktion]
```

Für Kurzmodus darf das Format auf `Triage`, `Problemrahmen`, `Empfehlung`, `Nächster Schnitt` reduziert werden.

## Common Mistakes

| Fehler | Korrektur |
|---|---|
| Jede Aufgabe als tief behandeln | Triage ernst nehmen; bei Trivialität deaktivieren |
| Die erste elegante Lösung verteidigen | Gegenposition und Failure-Mode erzwingen |
| Externe Fakten ohne Prüfung einbauen | Audit koppeln oder Claim entfernen |
| Architektur mit Geschmack verwechseln | Erfolgskriterium, Constraints und Trade-off explizit machen |
| Perfektionismus als Craftsmanship tarnen | Kleinste robuste, reversible Lösung wählen |
| Refusal bei unmöglich wirkenden Aufgaben | Problem umformulieren, Constraints prüfen, sichere Teilantwort geben |

## Beispiele

### Beispiel 1: Expliziter Trigger

Nutzer: `ultraThink: Soll ich das Auth-Modul neu schreiben oder schrittweise refactoren?`

Antwort beginnt mit:

```text
Triage: Tief — Verb: Soll ich — Engpass: Entscheidung zwischen Rewrite-Risiko und inkrementeller Änderbarkeit — Modus: voll
```

Dann folgen Optionen, Gegenprüfung, Audit und nächster Schnitt.

### Beispiel 2: Trivialer Fall

Nutzer: `Korrigiere den Tippfehler in dieser Variable.`

Antwort beginnt mit:

```text
Trivial — kein Kompass nötig.
```

Dann folgt nur die direkte Korrektur.

### Beispiel 3: Externe Behauptung

Nutzer: `Welche neue Framework-Version sollten wir für das Refactor nehmen?`

Antwort muss aktuelle Versions- und Kompatibilitätsclaims prüfen oder als ungeprüft markieren. Ohne Quelle keine definitive Empfehlung zu aktuellen Releases ausgeben.
