#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


def run(cmd: list[str]) -> None:
    print("$", " ".join(cmd))
    subprocess.run(cmd, check=True)


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    out = root / "tmp-smoke"
    out.mkdir(exist_ok=True)

    run([sys.executable, "-m", "py_compile", str(root / "scripts" / "repo_to_architecture_model.py")])
    run([sys.executable, "-m", "py_compile", str(root / "scripts" / "architecture_to_fireworks_spec.py")])

    arch = out / "architecture.json"
    spec = out / "fireworks-spec.json"

    run([
        sys.executable,
        str(root / "scripts" / "repo_to_architecture_model.py"),
        "--repo",
        str(root),
        "--output",
        str(arch),
        "--project-name",
        "Smoke Test Repo",
    ])

    run([
        sys.executable,
        str(root / "scripts" / "architecture_to_fireworks_spec.py"),
        "--input",
        str(arch),
        "--output",
        str(spec),
        "--strict",
    ])

    payload = json.loads(spec.read_text(encoding="utf-8"))
    assert payload["nodes"], "Expected nodes in Fireworks spec"
    assert "_adapter" in payload, "Expected adapter metadata"
    print("✓ smoke test passed")


if __name__ == "__main__":
    main()
