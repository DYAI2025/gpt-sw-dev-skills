---
name: repo-architecture-visualization-harness
description: creates repo-aware architecture models, editable Omni architecture editors, Fireworks SVG/PNG visuals, package split recommendations, story-map-driven agentic delivery maps, drift reports, and coding-agent handoff briefs from repositories, ZIPs, architecture JSON, OpenAPI contracts, skill files, and agentic harness documents.
---

# Repo Architecture Visualization Harness

## Overview

This skill turns repositories, uploaded ZIPs, architecture descriptions, Skill packages, OpenAPI contracts, and agentic delivery documents into a practical architecture operating view.

It combines three complementary capabilities:

1. **Omni architecture modeling**: normalize repo and system context into `architecture.json`.
2. **Editable architecture workbench**: produce or update an editable HTML architecture editor when available.
3. **Fireworks static rendering**: convert the same model into a polished Fireworks diagram spec and optional SVG/PNG outputs for documentation, onboarding, and stakeholder communication.

When agentic delivery or Story Map material is present, the skill also maps governance, stage gates, evidence, handovers, drift reports, and human review points.

## Apply this skill when the user asks to

- analyze or visualize a repository, ZIP, file tree, Skill package, CustomGPT package, or backend/API project;
- create `architecture.json` from a repo;
- generate editable architecture HTML plus static SVG/PNG diagrams;
- evaluate package split, file inclusion, generated artifacts, tests, deployment files, OpenAPI Actions, or knowledge-base candidates;
- compare or combine architecture visualization tools;
- turn repo structure into a coding-agent-ready dev brief;
- build or assess a Story Map-driven agentic delivery harness;
- map stage gates, evidence, human review, drift, or context packs;
- generate Fireworks Tech Graph specs from Omni Architecture models.

Do not use this skill for purely decorative diagrams with no repository, architecture, model, or delivery-governance semantics.

## Core principles

1. **Model first.** Always create or update a canonical `architecture.json` before producing diagrams.
2. **One source of truth.** Treat Omni `architecture.json` as authoritative. Fireworks JSON, SVG, and PNG are generated outputs.
3. **Editability before polish.** Use the editable Omni architecture editor for work sessions; use Fireworks for polished static publication.
4. **Traceability.** Separate facts, assumptions, recommendations, and unknowns.
5. **No silent changes.** Architecture edits, reroutes, endpoint changes, and governance changes must be recorded as deltas.
6. **Repo hygiene.** Exclude dependency caches, local artifacts, generated duplicates, and secrets from target packages unless the user explicitly asks for diagnostic inventory.
7. **Story Map authority.** When Story Map or delivery-harness files exist, treat them as context SSOT and check implementation artifacts against them.
8. **Safe rendering.** Never embed secrets, private bearer tokens, or unrestricted probe URLs into HTML or JSON models.

## Required outputs by task type

### Repository visualization

Return, as applicable:

1. repository inventory and file-role classification;
2. `architecture.json`;
3. editable architecture editor or instructions to generate it;
4. Fireworks diagram spec JSON;
5. SVG/PNG if a renderer is available;
6. package split recommendation;
7. risks, assumptions, and next action.

### Skill or CustomGPT package analysis

Return:

1. file inclusion/exclusion table;
2. target package structure;
3. knowledge-base files;
4. Action/OpenAPI files;
5. runtime/server files;
6. tests and validation commands;
7. gaps and safety risks.

### Agentic delivery harness analysis

Return:

1. Story Map SSOT map;
2. pipeline/stage/handover model;
3. evidence ledger model;
4. drift taxonomy;
5. human-review trigger points;
6. architecture nodes/edges;
7. implementation-ready dev brief.

### Fireworks static rendering

Return:

1. Fireworks spec JSON;
2. optional SVG/PNG;
3. `_adapter.warnings`;
4. explanation of mapping decisions;
5. instruction that Fireworks output is derived, not canonical.

## Workflow

### 1. Intake and classification

Accept any combination of:

- ZIP archive;
- repo path or file tree;
- `architecture.json`;
- Omni editor export;
- Fireworks diagram spec;
- OpenAPI YAML/JSON;
- Skill files such as `SKILL.md` and `agents/openai.yaml`;
- Story Map and harness documents;
- generated diagrams or examples.

For repos, run the same logic as `scripts/repo_to_architecture_model.py` where possible:
- inventory files;
- skip excluded directories and files;
- classify files by architecture role;
- create nodes and edges for meaningful groups.

### 2. Normalize to architecture model

Generate a model with at least:

```json
{
  "project": {
    "name": "Project",
    "domain": "repository",
    "repo": "",
    "timestamp": "ISO-8601",
    "description": ""
  },
  "visualization": {
    "preferredStyle": 7,
    "diagramType": "architecture",
    "audience": "engineering-docs",
    "outputs": ["editable-html", "svg", "png", "markdown-snapshot"]
  },
  "nodes": [],
  "edges": [],
  "changes": []
}
```

Include `repoInventory` when source files were available.

Use deterministic IDs in kebab-case. Keep stable ordering.

### 3. Add agentic harness overlay when present

If the repository or documents contain Story Map, pipeline, handover, evidence, context-pack, drift-report, or decision files, add these conceptual nodes:

- Story Map SSOT;
- Slice Planner;
- Context Compiler;
- Agent Execution Control Plane;
- Workflow Runtime;
- Evidence Ledger;
- Independent Review Quorum;
- Human Approval Gate;
- Drift Reconciliation.

Model handovers as workflow/control edges and evidence as data edges.

### 4. Produce editable architecture view

When an Omni editor generator is available, generate a single-file HTML editor from `architecture.json`.

If not available, return the `architecture.json` plus exact command expectations for generation.

The editor is the working surface for:
- architecture edits;
- node and edge changes;
- endpoint edits;
- change log;
- dev brief export;
- full snapshot export;
- validation and health overlays when supported.

### 5. Produce Fireworks static view

Use `scripts/architecture_to_fireworks_spec.py` to convert `architecture.json` into Fireworks spec JSON.

Typical command:

```bash
python scripts/architecture_to_fireworks_spec.py \
  --input architecture.json \
  --output fireworks-diagram-spec.json \
  --style 7
```

When a Fireworks renderer is available:

```bash
python scripts/architecture_to_fireworks_spec.py \
  --input architecture.json \
  --output fireworks-diagram-spec.json \
  --generator ../fireworks-tech-graph-main/scripts/generate-from-template.py \
  --render-svg architecture.svg \
  --render-png architecture.png
```

Inspect `_adapter.warnings` and disclose limitations.

### 6. Evaluate repository/package fitness

For every repo/package, classify files into:

- Skill Runtime / GPT Knowledge;
- Agent Policy;
- GPT Actions / OpenAPI;
- Backend/API/VPS;
- Visualization/Editor;
- Tests/Quality;
- Fixtures/Examples;
- Documentation;
- Build/Cache/Artifacts;
- Excluded.

Remove from target packages by default:

- `node_modules`;
- `.git`;
- `__pycache__`;
- `.DS_Store`;
- `.pytest_cache`;
- test-results;
- temporary generated HTML unless it is a curated example;
- local secrets;
- generated duplicates when source exists.

### 7. Generate handoff

For coding-agent handoff, include:

- task title;
- source files;
- generated files;
- exact commands;
- changed contracts;
- acceptance criteria;
- verification plan;
- non-goals;
- unresolved assumptions.

## Fireworks adapter contract

Use `references/fireworks-style-adapter.md`.

Key rule:

- Omni `architecture.json` is canonical.
- Fireworks diagram spec is generated.
- SVG/PNG are generated artifacts.
- No semantic edits should be made only for visual convenience.

## Agentic harness contract

Use `references/agentic-harness-framework.md`.

Key rule:

- Story Map is the context SSOT.
- Pipeline, handover, evidence, drift, and decision files are delivery-control objects.
- Human review should happen after machine/evidence readiness, not before basic checks exist.

## Quality gates

Before final output, verify:

- Python scripts compile if included.
- JSON outputs parse.
- SVG parses as XML if generated.
- Rendered artifacts are linked.
- File/package exclusions are explicit.
- Secrets are not embedded.
- Generated files are distinguishable from source files.
- The next action is concrete and minimal.

## Output style

Use German unless the user asks otherwise.

Use this structure for substantial analysis:

```markdown
## Kernverständnis
## Einordnung
## Artefakte
## Bewertung
## Empfehlung
## Nächste Aktion
```

For package splits, use:

```markdown
| Datei/Pfad | Zielpaket | Rolle | Begründung |
```

For code/server issues, use:

```markdown
- Symptom
- Ursache
- Prüfschritte
- Fix
- Regressionstest
```
