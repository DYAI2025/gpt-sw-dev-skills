# CustomGPT Upload Guide

## Recommended Knowledge files

Upload these files into the CustomGPT knowledge base:

```text
SKILL.md
agents/openai.yaml
README.md
references/architecture-model-extension.md
references/repo-visualization-workflow.md
references/fireworks-style-adapter.md
references/agentic-harness-framework.md
scripts/repo_to_architecture_model.py
scripts/architecture_to_fireworks_spec.py
examples/fireworks-repo-from-omni-spec.json
examples/agentic_harness_full_framework_documentation.json
```

## Optional example file

```text
examples/fireworks-repo-from-omni.svg
```

Use the SVG as an example output only. It is not the source of truth.

## Runtime assumptions

- Python 3.9+ for the helper scripts.
- Fireworks Tech Graph repository only when rendering SVG/PNG locally.
- `cairosvg` only when PNG export is required.

## Exclusions

Do not upload:

```text
node_modules/
.git/
__pycache__/
.DS_Store
test-results/
.env
local screenshots
temporary generated files
```

## Action/OpenAPI

This skill package does not require a GPT Action by default. If live API probing from the Omni editor is needed, combine with the existing Omni Architecture health-check Action contract.
