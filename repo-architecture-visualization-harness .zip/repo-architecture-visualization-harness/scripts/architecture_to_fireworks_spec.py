#!/usr/bin/env python3
"""Convert an Omni Architecture model into a Fireworks Tech Graph diagram spec.

The adapter keeps Omni's architecture.json as the source of truth and produces
the JSON contract consumed by fireworks-tech-graph's scripts/generate-from-template.py.

Typical usage:
  python scripts/architecture_to_fireworks_spec.py \
    --input architecture.json \
    --output fireworks-diagram-spec.json

Render immediately when the Fireworks repo is available:
  python scripts/architecture_to_fireworks_spec.py \
    --input architecture.json \
    --output fireworks-diagram-spec.json \
    --generator ../fireworks-tech-graph-main/scripts/generate-from-template.py \
    --render-svg architecture.svg \
    --render-png architecture.png

Input model:
  {
    "project": {"name": "...", "domain": "...", "description": "..."},
    "nodes": [{"id": "...", "x": 500, "y": 240, "type": "service", ...}],
    "edges": [{"from": "...", "to": "...", "relation": "api-call", ...}],
    "visualization": {
      "preferredStyle": 7,
      "diagramType": "architecture",
      "audience": "engineering-docs",
      "outputs": ["editable-html", "svg", "png", "markdown-snapshot"]
    }
  }

Output spec shape:
  {
    "template_type": "architecture",
    "style": 7,
    "containers": [],
    "nodes": [],
    "arrows": [],
    "legend": []
  }
"""
from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import sys
import textwrap
import xml.etree.ElementTree as ET
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


DEFAULT_WIDTH = 1120
DEFAULT_HEIGHT = 760
CANVAS_MARGIN_X = 40
TITLE_RESERVED_Y = 106
BOTTOM_RESERVED_Y = 86
NODE_DEFAULT_WIDTH = 174
NODE_DEFAULT_HEIGHT = 62


TYPE_LAYER: dict[str, tuple[str, str]] = {
    "entry": ("entry", "ENTRY / EXPERIENCE"),
    "ui": ("entry", "ENTRY / EXPERIENCE"),
    "external": ("entry", "ENTRY / EXPERIENCE"),
    "security": ("guardrails", "GUARDRAILS / POLICY"),
    "agent": ("logic", "APPLICATION / AGENT LOGIC"),
    "workflow": ("logic", "APPLICATION / AGENT LOGIC"),
    "domain": ("logic", "APPLICATION / AGENT LOGIC"),
    "service": ("logic", "APPLICATION / AGENT LOGIC"),
    "api": ("logic", "APPLICATION / AGENT LOGIC"),
    "data": ("data", "DATA / STATE"),
    "infra": ("ops", "INFRA / OPS"),
    "custom": ("support", "SUPPORTING COMPONENTS"),
}
LAYER_ORDER = ["entry", "guardrails", "logic", "data", "ops", "support"]
LAYER_LABEL = {
    "entry": "ENTRY / EXPERIENCE",
    "guardrails": "GUARDRAILS / POLICY",
    "logic": "APPLICATION / AGENT LOGIC",
    "data": "DATA / STATE",
    "ops": "INFRA / OPS",
    "support": "SUPPORTING COMPONENTS",
}

TYPE_SHAPE = {
    "entry": "rect",
    "ui": "rect",
    "external": "rect",
    "security": "hexagon",
    "agent": "double_rect",
    "workflow": "rect",
    "domain": "rect",
    "service": "rect",
    "api": "double_rect",
    "data": "cylinder",
    "infra": "double_rect",
    "custom": "rect",
}

TYPE_LABEL = {
    "entry": "ENTRY",
    "ui": "UI",
    "external": "EXT",
    "security": "GUARD",
    "agent": "AGENT",
    "workflow": "FLOW",
    "domain": "DOMAIN",
    "service": "SERVICE",
    "api": "API",
    "data": "DATA",
    "infra": "INFRA",
    "custom": "CUSTOM",
}

RELATION_FLOW = {
    "user-flow": "control",
    "workflow": "control",
    "api-call": "control",
    "event-flow": "async",
    "data-flow": "data",
    "dependency": "neutral",
    "deployment": "neutral",
    "ownership": "neutral",
    "risk-control": "feedback",
}
STYLE_FLOW = {
    "primary": "control",
    "api": "control",
    "event": "async",
    "data": "data",
    "dependency": "neutral",
    "risk": "feedback",
    "ownership": "neutral",
    "secondary": "neutral",
}

LEGEND_LABELS = {
    "control": "Primary API / control path",
    "read": "Read / lookup path",
    "write": "Write / persistence path",
    "data": "Data movement",
    "async": "Async event / queue path",
    "feedback": "Risk, policy, or operational feedback",
    "neutral": "Supporting dependency",
}


@dataclass(frozen=True)
class LayoutNode:
    node_id: str
    layer: str
    x: float
    y: float
    width: float
    height: float


def read_json(path: str | os.PathLike[str]) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path: str | os.PathLike[str], payload: dict[str, Any]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def slug(value: Any, fallback: str = "node") -> str:
    text = str(value or fallback).strip().lower()
    out = []
    previous_dash = False
    for char in text:
        if char.isalnum():
            out.append(char)
            previous_dash = False
        elif not previous_dash:
            out.append("-")
            previous_dash = True
    cleaned = "".join(out).strip("-")
    return cleaned or fallback


def as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def clean_label(value: Any, fallback: str = "") -> str:
    text = str(value if value is not None else fallback).strip()
    return text or fallback


def node_detail(node: dict[str, Any]) -> dict[str, Any]:
    detail = node.get("detail")
    return detail if isinstance(detail, dict) else {}


def node_label(node: dict[str, Any]) -> str:
    detail = node_detail(node)
    return clean_label(node.get("label") or detail.get("title") or node.get("id"), "Component")


def node_subtitle(node: dict[str, Any]) -> str:
    detail = node_detail(node)
    sub = node.get("sub") or detail.get("subtitle") or node.get("type")
    if isinstance(sub, str):
        return sub[:46]
    return ""


def node_type(node: dict[str, Any]) -> str:
    return slug(node.get("type", "custom"), "custom")


def layer_for_node(node: dict[str, Any]) -> str:
    return TYPE_LAYER.get(node_type(node), ("support", "SUPPORTING COMPONENTS"))[0]


def shape_for_node(node: dict[str, Any]) -> str:
    return str(node.get("visual", {}).get("shape") or TYPE_SHAPE.get(node_type(node), "rect"))


def type_label_for_node(node: dict[str, Any]) -> str:
    explicit = node.get("visual", {}).get("typeLabel")
    if explicit:
        return str(explicit).upper()[:18]
    return TYPE_LABEL.get(node_type(node), node_type(node).upper()[:18])


def compact_tags(node: dict[str, Any], max_tags: int = 2) -> list[dict[str, str]]:
    detail = node_detail(node)
    raw = as_list(detail.get("tags"))[:max_tags]
    tags = []
    for item in raw:
        if isinstance(item, dict):
            label = str(item.get("label", "")).strip()
        else:
            label = str(item).strip()
        if label:
            tags.append({"label": label[:16]})
    return tags


def active_nodes(model: dict[str, Any]) -> list[dict[str, Any]]:
    nodes = []
    seen = set()
    for idx, node in enumerate(as_list(model.get("nodes"))):
        if not isinstance(node, dict) or node.get("_deleted"):
            continue
        node_id = slug(node.get("id"), f"node-{idx + 1}")
        if node_id in seen:
            node_id = f"{node_id}-{idx + 1}"
        node = dict(node)
        node["id"] = node_id
        seen.add(node_id)
        nodes.append(node)
    return nodes


def active_edges(model: dict[str, Any], known_node_ids: set[str]) -> list[dict[str, Any]]:
    edges = []
    for edge in as_list(model.get("edges")):
        if not isinstance(edge, dict):
            continue
        source = slug(edge.get("from"), "")
        target = slug(edge.get("to"), "")
        if not source or not target or source not in known_node_ids or target not in known_node_ids:
            continue
        e = dict(edge)
        e["from"] = source
        e["to"] = target
        edges.append(e)
    return edges


def compute_layer_groups(nodes: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for node in nodes:
        groups[layer_for_node(node)].append(node)

    # Keep deterministic but still useful ordering: existing y/x if supplied, else label.
    for layer_nodes in groups.values():
        layer_nodes.sort(key=lambda n: (float(n.get("y", 0) or 0), float(n.get("x", 0) or 0), node_label(n).lower()))
    return groups


def compute_canvas_height(layer_count: int, max_nodes_per_layer: int, requested_height: int | None = None) -> int:
    if requested_height:
        return max(560, int(requested_height))
    # Larger repos need more vertical room, but keep the default close to Fireworks fixtures.
    return max(DEFAULT_HEIGHT, TITLE_RESERVED_Y + BOTTOM_RESERVED_Y + layer_count * 136 + max(0, max_nodes_per_layer - 5) * 8)


def compute_layout(
    nodes: list[dict[str, Any]],
    width: int,
    height: int,
) -> tuple[dict[str, LayoutNode], list[dict[str, Any]]]:
    groups = compute_layer_groups(nodes)
    present_layers = [layer for layer in LAYER_ORDER if groups.get(layer)]
    if not present_layers:
        return {}, []

    usable_height = height - TITLE_RESERVED_Y - BOTTOM_RESERVED_Y
    gap_y = 24
    row_height = max(100, (usable_height - gap_y * (len(present_layers) - 1)) / len(present_layers))
    containers: list[dict[str, Any]] = []
    layout: dict[str, LayoutNode] = {}

    y = TITLE_RESERVED_Y
    for idx, layer in enumerate(present_layers):
        layer_nodes = groups[layer]
        container_height = row_height
        containers.append({
            "x": CANVAS_MARGIN_X,
            "y": round(y, 2),
            "width": width - CANVAS_MARGIN_X * 2,
            "height": round(container_height, 2),
            "label": LAYER_LABEL.get(layer, layer.upper()),
            "header_prefix": f"{idx + 1:02d}",
            "subtitle": "",
            "fill": "none",
        })

        count = len(layer_nodes)
        inner_x = CANVAS_MARGIN_X + 52
        inner_w = width - CANVAS_MARGIN_X * 2 - 104
        node_w = min(208, max(144, (inner_w - max(0, count - 1) * 28) / max(1, count)))
        node_h = NODE_DEFAULT_HEIGHT
        if any(node_type(n) == "data" for n in layer_nodes):
            node_h = 78
        if count == 1:
            xs = [width / 2 - node_w / 2]
        else:
            step = (inner_w - node_w) / max(1, count - 1)
            xs = [inner_x + i * step for i in range(count)]
        node_y = y + max(34, (container_height - node_h) / 2 + 14)
        for n, node_x in zip(layer_nodes, xs):
            layout[n["id"]] = LayoutNode(
                node_id=n["id"],
                layer=layer,
                x=round(node_x, 2),
                y=round(node_y, 2),
                width=round(node_w, 2),
                height=round(node_h, 2),
            )
        y += container_height + gap_y
    return layout, containers


def flow_for_edge(edge: dict[str, Any], target_node: dict[str, Any] | None = None) -> str:
    explicit = str(edge.get("flow", "")).strip().lower()
    if explicit in LEGEND_LABELS:
        return explicit
    relation = str(edge.get("relation", "")).strip().lower()
    style = str(edge.get("style", "")).strip().lower()
    if target_node and node_type(target_node) == "data":
        method = str(edge.get("method", "")).strip().upper()
        if method in {"POST", "PUT", "PATCH", "DELETE"}:
            return "write"
        return "read"
    return RELATION_FLOW.get(relation) or STYLE_FLOW.get(style) or "control"


def ports_for_edge(source: LayoutNode | None, target: LayoutNode | None) -> tuple[str, str]:
    if not source or not target:
        return "right", "left"
    sx = source.x + source.width / 2
    sy = source.y + source.height / 2
    tx = target.x + target.width / 2
    ty = target.y + target.height / 2
    dx = tx - sx
    dy = ty - sy
    if abs(dx) >= abs(dy):
        return ("right", "left") if dx >= 0 else ("left", "right")
    return ("bottom", "top") if dy >= 0 else ("top", "bottom")


def edge_label(edge: dict[str, Any]) -> str:
    label = str(edge.get("label") or "").strip()
    if label:
        return label[:34]
    method = str(edge.get("method") or "").strip().upper()
    path = str(edge.get("path") or "").strip()
    if method and path:
        return f"{method} {path}"[:34]
    relation = str(edge.get("relation") or edge.get("style") or "").strip()
    return relation[:34]


def make_fireworks_nodes(nodes: list[dict[str, Any]], layout: dict[str, LayoutNode]) -> list[dict[str, Any]]:
    result = []
    for node in nodes:
        box = layout.get(node["id"])
        if not box:
            continue
        kind = shape_for_node(node)
        item: dict[str, Any] = {
            "id": node["id"],
            "kind": kind,
            "x": box.x,
            "y": box.y,
            "width": box.width,
            "height": box.height,
            "label": node_label(node),
        }
        sub = node_subtitle(node)
        if kind == "cylinder":
            item["sublabel"] = sub or type_label_for_node(node)
        else:
            item["type_label"] = type_label_for_node(node)
            if sub and len(sub) <= 32:
                item["sublabel"] = sub
        tags = compact_tags(node)
        if tags and kind not in {"cylinder"}:
            item["tags"] = tags
        if kind == "rect":
            item["flat"] = True
        result.append(item)
    return result


def make_fireworks_arrows(
    edges: list[dict[str, Any]],
    nodes_by_id: dict[str, dict[str, Any]],
    layout: dict[str, LayoutNode],
) -> tuple[list[dict[str, Any]], list[str]]:
    arrows = []
    used_flows = set()
    warnings = []
    for edge in edges:
        source = edge["from"]
        target = edge["to"]
        if source not in layout or target not in layout:
            warnings.append(f"Skipped edge {source}->{target}: missing layout endpoint")
            continue
        source_port, target_port = ports_for_edge(layout[source], layout[target])
        target_node = nodes_by_id.get(target)
        flow = flow_for_edge(edge, target_node)
        used_flows.add(flow)
        arrow: dict[str, Any] = {
            "source": source,
            "target": target,
            "source_port": source_port,
            "target_port": target_port,
            "flow": flow,
        }
        label = edge_label(edge)
        if label:
            arrow["label"] = label
        if str(edge.get("style", "")).lower() in {"event", "dependency"} or str(edge.get("relation", "")).lower() in {"event-flow", "dependency"}:
            arrow["dashed"] = True
        if edge.get("critical"):
            arrow["stroke_width"] = 3
        arrows.append(arrow)
    return arrows, sorted(used_flows)


def make_legend(used_flows: Iterable[str]) -> list[dict[str, str]]:
    order = ["control", "read", "write", "data", "async", "feedback", "neutral"]
    present = [flow for flow in order if flow in set(used_flows)]
    return [{"flow": flow, "label": LEGEND_LABELS[flow]} for flow in present]


def resolve_visualization_options(model: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    opts = model.get("visualization") if isinstance(model.get("visualization"), dict) else {}
    style = args.style if args.style is not None else opts.get("preferredStyle", 7)
    diagram_type = args.diagram_type or opts.get("diagramType") or "architecture"
    width = args.width or opts.get("width") or DEFAULT_WIDTH
    height = args.height or opts.get("height")
    audience = args.audience or opts.get("audience") or "engineering-docs"
    return {
        "style": int(style),
        "diagram_type": str(diagram_type),
        "width": int(width),
        "height": int(height) if height else None,
        "audience": audience,
        "outputs": opts.get("outputs", ["svg", "png"]),
    }


def convert(model: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    opts = resolve_visualization_options(model, args)
    nodes = active_nodes(model)
    nodes_by_id = {node["id"]: node for node in nodes}
    edges = active_edges(model, set(nodes_by_id))
    groups = compute_layer_groups(nodes)
    layer_count = len([layer for layer in LAYER_ORDER if groups.get(layer)])
    max_nodes_per_layer = max((len(items) for items in groups.values()), default=1)
    height = compute_canvas_height(layer_count, max_nodes_per_layer, opts["height"])
    width = opts["width"]
    layout, containers = compute_layout(nodes, width, height)
    fw_nodes = make_fireworks_nodes(nodes, layout)
    arrows, used_flows = make_fireworks_arrows(edges, nodes_by_id, layout)
    legend = make_legend(used_flows)

    project = model.get("project") if isinstance(model.get("project"), dict) else {}
    title = args.title or project.get("name") or "Architecture"
    subtitle = (
        args.subtitle
        or project.get("description")
        or f"{project.get('domain', 'software')} architecture · generated from Omni architecture.json"
    )

    spec: dict[str, Any] = {
        "template_type": opts["diagram_type"],
        "style": opts["style"],
        "width": width,
        "height": height,
        "title": str(title),
        "subtitle": str(subtitle)[:132],
        "containers": containers,
        "nodes": fw_nodes,
        "arrows": arrows,
        "legend": legend,
        "legend_position": "bottom-left",
        "footer": f"Generated from Omni architecture.json · {datetime.now(timezone.utc).isoformat(timespec='seconds')}",
        "_adapter": {
            "name": "architecture_to_fireworks_spec",
            "source": "omni-architecture-brief-engine",
            "target": "fireworks-tech-graph generate-from-template.py",
            "audience": opts["audience"],
            "nodeCount": len(fw_nodes),
            "edgeCount": len(arrows),
            "skippedDeletedNodes": len(as_list(model.get("nodes"))) - len(nodes),
            "warnings": [],
        },
    }

    if opts["style"] == 3:
        spec["blueprint_title_block"] = {
            "title": "OMNI",
            "subtitle": "ARCHITECTURE SPEC",
            "center_caption": f"STYLE {opts['style']}",
            "left_caption": "SRC: architecture.json",
            "right_caption": f"NODES: {len(fw_nodes)}",
            "width": 238,
            "height": 76,
            "x": width - 280,
            "y": height - 96,
        }
    return spec


def validate_fireworks_spec(spec: dict[str, Any], strict: bool = False) -> list[str]:
    warnings = []
    node_ids = {str(n.get("id")) for n in as_list(spec.get("nodes")) if isinstance(n, dict)}
    if not node_ids:
        warnings.append("spec has no nodes")
    for idx, node in enumerate(as_list(spec.get("nodes"))):
        if not isinstance(node, dict):
            warnings.append(f"node[{idx}] is not an object")
            continue
        for field in ("id", "x", "y", "width", "height", "label"):
            if field not in node:
                warnings.append(f"node[{idx}] missing {field}")
    for idx, arrow in enumerate(as_list(spec.get("arrows"))):
        if not isinstance(arrow, dict):
            warnings.append(f"arrow[{idx}] is not an object")
            continue
        if arrow.get("source") not in node_ids:
            warnings.append(f"arrow[{idx}] source not found: {arrow.get('source')}")
        if arrow.get("target") not in node_ids:
            warnings.append(f"arrow[{idx}] target not found: {arrow.get('target')}")
    if strict and warnings:
        raise ValueError("Invalid Fireworks spec:\n" + "\n".join(f"- {w}" for w in warnings))
    return warnings


def render_svg(generator: str, spec: dict[str, Any], svg_path: str | os.PathLike[str]) -> None:
    template_type = str(spec.get("template_type", "architecture"))
    target = Path(svg_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    command = [sys.executable, str(generator), template_type, str(target)]
    proc = subprocess.run(
        command,
        input=json.dumps(spec, ensure_ascii=False),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            "Fireworks SVG render failed:\n"
            + proc.stdout
            + ("\n" + proc.stderr if proc.stderr else "")
        )
    ET.parse(target)


def render_png(svg_path: str | os.PathLike[str], png_path: str | os.PathLike[str]) -> None:
    try:
        import cairosvg  # type: ignore
    except Exception as exc:  # pragma: no cover - depends on optional runtime package
        raise RuntimeError(
            "PNG export requires cairosvg. Install with: pip install cairosvg"
        ) from exc
    target = Path(png_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    cairosvg.svg2png(url=str(svg_path), write_to=str(target))


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Convert Omni architecture.json into a Fireworks diagram spec.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent(
            """\
            Examples:
              architecture_to_fireworks_spec.py -i architecture.json -o diagram.json
              architecture_to_fireworks_spec.py -i architecture.json -o diagram.json --style 3
              architecture_to_fireworks_spec.py -i architecture.json -o diagram.json \\
                --generator ../fireworks-tech-graph-main/scripts/generate-from-template.py \\
                --render-svg diagram.svg --render-png diagram.png
            """
        ),
    )
    parser.add_argument("-i", "--input", required=True, help="Omni architecture.json input")
    parser.add_argument("-o", "--output", required=True, help="Fireworks diagram spec JSON output")
    parser.add_argument("--style", type=int, choices=range(1, 8), help="Fireworks visual style 1..7")
    parser.add_argument("--diagram-type", default=None, help="Fireworks template type, default from model.visualization or architecture")
    parser.add_argument("--audience", default=None, help="Audience metadata, e.g. engineering-docs")
    parser.add_argument("--width", type=int, default=None, help="Output canvas width")
    parser.add_argument("--height", type=int, default=None, help="Output canvas height")
    parser.add_argument("--title", default=None, help="Override diagram title")
    parser.add_argument("--subtitle", default=None, help="Override diagram subtitle")
    parser.add_argument("--strict", action="store_true", help="Fail on adapter validation warnings")
    parser.add_argument("--generator", default=None, help="Path to fireworks-tech-graph scripts/generate-from-template.py")
    parser.add_argument("--render-svg", default=None, help="Optional SVG output path")
    parser.add_argument("--render-png", default=None, help="Optional PNG output path; requires --render-svg and cairosvg")
    return parser


def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()

    model = read_json(args.input)
    spec = convert(model, args)
    warnings = validate_fireworks_spec(spec, strict=args.strict)
    spec["_adapter"]["warnings"] = warnings
    write_json(args.output, spec)

    if args.render_svg:
        if not args.generator:
            raise SystemExit("--render-svg requires --generator")
        render_svg(args.generator, spec, args.render_svg)
    if args.render_png:
        if not args.render_svg:
            raise SystemExit("--render-png requires --render-svg")
        render_png(args.render_svg, args.render_png)

    print(f"✓ Fireworks spec written: {args.output}")
    if args.render_svg:
        print(f"✓ SVG rendered: {args.render_svg}")
    if args.render_png:
        print(f"✓ PNG rendered: {args.render_png}")
    if warnings:
        print("Warnings:")
        for warning in warnings:
            print(f"- {warning}")


if __name__ == "__main__":
    main()
