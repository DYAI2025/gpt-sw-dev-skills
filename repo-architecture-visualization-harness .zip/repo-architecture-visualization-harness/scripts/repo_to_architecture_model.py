#!/usr/bin/env python3
"""Create a first-pass Omni architecture.json from a repository tree.

This is an intake helper, not a substitute for human/LLM architecture review.
It inventories relevant files, groups them into architecture-relevant roles, and
emits a normalized model that can be refined in the Omni editor and optionally
rendered through architecture_to_fireworks_spec.py.

Usage:
  python scripts/repo_to_architecture_model.py --repo . --output architecture.json
"""
from __future__ import annotations

import argparse
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


EXCLUDED_DIRS = {
    ".git", "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache",
    ".venv", "venv", "dist", "build", "coverage", "test-results", ".next",
}
EXCLUDED_FILES = {".DS_Store"}

ROLE_RULES: list[tuple[str, str, str, str, str]] = [
    ("skill-runtime", "Skill Runtime", "agent", "skill · runtime behavior", "SKILL.md"),
    ("agent-policy", "Agent Policy", "agent", "runtime · interface", "agents/"),
    ("model-contracts", "Model / Contracts", "domain", "schema · reference", "references/"),
    ("actions-openapi", "GPT Actions / OpenAPI", "api", "action · contract", "openapi"),
    ("editor-generator", "Editor / Diagram Generator", "service", "generator · script", "scripts/"),
    ("templates", "Templates", "data", "visual · templates", "templates/"),
    ("fixtures", "Fixtures / Examples", "data", "examples · regression", "fixtures/"),
    ("assets", "Assets / Samples", "data", "visual · samples", "assets/"),
    ("tests", "Tests / Validation", "service", "quality · regression", "tests/"),
    ("deployment", "Deployment Docs", "infra", "ops · deployment", "deploy"),
    ("package", "Package Metadata", "infra", "dependencies · scripts", "package.json"),
    ("docs", "Documentation", "domain", "docs · usage", "README"),
]


def should_skip(path: Path) -> bool:
    return any(part in EXCLUDED_DIRS for part in path.parts) or path.name in EXCLUDED_FILES


def iter_files(repo: Path) -> list[Path]:
    files: list[Path] = []
    for path in repo.rglob("*"):
        rel = path.relative_to(repo)
        if should_skip(rel):
            continue
        if path.is_file():
            files.append(rel)
    return sorted(files, key=lambda p: str(p).lower())


def classify(rel: Path) -> str:
    text = str(rel).replace("\\", "/")
    lower = text.lower()
    if text == "SKILL.md":
        return "skill-runtime"
    if lower.startswith("agents/"):
        return "agent-policy"
    if lower.startswith("references/"):
        if "openapi" in lower or lower.endswith(".yaml") and "action" in lower:
            return "actions-openapi"
        return "model-contracts"
    if "openapi" in lower or lower.endswith(("openapi.yaml", "openapi.yml")):
        return "actions-openapi"
    if lower.startswith("scripts/"):
        return "editor-generator"
    if lower.startswith("templates/"):
        return "templates"
    if lower.startswith("fixtures/") or lower.startswith("examples/"):
        return "fixtures"
    if lower.startswith("assets/"):
        return "assets"
    if lower.startswith("tests/") or lower.endswith((".spec.ts", ".test.ts", ".spec.js", ".test.js")):
        return "tests"
    if "deploy" in lower or "systemd" in lower or "nginx" in lower or "docker" in lower:
        return "deployment"
    if rel.name in {"package.json", "package-lock.json", "pyproject.toml", "requirements.txt"}:
        return "package"
    if rel.name.lower().startswith("readme") or lower.startswith("docs/"):
        return "docs"
    return "docs"


def role_meta(role: str) -> tuple[str, str, str]:
    for key, label, ntype, sub, _ in ROLE_RULES:
        if key == role:
            return label, ntype, sub
    return role.replace("-", " ").title(), "custom", "repository group"


def build_model(repo: Path, files: list[Path], project_name: str | None = None) -> dict[str, Any]:
    groups: dict[str, list[str]] = {}
    for rel in files:
        groups.setdefault(classify(rel), []).append(str(rel).replace("\\", "/"))

    ordered_roles = [rule[0] for rule in ROLE_RULES if rule[0] in groups]
    for role in sorted(groups):
        if role not in ordered_roles:
            ordered_roles.append(role)

    nodes = [
        {
            "id": "user-request",
            "x": 180,
            "y": 180,
            "type": "entry",
            "icon": "◎",
            "label": "User Request",
            "sub": "repo analysis",
            "detail": {
                "title": "User Request",
                "subtitle": "entry · uploaded repo or workspace",
                "tags": ["intake", "repo"],
                "flow": ["Receive repository path or archive", "Apply exclusion rules", "Build file inventory"],
                "apis": [],
                "schemas": [],
                "notes": "Starting point for repo visualization.",
                "constraints": ["Do not include local caches, node_modules, .git, or secrets"],
                "risks": ["Heuristic classification can miss domain-specific runtime boundaries"],
            },
        },
        {
            "id": "repo-inventory",
            "x": 460,
            "y": 180,
            "type": "workflow",
            "icon": "◇",
            "label": "Repo Inventory",
            "sub": f"{len(files)} files",
            "detail": {
                "title": "Repository Inventory",
                "subtitle": "workflow · file classification",
                "tags": ["inventory", "classification"],
                "flow": ["Walk repository tree", "Exclude generated/cache files", "Group files by architecture role"],
                "apis": [],
                "schemas": [],
                "notes": f"Scanned repository: {repo.name}",
                "constraints": ["Classification is deterministic and path-based"],
                "risks": ["Generated files can be mistaken for source when naming is unusual"],
            },
        },
    ]

    x_positions = [160, 390, 620, 850]
    y_start = 340
    y_gap = 150
    for idx, role in enumerate(ordered_roles):
        label, ntype, sub = role_meta(role)
        files_for_role = groups[role]
        x = x_positions[idx % len(x_positions)]
        y = y_start + (idx // len(x_positions)) * y_gap
        sample = files_for_role[:8]
        nodes.append({
            "id": role,
            "x": x,
            "y": y,
            "type": ntype,
            "icon": "▣" if ntype in {"service", "api"} else "◇",
            "label": label,
            "sub": f"{len(files_for_role)} files",
            "detail": {
                "title": label,
                "subtitle": sub,
                "tags": [role, ntype],
                "flow": [f"Owns {len(files_for_role)} classified file(s)"],
                "apis": [],
                "schemas": [],
                "notes": "Representative files:\\n" + "\\n".join(f"- {p}" for p in sample),
                "constraints": [],
                "risks": [],
            },
        })

    edges = [
        {
            "from": "user-request",
            "to": "repo-inventory",
            "style": "primary",
            "relation": "workflow",
            "label": "analyze",
            "protocol": "internal",
            "data": "repo path or ZIP",
        }
    ]
    for role in ordered_roles:
        edges.append({
            "from": "repo-inventory",
            "to": role,
            "style": "dependency",
            "relation": "dependency",
            "label": "classifies",
            "protocol": "file",
            "data": f"{len(groups[role])} files",
        })

    # Useful inferred relationships.
    for a, b, label in [
        ("skill-runtime", "agent-policy", "summarized by"),
        ("skill-runtime", "model-contracts", "uses"),
        ("skill-runtime", "editor-generator", "invokes"),
        ("editor-generator", "templates", "renders"),
        ("editor-generator", "fixtures", "tests with"),
        ("tests", "editor-generator", "validates"),
        ("actions-openapi", "deployment", "targets"),
    ]:
        if a in groups and b in groups:
            edges.append({
                "from": a,
                "to": b,
                "style": "secondary",
                "relation": "dependency",
                "label": label,
                "protocol": "internal",
            })

    return {
        "project": {
            "name": project_name or f"{repo.name} Repository Architecture",
            "domain": "repository",
            "repo": str(repo),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "description": "Architecture model inferred from repository file structure.",
        },
        "visualization": {
            "preferredStyle": 7,
            "diagramType": "architecture",
            "audience": "engineering-docs",
            "outputs": ["editable-html", "svg", "png", "markdown-snapshot"],
        },
        "nodes": nodes,
        "edges": edges,
        "changes": [],
        "repoInventory": {
            "fileCount": len(files),
            "excludedDirs": sorted(EXCLUDED_DIRS),
            "groups": groups,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Create Omni architecture.json from a repo tree.")
    parser.add_argument("--repo", required=True, help="Repository root")
    parser.add_argument("--output", required=True, help="architecture.json output")
    parser.add_argument("--project-name", default=None, help="Override project name")
    args = parser.parse_args()

    repo = Path(args.repo).resolve()
    if not repo.exists() or not repo.is_dir():
        raise SystemExit(f"Repository directory not found: {repo}")

    files = iter_files(repo)
    model = build_model(repo, files, args.project_name)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(model, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"✓ architecture.json written: {out}")
    print(f"✓ files classified: {len(files)}")


if __name__ == "__main__":
    main()
