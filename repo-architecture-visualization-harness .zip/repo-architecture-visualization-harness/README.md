# Repo Architecture Visualization Harness

A CustomGPT/Skill package for repository-aware architecture visualization.

It combines:

- Omni Architecture model-first workflow;
- editable architecture HTML workbench;
- Fireworks Tech Graph static SVG/PNG rendering;
- repository package classification;
- Story-Map-driven agentic delivery harness mapping;
- drift, evidence, handover, and coding-agent handoff support.

## Core files

```text
SKILL.md
agents/openai.yaml
references/
scripts/
examples/
tests/
```

## Typical usage

### 1. Create architecture.json from a repo

```bash
python scripts/repo_to_architecture_model.py --repo ./my-repo --output out/architecture.json
```

### 2. Convert architecture.json into Fireworks spec

```bash
python scripts/architecture_to_fireworks_spec.py   --input out/architecture.json   --output out/fireworks-diagram-spec.json   --style 7
```

### 3. Render SVG/PNG when Fireworks generator is available

```bash
python scripts/architecture_to_fireworks_spec.py   --input out/architecture.json   --output out/fireworks-diagram-spec.json   --generator ../fireworks-tech-graph-main/scripts/generate-from-template.py   --render-svg out/architecture.svg   --render-png out/architecture.png
```

## What goes into CustomGPT Knowledge

Upload:

```text
SKILL.md
agents/openai.yaml
references/*.md
scripts/repo_to_architecture_model.py
scripts/architecture_to_fireworks_spec.py
examples/fireworks-repo-from-omni-spec.json
examples/agentic_harness_full_framework_documentation.json
```

Do not upload large dependency caches such as `node_modules`.

## Safety

Do not include secrets, private tokens, `.env` files, local cache directories, or unrestricted internal probe URLs in generated outputs.
