# File Manifest

| Path | Bytes | SHA256 |
|---|---:|---|
| `CUSTOMGPT_UPLOAD_GUIDE.md` | 1195 | `20b628dcc9847163a13b7a15b5f72a2f8aee3a1e35a4302875220318f5c7e889` |
| `FILE_MANIFEST.md` | 2544 | `82418b565bae7021391f664a2f23019857eb710a9fbea1f80e1498507d5ef5af` |
| `LICENSE` | 1061 | `5bd54dd16514f04a138d83ddaf327e59a5d8bd2e505801e43b440210e8c613c4` |
| `README.md` | 1730 | `c0e286e30d9d7f97b5607e2f7f87c591d57eea3dd99cd3dfe16fe3b78b082e56` |
| `SKILL.md` | 9120 | `10ec1ecfe505fe20e81cb9d50689f7a95fc5b21ab88571d8a443e2daa73f1b7d` |
| `VALIDATION_REPORT.md` | 495 | `3f8580ad585fb2f97e40e8cb788a32407cd43a858c7d0265913057101b4546e9` |
| `agents/openai.yaml` | 2887 | `797f8014fcbbaa985358e0b543257e150a919405db5c9c306a5464d8fba2c676` |
| `examples/agentic-harness-architecture.json` | 9338 | `ed3d6d4cdb74d80f2037dedaa0815435cf3c44b69d578eeb766fac37d1a34189` |
| `examples/agentic-harness-fireworks-spec.json` | 6400 | `274fb5009686df1bcb7d49455241016edb0504998ae4e0538bf008fa24c52667` |
| `examples/agentic_harness_full_framework_documentation.json` | 8364 | `04dfcf32589df03275f8cef572fd1d20dc34db7d846eb789298a9e7d1257709e` |
| `examples/fireworks-repo-from-omni-spec.json` | 9902 | `3435e417bdbfb9e0ace940a7d655a6a37af1b0c7580daf46be30b26769a56861` |
| `examples/fireworks-repo-from-omni.svg` | 20638 | `e7ca88d3cdaa52d4aca342337270e9c4f2eaff795b769cb07cb430eb2248dd72` |
| `references/agentic-harness-framework.md` | 6833 | `1c464a97a0093ec637c76d903312bf4922c376359ccb01167f7ccc18d77dbc52` |
| `references/architecture-model-extension.md` | 1629 | `3605547060c07adde22babade26935ca1ac285d3cd44116a72a26591f7b6c728` |
| `references/fireworks-style-adapter.md` | 2354 | `b9997764e2d632ac86183422ad6a6d5117e75cb480b34700c4fa841047bd06df` |
| `references/repo-visualization-workflow.md` | 1700 | `5a5610123830b14a6d47d776bdcff3715d3bc9d8ff588e34fb07e87faea300b9` |
| `scripts/architecture_to_fireworks_spec.py` | 24085 | `f714fd500aef52c4e0806bf6443974bcfe7c0bb232c87650cd231e488b2e9390` |
| `scripts/repo_to_architecture_model.py` | 10207 | `b0c1d2a6c50434b2fead69351d5954bae33a90f001eb2b03a2f6ff1a7bba9330` |
| `tests/smoke_test.py` | 1362 | `8f7a90132eb49ca35848d38926f7c0b19b5baebc1e414b8a33cb1a781d268831` |
