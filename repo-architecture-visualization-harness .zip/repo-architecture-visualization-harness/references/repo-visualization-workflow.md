# Repository Visualization Workflow

## Purpose

Convert repository files, ZIPs, or extracted workspaces into an editable architecture model and optional Fireworks static visuals.

## Workflow

1. **Inventory**
   - Walk the repo tree.
   - Exclude `.git`, `node_modules`, `__pycache__`, build outputs, test-results, temporary artifacts, and local OS files.
   - Record file count and role grouping.

2. **Classify**
   Group files into:
   - Skill Runtime
   - Agent Policy
   - Model / Contracts
   - GPT Actions / OpenAPI
   - Editor / Diagram Generator
   - Templates
   - Fixtures / Examples
   - Assets / Samples
   - Tests / Validation
   - Deployment Docs
   - Package Metadata
   - Documentation

3. **Normalize**
   Emit a valid Omni `architecture.json` with:
   - `project`
   - `visualization`
   - `nodes`
   - `edges`
   - `changes`
   - `repoInventory`

4. **Visualize**
   - Use Omni HTML editor for exploration and editing.
   - Use Fireworks adapter for static SVG/PNG publication.

5. **Evaluate**
   Check:
   - missing source-of-truth files;
   - generated artifacts mistaken for sources;
   - hidden runtime dependencies;
   - absent tests;
   - OpenAPI/Action mismatch;
   - unsafe secret handling;
   - drift between Story Map, architecture model, and implementation files.

6. **Handoff**
   Produce one or more:
   - architecture model JSON;
   - static diagram spec;
   - SVG/PNG graphic;
   - package split recommendation;
   - dev brief;
   - Story Map drift report.

## Output discipline

Always distinguish:
- facts found in files;
- assumptions inferred from names or structure;
- recommendations for packaging or refactoring;
- unknowns requiring human verification.
