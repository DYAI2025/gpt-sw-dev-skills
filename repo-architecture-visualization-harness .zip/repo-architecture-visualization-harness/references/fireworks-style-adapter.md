# Fireworks Style Adapter

## Goal

Add a static, high-quality SVG/PNG render path to the Omni architecture workflow without replacing the editable architecture editor.

## Source and target

- Source of truth: `architecture.json` in the Omni Architecture model.
- Static render target: Fireworks Tech Graph diagram spec consumed by `scripts/generate-from-template.py`.

## Optional model field

```json
{
  "visualization": {
    "preferredStyle": 7,
    "diagramType": "architecture",
    "audience": "engineering-docs",
    "outputs": ["editable-html", "svg", "png", "markdown-snapshot"]
  }
}
```

## Adapter rules

1. Keep `architecture.json` authoritative.
2. Never edit architecture semantics only to make a prettier diagram.
3. Use Fireworks spec as generated output, not as the canonical model.
4. Record skipped nodes/edges and mapping limitations under `_adapter.warnings`.
5. Preserve stable IDs from Omni nodes.
6. Map Omni node types to Fireworks shapes:
   - `entry`, `ui`, `external` → flat rectangle
   - `agent`, `api`, `infra` → double rectangle
   - `data` → cylinder
   - `security` → hexagon
   - unknown/custom → rectangle
7. Map Omni edge relations to Fireworks flow types:
   - `workflow`, `user-flow`, `api-call` → `control`
   - `event-flow` → `async`
   - `data-flow` → `data`
   - `dependency`, `deployment`, `ownership` → `neutral`
   - `risk-control` → `feedback`

## Output contract

The adapter emits:

```json
{
  "template_type": "architecture",
  "style": 7,
  "width": 1120,
  "height": 760,
  "title": "Project Architecture",
  "subtitle": "Generated from Omni architecture.json",
  "containers": [],
  "nodes": [],
  "arrows": [],
  "legend": [],
  "_adapter": {
    "name": "architecture_to_fireworks_spec",
    "source": "omni-architecture-brief-engine",
    "target": "fireworks-tech-graph generate-from-template.py",
    "warnings": []
  }
}
```

## When to render SVG/PNG

Render static graphics when the user asks for:
- README or documentation diagrams;
- presentation-ready repo maps;
- architecture snapshots for stakeholders;
- package explainers;
- onboarding visuals;
- comparison of repo capabilities.

Use the editable Omni HTML editor when the user asks to change architecture, capture deltas, export dev briefs, validate expected architecture, or conduct live API health checks.
