# Architecture Model Extension

This skill uses the Omni Architecture model as its canonical schema and adds repository- and visualization-specific fields.

## Required root fields

```json
{
  "project": {},
  "nodes": [],
  "edges": [],
  "changes": []
}
```

## Recommended repo fields

```json
{
  "repoInventory": {
    "fileCount": 0,
    "excludedDirs": [],
    "groups": {}
  }
}
```

## Recommended visualization fields

```json
{
  "visualization": {
    "preferredStyle": 7,
    "diagramType": "architecture",
    "audience": "engineering-docs",
    "outputs": ["editable-html", "svg", "png", "markdown-snapshot"]
  }
}
```

## Recommended agentic harness fields

```json
{
  "storyMap": {
    "ssotPath": "/story-map/product.md",
    "slicesPath": "/story-map/slices/",
    "status": "unknown | current | stale | missing"
  },
  "deliveryHarness": {
    "pipelinePath": "/harness/pipeline.yaml",
    "handoversPath": "/harness/handovers.yaml",
    "evidenceSchemaPath": "/harness/evidence.schema.yaml",
    "driftReportsPath": "/harness/drift-reports/",
    "decisionsPath": "/harness/decisions/"
  }
}
```

## Node and edge interpretation

- Repo folders become grouped components only when they represent an architecture-relevant responsibility.
- Generated files are outputs unless no source file is available.
- Test fixtures are evidence for behavior, not production runtime components.
- Story Map files are context authority and should be modeled as governance/data nodes.
- Pipeline and handover files are workflow-control nodes.
- Evidence files are validation outputs and should be tied to gates or stages.
