# Agentic Harness Reference

## Purpose

This reference adapts the uploaded **Story-Map Driven Agentic Delivery Harness** documentation into the skill's repository-visualization and delivery-governance workflow.

Project purpose:

> A markdown-first, test-driven framework for enterprise adoption of agentic product delivery, using Story Mapping as Context Single Source of Truth and testable handovers as stage gates.

## Core thesis

The product is not a generic multi-agent runner. It is a test-driven context-governance harness for enterprise agentic delivery.

## Core loop

1. Story Map SSOT defines product intent, slices, acceptance criteria and architecture impact.
2. Context Compiler emits role/slice-specific context packs.
3. CanDef executes agents against isolated worktrees/sessions.
4. RuFlo workflow state machine tracks stages and enforces pause/resume handovers.
5. Autonomous tests verify code, product behavior, context fidelity and handover readiness.
6. GodMode-style independent review quorum validates outputs.
7. Human-in-the-loop is triggered only after machine/evidence readiness.
8. Story Map Reconciliation updates SSOT or stops the line on drift.

## Repository roles

| Repository | Role | Use in target skill |
|---|---|---|
| SOAR / SAW | Governance and method layer | Owns stage semantics, gate policies, role responsibilities and escalation rules. |
| Initiative | Product/Story Map/Evidence application layer | Becomes Story Map Cockpit, Slice Planner, Evidence Center and Human Review UI. |
| CanDef / Kandev | Execution control plane | Executes slices and provides operational status/evidence for agent work. |
| GodModeSkill | Multi-LLM review quorum and safety pattern | Implemented as Review Quorum Gate pattern, not a separate user-facing platform. |
| RuFlo / Claude-Flow | Workflow/MCP/plugin/memory substrate | Compiles pipeline.yaml/stage handovers into executable workflow_* calls; supplies background checks, memory recall and autonomous product test tools. |

## Canonical objects

| Object | Meaning |
|---|---|
| Company | Customer tenant and boundaries. |
| Product | Product or platform being adapted for agentic delivery. |
| StoryMap | Markdown SSOT with product goals, activities, tasks, slices, AC, architecture impact and test contracts. |
| Slice | Small, independently executable product increment tied to story map and tests. |
| Pipeline | Ordered or graph-based stages for a slice lifecycle. |
| Stage | A workflow state with entry criteria, execution role, exit tests, evidence and handover target. |
| Handover | Testable transition between stages, blocked unless required checks/evidence pass. |
| ContextPack | Versioned context projection for one agent/team/role. |
| AgentTeam | Group of agents under a human operator, scoped by permissions and slice. |
| Session | Concrete execution instance in CanDef/RuFlo with logs, status and artifacts. |
| Evidence | Tests, diffs, browser traces, reviews, screenshots, logs and verdicts. |
| DriftReport | Context, requirement, architecture, test or scope drift against Story Map SSOT. |
| Decision | Human or gate decision with rationale, inputs and traceability. |

## Minimal file contract

| Path | Role |
|---|---|
| `/story-map/product.md` | Product goal, personas, success metrics, constraints. |
| `/story-map/slices/slice-001.md` | Slice scope, non-goals, AC, architecture impact, tests and handover gates. |
| `/harness/pipeline.yaml` | Stage graph and allowed transitions. |
| `/harness/handovers.yaml` | Handover tests, evidence requirements and HITL trigger rules. |
| `/harness/evidence.schema.yaml` | Evidence object schema and verdict requirements. |
| `/harness/context-packs/` | Compiled role/slice-specific context packs. |
| `/harness/drift-reports/` | Generated drift reports against SSOT. |
| `/harness/decisions/` | Human and architecture decisions. |

## Pipeline stage template

```json
{
  "stage_id": "implementation_to_qa",
  "entry_criteria": [
    "slice.approved == true",
    "context_pack.current == true",
    "architecture_gate.status != red"
  ],
  "agent_roles_allowed": [
    "backend-agent",
    "frontend-agent",
    "qa-agent",
    "architect-reviewer"
  ],
  "required_tests": [
    "unit",
    "integration",
    "contract",
    "autonomous_product_test",
    "context_drift_check"
  ],
  "required_evidence": [
    "changed_files",
    "test_report",
    "browser_trace",
    "risk_note",
    "review_findings"
  ],
  "handover_rule": "all required tests pass AND independent review quorum pass AND no red drift",
  "hitl_trigger": "after machine readiness, before merge or next major stage"
}
```

## RuFlo mapping

| Need | Support | Gap |
|---|---|---|
| Pipeline State Machine | workflow_create, workflow_run, workflow_status, workflow_pause, workflow_resume, workflow_cancel | Need typed Stage/Handover/Evidence adapter. |
| Manual/HITL Gate | workflow_pause/resume | Need approval identity, evidence lock and policy reason. |
| Autonomous Product Test | ruflo-browser + ruflo-testgen + browser_* tools | Need Story Map AC → test compiler. |
| Context Drift Loop | memory/search, hooks, workers, docs drift, guidance | Need SSOT authority and drift taxonomy. |
| Safety Gate | aidefence/security plugins | Need customer policy packs and fail-closed handover integration. |
| Regression Evidence | verification witness manifests | Need generalized evidence ledger beyond marker substrings. |

## Product stack recommendation

```json
{
  "frontend": "Initiative extended into Story Map Cockpit, Slice Planner, Gate Board and Evidence Center.",
  "execution": "CanDef for agent sessions, worktrees, PRs, terminal and operational review.",
  "workflow_runtime": "RuFlo workflow_* as stage/handover runtime adapter.",
  "governance": "SOAR/SAW policies and role gates.",
  "review": "GodModeSkill quorum patterns embedded as stage gates.",
  "memory": "RuFlo AgentDB/RVF only as recall/learning layer; Story Map remains authoritative."
}
```

## Skill interpretation

The skill treats Story Map as the authoritative context source, not as optional documentation. Repository visualizations should therefore expose:
- where story-map files live;
- which slices, gates, and evidence files are present;
- whether implementation artifacts are traceable back to accepted criteria;
- whether generated diagrams, dev briefs, and snapshots reflect the current Story Map SSOT;
- which stage or handover is blocked by missing evidence or red drift.

## Governance defaults

- Never silently update Story Map, pipeline, handover, or evidence contracts.
- Any architecture or repo visualization that detects drift must record it as a finding.
- Human review is recommended before accepting changes to stage semantics, approval identity, security gates, or production deployment behavior.
